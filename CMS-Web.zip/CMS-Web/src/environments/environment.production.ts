const wkEnvConfig = window['wkEnvConfig'];

export const environment = {
  environmentName: wkEnvConfig.environmentName,
  portalUrl: wkEnvConfig.portalUrl,
  appUrl: wkEnvConfig.portalUrl + 'cnrcms/',
  apiUrl: wkEnvConfig.portalUrl + 'webservices/api/cnrcms/',
  commonApiUrl: wkEnvConfig.portalUrl + 'webservices/api/nilscommon/',
  logLevel: '5',
  serverLogLevel: '5',
  serverLoggingUrl: wkEnvConfig.portalUrl + 'webservices/api/insource/logs',
  authUrl: wkEnvConfig.portalUrl + 'Webservices/API/ICSAuth/',
  customerCareEmail: '',
  feedbackEmail: '',
  phoneNumber: '',
  productUrl: 'cnrcms',
  gtagMeasurementId: wkEnvConfig.gtagMeasurementId,
  pendoId: wkEnvConfig.pendoId,
  compareToolsPageSize: wkEnvConfig.compareToolsPageSize
};
