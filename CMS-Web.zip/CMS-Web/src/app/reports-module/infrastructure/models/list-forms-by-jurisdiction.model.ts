
export interface ListFormsByJursidiction {
    totalCount?: number;
    paginationData?: [
        {
            stateCode?: string,
            actionDescription?: string,
            lobAbbreviation?: string,
            whereConditionDescription?: string,
            rtfName?: string
        }
    ];
}
