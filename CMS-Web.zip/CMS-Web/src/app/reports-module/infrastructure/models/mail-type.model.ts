export interface MailType {
    stateCode?: string;
    actionCode?: string;
    lobAbbr?: string;
    whereConditionDescription?: string;
    mailType?: string;
    isChecked?: boolean;
}
