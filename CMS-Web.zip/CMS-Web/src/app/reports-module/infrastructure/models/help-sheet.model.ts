export interface HelpSheet {
    formId?: number;
    stateCode?: string;
    helpFile?: string;
}
