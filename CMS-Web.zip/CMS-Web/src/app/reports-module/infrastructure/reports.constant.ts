import { environment } from '@env';

export class ReportsConstant {

    static webApis = {
        getDaysNoticeReportData: environment.apiUrl + 'DaysNotice/Report',
        getJurisdictions: environment.apiUrl + 'State',
        getFormsByJurisdicions: environment.apiUrl + 'Form/All',
        downloadFile: environment.commonApiUrl + 'Download?file={fileName}',
        permittedReasons: environment.apiUrl + 'MaintainReasons/WithoutFormRule',
        withoutFormRule: environment.apiUrl + 'DaysNotice/WithoutFormRule',
        withoutFormRuleCount: environment.apiUrl + 'DaysNotice/WithoutFormRuleCount',
        daysNoticReportCount: environment.apiUrl + 'DaysNotice/ReportCount',
        getMailTypes: environment.apiUrl + 'MailType/WithoutFormRules',
        searchWizardCriteriaByField: environment.apiUrl + 'FieldCriteria',
        seaerchWizardCriteriaByForm: environment.apiUrl + 'FormCriteria',
        getLobs: environment.apiUrl + 'LOB?adminMenuItem={adminMenuItem}',
        getActions: environment.apiUrl + 'Action',
        getCircumstances: environment.apiUrl + 'Circumstance',
        getFormsBySearchCriteria: environment.apiUrl + 'RTFActionField/FormsBySearchCriteria?PageNo={PageNo}&PageSize={PageSize}',
        getFormsBySearchCriteriaCount: environment.apiUrl + 'RTFActionField/FormsBySearchCriteriaCount',
        getFieldRuleAssignment: environment.apiUrl + 'FieldRule/BadFieldRules',
        getMissingHelpSheets: environment.apiUrl + 'Form/MissingHelpsheets',
        getMissingHelpsheetsCount: environment.apiUrl + 'Form/MissingHelpsheetsCount',
        getFieldDependancyCopyRule: environment.apiUrl + 'Form/{formId}/PriorVersionForms',
        getFieldDependencyRule: environment.apiUrl + 'FieldRule/{formId}/FormRules?rtfName={RtfName}',
        updateFieldDependencyRule: environment.apiUrl + 'FieldRule/{formId}/UpdatedFormFieldRules',
        copyPriorRuleData: environment.apiUrl + 'FieldRule/CopyFormFieldRules',
        getRulesMarkedRegulatory: environment.apiUrl + 'RTFActionField/RulesMarkedRegRequired',
        getInactiveAwebForms: environment.apiUrl + 'MatrixData/InactiveAwebForms',
        getNonReferencedFormsInMatrix: environment.apiUrl + 'Form/NonReferencedFormsInMatrix',
        getRulesSummary: environment.apiUrl + 'AccountFormState/Rules',
        getMissingFormFields: environment.apiUrl + 'RTFActionField/FormMissingFields'
    };

    static multiSelectOptions = {
        allJurisdictions: 'All Jurisdictions',
        allLobs: 'All Line(s) of Business',
        allActions: 'All Actions',
        allCircumstance: 'All Circumstances',
    };

    static responseType = {
        blobType: 'blob'
    };

    static formsByJ = {
        allJurisdictions: 'All Jurisdictions',
        display: 'display'
    };

    static cnr = {
        cnr4: 'CNR4\\webfill\\filtered\\',
        cnrpdf: 'CNR4\\',
        cnrPdfFilePath: 'authenticity_staging\\Dev\\cnrv4\\',
        authStagingPath: 'authenticity_staging\\CNRWIP\\'
    };

    static fileExtn = {
        pdf: '.pdf'
    };

    static paginationOptions = {
        currentPage: 1,
        pageSize: 200,
        totalItems: 2000
    };

    static daysNoticeReportColNames = ['Jurisdiction', 'Action', 'Line of Business', 'Circumstance', 'Minimum Days', 'Maximum Days'];

    static daysNoticeReportGridDataKeys = ['stateCode', 'actionCode', 'lob', 'whereConditionDesc', 'daysNotice', 'dayNoticeMax'];

    static permittedReasonsColNames = ['Jurisdiction', 'Action', 'LOB', 'Circumstance', 'Reason'];

    static permittedReasonsGridDataKeys = ['stateCode', 'actionCode', 'lob', 'whereConditionDesc', 'reasonText'];

    static daysNoticeRulesColNames = ['Jurisdiction', 'Action', 'LOB', 'Circumstance'];

    static daysNoticeRulestGridDataKeys = ['stateCode', 'actionCode', 'lob', 'circumstance'];

    static stateCode = 'stateCode';

    static wizardCriteriaByFieldName = ['Action', 'Line of Business', 'Circumstance'];

    static wizardCriteriaByFieldKeys = ['actionDescription', 'lobDescription', 'whereConditionDescription'];

    static wizardCriteriaByFormName = ['Jurisdiction', 'Form', 'Action', 'Line of Business', 'Circumstance'];

    static wizardCriteriaByFormKeys = ['stateCode', 'rtfName', 'actionDescription', 'lobDescription', 'whereConditionDescription'];

    static badFieldRuleAssignmentNames = ['Jurisdiction', 'Form', 'Field Rule', 'Field'];

    static badFieldRuleAssignmentKeys = ['stateCode', 'rtfName', 'fieldRuleDescription', 'fieldName'];

    static editFormComponentsColNames = ['Component', 'Page Order', 'Standalone?',
     'RTF Section Starts', 'RTF Section Ends', 'PDF Section Starts',
     'PDF Section Ends', 'Copies', 'Page Type', 'Actions'];

    static editFormComponentsGridDataKeys = ['componentType', 'pageOrder', 'standaloneEnabled',
     'rtfSectionStart', 'rtfSectionEnd', 'pdFpageStart',
     'pdFpageEnd', 'copies', 'pageType', 'actions'];

    static rulesMarkedColNameWithSortingDetails = [{name: 'Jurisdiction', isSortingRequired: true, sortingKey: 'stateCode'},
     {name: 'RTF Name', isSortingRequired: true, sortingKey: 'form'}, {name: 'Action' , isSortingRequired: true, sortingKey: 'actionCode'},
    {name: 'LOB', isSortingRequired: true, sortingKey: 'lob'}, {name: 'Circumstance', isSortingRequired: true, sortingKey: 'circumstance'},
    {name: 'Field', isSortingRequired: true, sortingKey: 'field'}];

    static rulesMarkedGridDataColNames = ['Jurisdiction', 'RTF Name', 'Action', 'LOB', 'Circumstance', 'Field'];

    static rulesMarkedGridDataKeys = ['stateCode', 'form', 'actionCode', 'lob', 'circumstance', 'field'];

    static dateFormats = {
        mmdyyyy: 'MM/DD/yyyy',
        mmddyyyy: 'MMDDyyyy'
    };

    static exportExcel = {
        exportMailTypeName: 'ListFormsbyJurisdictionActionLOBCircumstance',
        pageMailTypeTitle: 'List Forms by Jurisdiction, Action, LOB, Circumstance',
        fileNameMailType: 'List Forms by Jurisdiction, Action, LOB, Circumstance',
        formByJurisidctionHeader: [
            'Jurisdiction',
            'Action',
            'Line of Business',
            'Circumstance',
            'RTF Name'
        ],
        formByJurisidctionKeys: [
            'stateCode',
            'actionDescription',
            'lobAbbreviation',
            'whereConditionDescription',
            'rtfName'
        ],
        exportFormsMissingHelpsheetName: 'CheckforFormsmissingHelpsheetsOnLiveSystem',
        pageFormsMissingHelpsheetTitle: 'Check for Forms missing Helpsheets on Live System',
        fileNameFormsMissingHelpsheet: 'Check for Forms missing Helpsheets on Live System',
        exportFormsNotReferencedMatrixName: 'Forms referenced by CNR Matrices, not Active in CNR for Live AWeb Account',
        summaryMatricesName: 'Forms in CNR not referenced in CNR Summary Matrices',
        adverseMatricesName: 'Forms in CNR not referenced in Adverse Decision Matrices',
        nonReferencedFormsInMatrix: 'Forms in CNR not referenced in CNR Summary and Adverse Decision Matrices',
        exportName: {
            badFieldRuleAssignment: 'CheckForBadFieldRuleAssignments',
            checkDaysNoticeRules: 'Days Notice rules with no corresponding Form rules ',
            daysNoticeReport: 'daysNotice_Report',
            permittedReasonWithoutFormRules: 'Permitted Reason entries without corresponding Form Rules',
            wizardCriteriaByField: 'FindWizardCriteriaByField',
            wizardCriteriaByForm: 'FindWizardCriteriaByForm'
        },
        pageTitle: {
            badFieldRuleAssignment: 'Check for Bad Field Rule Assignments',
            daysNoticeReport: `Days' Notice Report`,
            permittedReasonWithoutFormRules: 'Permitted Reason entries without corresponding Form Rules',
            wizardCriteriaByField: 'Find Wizard Criteria By Field',
            wizardCriteriaByForm: 'Find Wizard Criteria By Form'
        },
        fileName: {
            permittedReasonWithoutFormRules: 'Permitted Reasons without corresponding Form Rules',
        }
    };

    static listFormsByJurisdiction = {
        orderAsc: 'Asc'
    };

    static commonGridSortby = {
        stateCode: 'stateCode',
        action: 'action'
    };

    static scrollSpan = 'span-';

    static cssStyles = {
        relative: 'relative',
        fluxibleHeight: '-42px'
    };

    static maxTwoHundred = 200;

    static NotReferencedFormsAwebHeaders =  ['Matrix', 'Jurisdiction', 'Policy Type', 'Uniform Base Form Number', 'No. Of Occurrences'];

    static NotReferencedFormsAwebKeys = ['product', 'stateCode', 'policyType', 'uniformNo', 'totalOccurrences'];

    static NonReferencedFormsInMatrixHeaders = ['Matrix', 'Jurisdiction', 'Uniform Base Form Number'];

    static NonReferencedFormsInMatrixKeys = ['productName', 'stateCode', 'baseForm'];

    static rulesSummarySortArray = [
        {label : 'Jurisdiction', key: 'stateName', isSorttingApplied: false},
        {label : 'Action', key: 'actionCode', isSorttingApplied: false},
        {label : 'LOB', key: 'lobAbbr', isSorttingApplied: false},
        {label : 'Circumstance', key: 'whereConditionDesc', isSorttingApplied: false}
    ];

    static allSelections = {
        allJurisdictions: 'All Jurisdictions',
        allLobs: 'All Line(s) of Business',
        allActions: 'All Actions',
        allCircumstance: 'All Circumstances',
        allFields: 'All Form Fields'
    };

    static displayOptions = [{name: 'Days Notice'}, {name: 'Mail Type'},
    {name: 'Permitted Reasons'}, {name: 'Forms'}, {name: 'Forms Pages'} ];

    static fieldOptions = [{name: 'Form Header Fields', displayGroup: [10, 20, 30, 100]}, {name: 'Main Form Fields', displayGroup: [200]} ,
    {name: 'Premium Adjustment Fields', displayGroup: [210]},
    {name: 'Additional Interest Fields', displayGroup: [1000, 1010, 1020, 1030, 1040, 1040, 1060, 1070, 1080]}];
    static formsMissingFieldsHeaders = ['Jurisdiction', 'RTF Name', 'Missing Fields'];

    static formsMissingFieldsKeys = ['stateCode', 'rtfName', 'fieldName'];

    static formsMissingFieldsSortingDetails = [{name: 'Jurisdiction', isSortingRequired: true, sortingKey: 'stateCode'},
    {name: 'RTF Name', isSortingRequired: false, sortingKey: 'rtfName'}, {name: 'Missing Fields', isSortingRequired: false, sortingKey: 'fieldName'}];

    static formsMissingFieldsColumnWidth = ['25%', '35%', '45%'];

    static multiSelectPlaceHolder = {
        jurisdiction: 'Select Jurisdiction(s)',
        action: 'Select Action(s)',
        lob: 'Select Line(s) of Business',
        circumstance: 'Select Circumstance(s)',
        display: 'Select Display(s)',
        fields: 'Select Field(s) Displayed'
    };

    static pageSizes = [500, 1000, 1500];
    static numberWithComma = /\B(?=(\d{3})+(?!\d))/g;

    static formsByJurisdictionsHeaders = ['Jurisdictions', 'Uniform Base Form Number', 'Forms'];

    static formsByJurisdictionsKeys = ['stateName', 'uniformNo', 'rtfname'];

    static formsByJurisdictionsExportName = 'FormsByJurisdictions';

    static multiState = 'Multi-State';
    static ruleSummaryErrors = {
        name: 'TimeoutError'
    };
    static ruleSummaryTimeInterval = 120000;
    static filterStateCode = 'stateCode';
}

