import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReportsRoutingModule } from './reports-routing.module';
import { ReportsService } from './services/reports.service';
import { NgSelectModule } from '@ng-select/ng-select';
import { environment } from '@env';
import { NilsSharedModule } from '@wk/nils-shared';
import { ListFormsByJurisdictionActionComponent } from './components/list-forms-by-jurisdiction-action/list-forms-by-jurisdiction-action.component';
import { ListFormsByJurisdictionComponent } from './components/list-forms-by-jurisdiction/list-forms-by-jurisdiction.component';
import { PermittedReasonWithoutFormRulesComponent } from './components/permitted-reason-without-form-rules/permitted-reason-without-form-rules.component';
import { CommonGridComponent } from './components/common-grid/common-grid.component';
import { UtilityModule } from 'app/utility-module/utility-module.module';
import { DaysNoticeReportComponent } from './components/days-notice-report/days-notice-report.component';
import { CheckDaysNoticeRulesComponent } from './components/check-days-notice-rules/check-days-notice-rules.component';
import { CheckMailTypeComponent } from './components/check-mail-type/check-mail-type.component';
import { ReportsUtilityService } from './services/report-utility.service';
import { WizardCriteriaByFieldComponent } from './components/wizard-criteria-by-field/wizard-criteria-by-field-component';
import { WizardCriteriaByFormComponent } from './components/wizard-criteria-by-form/wizard-criteria-by-form-component';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { ReportsMenuComponent} from './components/reports-menu/reports-menu.component';
import { BadFieldRuleAssignmentsComponent } from './components/bad-field-rule-assignments/bad-field-rule-assignments.component';
import { FormsMissingHelpsheetComponent } from './components/forms-missing-helpsheet/forms-missing-helpsheet.component';
import { ConfigurationsHttpService } from 'app/configurations-module/services/configurations-http.service';
import { RulesMarkedRegulatoryComponent } from './components/rules-marked-regulatory/rules-marked-regulatory.component';
import { FormsReferencedByCnrMatrixComponent } from './components/forms-referenced-by-cnr-matrix/forms-referenced-by-cnr-matrix.component';
import { NonReferencedFormsInMatrixComponent } from './components/non-referenced-forms-in-matrix/non-referenced-forms-in-matrix.component';
import { RulesSummaryReportComponent } from './components/rules-summary-report/rules-summary-report.component';
import { FormsMissingFieldsComponent } from './components/forms-missing-fields/forms-missing-fields.component';

@NgModule({
  declarations: [
    ListFormsByJurisdictionActionComponent,
    ListFormsByJurisdictionComponent,
    PermittedReasonWithoutFormRulesComponent,
    DaysNoticeReportComponent,
    CommonGridComponent,
    CheckDaysNoticeRulesComponent,
    CheckMailTypeComponent,
    WizardCriteriaByFieldComponent,
    WizardCriteriaByFormComponent,
    ReportsMenuComponent,
    BadFieldRuleAssignmentsComponent,
    FormsMissingHelpsheetComponent,
    RulesMarkedRegulatoryComponent,
    FormsReferencedByCnrMatrixComponent,
    NonReferencedFormsInMatrixComponent,
    RulesSummaryReportComponent,
    FormsMissingFieldsComponent
  ],
  imports: [
    CommonModule,
    ReportsRoutingModule,
    NilsSharedModule.loadConfig({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      commonApiUrl: '',
      userGroupURL: '',
      feedbackEmail: environment.feedbackEmail,
      customerCareEmail: environment.customerCareEmail,
      productUrl: environment.productUrl
    }),
    NgSelectModule,
    UtilityModule
  ],
  providers: [ReportsService,
    ReportsUtilityService,
    ConfigurationsMaintainService,
    ConfigurationsHttpService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ReportsModule { }
