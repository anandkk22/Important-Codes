import { Injectable } from '@angular/core';

@Injectable()
export class FormsMissingFieldsUtilityService {

  constructor() { }

  searchGridData(searchTerm, response) {
    let filteredData = null;
    if (searchTerm && response) {
      const convertedSearchTerm =  searchTerm.trim().toLowerCase();
      if (searchTerm.length > 0 && response.length > 0) {
        filteredData = response.filter(x =>
          (x.stateCode?.toLowerCase().includes(convertedSearchTerm) ||
            x.rtfName?.toLowerCase().includes(convertedSearchTerm) ||
            x.fieldName?.toLowerCase().includes(convertedSearchTerm)
          ));
      }

      else {
        filteredData = response;
      }
    }
    return filteredData;
  }

}
