import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';

@Injectable()
export class FormsMissingFieldsHttpService {

  constructor(private http: HttpClient) { }

  getMissingFieldsData() {
    return this.http.get(`${ReportsConstant.webApis.getMissingFormFields}`);
  }
}
