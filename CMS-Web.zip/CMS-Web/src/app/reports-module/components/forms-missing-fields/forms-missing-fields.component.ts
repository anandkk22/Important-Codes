import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SpinnerService } from '@wk/nils-core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { FormsMissingFieldsHttpService } from './forms-missing-fields-http.service';
import { FormsMissingFieldsUtilityService } from './forms-missing-fields-utility.service';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
@Component({
  selector: 'app-forms-missing-fields',
  templateUrl: './forms-missing-fields.component.html',
  styleUrls: ['./forms-missing-fields.component.scss'],
  providers: [FormsMissingFieldsHttpService, FormsMissingFieldsUtilityService]
})
export class FormsMissingFieldsComponent implements OnInit {

  isDataAvailable = false;
  gridData = null;
  removeAllSelectedRows = false;
  searchText = null;
  missingFieldsData = null;
  gridDetails = {
    columnNames: [],
    gridDataKeys: ReportsConstant.formsMissingFieldsKeys,
    isCheckBoxRequired: true,
    isExportToExcelRequired: true,
    isPaginationRequired: false,
    isGotoLinkRequired: false,
    totalNoOfError: 0,
    gotoLinkStates: [],
    checkboxKey: ReportsConstant.stateCode,
    goToLinksKey: null,
    isCheckMailType: false,
    isColSortingRequired: true,
    columnNamesWithSortInfo: ReportsConstant.formsMissingFieldsSortingDetails,
    colWidth: ReportsConstant.formsMissingFieldsColumnWidth,
    exportExcelData: {
      exportName: this.translate.instant('REPORTS.FORMS_MISSING_FIELDS.HEADING'),
      pageTitle: this.translate.instant('REPORTS.FORMS_MISSING_FIELDS.HEADING'),
      fileName: this.translate.instant('REPORTS.FORMS_MISSING_FIELDS.HEADING'),
      data: {
        result: [],
        headers: ReportsConstant.formsMissingFieldsHeaders,
        keys: ReportsConstant.formsMissingFieldsKeys
      },
    }
  };
  constructor(private spinnerService: SpinnerService,
    private missingFieldsHttpService: FormsMissingFieldsHttpService,
    private missingFieldsUtilityService: FormsMissingFieldsUtilityService,
    private reportsUtilityService: ReportsUtilityService,
    private translate: TranslateService) { }

    ngOnInit(): void {
      this.getFormData();
    }

    getFormData() {
      this.missingFieldsHttpService.getMissingFieldsData().subscribe((res: any) => {
        if (res) {
          this.gridData = this.reportsUtilityService.sortAscendingByKey(ReportsConstant.filterStateCode, res);
          this.missingFieldsData = res;
          this.isDataAvailable = true;
        }
      });
    }

    search() {
      this.removeAllSelectedRows = true;
      if (this.searchText && this.searchText.length > 0) {
        this.searchText.trim();
        this.gridData = this.missingFieldsUtilityService.searchGridData(this.searchText, this.missingFieldsData);
      }
      else {
        this.clearSearchedText();
      }
    }

    clearSearchedText() {
      this.removeAllSelectedRows = true;
      this.gridData = this.missingFieldsData;
      this.searchText = null;
    }

}
