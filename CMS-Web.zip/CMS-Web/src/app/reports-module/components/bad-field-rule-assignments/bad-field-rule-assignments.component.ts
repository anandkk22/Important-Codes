import { Component, OnDestroy, OnInit } from '@angular/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { TranslateService } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { BadFieldRuleAssignmentUtilityService } from './bad-field-rule-assignments-utility.service';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';

@Component({
  selector: 'app-bad-field-rule-assignments',
  templateUrl: './bad-field-rule-assignments.component.html',
  styleUrls: ['./bad-field-rule-assignments.component.scss'],
  providers: [BadFieldRuleAssignmentUtilityService]
})
export class BadFieldRuleAssignmentsComponent implements OnInit, OnDestroy {

  activeSubscription: Subscription;
  badFieldRuleAssignmentData = null;
  isBadFieldRuleGridData: boolean;
  isGridDataAvailable = false;
  searchKeyword: string;
  gotoLinksData = [];
  sortKey = ReportsConstant.badFieldRuleAssignmentKeys[0];
  gridData = null;
  removeAllSelctedRow = false;
  gridDetails = {
    columnNames: ReportsConstant.badFieldRuleAssignmentNames,
    gridDataKeys: ReportsConstant.badFieldRuleAssignmentKeys,
    isCheckBoxRequired: true,
    isExportToExcelRequired: true,
    isPaginationRequired: false,
    isGotoLinkRequired: true,
    totalNoOfError: 0,
    gotoLinkStates: [],
    checkboxKey: ReportsConstant.stateCode,
    goToLinksKey: ReportsConstant.stateCode,
    isCheckMailType: false,
    exportExcelData: {
      exportName: ReportsConstant.exportExcel.exportName.badFieldRuleAssignment,
      pageTitle: ReportsConstant.exportExcel.pageTitle.badFieldRuleAssignment,
      fileName: ReportsConstant.exportExcel.pageTitle.badFieldRuleAssignment,
      data: {
        result: [],
        headers: ReportsConstant.badFieldRuleAssignmentNames,
        keys: ReportsConstant.badFieldRuleAssignmentKeys
      },
    }
  };

  constructor(
    private reportsUtilityService: ReportsUtilityService,
    private badFieldRuleAssignmentUtilityService: BadFieldRuleAssignmentUtilityService) { }

  ngOnInit(): void {
    this.isBadFieldRuleGridData = false;
    this.getBadFieldRuleAssignmentData();
  }

  getBadFieldRuleAssignmentData() {
    this.activeSubscription = this.badFieldRuleAssignmentUtilityService.getFieldRuleAssignment().subscribe((res: any) => {
      if (res && res.length > 0) {
        const updatedData = this.reportsUtilityService.sortAscendingByKey(ReportsConstant.filterStateCode, res);
        this.badFieldRuleAssignmentData = this.badFieldRuleAssignmentUtilityService.updateBadFieldRecords(updatedData);
        this.addMultiStateAtBottomOfGrid();
        this.gridData = this.badFieldRuleAssignmentData;
        this.gridDetails.totalNoOfError = this.badFieldRuleAssignmentData.length;
        this.isBadFieldRuleGridData = true;
        this.isGridDataAvailable = true;
        this.updateGotoLinkState(this.badFieldRuleAssignmentData);
      }
    });
  }

  addMultiStateAtBottomOfGrid() {
    const sortedData = this.badFieldRuleAssignmentUtilityService.getSorterData(this.badFieldRuleAssignmentData, this.sortKey);
    this.badFieldRuleAssignmentData = sortedData;
  }

  updateGotoLinkState(res) {
    const removedEmptyState = this.badFieldRuleAssignmentUtilityService.removedEmptyState(res);
    this.gotoLinksData = [];
    removedEmptyState.forEach(element => {
      if (!(this.gotoLinksData.includes(element.stateCode))) {
        this.gotoLinksData.push(element.stateCode);
      }
    });
    this.gridDetails.gotoLinkStates = this.gotoLinksData;
  }

  resetSearch() {
    this.searchKeyword = null;
    this.gridData = this.badFieldRuleAssignmentData;
    this.gridDetails.totalNoOfError = this.badFieldRuleAssignmentData.length;
    this.removeAllSelctedRow = true;
    this.updateGotoLinkState(this.badFieldRuleAssignmentData);
  }

  search() {
    let updatedData;
    this.removeAllSelctedRow = true;
    updatedData = this.badFieldRuleAssignmentData
      .filter(x =>
      (
        x.rtfName?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase()) ||
        x.fieldRuleDescription?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase()) ||
        x.fieldName?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase())
      )
      );
    this.gridDetails.totalNoOfError = updatedData.length;
    this.gridData = updatedData;
    this.updateGotoLinkState(updatedData);
    this.gridDetails.exportExcelData.data.result = updatedData;
  }

  sortData(data, key) {
    return data.sort((a, b) => 0 - (a[key]?.toLowerCase() > b[key]?.toLowerCase() ? -1 : 1));
  }

  showClearIcon() {
    return this.searchKeyword ? true : false;
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

}
