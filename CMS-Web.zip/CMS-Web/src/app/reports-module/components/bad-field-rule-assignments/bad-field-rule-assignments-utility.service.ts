import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';

@Injectable()
export class BadFieldRuleAssignmentUtilityService {

    multiStateRecord = [];
    emptyStateRecord = [];

    constructor(private http: HttpClient) { }

    getFieldRuleAssignment() {
      return this.http.get(`${ReportsConstant.webApis.getFieldRuleAssignment}`);
    }

    updateBadFieldRecords(data) {
      const badFieldRuleRecordsMulti = data.filter(x => (x.stateCode !== ReportsConstant.multiState));
      const removedMultiAndEmpty = badFieldRuleRecordsMulti.filter(x => (x.stateCode !== null));
      this.emptyStateRecord = data.filter(x => (x.stateCode === null));
      this.multiStateRecord = data.filter(item => !badFieldRuleRecordsMulti.includes(item));
      return removedMultiAndEmpty;
    }

    getSorterData(badFieldRuleAssignmentData, sortKey) {
      const sortedData = this.sortData(badFieldRuleAssignmentData, sortKey);
      for (let i = 0; i < this.emptyStateRecord.length; i++) {
        sortedData.push(this.emptyStateRecord[i]);
      }
      for (let i = 0; i < this.multiStateRecord.length; i++) {
        sortedData.push(this.multiStateRecord[i]);
      }
      return sortedData;
    }

    sortData(data, key) {
      return data.sort((a, b) => 0 - (a[key]?.toLowerCase() > b[key]?.toLowerCase() ? -1 : 1));
    }

    removedEmptyState(res) {
      const filterValue = [];
        res.forEach(element => {
            if (element.stateCode !== null) {
                filterValue.push(element);
            }
        });
        return filterValue;
    }
}
