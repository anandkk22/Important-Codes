import { Component, Input, OnInit, Output, EventEmitter, OnChanges, OnDestroy } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import '@wk/components/dist/pagination';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { Observable, Subject, Subscription } from 'rxjs';

@Component({
  selector: 'app-common-grid',
  templateUrl: './common-grid.component.html',
  styleUrls: ['./common-grid.component.scss']
})
export class CommonGridComponent implements OnInit, OnChanges, OnDestroy {
  onSearchEvent: Subject<void> = new Subject<void>();
  private getPageSub: Subscription;
  @Input() getPage: Observable<void>;
  @Input() removeAllSelctedRow: any;
  @Input() gridData;
  @Input() gridDetails;
  @Input() isClientSidePagination;
  @Input() isFullWidth;
  selectedRow = [];
  checkBoxForm: FormGroup;
  isChecked = false;
  isAtleastOneSelected = false;
  exportExcelClicked = false;
  paginationOptions: any = {
    currentPage: ReportsConstant.paginationOptions.currentPage,
    pageSize: ReportsConstant.paginationOptions.pageSize,
    totalItems: ReportsConstant.paginationOptions.totalItems,
  };
  @Output() paginationData = new EventEmitter();

  constructor(
    private reportsUtilityService: ReportsUtilityService) { }

  ngOnInit(): void {
    if (this.gridDetails.isCheckMailType) {
     this.getPageSub = this.getPage?.subscribe(() => this.setPage());
    }
    this.formatGridData();
    setTimeout(() => {
      this.reportsUtilityService.loadUpadtedPageSizes();
    }, 250);
  }

  setPage() {
    this.paginationOptions.currentPage = 1;
    this.resetSelectedData();
  }

  resetSelectedData() {
    this.selectedRow = [];
    this.gridData.forEach(ele => {
      if (ele.isSelected) {
        ele.isSelected = false;
      }
    });
    this.checkIfAtleastOneSelected();
  }

  ngOnChanges() {
    if (this.removeAllSelctedRow) {
      this.selectedRow = [];
      this.formatGridData();
      this.checkIfAtleastOneSelected();
    }
  }

  formatGridData() {
    this.gridData.forEach(element => {
      element.isSelected = false;
    });
  }

  checkAllCheckbox() {
    if (this.isChecked) {
      this.checkAllcheckboxValue();
      this.gridDetails.exportExcelData.data.result = this.selectedRow;
    } else {
      this.selectedRow = [];
      this.isAtleastOneSelected = false;
      this.formatGridData();
    }
    this.checkIfAtleastOneSelected();
  }

  checkAllcheckboxValue() {
    this.selectedRow = [];
    this.gridData.forEach(element => {
      element.isSelected = true;
      this.addToSelectedtable(element);
    });
    this.isAtleastOneSelected = true;
  }

  changeCheckbox(data) {
    data.isSelected = !data.isSelected;
    if (!data.isSelected) {
      this.removeFromSelectedtable(data);
    } else if (data.isSelected) {
      this.addToSelectedtable(data);
    }
    this.checkIfAtleastOneSelected();
    this.gridDetails.exportExcelData.data.result = this.selectedRow;
  }

  addToSelectedtable(oneRow) {
    this.selectedRow.push(oneRow);
    if (this.gridDetails.sortByInExcel === ReportsConstant.commonGridSortby.stateCode) {
      this.selectedRow.sort((a, b) => (a.stateCode.localeCompare(b.stateCode)));
    }
  }

  exportExcel() {
    this.exportExcelClicked = true;
    this.gridDetails.exportExcelData.data.result = this.selectedRow;
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
      this.selectedRow = [];
      this.formatGridData();
      this.checkIfAtleastOneSelected();
    }
  }

  removeFromSelectedtable(data) {
    const index = this.selectedRow.findIndex(d => d === data);
    this.selectedRow.splice(index, 1);
  }

  checkIfAtleastOneSelected() {
    if (this.selectedRow.length === 0) {
      this.isAtleastOneSelected = false;
      this.isChecked = false;
    } else if (this.gridData.length === this.selectedRow.length) {
      this.isAtleastOneSelected = false;
      this.isChecked = true;
    } else if ((this.gridData.length > this.selectedRow.length)
      && (this.selectedRow.length > 0)) {
      this.isAtleastOneSelected = true;
      this.isChecked = false;
    }
    else {
      this.isAtleastOneSelected = false;
      this.isChecked = false;
    }
  }

  isCheckbox(key) {
    return key === this.gridDetails.checkboxKey ? true : false;
  }

  selectAllData() {
    this.selectedRow = this.gridData;
  }

  showCheckbox(index) {
    return this.gridDetails && this.gridDetails.isCheckBoxRequired && (index === 0) ? true : false;
  }

  onPageClick(event) {
    this.paginationOptions.currentPage = event.detail;
    this.paginationData.emit(this.paginationOptions);
    this.reportsUtilityService.loadUpadtedPageSizes();
  }

  pageSizeChange(event) {
    this.paginationOptions.currentPage =
      ReportsConstant.paginationOptions.currentPage;
    this.paginationOptions.pageSize = event.detail;
    this.paginationData.emit(this.paginationOptions);
    this.reportsUtilityService.loadUpadtedPageSizes();
  }

  scrollToState(state) {
    const div = document.getElementById(state);
    const pos = div.style.position;
    const top = div.style.top;
    div.style.position = ReportsConstant.cssStyles.relative;
    div.style.top = ReportsConstant.cssStyles.fluxibleHeight;
    div.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
    div.style.top = top;
    div.style.position = pos;
  }
  getGoToLinkKey(data: any) {
    if (data && data[this.gridDetails.goToLinksKey]) {
      return data[this.gridDetails.goToLinksKey];
    }
  }

  onChangeJurisdiction(event) {
    this.selectedRow = [];
    this.gridData.forEach(ele => {
      if (ele.isSelected) {
        ele.isSelected = false;
      }
    });
    if (event.length) {
      this.onSearchEvent.next();
      this.searchGridData();
    } else if (event.length === 0) {
      this.gridData = [];
    }
    this.paginationOptions.currentPage = 1;
    this.checkIfAtleastOneSelected();
  }

  searchGridData() {
    this.gridData = this.reportsUtilityService.searchGridData(this.gridDetails.searchTerm, this.gridDetails.selectedJurisdictions,
      this.gridDetails.gridData, this.gridDetails.copyMailTypeEntries);
  }

  sortAscending(key, array) {
    this.gridData = this.reportsUtilityService.sortAscendingByKey(key, array);
  }

  sortDescending(key, array) {
    this.gridData = this.reportsUtilityService.sortDescendingByKey(key, array);
  }

  getColumnWidth(i) {
    if (this.gridDetails && this.gridDetails.colWidth && this.gridDetails.colWidth.length > 0 && this.gridDetails.colWidth[i]) {
      return this.gridDetails.colWidth[i];
    } else {
      return null;
    }
  }

  ngOnDestroy() {
    if (this.gridDetails.isCheckMailType) {
      this.getPageSub.unsubscribe();
    }
  }
}
