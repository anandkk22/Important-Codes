import { Component, OnInit, OnDestroy } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ThresholdExceededData } from 'app/configurations-module/infrastructure/models/configuration.model';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { ReportsService } from 'app/reports-module/services/reports.service';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-check-days-notice-rules',
  templateUrl: './check-days-notice-rules.component.html',
  styleUrls: ['./check-days-notice-rules.component.scss']
})
export class CheckDaysNoticeRulesComponent implements OnInit, OnDestroy {
  searchCloseStatus = false;
  todayDate = this.reportsUtilityService.todayDate();
  todayDateFileName = this.reportsUtilityService.getTodayDateFileName();
  daysRulesResponse = [];
  daysRules = [];
  selectedjurisdictions: any;
  searchValue = '';
  activeSubscription: Subscription;
  gridData = null;
  removeAllSelctedRow = false;
  gridDetails = {
    columnNames: ReportsConstant.daysNoticeRulesColNames,
    gridDataKeys: ReportsConstant.daysNoticeRulestGridDataKeys,
    isCheckBoxRequired: true,
    isExportToExcelRequired: true,
    isPaginationRequired: false,
    isGotoLinkRequired: true,
    sortByInExcel: ReportsConstant.commonGridSortby.stateCode,
    gotoLinkStates: [],
    checkboxKey: ReportsConstant.stateCode,
    goToLinksKey: ReportsConstant.stateCode,
    isFullWidth: true,
    isCheckMailType: false,
    exportExcelData: {
      exportName: ReportsConstant.exportExcel.exportName.checkDaysNoticeRules + this.todayDate,
      pageTitle: ReportsConstant.exportExcel.exportName.checkDaysNoticeRules + this.todayDate,
      fileName: ReportsConstant.exportExcel.exportName.checkDaysNoticeRules + this.todayDateFileName,
      data: {
        result: [],
        headers: ReportsConstant.daysNoticeRulesColNames,
        keys: ReportsConstant.daysNoticeRulestGridDataKeys
      },
    }
  };
  constructor(
    private reportService: ReportsService,
    private reportsUtilityService: ReportsUtilityService,
    private translate: TranslateService
  ) { }

  ngOnInit(): void {
    this.getFormRules();
  }

  getFormRules() {
    this.reportService.getWithoutFormRuleCount().subscribe((response: ThresholdExceededData) => {
      if (response) {
        // Temparary commented, will change after anand confirmation
        /*const message = this.translate.instant('CONFIGURATION_MENU.MESSAGES.THRESHOLD_MESSAGE_REPORT');
        if (response.isThresholdExceeded) {
          this.daysRulesResponse.length = 0;
          this.reportsUtilityService.showAlertMessage(message);
        } else { */
          this.activeSubscription = this.reportService.getWithoutFormRule().subscribe((res: any) => {
            this.daysRulesResponse = this.reportsUtilityService.addRowId(res);
            this.gridData = this.daysRulesResponse;
            this.selectedjurisdictions = this.reportsUtilityService.getjurisdictionsCodes(this.gridData);
            this.gridDetails.gotoLinkStates = this.selectedjurisdictions;
          });
        // }
      }
    });
  }

  isDataAvaliable() {
    return this.daysRulesResponse.length === 0 ? false : true;
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

  searchCircumstance() {
    this.removeAllSelctedRow = true;
    this.gridData = this.daysRulesResponse;
    this.searchCloseStatus = true;
    if (this.searchValue && this.searchValue.trim() !== '') {
      this.gridData = this.reportsUtilityService.getFilterGrid(this.gridData, this.searchValue);
    }
    this.selectedjurisdictions = this.reportsUtilityService.getjurisdictionsCodes(this.gridData);
    this.gridDetails.gotoLinkStates = this.selectedjurisdictions;
  }

  searchClose() {
    this.removeAllSelctedRow = true;
    this.searchCloseStatus = false;
    this.searchValue = '';
    this.gridData = this.daysRulesResponse;
    this.selectedjurisdictions = this.reportsUtilityService.getjurisdictionsCodes(this.gridData);
    this.gridDetails.gotoLinkStates = this.selectedjurisdictions;
  }

}
