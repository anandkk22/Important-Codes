import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReportsConstant } from '../../infrastructure/reports.constant';
@Injectable()
export class RulesMarkedRegulatoryService {

  constructor(private http: HttpClient) { }

  getRulesMarkedRegulatoryDatas() {
    return this.http.get(`${ReportsConstant.webApis.getRulesMarkedRegulatory}`);
  }

  searchGridData(searchTerm, response) {
    const convertedSearchTerm =  searchTerm.trim().toLowerCase();
    if (searchTerm.length > 0 && response.length > 0) {
      const filteredData = response.filter(x =>
        (
          x.stateCode?.toLowerCase().includes(convertedSearchTerm) ||
          x.form?.toLowerCase().includes(convertedSearchTerm) ||
          x.actionCode?.toLowerCase().includes(convertedSearchTerm) ||
          x.lob?.toLowerCase().includes(convertedSearchTerm) ||
          x.circumstance?.toLowerCase().includes(convertedSearchTerm) ||
          x.field?.toLowerCase().includes(convertedSearchTerm)
        )
        );
      return filteredData;
    } else {
      return response;
    }
  }

}
