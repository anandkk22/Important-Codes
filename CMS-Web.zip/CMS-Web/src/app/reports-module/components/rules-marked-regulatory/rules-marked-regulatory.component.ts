import { Component, OnInit, OnDestroy } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { RulesMarkedRegulatoryService } from './rules-marked-regulatory.service';
import { Subscription } from 'rxjs';
@Component({
  selector: 'app-rules-marked-regulatory',
  templateUrl: './rules-marked-regulatory.component.html',
  styleUrls: ['./rules-marked-regulatory.component.scss'],
  providers: [RulesMarkedRegulatoryService]
})
export class RulesMarkedRegulatoryComponent implements OnInit, OnDestroy {

  isDataAvailable: Boolean = false;
  gridDetails = {
    columnNames: [],
    gridDataKeys: ReportsConstant.rulesMarkedGridDataKeys,
    isCheckBoxRequired: true,
    isExportToExcelRequired: true,
    isPaginationRequired: false,
    isGotoLinkRequired: false,
    totalNoOfError: 0,
    gotoLinkStates: [],
    checkboxKey: ReportsConstant.stateCode,
    goToLinksKey: null,
    isCheckMailType: false,
    isColSortingRequired: true,
    columnNamesWithSortInfo: ReportsConstant.rulesMarkedColNameWithSortingDetails,
    exportExcelData: {
      exportName: this.translate.instant('REPORTS.RULES_MARKED_REGULATORY.EXPORT_NAME'),
      pageTitle: this.translate.instant('REPORTS.RULES_MARKED_REGULATORY.EXPORT_FXCEL_FILE_NAME'),
      fileName: this.translate.instant('REPORTS.RULES_MARKED_REGULATORY.HEADING'),
      data: {
        result: [],
        headers: ReportsConstant.rulesMarkedGridDataColNames,
        keys: ReportsConstant.rulesMarkedGridDataKeys
      },
    }
  };
  gridData = null;
  removeAllSelctedRow = false;
  searchText = '';
  rulesMarkedRegulatoryRes = null;
  activeSubscription: Subscription;

  constructor(
    private rulesMarkedRegulatoryService: RulesMarkedRegulatoryService,
    private translate: TranslateService
  ) { }

  ngOnInit() {
    this.getRulesMarkedRegulatoryDatas();
  }

  getRulesMarkedRegulatoryDatas() {
    this.activeSubscription = this.rulesMarkedRegulatoryService.getRulesMarkedRegulatoryDatas().subscribe((res: any) => {
      if (res) {
        this.gridData = [...res];
        this.rulesMarkedRegulatoryRes = [...res];
        this.isDataAvailable = true;
      }
    });
  }

  searchInCircumstanceField() {
    this.searchText.trim();
    this.removeAllSelctedRow = true;
    if (this.searchText.length > 0 && (this.searchText !== '')) {
        this.gridData = this.rulesMarkedRegulatoryService.searchGridData(this.searchText, this.rulesMarkedRegulatoryRes);
    } else {
      this.searchClose();
    }
  }

  searchClose() {
    this.removeAllSelctedRow = true;
    this.gridData = this.rulesMarkedRegulatoryRes;
    this.searchText = '';
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

}
