import { Component, EventEmitter, OnDestroy, OnInit, Output } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { MailType } from 'app/reports-module/infrastructure/models/mail-type.model';
import { ReportsService } from 'app/reports-module/services/reports.service';
import { Subject, Subscription } from 'rxjs';
import { Constants } from '@global/infrastructure/constants';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { formatDate } from '@angular/common';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { SpinnerService } from '@wk/nils-core';

@Component({
    selector: 'app-check-mail-type',
    templateUrl: './check-mail-type.component.html',
    styleUrls: ['./check-mail-type.component.scss']
})
export class CheckMailTypeComponent implements OnInit, OnDestroy {
    private activeSubscription: Subscription;
    onSearchEvent: Subject<void> = new Subject<void>();
    headerName = this.translate.instant('REPORTS.CHECK_MAIL_TYPE.HEADING');
    mailTypeEntries: MailType[] = [];
    today = new Date();
    locale = 'en-US';
    isFullWidth = true;
    currentDate = formatDate(this.today, Constants.dateFormat.excelDateFormat, this.locale);
    gridData = null;
    searchText = null;
    isSearchApplied: Boolean = false;
    isAllCheckBoxSelected = false;
    gridDetails = {
        columnNames: ConfigurationsConstant.exportExcel.mailTypeHeader,
        gridDataKeys: ConfigurationsConstant.exportExcel.mailTypeKeys,
        isCheckBoxRequired: true,
        isExportToExcelRequired: true,
        isPaginationRequired: false,
        isGotoLinkRequired: false,
        gotoLinkStates: [],
        isClientSidePagination: true,
        isFullWidth: true,
        filterJurisdiction: [],
        selectedJurisdictions: [],
        copyMailTypeEntries: [],
        searchTerm: '',
        multiSelectDropdown: true,
        sortByInExcel: ReportsConstant.commonGridSortby.stateCode,
        checkboxKey: ReportsConstant.stateCode,
        isSearchClicked: false,
        hideJursidction: false,
        isCheckMailType: true,
        exportExcelData: {
            exportName: ConfigurationsConstant.exportExcel.exportMailTypeName,
            pageTitle: ConfigurationsConstant.exportExcel.pageMailTypeTitle,
            fileName: ConfigurationsConstant.exportExcel.fileNameMailType + this.currentDate,
            isCheckMailType: true,
            data: {
                result: [],
                headers: ConfigurationsConstant.exportExcel.mailTypeHeader,
                keys: ConfigurationsConstant.exportExcel.mailTypeKeys
            },
        },
    };
    isChecked = false;
    isAtleastOneSelected = false;
    paginationOptions = Constants.paginationOptions;
    pageSizeDropdown: HTMLElement;
    isSearchedApplied: Boolean = false;
    PageNo = ReportsConstant.paginationOptions.currentPage;
    PageSize = ReportsConstant.paginationOptions.pageSize;
    isMailtypeDataAvailable = false;

    constructor(
        private translate: TranslateService,
        private reportsService: ReportsService,
        private reportUtilitService: ReportsUtilityService,
        private spinnerService: SpinnerService) { }

    ngOnInit() {
        this.getJurisdiction();
        this.getMailTypeReport();
    }
    getMailTypeReport() {
        this.activeSubscription = this.reportsService.getMailtypes().subscribe((response: MailType[]) => {
                this.gridData = response;
                this.paginationOptions.totalItems = this.gridData.length;
                this.gridDetails.copyMailTypeEntries = this.gridData;
                this.reportUtilitService.loadUpadtedPageSizes();
                this.isMailtypeDataAvailable = true;
        });
    }

    getJurisdiction() {
        this.reportsService.getJurisdictions().subscribe((res: any) => {
            this.gridDetails.filterJurisdiction = this.reportUtilitService.addGroupName(res, Constants.checkTypeMail.allJurisdictions);
            this.gridDetails.selectedJurisdictions = this.gridDetails.filterJurisdiction;
        });
    }

    clearSearch() {
        this.onSearchEvent.next();
        this.gridDetails.isSearchClicked = true;
        this.gridDetails.searchTerm = '';
        this.searchGridData();
        this.isSearchedApplied = false;
        this.gridDetails.hideJursidction = false;
    }

    search() {
        this.onSearchEvent.next();
        this.searchGridData();
        this.isSearchedApplied = true;
    }
    showClearIcon() {
        return (this.gridDetails.searchTerm && this.gridDetails.searchTerm.trim().length > 0);
    }
    searchGridData() {
        this.gridDetails.isSearchClicked = true;
        this.gridData = this.reportUtilitService.searchGridData(this.gridDetails.searchTerm, this.gridDetails.selectedJurisdictions,
            this.gridData, this.gridDetails.copyMailTypeEntries);
    }

    updatedPaginationData(event) {
        this.PageNo = event.currentPage;
        this.PageNo = event.paginationData.currentPage;
        this.PageSize = event.paginationData.pageSize;
        this.getMailTypeReport();
    }

    ngOnDestroy() {
        this.activeSubscription.unsubscribe();
    }
}
