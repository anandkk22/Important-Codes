import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { ReportsService } from 'app/reports-module/services/reports.service';
import { forkJoin, Subscription } from 'rxjs';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { Constants } from '@global/infrastructure/constants';
import { PermittedReasonWithoutFormRulesHttpService } from './permitted-reason-without-form-rules-http.service';
@Component({
  selector: 'permitted-reason-without-form-rules',
  templateUrl: './permitted-reason-without-form-rules.component.html',
  styleUrls: ['./permitted-reason-without-form-rules.component.scss'],
  providers: [PermittedReasonWithoutFormRulesHttpService]
})
export class PermittedReasonWithoutFormRulesComponent implements OnInit {
  todayDateFileName = this.reportUtilitService.getTodayDateFileName();
  activeSubscription: Subscription;
  isDataAvailable: Boolean = false;
  gridData = [];
  gridDetails = {
    columnNames: ReportsConstant.permittedReasonsColNames,
    gridDataKeys: ReportsConstant.permittedReasonsGridDataKeys,
    exportExcelData: {
      exportName: ReportsConstant.exportExcel.exportName.permittedReasonWithoutFormRules,
      pageTitle: ReportsConstant.exportExcel.pageTitle.permittedReasonWithoutFormRules,
      fileName: ReportsConstant.exportExcel.fileName.permittedReasonWithoutFormRules + this.todayDateFileName,
      data: {
        result: [],
        headers: ReportsConstant.permittedReasonsColNames,
        keys: ReportsConstant.permittedReasonsGridDataKeys
      },
    }
  };
  paginationOptions: any = {
    currentPage: ReportsConstant.paginationOptions.currentPage,
    pageSize: ReportsConstant.paginationOptions.pageSize,
    totalItems: ReportsConstant.paginationOptions.totalItems,
  };
  searchText = '';
  stateCode = [];
  isSearchApplied: Boolean = false;
  selectedRow = [];
  jurisdictions = [];
  searchForm: FormGroup;
  subscriptions: Subscription[] = [];
  isDataPaginated = false;
  isChecked = false;
  isAtleastOneSelected = false;
  exportExcelClicked = false;
  filterJurisdiction = [];
  selectedJurisdictions = [];
  isFullWidth = true;
  constructor(
    private permittedReasonWithoutFormRulesHttpService: PermittedReasonWithoutFormRulesHttpService,
    private translate: TranslateService,
    private reportsService: ReportsService,
    private fb: FormBuilder,
    private reportUtilitService: ReportsUtilityService
  ) { }

  ngOnInit(): void {
    this.createSearchForm();
    this.getInitialData();
    this.loadPageSize();
  }

  loadPageSize() {
      this.reportUtilitService.loadUpadtedPageSizes();
  }

  createSearchForm() {
    this.searchForm = this.fb.group({
      textsearch: ['']
    });
  }

  getInitialData() {
    this.reportsService.getJurisdictions().subscribe((res: any) => {
     if (res) {
      this.filterJurisdiction = this.reportUtilitService.addGroupName(res, Constants.checkTypeMail.allJurisdictions);
      this.selectedJurisdictions = this.filterJurisdiction;
      this.stateCode = this.reportUtilitService.getJurisdictionsCodes(this.selectedJurisdictions);
      this.getPermittedReasons();
     }
    });
  }

  getPermittedReasons() {
    this.activeSubscription = this.permittedReasonWithoutFormRulesHttpService
    .getPermittedReasons(this.searchText, this.stateCode, this.paginationOptions.currentPage, this.paginationOptions.pageSize)
    .subscribe((res: any) => {
     if (res) {
      this.gridData = this.reportUtilitService.addIsSelectedInGrid(res.permittedReasons, this.selectedRow);
        this.paginationOptions.totalItems = res.totalRecords;
        this.isDataPaginated = res.totalRecords > ReportsConstant.maxTwoHundred;
        this.isDataAvailable = true;
      this.loadPageSize();
     }
    });
  }

  searchPermittedReasons() {
    this.selectedRow = [];
    this.checkIfAtleastOneSelected();
    this.paginationOptions.currentPage = ReportsConstant.paginationOptions.currentPage;
      this.searchText =  this.searchForm.value && this.searchForm.value.textsearch;
      this.isSearchApplied = true;
      this.getPermittedReasons();
      this.reportUtilitService.loadUpadtedPageSizes();
  }
  showClearIcon() {
    return (this.searchText && this.searchText.trim());
  }
  clearPermittedReasonsSearch() {
    this.selectedRow = [];
    this.checkIfAtleastOneSelected();
    this.paginationOptions.currentPage = ReportsConstant.paginationOptions.currentPage;
    this.searchText = '';
    this.getPermittedReasons();
    this.isSearchApplied = false;
    this.reportUtilitService.loadUpadtedPageSizes();
  }

  onChangeJurisdiction(event) {
    this.selectedRow = [];
    this.checkIfAtleastOneSelected();
    this.stateCode = this.reportUtilitService.getJurisdictionsCodes(this.selectedJurisdictions);
    this.paginationOptions.currentPage = 1;
    this.getPermittedReasons();
  }

  getAllPermittedReasons() {
    this.selectedRow = [];
    this.permittedReasonWithoutFormRulesHttpService.getPermittedReasons(this.searchText, this.stateCode, 0, this.paginationOptions.pageSize)
    .subscribe((res: any) => {
     if (res) {
      this.selectedRow = res.permittedReasons;
      this.checkIfAtleastOneSelected();
     }
    });
  }

  onPageClick(event) {
    this.paginationOptions.currentPage = event.detail;
    this.getPermittedReasons();
    this.reportUtilitService.loadUpadtedPageSizes();
  }

  pageSizeChange(event) {
    this.paginationOptions.currentPage = ReportsConstant.paginationOptions.currentPage;
    this.paginationOptions.pageSize = event.detail;
    this.getPermittedReasons();
    this.reportUtilitService.loadUpadtedPageSizes();
  }

  checkAllCheckbox() {
    if (this.isChecked) {
      this.gridData = this.reportUtilitService.addIsSelectedInGridTrue(this.gridData);
      this.getAllPermittedReasons();
    } else {
      this.selectedRow = [];
      this.isAtleastOneSelected = false;
      this.gridData = this.reportUtilitService.addIsSelectedInGrid(this.gridData, this.selectedRow);
    }
    this.checkIfAtleastOneSelected();
  }

  changeCheckbox(data) {
    data.isSelected = !data.isSelected;
    if (!data.isSelected) {
      this.removeFromSelectedtable(data.accountActionReasonId);
    } else if (data.isSelected) {
      this.addToSelectedtable(data);
    }
    this.checkIfAtleastOneSelected();
  }

  addToSelectedtable(oneRow) {
    if (this.selectedRow.findIndex(d => d.accountActionReasonId === oneRow.accountActionReasonId) === -1) {
      this.selectedRow.push(oneRow);
      this.selectedRow.sort((a, b) => (a.stateCode.localeCompare(b.stateCode)));
    }
  }

  removeFromSelectedtable(gridId) {
    const index = this.selectedRow.findIndex(d => d.accountActionReasonId === gridId);
    this.selectedRow.splice(index, 1);
  }

  checkIfAtleastOneSelected() {
    if (this.selectedRow.length === 0) {
      this.isAtleastOneSelected = false;
      this.isChecked = false;
    } else if (this.paginationOptions.totalItems === this.selectedRow.length) {
      this.isAtleastOneSelected = false;
      this.isChecked = true;
    } else if ((this.paginationOptions.totalItems > this.selectedRow.length)
      && (this.selectedRow.length > 0)) {
      this.isAtleastOneSelected = true;
      this.isChecked = false;
    } else {
      this.isAtleastOneSelected = false;
      this.isChecked = false;
    }
  }

  exportExcel() {
    this.gridDetails.exportExcelData.data.result = this.selectedRow;
    setTimeout(() => {
      this.exportExcelClicked = true;
    }, 1500);
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
      this.selectedRow = [];
      this.gridData = this.reportUtilitService.addIsSelectedInGrid(this.gridData, this.selectedRow);
      this.checkIfAtleastOneSelected();
    }
  }

}
