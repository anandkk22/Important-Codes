import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';

@Injectable()
export class PermittedReasonWithoutFormRulesHttpService {

  constructor(private http: HttpClient) { }

  getPermittedReasons(searchText, stateCodes, pageNo, pageSize) {
    const reqData = {
      searchText: searchText,
      stateCodes: stateCodes,
      pageNo: pageNo,
      pageSize: pageSize
    };
    return this.http.post(`${ReportsConstant.webApis.permittedReasons}`, reqData);
  }

}
