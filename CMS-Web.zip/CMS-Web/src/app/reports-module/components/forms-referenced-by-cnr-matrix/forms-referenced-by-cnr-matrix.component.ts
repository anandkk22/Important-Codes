import { Component, OnInit } from '@angular/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { FormsReferncedMatrixService } from './forms-refernced-matrix.service';
@Component({
  selector: 'app-forms-referenced-by-cnr-matrix',
  templateUrl: './forms-referenced-by-cnr-matrix.component.html',
  styleUrls: ['./forms-referenced-by-cnr-matrix.component.scss'],
  providers: [FormsReferncedMatrixService]
})
export class FormsReferencedByCnrMatrixComponent implements OnInit {

  isDataAvailable = false;
  exportExcelClicked = false;
  columnNames = ReportsConstant.NotReferencedFormsAwebHeaders;
  gridDataKeys = ReportsConstant.NotReferencedFormsAwebKeys;
  sortOrderDesc = true;
  gridData = null;
  exportData: any = {
    exportName: ReportsConstant.exportExcel.exportFormsNotReferencedMatrixName,
    pageTitle: ReportsConstant.exportExcel.exportFormsNotReferencedMatrixName,
    fileName: ReportsConstant.exportExcel.exportFormsNotReferencedMatrixName,
    data: {
      result: [],
      headers: ReportsConstant.NotReferencedFormsAwebHeaders,
      keys: ReportsConstant.NotReferencedFormsAwebKeys
    }
  };

  constructor(private formsReferncesMatrix: FormsReferncedMatrixService,
      private reportsUtilityService: ReportsUtilityService) { }

  ngOnInit(): void {
    this.getFormData();
  }

  getFormData() {
    this.formsReferncesMatrix.getNonReferencedFormsInMatrices().subscribe((res: any) => {
      if (res) {
        this.gridData = res;
        this.exportData.data.result = res;
        this.isDataAvailable = true;
      }
    });
  }

  exportExcel() {
    this.exportExcelClicked = true;
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
    }
  }
  sortAscending(header: any) {
    this.gridData = this.reportsUtilityService.sortAscendingByKey(header, this.gridData);
    }
  sortDescending(header: any) {
      this.gridData = this.reportsUtilityService.sortDescendingByKey(header, this.gridData);
  }
}
