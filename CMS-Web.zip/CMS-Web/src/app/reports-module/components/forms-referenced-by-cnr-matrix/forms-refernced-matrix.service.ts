import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';

@Injectable()
export class FormsReferncedMatrixService {

  constructor(private http: HttpClient) { }

    getNonReferencedFormsInMatrices() {
        return this.http.get(`${ReportsConstant.webApis.getInactiveAwebForms}`);
    }

}
