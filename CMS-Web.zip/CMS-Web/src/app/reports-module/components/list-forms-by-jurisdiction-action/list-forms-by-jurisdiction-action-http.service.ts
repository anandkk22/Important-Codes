import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';

@Injectable()
export class ListFormsByJurisdictionActionHttpService {

  constructor(private http: HttpClient) { }

  getFormsBySearchCriteria(displayParam, PageNo, PageSize) {
    return this.http.post(`${ReportsConstant.webApis.getFormsBySearchCriteria}`
    .replace('{PageNo}', PageNo).replace('{PageSize}', PageSize), displayParam);
  }

  getgetFormsBySearchCriteriaCount(displayParam) {
    return this.http.post(`${ReportsConstant.webApis.getFormsBySearchCriteriaCount}`, displayParam);
  }
}
