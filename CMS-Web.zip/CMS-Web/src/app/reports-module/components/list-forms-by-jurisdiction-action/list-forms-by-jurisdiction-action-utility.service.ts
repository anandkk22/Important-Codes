import { Injectable } from '@angular/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';

@Injectable()
export class ListFormsByJurisdictionActionUtilityService {

  constructor() { }

  getDisplayFormParam(selectedJurisdictions, selectedActions, selectedLobs, selectedCircumstances) {
    const param = {
      stateCodes: this.getCodes(selectedJurisdictions, 'code') || [],
      actionIds: this.getCodes(selectedActions, 'id') || [],
      lobIds: this.getCodes(selectedLobs, 'id') || [],
      whereConditionIds: this.getCodes(selectedCircumstances, 'id') || [],
      rtfName: null,
      sortBy: 0
    };
    return param;
  }

  getCodes(selectedValues, key) {
    const codes = [];
    selectedValues.forEach(element => {
      if (element[key] !== null) {
        codes.push(element[key]);
      }
    });
    return codes;
  }

  getSelectedStates(res) {
    const states = [];
    res.forEach(element => {
      if (element.stateCode && !states.includes(element.stateCode)) {
        states.push(element.stateCode);
      }
    });

    return states;
  }

  getJurisdictionsNames(jurisdictions) {
    const jurisdictionsNames = [];
    jurisdictions.forEach(element => {
      jurisdictionsNames.push(element.name);
    });
    return jurisdictionsNames;
  }

  sortTable(col, sortOrder, data) {
    const direction = sortOrder === ReportsConstant.listFormsByJurisdiction.orderAsc ? 1 : -1;
    data.sort((a, b) => {
      if (a[col] < b[col]) {
        return -1 * direction;
      }
      else if (a[col] > b[col]) {
        return 1 * direction;
      }
      else {
        return 0;
      }
    });
  }

  formatrtfName(res) {
    const data = [];
    for (let i = 0; i < res.length; i++) {
      data.push({
        stateCode: res[i].stateCode,
        actionDescription: res[i].actionDescription,
        lobAbbreviation: res[i].lobAbbreviation,
        whereConditionDescription: res[i].whereConditionDescription,
        rtfName: res[i].rtfName?.split('.')?.slice(0, -1)?.join('.') + ReportsConstant.fileExtn.pdf
      });
    }
    return data;
  }

  getFilePath(rtfName) {
    const filePath = ReportsConstant.cnr.cnrPdfFilePath + rtfName;
    return filePath;
  }

  scrollIntoView(isGotoLink, state) {
    isGotoLink = true;
    document.getElementById(state).scrollIntoView({
      behavior: 'smooth'
    });
  }
}
