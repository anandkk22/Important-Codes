import { Component, OnInit, ViewChild } from '@angular/core';
import '@wk/components/dist/accordion';
import { ListFormsByJursidiction } from 'app/reports-module/infrastructure/models/list-forms-by-jurisdiction.model';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { ReportsService } from 'app/reports-module/services/reports.service';
import { CmsSelectsComponent } from 'app/utility-module/cms-selects/cms-selects.component';
import { Subject } from 'rxjs';
import { ListFormsByJurisdictionActionHttpService } from './list-forms-by-jurisdiction-action-http.service';
import { ListFormsByJurisdictionActionUtilityService } from './list-forms-by-jurisdiction-action-utility.service';

@Component({
  selector: 'list-forms-by-jurisdiction-action',
  templateUrl: './list-forms-by-jurisdiction-action.component.html',
  styleUrls: ['./list-forms-by-jurisdiction-action.component.scss'],
  providers: [ListFormsByJurisdictionActionUtilityService, ListFormsByJurisdictionActionHttpService]
})
export class ListFormsByJurisdictionActionComponent implements OnInit {
  @ViewChild(CmsSelectsComponent) child: CmsSelectsComponent;
  pageSizeDropdown: HTMLElement;
  displayFormLists = [];
  isDisplayClicked: Boolean = false;
  exportExcelClicked = false;
  exportData: any = {
    exportName: ReportsConstant.exportExcel.exportMailTypeName,
    pageTitle: ReportsConstant.exportExcel.pageMailTypeTitle,
    fileName: ReportsConstant.exportExcel.fileNameMailType,
    data: {
      result: [],
      headers: ReportsConstant.exportExcel.formByJurisidctionHeader,
      keys: ReportsConstant.exportExcel.formByJurisidctionKeys
    },
  };
  multiJurisdiction = true;
  orderByColums = [];
  isFullWidth = true;
  resetBtn = false;
  isGotoLink = true;
  onCancelButtonClick: Subject<void> = new Subject<void>();
  listFormsByJuriMaster = {
    pageNo: 1,
    pageSize: 500,
    totalCount: 0
  };
  paginationOptions = {
    currentPage: this.listFormsByJuriMaster.pageNo,
    pageSize: this.listFormsByJuriMaster.pageSize
  };
  displayParam = {};
  listFormsData = [];
  isDisplayEnabled = false;
  isResetEnabled = false;

  constructor(
    private reportsService: ReportsService,
    private reportsUtilityService: ReportsUtilityService,
    private listFormsByJurisdictionActionUtilityService: ListFormsByJurisdictionActionUtilityService,
    private listFormsByJurisdictionActionHttpService: ListFormsByJurisdictionActionHttpService
  ) { }

  ngOnInit(): void {
  }

  changeDropdown() {
    this.isDisplayEnabled = (this.child.selectedJurisdictions.length > 0 && this.child.selectedActions.length > 0 &&
      this.child.selectedLobs.length > 0 && this.child.selectedCircumstances.length > 0);
    this.isResetEnabled = (this.child.selectedJurisdictions.length > 0 || this.child.selectedActions.length > 0 ||
      this.child.selectedLobs.length > 0 || this.child.selectedCircumstances.length > 0);
  }

  reset() {
    this.child.cancel();
    this.child.isSubmitClicked = false;
    this.isDisplayEnabled = false;
    this.isResetEnabled = false;
    this.isDisplayClicked = false;
    this.listFormsByJuriMaster.pageNo = 1;
  }

  displayForm() {
    this.displayParam = this.listFormsByJurisdictionActionUtilityService.getDisplayFormParam(this.child.selectedJurisdictions,
      this.child.selectedActions, this.child.selectedLobs, this.child.selectedCircumstances);
    this.getGridData(this.displayParam, true, true);
    this.resetBtn = false;
  }

  getGridData(displayParam, pageData, firstLoad) {
    const pageSize = (pageData ? this.listFormsByJuriMaster.pageSize : this.listFormsByJuriMaster.totalCount);
    this.listFormsByJurisdictionActionHttpService.getFormsBySearchCriteria(displayParam, this.listFormsByJuriMaster.pageNo, pageSize)
      .subscribe((res: ListFormsByJursidiction) => {
        this.listFormsData = this.listFormsByJurisdictionActionUtilityService.formatrtfName(res.paginationData);
        this.listFormsByJuriMaster.totalCount = res.totalCount;
        if (this.listFormsData) {
          this.getFormData(this.listFormsData);
          setTimeout(() => {
            this.reportsUtilityService.getRecordsFormat();
          }, 0);
        }
        if (firstLoad) {
          this.loadUpadtedPageSizes();
        }
      });
  }

  loadUpadtedPageSizes() {
    setTimeout(function () {
      this.pageSizeDropdown = document.querySelector('#pagination-bar-dynamic .wk-field-select');
      this.addMorePageSizes();
      this.adminMenuUtilityService.getRecordsFormat();
      this.reportsUtilityService.getRecordsFormat();
    }.bind(this), 250);
  }

  getFormData(res) {
    this.displayFormLists = res;
    this.isDisplayClicked = true;
  }

  sortTable(columname, sortOrder, displayFormLists) {
    this.listFormsByJurisdictionActionUtilityService.sortTable(columname, sortOrder, displayFormLists);
    this.resetBtn = true;
  }

  downloadFile(rtfName) {
    rtfName = rtfName?.split('.')?.slice(0, -1)?.join('.') + ReportsConstant.fileExtn.pdf;
    const filePath = this.listFormsByJurisdictionActionUtilityService.getFilePath(rtfName);
    this.reportsService.downloadFile(filePath).subscribe(response => {
      if (response) {
        this.reportsUtilityService.loadFile(response, rtfName);
      }
    });
  }

  exportExcel() {
    this.getExcelData(this.displayParam);
  }

  getExcelData(displayParam) {
    this.listFormsByJuriMaster.pageNo = 1;
    this.manipulatePageSizes();
    this.listFormsByJurisdictionActionHttpService
      .getFormsBySearchCriteria(displayParam, this.listFormsByJuriMaster.pageNo, this.listFormsByJuriMaster.totalCount)
      .subscribe((res: ListFormsByJursidiction) => {
        this.exportData.data.result = this.listFormsByJurisdictionActionUtilityService.formatrtfName(res.paginationData);
        this.pushDataToExcel();
      });
  }

  pushDataToExcel() {
    setTimeout(() => {
      this.exportExcelClicked = true;
    }, 1000);
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
    }
  }

  onPageClick(event) {
    this.manipulatePageSizes();
    const detail = event.detail;
    this.listFormsByJuriMaster.pageNo = detail;
    this.getGridData(this.displayParam, true, false);
    setTimeout(() => {
      this.reportsUtilityService.getRecordsFormat();
    }, 0);
  }

  pageSizeChange(event) {
    this.manipulatePageSizes();
    const detail = event.detail;
    this.listFormsByJuriMaster.pageSize = detail;
    this.listFormsByJuriMaster.pageNo = 1;
    this.getGridData(this.displayParam, true, false);
    setTimeout(() => {
      this.reportsUtilityService.getRecordsFormat();
    }, 0);
  }

  manipulatePageSizes() {
    setTimeout(function () {
      this.addMorePageSizes();
    }.bind(this));
  }

  addMorePageSizes() {
    for (let i = 0; i < ReportsConstant.pageSizes.length; i++) {
      this.pageSizeDropdown[i].value = ReportsConstant.pageSizes[i].toString();
      this.pageSizeDropdown[i].innerHTML = ReportsConstant.pageSizes[i];
    }
  }
}
