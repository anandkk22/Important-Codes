import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { TranslateService } from '@ngx-translate/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { WizardCriteriaByFieldHttpService } from './wizard-criteria-by-field-http.service';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';

@Component({
    selector: 'app-wizard-criteria-by-field',
    templateUrl: './wizard-criteria-by-field-component.html',
    styleUrls: ['./wizard-criteria-by-field-component.scss'],
    providers: [WizardCriteriaByFieldHttpService]
})

export class WizardCriteriaByFieldComponent implements OnInit, OnDestroy {

    activeSubscription: Subscription;
    allJurisdictions: [];
    wizdardCriteriaSearchData: any = [];
    selectedJurisdictionsCodes: string = null;
    selectedFieldValue: string;
    isWizardCriteriaSearchTable: boolean;
    noRecordsFound: boolean;
    exportExcelClicked: boolean;
    selectedValueForField: string;
    wizardByFieldHeaders = ReportsConstant.wizardCriteriaByFieldName;
    wizardByFieldKeys = ReportsConstant.wizardCriteriaByFieldKeys;
    exportData: any = {
        exportName: ReportsConstant.exportExcel.exportName.wizardCriteriaByField,
        pageTitle: ReportsConstant.exportExcel.pageTitle.wizardCriteriaByField,
        fileName: ReportsConstant.exportExcel.pageTitle.wizardCriteriaByField,
        data: {
            result: [],
            headers: this.wizardByFieldHeaders,
            keys: this.wizardByFieldKeys
        }
    };

    constructor(
        private wizardCriteriaByFieldHttpService: WizardCriteriaByFieldHttpService,
        private translate: TranslateService,
        private reportUtilityService: ReportsUtilityService) { }

    ngOnInit(): void {
        this.isWizardCriteriaSearchTable = false;
        this.noRecordsFound = false;
        this.exportExcelClicked = false;
        this.getJurisdictions();
    }

    customSearchFn(term: string, item: any) {
        return item.name.toLocaleLowerCase().startsWith(term.toLocaleLowerCase());
    }

    getJurisdictions() {
        this.activeSubscription = this.wizardCriteriaByFieldHttpService.getJurisdictions().subscribe((res: any) => {
            if (res && res.length) {
                this.allJurisdictions = res;
            }
        });
    }

    onFieldChange(ev) {
        this.selectedFieldValue = ev.target.value.trim();
    }

    searchJurisdiction() {
        this.noRecordsFound = false;
        if (this.selectedJurisdictionsCodes && this.selectedFieldValue) {
            const param = {
                StateCode: this.selectedJurisdictionsCodes,
                FieldName: this.selectedFieldValue
            };
            this.wizardCriteriaByFieldHttpService.getWizardsFieldCriteria(param).subscribe((res: any) => {
                if (res && res.length > 0) {
                    this.wizdardCriteriaSearchData = res;
                    this.exportData.data.result = res;
                    this.isWizardCriteriaSearchTable = true;
                    this.selectedValueForField = this.selectedFieldValue;
                } else {
                    this.noRecordsFound = true;
                    this.isWizardCriteriaSearchTable = false;
                }
            });
        }
    }


    isSearchBtnValid() {
        let returnValue = true;
        if (this.selectedJurisdictionsCodes && this.selectedFieldValue) {
            returnValue = false;
        }
        return returnValue;
    }


    isSearchFieldBtnValid() {
        if (this.selectedJurisdictionsCodes || this.selectedFieldValue) {
            return false;
        }
        return true;
    }


    resetJurisdiction() {
        this.wizdardCriteriaSearchData = [];
        this.selectedJurisdictionsCodes = null;
        this.selectedFieldValue = null;
        this.isWizardCriteriaSearchTable = false;
        this.noRecordsFound = false;
        this.exportData.data.result = [];
        this.selectedValueForField = null;
        this.isSearchBtnValid();
    }

    sortAscending(header: any) {
        this.wizdardCriteriaSearchData = this.reportUtilityService.sortAscendingByKey(header, this.wizdardCriteriaSearchData);
    }

    sortDescending(header: any) {
        this.wizdardCriteriaSearchData = this.reportUtilityService.sortDescendingByKey(header, this.wizdardCriteriaSearchData);
    }

    exportExcel() {
        this.exportExcelClicked = true;
    }

    excelDownloaded(status) {
        if (status) {
            this.exportExcelClicked = false;
        }
    }

    ngOnDestroy() {
        this.activeSubscription.unsubscribe();
    }
}
