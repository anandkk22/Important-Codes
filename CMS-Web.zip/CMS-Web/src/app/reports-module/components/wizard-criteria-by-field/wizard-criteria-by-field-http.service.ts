import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';

@Injectable()
export class WizardCriteriaByFieldHttpService {

    constructor(private http: HttpClient) { }

    getJurisdictions() {
      return this.http.get(`${ReportsConstant.webApis.getJurisdictions}`);
    }

    getWizardsFieldCriteria(param) {
      let params = new HttpParams();
      params = params.append('StateCode', param.StateCode);
      params = params.append('FieldName', param.FieldName);
      return this.http.get(`${ReportsConstant.webApis.searchWizardCriteriaByField}`, {params: params});
    }
}
