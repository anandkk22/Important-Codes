import { Component, OnInit } from '@angular/core';
import { SpinnerService } from '@wk/nils-core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { NonReferencedFormsInMatrixHttpService } from './non-referenced-forms-in-matrix-http.service';

@Component({
  selector: 'app-non-referenced-forms-in-matrix',
  templateUrl: './non-referenced-forms-in-matrix.component.html',
  styleUrls: ['./non-referenced-forms-in-matrix.component.scss'],
  providers: [NonReferencedFormsInMatrixHttpService]
})
export class NonReferencedFormsInMatrixComponent implements OnInit {

  isDataAvailable = false;
  exportExcelClicked1 = false;
  exportExcelClicked2 = false;
  columnNames = ReportsConstant.NonReferencedFormsInMatrixHeaders;
  nonReferencedFormsInMatrixTitle = ReportsConstant.exportExcel.nonReferencedFormsInMatrix;
  summaryMatricesData = null;
  summaryMatrixName = ReportsConstant.exportExcel.summaryMatricesName;
  adverseDecisionMatricesData = null;
  adverseDecisionMatrixName = ReportsConstant.exportExcel.adverseMatricesName;

  exportSummaryData: any = {
    exportName: this.summaryMatrixName,
    pageTitle: this.summaryMatrixName,
    fileName: this.summaryMatrixName,
    data: {
      result: [],
      headers: ReportsConstant.NonReferencedFormsInMatrixHeaders,
      keys: ReportsConstant.NonReferencedFormsInMatrixKeys
    }
  };

  exportAdverseData: any = {
    exportName: this.adverseDecisionMatrixName,
    pageTitle: this.adverseDecisionMatrixName,
    fileName: this.adverseDecisionMatrixName,
    data: {
      result: [],
      headers: ReportsConstant.NonReferencedFormsInMatrixHeaders,
      keys: ReportsConstant.NonReferencedFormsInMatrixKeys
    }
  };

  constructor(private spinnerService: SpinnerService,
      private nonReferencedFormsHttpService: NonReferencedFormsInMatrixHttpService) { }

  ngOnInit(): void {
    this.getFormData();
  }

  getFormData() {

    this.nonReferencedFormsHttpService.getNonReferencedFormsInMatrix().subscribe((res: any) => {
      if (res) {
        this.summaryMatricesData = this.formatGridData(res.cnrSummaryMatrices);
        this.adverseDecisionMatricesData = this.formatGridData(res.cnrAdverseDecisionMatrices);
        this.exportAdverseData.data.result = this.adverseDecisionMatricesData;
        this.exportSummaryData.data.result = this.summaryMatricesData;
        this.isDataAvailable = true;
      }
    });
  }

  exportExcel(isSummaryClicked, isAdverseClicked) {
    if (isSummaryClicked) {
      this.exportExcelClicked1 = true;
      this.exportExcelClicked2 = false;
    }

    else {
      this.exportExcelClicked1 = false;
      this.exportExcelClicked2 = true;
    }
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked1 = false;
      this.exportExcelClicked2 = false;
    }
  }

  formatGridData(gridData: any) {

    const newData = [];

    gridData.forEach(element => {
      element.notReferencedForms.forEach(ele => {
        newData.push({'productName': element.productName, 'stateCode': ele.stateCode, 'baseForm': ele.baseForm});
      });
    });

    return newData;
  }

}
