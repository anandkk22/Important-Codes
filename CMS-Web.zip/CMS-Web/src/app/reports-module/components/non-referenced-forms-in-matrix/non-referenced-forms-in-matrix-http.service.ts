import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';

@Injectable()
export class NonReferencedFormsInMatrixHttpService {

  constructor(private http: HttpClient) { }

  getNonReferencedFormsInMatrix() {
    return this.http.get(`${ReportsConstant.webApis.getNonReferencedFormsInMatrix}`);
  }
}
