import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';


@Injectable()
export class WizardCriteriaByFormHttpService {

    constructor(private http: HttpClient) { }

    getJurisdictions() {
      return this.http.get(`${ReportsConstant.webApis.getJurisdictions}`);
    }

    getWizardCriteriaByForm(bodyParam) {
      return this.http.post(`${ReportsConstant.webApis.seaerchWizardCriteriaByForm}`, bodyParam);
    }
}
