import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ReportsService } from 'app/reports-module/services/reports.service';
import { TranslateService } from '@ngx-translate/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { WizardCriteriaByFormUtilityService } from './wizard-criteria-by-form-utility.service';
import { WizardCriteriaByFormHttpService } from './wizard-criteria-by-form-http.service';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import '@wk/components/dist/tooltip';

@Component({
    selector: 'app-wizard-criteria-by-form',
    templateUrl: './wizard-criteria-by-form-component.html',
    styleUrls: ['./wizard-criteria-by-form-component.scss'],
    providers: [WizardCriteriaByFormUtilityService, WizardCriteriaByFormHttpService]
})

export class WizardCriteriaByFormComponent implements OnInit, OnDestroy {

    activeSubscription: Subscription;
    allJurisdictions = [];
    selectedJurisdictions = [];
    jurisdictionsCodes = [];
    jurisdictionName = [];
    wizardCriteriaFormData = [];
    isWizardCriteriaByFormDataAvailable: boolean;
    isNoRecordFound: boolean;
    selectedFormValue: string;
    exportExcelClicked: boolean;
    isGotoLink = true;
    exportData: any = {
        exportName: ReportsConstant.exportExcel.exportName.wizardCriteriaByForm,
        pageTitle: ReportsConstant.exportExcel.pageTitle.wizardCriteriaByForm,
        fileName: ReportsConstant.exportExcel.pageTitle.wizardCriteriaByForm,
        data: {
            result: [],
            headers: ReportsConstant.wizardCriteriaByFormName,
            keys: ReportsConstant.wizardCriteriaByFormKeys
        }
    };


    constructor(
        private reportsUtilityService: ReportsUtilityService,
        private translate: TranslateService,
        private wizardCriteriaByFormUtilityService: WizardCriteriaByFormUtilityService,
        private wizardCriteriaByFormHttpService: WizardCriteriaByFormHttpService) {

    }

    ngOnInit(): void {
        this.getJurisdictions();
        this.selectedJurisdictions = [];
        this.jurisdictionsCodes = [];
        this.jurisdictionName = [];
        this.wizardCriteriaFormData = [];
        this.selectedFormValue = null;
        this.isWizardCriteriaByFormDataAvailable = false;
        this.isNoRecordFound = false;
    }

    getJurisdictions() {
        this.activeSubscription = this.wizardCriteriaByFormHttpService.getJurisdictions().subscribe((res: any) => {
            if (res && res.length) {
                this.allJurisdictions = this.reportsUtilityService.addGroupName(res, ReportsConstant.formsByJ.allJurisdictions);
            }
        });
    }

    onFormValueChange(ev) {
        this.selectedFormValue = ev.target.value.trim();
    }

    isSearchBtnValid() {
        let returnValue = true;
        if (this.selectedFormValue !== null && this.selectedFormValue !== '') {
            returnValue = false;
        }
        return returnValue;
    }

    isResetBtnValid() {
        let returnValue = true;
        if (this.selectedJurisdictions.length !== 0 || (this.selectedFormValue !== null && this.selectedFormValue !== '')) {
            returnValue = false;
        }
        return returnValue;
    }

    searchForms() {
        let jurisdictionCodesData = [];
        this.isNoRecordFound = false;
        jurisdictionCodesData = this.wizardCriteriaByFormUtilityService.getJurisdictionsCodes(this.selectedJurisdictions);
        this.jurisdictionName = this.wizardCriteriaByFormUtilityService.getJurisdictionsNames(this.selectedJurisdictions);
        const selectedFormValue = this.selectedFormValue;
        const bodyParam = {
            stateCodes: jurisdictionCodesData,
            rtfName: selectedFormValue
        };
        this.wizardCriteriaByFormHttpService.getWizardCriteriaByForm(bodyParam).subscribe((res: any) => {
            if (res && res.length > 0) {
                this.wizardCriteriaFormData = res;
                this.exportData.data.result = res;
                this.isWizardCriteriaByFormDataAvailable = true;
                this.jurisdictionsCodes = this.wizardCriteriaByFormUtilityService.updateJurisdictionCodes(res, this.selectedJurisdictions);
            } else {
                this.isNoRecordFound = true;
                this.isWizardCriteriaByFormDataAvailable = false;
                this.wizardCriteriaFormData = [];
                this.jurisdictionsCodes = [];
            }
        });
    }

    scrollToState(stateId) {
        this.wizardCriteriaByFormUtilityService.scrolltoJurisdiction(stateId, this.jurisdictionsCodes, this.isGotoLink);
    }

    resetJurisdiction() {
        this.selectedJurisdictions = [];
        this.selectedFormValue = null;
        this.wizardCriteriaFormData = [];
        this.exportData.data.result = [];
        this.isWizardCriteriaByFormDataAvailable = false;
        this.isNoRecordFound = false;
    }

    exportExcel() {
        this.exportExcelClicked = true;
    }

    excelDownloaded(status) {
        if (status) {
            this.exportExcelClicked = false;
        }
    }

    ngOnDestroy() {

    }
}
