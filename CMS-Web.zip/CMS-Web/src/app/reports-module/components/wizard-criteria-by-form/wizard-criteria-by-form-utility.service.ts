import { Injectable } from '@angular/core';

@Injectable()
export class WizardCriteriaByFormUtilityService {

    constructor() { }

    getJurisdictionsCodes(jurisdictions) {
      const jurisdictionsCodes = [];
      jurisdictions.forEach(element => {
        jurisdictionsCodes.push(element.code);
      });
      return jurisdictionsCodes;
    }

    getJurisdictionsNames(jurisdictions) {
      const jurisdictionsNames = [];
      jurisdictions.forEach(element => {
        jurisdictionsNames.push(element.name);
      });
      return jurisdictionsNames;
    }

    scrolltoJurisdiction(stateId, selectedjurisdictionsNames, isGotoLink) {
      isGotoLink = true;
      document.getElementById(selectedjurisdictionsNames[stateId]).scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        inline: 'nearest'
      });
    }

    updateJurisdictionCodes(data, selectedJurisdictions) {
      const jurisdictionsCodes = [];
      const updatedJurisdictionCode = [];
      data.forEach(element => {
        if (!(jurisdictionsCodes.includes(element.stateCode))) {
          jurisdictionsCodes.push(element.stateCode);
        }
      });
      if (selectedJurisdictions.length > 0) {
        for (let i = 0; i < selectedJurisdictions.length; i++) {
          if (jurisdictionsCodes.indexOf(selectedJurisdictions[i].code) >= 0) {
              updatedJurisdictionCode.push(selectedJurisdictions[i].code);
          }
        }
        return updatedJurisdictionCode.sort((a, b) => 0 - (a > b ? -1 : 1));
      }
      return jurisdictionsCodes;
  }
}
