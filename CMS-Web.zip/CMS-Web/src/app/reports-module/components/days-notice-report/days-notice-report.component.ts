import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ThresholdExceededData } from 'app/configurations-module/infrastructure/models/configuration.model';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { ReportsService } from 'app/reports-module/services/reports.service';
import { CmsSelectsComponent } from 'app/utility-module/cms-selects/cms-selects.component';
import { Subject, Subscription } from 'rxjs';

@Component({
  selector: 'app-days-notice-report',
  templateUrl: './days-notice-report.component.html',
  styleUrls: ['./days-notice-report.component.scss']
})
export class DaysNoticeReportComponent implements OnInit {
  @ViewChild(CmsSelectsComponent) child: CmsSelectsComponent;
  onCancelButtonClick: Subject<void> = new Subject<void>();
  activeSubscription: Subscription;
  allDaysNoticeReportData = [];
  selectedjurisdictions: any;
  searchText = null;
  exportExcelClicked = false;
  gridData = null;
  isSearchApplied: Boolean = false;
  isDisplayEnabled = false;
  isResetEnabled = false;
  isGridDisplayed = false;
  isDisplayClicked: Boolean = false;
  removeAllSelectedRows = false;
  gridDetails = {
    columnNames: ReportsConstant.daysNoticeReportColNames,
    gridDataKeys: ReportsConstant.daysNoticeReportGridDataKeys,
    isCheckBoxRequired: true,
    isExportToExcelRequired: true,
    isPaginationRequired: false,
    isGotoLinkRequired: false,
    gotoLinkStates: [],
    checkboxKey: ReportsConstant.stateCode,
    goToLinksKey: ReportsConstant.stateCode,
    isCheckMailType: false,
    exportExcelData: {
      exportName: ReportsConstant.exportExcel.exportName.daysNoticeReport,
      pageTitle: ReportsConstant.exportExcel.pageTitle.daysNoticeReport,
      fileName: ReportsConstant.exportExcel.pageTitle.daysNoticeReport,
      data: {
        result: [],
        headers: ReportsConstant.daysNoticeReportColNames,
        keys: ReportsConstant.daysNoticeReportGridDataKeys
      },
    }
  };
  constructor(private reportService: ReportsService,
    private reportsUtilityService: ReportsUtilityService,
    private translate: TranslateService) { }

  ngOnInit(): void {
  }

  getDaysNoticeReportData() {
    const jurisdictionsCodes = [this.child.selectedJurisdictions];
    const actionIds = this.reportsUtilityService.getSelectedIds(this.child.selectedActions);
    const lobIds = this.reportsUtilityService.getSelectedIds(this.child.selectedLobs);
    const circumstanceIds = this.reportsUtilityService.getSelectedIds(this.child.selectedCircumstances);
    const sendData = {
      stateCodes: jurisdictionsCodes,
      actionIds: actionIds,
      lobIds: lobIds,
      whereConditionIds: circumstanceIds
    };
    this.reportService.getDaysNoticReportCount(sendData).subscribe((response: ThresholdExceededData) => {
      if (response) {
        const thresholdCount = this.reportService.numberWithComma(response.thresholdCount);
        const message = this.translate.instant('CONFIGURATION_MENU.MESSAGES.THRESHOLD_MESSAGE_REPORT', { thresholdCount:  thresholdCount});
        if (response.isThresholdExceeded) {
          this.isGridDisplayed = false;
          this.reportsUtilityService.showAlertMessage(message);
        } else {
          this.allDaysNoticeReportData = [];
          this.activeSubscription = this.reportService.getDaysNoticeData(sendData).subscribe((res: any) => {
            if (res) {
              res.forEach(ele => {
                this.allDaysNoticeReportData.push(ele);
              });
              this.isGridDisplayed = true;
              this.gridData = this.filterGridData();
              this.getAllDaysNoticeData(this.allDaysNoticeReportData);
            }
          });
        }
      }
    });
  }

  isDataAvaliable() {
    return this.allDaysNoticeReportData.length === 0 ? false : true;
  }

  filterGridData() {
    let filteredDaysNoticeReportDataByAction = [];
    if (this.child?.selectedActions?.length > 0) {
      this.allDaysNoticeReportData.forEach((reportData) => {
        if (this.child.selectedActions.map((selectedAction) => selectedAction.code).includes(reportData.actionCode)) {
          filteredDaysNoticeReportDataByAction.push(reportData);
        }
      });
    } else {
      filteredDaysNoticeReportDataByAction = this.allDaysNoticeReportData;
    }

    let filteredDaysNoticeReportDataByLobs = [];
    if (this.child?.selectedLobs?.length > 0) {
      filteredDaysNoticeReportDataByAction.forEach((reportData) => {
        if (this.child.selectedLobs.map((selectedLob) => selectedLob.name).includes(reportData.lob)) {
          filteredDaysNoticeReportDataByLobs.push(reportData);
        }
      });
    } else {
      filteredDaysNoticeReportDataByLobs = filteredDaysNoticeReportDataByAction;
    }

    let filteredDaysNoticeReportDataByCircumstances = [];

    if (this.child?.selectedCircumstances?.length > 0) {
      filteredDaysNoticeReportDataByLobs.forEach((reportData) => {
        if (this.child.selectedCircumstances.map((selectedCircumstance) =>
          selectedCircumstance.name).includes(reportData.whereConditionDesc)) {
          filteredDaysNoticeReportDataByCircumstances.push(reportData);
        }
      });
    } else {
      filteredDaysNoticeReportDataByCircumstances = filteredDaysNoticeReportDataByLobs;
    }

    return filteredDaysNoticeReportDataByCircumstances;
  }

  getAllDaysNoticeData(allDaysNoticeReportData: any) {
    this.selectedjurisdictions = this.reportsUtilityService.getjurisdictionsCodes(allDaysNoticeReportData);
  }

  changeDropdown() {
    this.isDisplayEnabled = this.child.selectedJurisdictions.length > 0 ? true : false;
    this.isResetEnabled = (this.child.selectedActions.length > 0 ||
      this.child.selectedLobs.length > 0 || this.child.selectedCircumstances.length > 0) ? true : false;
  }

  reset() {
    this.child.cancel();
    this.child.isSubmitClicked = false;
    this.isDisplayEnabled = false;
    this.isDisplayClicked = false;
    this.isResetEnabled = false;
    this.removeAllSelectedRows = true;
    this.isGridDisplayed = false;
  }

  displayForm() {
    this.removeAllSelectedRows = true;
    this.getDaysNoticeReportData();
  }
}
