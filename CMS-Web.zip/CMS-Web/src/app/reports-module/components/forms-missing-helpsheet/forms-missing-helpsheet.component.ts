import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { HelpSheet } from 'app/reports-module/infrastructure/models/help-sheet.model';
import { FormsMissingHelpsheetHttpService } from './forms-missing-helpsheet-http.service';
import { FormsMissingHelpsheetUtilityService } from './forms-missing-helpsheet-utility.service';
import { ThresholdExceededData } from 'app/configurations-module/infrastructure/models/configuration.model';
import { TranslateService } from '@ngx-translate/core';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';


@Component({
  selector: 'app-forms-missing-helpsheet',
  templateUrl: './forms-missing-helpsheet.component.html',
  styleUrls: ['./forms-missing-helpsheet.component.scss'],
  providers: [FormsMissingHelpsheetHttpService, FormsMissingHelpsheetUtilityService]
})
export class FormsMissingHelpsheetComponent implements OnInit, OnDestroy {
  private activeSubscription: Subscription;
  allJurisdictions = [];
  selectedJurisdictions = [];
  selectedStates = [];
  missingHelpSheets = [];
  isDataAvailable = false;
  isSubmitClicked = false;
  getStateNames = [];
  searchText: any = '';
  isSearchedApplied: Boolean = false;
  filteredStates = [];
  exportExcelClicked = false;
  helpSheet = true;
  noRecordsFound = false;
  exportData: any = {
    exportName: ReportsConstant.exportExcel.exportFormsMissingHelpsheetName,
    pageTitle: ReportsConstant.exportExcel.pageFormsMissingHelpsheetTitle,
    fileName: ReportsConstant.exportExcel.fileNameFormsMissingHelpsheet,
    data: {
      result: [],
      selectedjurisdictionsNames: [],
      filterStateCode: []
    },
  };

  constructor(private formsMissingHelpsheetHttpService: FormsMissingHelpsheetHttpService,
    private formsMissingHelpsheetUtilityService: FormsMissingHelpsheetUtilityService,
    private translate: TranslateService,
    private reportsUtilityService: ReportsUtilityService) { }

  ngOnInit(): void {
    this.getJurisdictions();
  }

  onSelectionChange() {
    this.selectedStates = this.formsMissingHelpsheetUtilityService.getSelectedStates(this.selectedJurisdictions);
  }

  getJurisdictions() {
    this.activeSubscription = this.formsMissingHelpsheetHttpService.getJurisdictions().subscribe((res: any) => {
      this.allJurisdictions = this.formsMissingHelpsheetUtilityService.addGroupName(res, ReportsConstant.formsByJ.allJurisdictions);
    });

  }

  display() {
    this.searchText = '';
    this.isDataAvailable = false;
    this.exportData.data.filterStateCode = [];
    this.getStateNames = [];
    this.onSelectionChange();
    if (this.selectedJurisdictions.length === 0) {
      this.isSubmitClicked = true;
    } else {
      this.formsMissingHelpsheetHttpService.getMissingHelpSheet(this.selectedStates).subscribe((response: HelpSheet[]) => {
        if (response.length === 0) {
          this.isDataAvailable = false;
          this.noRecordsFound = true;
        }
        else {
          this.isDataAvailable = true;
          const sortStatesByCode = response.sort((a, b) => a.stateCode.localeCompare(b.stateCode));
          const filteredStateFromResponse = [...new Set(response.map(ele => ele.stateCode))];
          const filterSelectedStateCode = [];
          for (let i = 0; i < this.selectedStates.length; i++) {
            if (filteredStateFromResponse.includes(this.selectedStates[i])) {
              filterSelectedStateCode.push(this.selectedStates[i]);
            }
          }
          this.selectedStates = filterSelectedStateCode;
          this.getFilteredStates(this.selectedStates, sortStatesByCode, this.allJurisdictions);
          this.missingHelpSheets = this.exportData.data.filterStateCode;
          this.exportData.data.result = this.exportData.data.filterStateCode;
        }
      });
    }
  }

  reset() {
    this.searchText = null;
    this.selectedJurisdictions = [];
    this.isSubmitClicked = false;
    this.isDataAvailable = false;
    this.noRecordsFound = false;
  }

  scrollToState(stateId) {
    this.formsMissingHelpsheetUtilityService.scrolltoJurisdiction(stateId);
  }

  search() {
    this.isSearchedApplied = true;
    this.exportData.data.filterStateCode = [];
    this.getStateNames = [];
    this.missingHelpSheets = Array.prototype.concat(...this.missingHelpSheets);
    if (this.searchText && this.searchText.length > 0 && this.searchText !== '') {
      this.filteredStates = this.missingHelpSheets.filter(ele => ele.helpFile?.toLowerCase().includes(this.searchText.trim().toLowerCase())
        || ele.formId?.toString().includes(this.searchText.trim()));
    } else {
      this.filteredStates = this.missingHelpSheets;
    }
    const commonStateCode = this.filteredStates.map(ele => ele.stateCode);
    this.selectedStates = [...new Set(commonStateCode)];
    this.getFilteredStates(this.selectedStates, this.filteredStates, this.allJurisdictions);
    this.exportData.data.result = this.exportData.data.filterStateCode;
  }

  clearSearch() {
    this.searchText = '';
    this.search();
    this.isSearchedApplied = false;
  }

  exportExcel() {
    this.exportExcelClicked = true;
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
    }
  }

  getFilteredStates(selectedStates, filteredStates, allJurisdictions) {
    for (let i = 0; i < selectedStates.length; i++) {
      this.exportData.data.filterStateCode.push(filteredStates.filter(ele => ele.stateCode === selectedStates[i]));
      this.getStateNames.push(allJurisdictions.filter(ele => ele.code === selectedStates[i]));
      this.exportData.data.selectedjurisdictionsNames = this.getStateNames.map(ele => ele[0].name);
    }
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

}
