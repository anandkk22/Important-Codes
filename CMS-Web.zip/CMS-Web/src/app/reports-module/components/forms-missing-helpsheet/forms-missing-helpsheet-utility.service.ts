import { Injectable } from '@angular/core';

@Injectable()
export class FormsMissingHelpsheetUtilityService {

    constructor() { }

    addGroupName(data, type) {
        data.forEach(element => {
            element.all = type;
        });
        return data;
    }

    getSelectedStates(res) {
        const states = [];
        res.forEach(element => {
            if (element.code && !states.includes(element.code)) {
                states.push(element.code);
            }
        });
        return states;
    }

    scrolltoJurisdiction(state) {
        document.getElementById(state).scrollIntoView({
            behavior: 'smooth'
        });
    }
}
