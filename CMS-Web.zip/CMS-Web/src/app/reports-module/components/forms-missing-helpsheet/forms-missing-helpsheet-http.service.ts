import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';

@Injectable()
export class FormsMissingHelpsheetHttpService {

    constructor(private http: HttpClient) { }

    getJurisdictions() {
        return this.http.get(`${ReportsConstant.webApis.getJurisdictions}`);
    }

    getMissingHelpSheet(state) {
        return this.http.post(`${ReportsConstant.webApis.getMissingHelpSheets}`, state);
    }

    getMissingHelpsheetsCount(state) {
        return this.http.post(`${ReportsConstant.webApis.getMissingHelpsheetsCount}`, state);
    }
}
