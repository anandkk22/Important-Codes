import { Component, OnInit } from '@angular/core';
import { environment } from '@env';
import { TranslateService } from '@ngx-translate/core';
import { AppConstants } from 'app/app.constants';

@Component({
  selector: 'app-reports-menu',
  templateUrl: './reports-menu.component.html',
  styleUrls: ['./reports-menu.component.scss']
})
export class ReportsMenuComponent implements OnInit {
  reportMenu = [];
  index = 0;
  reportsRouterLinks = [AppConstants.uiRoutes.badFieldRuleAssignments, AppConstants.uiRoutes.checkDaysNoticeRules,
    AppConstants.uiRoutes.nonReferencedFormsInMatrix, AppConstants.uiRoutes.formsReferencedByCNRMatrix,
    AppConstants.uiRoutes.formsMissingHelpsheet, AppConstants.uiRoutes.checkMailType,
    AppConstants.uiRoutes.PermittedReasonWithoutFormRulesComponent, AppConstants.uiRoutes.daysNoticeReport,
    AppConstants.uiRoutes.wizardCriteriaByField, AppConstants.uiRoutes.wizardCriteriaByForm, AppConstants.uiRoutes.formsMissingFields,
    AppConstants.uiRoutes.listFormsByJurisdiction, AppConstants.uiRoutes.listFormsByJurisdictionAction,
    AppConstants.uiRoutes.rulesMarkedRegulatory, AppConstants.uiRoutes.rulesSummaryReport];
  constructor(private translate: TranslateService) { }

  ngOnInit(): void {
  }

  doNavigation(item) {
    if (item) {
      window.open(`${environment.appUrl}${AppConstants.uiRoutes.reports}/${item}`);
    }
  }
}
