import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { ReportsConstant } from '../../infrastructure/reports.constant';
import { timeout} from 'rxjs/operators';
@Injectable()
export class RulesSummaryReportService {

  constructor(private http: HttpClient,
    private reportsUtilityService: ReportsUtilityService) { }

  getCodes(data, key) {
    const returnData = [];
    data.forEach(element => {
        returnData.push(element[key]);
    });

    return returnData;
  }

  sortResponse(arrSort, appliedSortArray) {
    const multipuleColSortingKeys = [...appliedSortArray];
    multipuleColSortingKeys.reverse();
    let AscSortByFirtKey = this.reportsUtilityService.sortAscendingByKey(multipuleColSortingKeys[0].key, arrSort);
    if (multipuleColSortingKeys.length > 1) {
      const grp = [];
      multipuleColSortingKeys.forEach(element => {
        if (element.key) {
          grp.push(element.key);
        }
      });
      const grouped = {};
      arrSort.forEach(function (a) {
        grp.reduce(function (o, g, i) {
          o[a[g]] = o[a[g]] || (i + 1 === grp.length ? [] : {});
          return o[a[g]];
        }, grouped).push(a);
      });
      const data = this.datsFormatting(grouped, grp);
      AscSortByFirtKey = [...data];
    }

    return AscSortByFirtKey;
  }


  datsFormatting(datas, datasSortKey) {
    let finalData = [];
    Object.keys(datas).forEach(key => {
      if (typeof datas[key] === 'object' && datasSortKey.length > 2) {
        Object.keys(datas[key]).forEach(key1 => {
          if (typeof datas[key][key1] === 'object' && datasSortKey.length > 3) {
            Object.keys(datas[key][key1]).forEach(key2 => {
              if (typeof datas[key][key1][key2] === 'object') {
                finalData = [...finalData, ...this.getFinalObject(datas[key][key1][key2])];
              }
            });
          } else {
            finalData = [...finalData, ...this.getFinalObject(datas[key][key1])];
          }
        });
      } else {
        finalData = [...finalData, ...this.getFinalObject(datas[key])];
      }
    });
    finalData.unshift();

    return finalData;
  }

  getFinalObject(data) {
    const finalData = [];
    Object.keys(data).forEach(ele => {
      data[ele].forEach(eles => {
        finalData.push(eles);
      });
    });

    return finalData;
  }

  getRulesSummaryParam(selectedJurisdictions, selectedLobs, selectedCircumstances, selectedActions,
    selectedDisplays, selectedFields, fieldRules) {

    const selectedJurisdictionCodes = selectedJurisdictions.length > 0 ? this.getCodes(selectedJurisdictions, 'code') : [];
    const selectedActionsCodes = selectedActions.length > 0 ? this.getCodes(selectedActions, 'id') : [];
    const selectedLobsCodes = selectedLobs.length > 0 ? this.getCodes(selectedLobs, 'id') : [];
    const selectedCircumstancesCodes = selectedCircumstances.length > 0 ? this.getCodes(selectedCircumstances, 'id') : [];

    const displayReqParam = {
      'stateCodes': [...selectedJurisdictionCodes],
      'actionIds': [...selectedActionsCodes],
      'lobIds': [...selectedLobsCodes],
      'circumstances': [...selectedCircumstancesCodes],
      'daysNotice': this.isAvalibaleInSelectedDisplays(selectedDisplays, ReportsConstant.displayOptions[0]),
      'mailType': this.isAvalibaleInSelectedDisplays(selectedDisplays, ReportsConstant.displayOptions[1]),
      'permittedReasons': this.isAvalibaleInSelectedDisplays(selectedDisplays, ReportsConstant.displayOptions[2]),
      'forms': this.isAvalibaleInSelectedDisplays(selectedDisplays, ReportsConstant.displayOptions[3]),
      'formPages': this.isAvalibaleInSelectedDisplays(selectedDisplays, ReportsConstant.displayOptions[4]),
      'fields': [...selectedFields],
      'fieldRules': fieldRules
    };

    return displayReqParam;
  }

  isAvalibaleInSelectedDisplays(selectedDisplays, selectedData) {
    let isSelected = false;
    selectedDisplays.forEach(element => {
      if (element.name === selectedData.name) {
        isSelected = true;
      }
    });

    return isSelected;
  }

  getFields(selectedFields) {
    const fields = [];
    selectedFields.forEach(element => {
      fields.push(element.name);
    });

    return fields;
  }


  getRulesSummary(displayReqParam) {
    return this.http.post(`${ReportsConstant.webApis.getRulesSummary}`, displayReqParam)
            .pipe(timeout(ReportsConstant.ruleSummaryTimeInterval));
  }

  isActive(selectedDisplays, name) {
    const data = selectedDisplays.filter(x => x.name === name);
    if (data.length > 0) {
      return true;
    }

    return false;
  }

  getSelectedDisplayGroupCode(selectedFields) {
    let codes = [];
    selectedFields.forEach(element => {
      codes = [...codes, ...element.displayGroup];
    });

    codes.unshift();
    return codes;
  }

}
