import { Component, OnInit, OnDestroy } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SpinnerService } from '@wk/nils-core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { ReportsService } from 'app/reports-module/services/reports.service';
import { Subscription } from 'rxjs';
import { RulesSummaryReportService } from './rules-summary-report.service';

@Component({
  selector: 'app-rules-summary-report',
  templateUrl: './rules-summary-report.component.html',
  styleUrls: ['./rules-summary-report.component.scss'],
  providers: [RulesSummaryReportService]
})
export class RulesSummaryReportComponent implements OnInit, OnDestroy {

  isDataAvailable: Boolean = false;
  allJurisdictions = [];
  allActions = [];
  allCircumstances = [];
  allRulesSummary = [];
  allLobs = [];
  activeSubscription: Subscription;
  rulesSummarySortArray = [...ReportsConstant.rulesSummarySortArray];
  selectedJurisdictions = [];
  selectedLobs = [];
  selectedCircumstances = [];
  selectedActions = [];
  allFields = [];
  selectedFields = [];
  allDisplays = [...ReportsConstant.displayOptions];
  selectedDisplays = [];
  rulesSummarySorttedArray = [];
  displayedData = [];
  fieldDependancy = true;
  isDisplayContainsForm = true;
  isOpenSortingClicked = false;
  fieldDependancyValue = false;
  showMailType = false;
  showDaysNotice = false;
  showPermitedReasons = false;
  showForm = false;
  showFormPages = false;
  showDependancyValue = false;
  isDisplayClicked = false;
  showFields = false;
  selectedDisplayGroups = [];
  selectJurisdiction = ReportsConstant.multiSelectPlaceHolder.jurisdiction;
  selectLOB = ReportsConstant.multiSelectPlaceHolder.lob;
  selectAction = ReportsConstant.multiSelectPlaceHolder.action;
  selectCircumstance = ReportsConstant.multiSelectPlaceHolder.circumstance;
  selectDisplay = ReportsConstant.multiSelectPlaceHolder.display;
  selectFileds = ReportsConstant.multiSelectPlaceHolder.fields;

  constructor(
    private reportsService: ReportsService,
    private rulesSummaryReportService: RulesSummaryReportService,
    private reportsUtilityService: ReportsUtilityService,
    private spinnerService: SpinnerService,
    private translate: TranslateService
  ) { }

  ngOnInit() {
    this.getJurisdictions();
    this.allFields = this.reportsUtilityService.addGroupName(
      this.reportsUtilityService.sortAscendingByKey('name',
        ReportsConstant.fieldOptions), ReportsConstant.allSelections.allFields);
  }

  onJurisdictionsChange() {
    if (this.selectedJurisdictions.length > 0 && this.allActions.length === 0) {
      this.activeSubscription = this.reportsService.getActions().subscribe((res: any) => {
        if (res) {
          this.allActions = this.reportsUtilityService.addGroupName(res, ReportsConstant.allSelections.allActions);
        }
      });
    }
  }

  onLobChange() {
    if (this.selectedLobs.length > 0 && this.allCircumstances.length === 0) {
      this.activeSubscription = this.reportsService.getCircumstances().subscribe((res: any) => {
        if (res) {
          this.allCircumstances = this.reportsUtilityService.addGroupName(res, ReportsConstant.allSelections.allCircumstance);
        }
      });
    }
  }

  onActionChange() {
    if (this.selectedActions.length > 0 && this.allLobs.length === 0) {
      this.activeSubscription = this.reportsService.getLobs(2).subscribe((res: any) => {
        if (res) {
          this.allLobs = this.reportsUtilityService.addGroupName(
            this.reportsUtilityService.sortAscendingByKey('name', res), ReportsConstant.allSelections.allLobs);
        }
      });
    }
  }

  onDisplayChange() {
    const formPagesData = this.selectedDisplays.filter(x => x.name === ReportsConstant.displayOptions[4].name);
    const data = this.selectedDisplays.filter(x => x.name === ReportsConstant.displayOptions[3].name);
    if (data.length === 0) {
      this.selectedFields = [];
    }
    if (formPagesData.length > 0 && data.length === 0) {
      this.selectedDisplays.push(ReportsConstant.displayOptions[3]);
      this.isDisplayContainsForm = false;
    } else {
      if (data.length > 0) {
        this.isDisplayContainsForm = false;
      }
      else {
        this.fieldDependancyValue = false;
        this.isDisplayContainsForm = true;
      }
    }
  }

  getJurisdictions() {
    this.activeSubscription = this.reportsService.getJurisdictions().subscribe((res: any) => {
      if (res) {
        this.allJurisdictions = this.reportsUtilityService.addGroupName(res, ReportsConstant.allSelections.allJurisdictions);
        this.isDataAvailable = true;
      }
    });
  }

  isDisplayEnabled() {
    return this.selectedJurisdictions.length > 0 && this.selectedLobs.length > 0 && this.selectedCircumstances.length > 0 &&
      this.selectedActions.length > 0 && this.selectedDisplays.length > 0 ? false : true;
  }

  isResetEnabled() {
    return this.selectedJurisdictions.length > 0 || this.selectedLobs.length > 0 || this.selectedCircumstances.length > 0 ||
      this.selectedActions.length > 0 || this.selectedDisplays.length > 0 ? false : true;
  }

  displayData() {
    this.selectedDisplayGroups = this.rulesSummaryReportService.getSelectedDisplayGroupCode(this.selectedFields);
    const displayReqParam = this.rulesSummaryReportService.getRulesSummaryParam(this.selectedJurisdictions, this.selectedLobs,
      this.selectedCircumstances, this.selectedActions, this.selectedDisplays, this.selectedDisplayGroups, this.fieldDependancy);
    const sortArray = this.rulesSummarySorttedArray.length > 0 ? [...this.rulesSummarySorttedArray] :
      [...this.rulesSummarySortArray].reverse();
    this.activeSubscription = this.rulesSummaryReportService.getRulesSummary(displayReqParam).subscribe((res: any) => {
      if (res) {
        this.showDaysNotice = this.rulesSummaryReportService.isActive(this.selectedDisplays, ReportsConstant.displayOptions[0].name);
        this.showMailType = this.rulesSummaryReportService.isActive(this.selectedDisplays, ReportsConstant.displayOptions[1].name);
        this.showPermitedReasons = this.rulesSummaryReportService.isActive(this.selectedDisplays, ReportsConstant.displayOptions[2].name);
        this.showForm = this.rulesSummaryReportService.isActive(this.selectedDisplays, ReportsConstant.displayOptions[3].name);
        this.showFormPages = this.rulesSummaryReportService.isActive(this.selectedDisplays, ReportsConstant.displayOptions[4].name);
        this.showDependancyValue = this.fieldDependancyValue;
        this.displayedData = this.rulesSummaryReportService.sortResponse(res, sortArray);
        this.showFields = this.selectedFields.length > 0 ? true : false;
        this.isDisplayClicked = true;
      }
    },
      (errors: any) => {
        if (errors.name === ReportsConstant.ruleSummaryErrors.name) {
          const message = this.translate.instant('REPORTS.RULES_SUMMARY.ALERT_MESSAGE');
          this.reportsUtilityService.showAlertMessage(message);
          this.spinnerService.stop();
          this.isDisplayClicked = false;
          this.displayedData = [];
        }
      }
    );
  }

  applySort(sortData) {
    sortData.isSorttingApplied = !sortData.isSorttingApplied;
    const noAppliedSort = [];

    if (sortData.isSorttingApplied) {
      this.rulesSummarySorttedArray.unshift(sortData);
    } else {
      const index = this.rulesSummarySorttedArray.findIndex(x => x.label === sortData.label);
      if (index !== -1) {
        this.rulesSummarySorttedArray.splice(index, 1);
      }
    }

    if (this.rulesSummarySorttedArray.length === 0) {
      this.rulesSummarySortArray = [...ReportsConstant.rulesSummarySortArray];
    }

    ReportsConstant.rulesSummarySortArray.forEach(initialSort => {
      const data = this.rulesSummarySorttedArray.filter(x => x.label === initialSort.label);
      if (data.length === 0) {
        noAppliedSort.push(initialSort);
      }
    });

    this.rulesSummarySortArray = [];
    this.rulesSummarySortArray = [...this.rulesSummarySorttedArray, ...noAppliedSort];
  }

  openSortingOption() {
    this.isOpenSortingClicked = !this.isOpenSortingClicked;
  }

  downloadForm(name) {
    const filePath = ReportsConstant.cnr.cnrPdfFilePath + name;
    this.reportsService.downloadFile(filePath).subscribe(response => {
      if (response) {
        this.reportsUtilityService.loadFile(response, name);
      }
    }, async (error) => {
      const message = JSON.parse(await error.error.text()).Message;
      this.reportsUtilityService.showAlertMessage(message);
      this.spinnerService.stop();
    });
  }

  reset() {
    this.selectedJurisdictions = [];
    this.selectedLobs = [];
    this.selectedCircumstances = [];
    this.selectedActions = [];
    this.selectedFields = [];
    this.selectedDisplays = [];
    this.rulesSummarySorttedArray = [];
    this.isDisplayContainsForm = true;
    this.fieldDependancyValue = false;
    this.rulesSummarySortArray = [...ReportsConstant.rulesSummarySortArray];
    this.rulesSummarySortArray.forEach(element => {
      element.isSorttingApplied = false;
    });
  }

  onClickFieldDependancy(event: boolean) {
    if (event !== this.fieldDependancyValue) {
      this.fieldDependancyValue = !this.fieldDependancyValue;
    }
  }

  isSelected(item, isSelected) {
    const formPagesData = this.selectedDisplays.filter(x => x.name === ReportsConstant.displayOptions[4].name);
    if (formPagesData.length > 0) {
      if ((item.name === ReportsConstant.displayOptions[3].name) && !isSelected) {
        return true;
      }
    }

    return isSelected;

  }

  isValidDisplayGroup(displayGroup) {
    return this.selectedDisplayGroups.includes(displayGroup);
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

}
