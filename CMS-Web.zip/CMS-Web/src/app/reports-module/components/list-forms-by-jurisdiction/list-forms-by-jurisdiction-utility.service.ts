import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { ReportsService } from 'app/reports-module/services/reports.service';

@Injectable()
export class ListFormsByJurisdictionsUtilityService {

  constructor(private reportService: ReportsService,
    private reportsUtilityService: ReportsUtilityService,
    private translate: TranslateService,
    private popupService: PopupService,
    private spinnerService: SpinnerService
  ) { }

  getJurisdictionsCodes(jurisdictions) {
    const jurisdictionsCodes = [];
    jurisdictions.forEach(element => {
      jurisdictionsCodes.push(element.code);
    });
    return jurisdictionsCodes;
  }

  getJurisdictionsNames(jurisdictions) {
    const jurisdictionsNames = [];
    jurisdictions.forEach(element => {
      jurisdictionsNames.push(element.name);
    });
    return jurisdictionsNames;
  }

  getExportData(allData: any) {
    const exportData = this.findMultiStateForms(allData);
    return exportData;
  }

  findMultiStateForms(allData: any) {
    const uniqueIds = new Set();
    const duplicateIds = new Set();
    const uniqueData = new Set();
    allData.filter(element => {
      const isDuplicate = uniqueIds.has(element.uniformNo);
      if (!isDuplicate) {
        uniqueIds.add(element.uniformNo);
        uniqueData.add(element);
      }
      else {
        duplicateIds.add(element);
      }
    });
    const distinctData = [...uniqueData];
    const dataX = [...duplicateIds];
    dataX.forEach((item: any) => {
      item.stateName = 'X';
    });
    distinctData.push(...dataX);

    return distinctData;

  }

  scrolltoJurisdiction(stateId, selectedjurisdictionsNames) {
  document.getElementById(selectedjurisdictionsNames[stateId]).scrollIntoView({
    behavior: 'smooth',
    block: 'start',
    inline: 'nearest'
  });
}

downloadRtfName(filePath: any, rtfName: any) {
  this.reportService.downloadFile(filePath).subscribe(response => {
    if (response) {
      this.reportsUtilityService.loadFile(response, rtfName);
    }
  }, async (error) => {
    const message = JSON.parse(await error.error.text()).Message;
    this.showAlert(message);
    this.spinnerService.stop();
  });
}

showAlert(message) {
  this.popupService.showAlert({
    title: this.translate.instant('MESSAGES.CONFIRMATION.ALERT'),
    message: message,
    positiveLabel: this.translate.instant('BUTTON.OK'),
    negativeLabel: '',
  });
}

getAllData(data, jurisdictions) {
  const allUniformNoData = [];
  const allRtfNameData = [];
  const filteredData = [];
  jurisdictions.forEach(i => {
    const uniformData = [];
    const rtfNameData = [];
    data.forEach(element => {
      if (element.stateCode === i) {
        uniformData.push(element.uniformNo);
        rtfNameData.push(element.rtfname);
        filteredData.push(element);
      }
    });
    allUniformNoData.push(uniformData);
    allRtfNameData.push(rtfNameData);
  });

  return [filteredData, allUniformNoData, allRtfNameData];
}

getDistinctFormCount(uniformNoData) {
  let uniformNo = [];
  uniformNoData.forEach(ele => {
    uniformNo = uniformNo.concat(ele);
  });

  return new Set(uniformNo).size;
}
}
