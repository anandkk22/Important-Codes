import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';

@Injectable()
export class ListFormsByJurisdictionsHttpService {

  constructor(private http: HttpClient) { }

  getFormsByJurisdictions() {
    return this.http.get(`${ReportsConstant.webApis.getFormsByJurisdicions}`);
  }
}
