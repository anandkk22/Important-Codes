import { Component, OnDestroy, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { ReportsUtilityService } from 'app/reports-module/services/report-utility.service';
import { ReportsService } from 'app/reports-module/services/reports.service';
import { Subscription } from 'rxjs';
import { ListFormsByJurisdictionsHttpService } from './list-forms-by-jurisdiction-http.service';
import { ListFormsByJurisdictionsUtilityService } from './list-forms-by-jurisdiction-utility.service';

@Component({
  selector: 'app-list-forms-by-jurisdiction',
  templateUrl: './list-forms-by-jurisdiction.component.html',
  styleUrls: ['./list-forms-by-jurisdiction.component.scss'],
  providers: [ListFormsByJurisdictionsHttpService, ListFormsByJurisdictionsUtilityService]
})
export class ListFormsByJurisdictionComponent implements OnInit, OnDestroy {
  activeSubscription: Subscription;
  allJurisdictions = [];
  selectedJurisdictions = [];
  jurisdictionsCodes = [];
  selectedjurisdictionsNames = [];
  isClickedDisplay = false;
  noOfJurisdictions: number;
  allDistinctFormsCount: number;
  allFormsData = [];
  uniformNo: any[];
  formData: any[] = [];
  rtfName: any[];
  rtfData: any[] = [];
  exportExcelClicked = false;
  exportData: any = {
    exportName: ReportsConstant.formsByJurisdictionsExportName,
    pageTitle: this.translate.instant('REPORTS.FORMS_BY_JURISDICTIONS.HEADING'),
    fileName: this.translate.instant('REPORTS.FORMS_BY_JURISDICTIONS.HEADING'),
    data: {
      result: [],
      headers: ReportsConstant.formsByJurisdictionsHeaders,
      keys: ReportsConstant.formsByJurisdictionsKeys
    },
  };
  allExportData: any[] = [];
  uniformNoData: any[];
  isDataAvailable = false;
  filteredData: any;
  constructor(
    private reportService: ReportsService,
    private reportsUtilityService: ReportsUtilityService,
    private listFormsByJurisdictionsUtilityService: ListFormsByJurisdictionsUtilityService,
    private listFormsByJurisdictionsHttpService: ListFormsByJurisdictionsHttpService,
    private translate: TranslateService) { }

  ngOnInit(): void {
    this.getJurisdictions();
    this.getAllFormsByJurisdictions();
  }

  isValid() {
    return this.selectedJurisdictions.length === 0 ? true : false;
  }
  getJurisdictions() {
    this.activeSubscription = this.reportService.getJurisdictions().subscribe((res: any) => {
      this.allJurisdictions = this.reportsUtilityService.addGroupName(res, ReportsConstant.formsByJ.allJurisdictions);
    });
  }

  resetFields() {
    this.selectedJurisdictions = [];
    this.filteredData = [];
    this.uniformNoData = [];
    this.rtfData = [];
    this.isClickedDisplay = false;
  }

  displayForms() {
    this.filteredData = [];
    this.uniformNoData = [];
    this.rtfData = [];
    this.selectedJurisdictions = this.reportsUtilityService.sortAscendingByKey('code', this.selectedJurisdictions);
    this.jurisdictionsCodes = this.listFormsByJurisdictionsUtilityService.getJurisdictionsCodes(this.selectedJurisdictions);
    this.noOfJurisdictions = this.jurisdictionsCodes.length;
    this.selectedjurisdictionsNames = this.listFormsByJurisdictionsUtilityService.getJurisdictionsNames(this.selectedJurisdictions);
    [this.filteredData, this.uniformNoData, this.rtfData] = this.listFormsByJurisdictionsUtilityService.getAllData(
      this.allFormsData, this.jurisdictionsCodes);
    this.allDistinctFormsCount = this.listFormsByJurisdictionsUtilityService.getDistinctFormCount(this.uniformNoData);
    this.exportData.data.isFormsByJurisdictions = {'isFormsByJurisdictions': false};
    this.exportData.data.result = this.listFormsByJurisdictionsUtilityService.getExportData(this.filteredData);
    this.exportData.data.count = {'jurisdictionsCount': this.noOfJurisdictions, 'formsCount': this.allDistinctFormsCount};
    this.isClickedDisplay = true;

  }

  getAllFormsByJurisdictions() {
    this.listFormsByJurisdictionsHttpService.getFormsByJurisdictions().subscribe((res: any) => {
      this.allFormsData = res;
      this.isDataAvailable = true;
    });
  }

  scrollToState(stateId) {
    this.listFormsByJurisdictionsUtilityService.scrolltoJurisdiction(stateId, this.selectedjurisdictionsNames);
  }

  downloadFile(rtfName) {
    const filePath = ReportsConstant.cnr.authStagingPath + rtfName;
    this.listFormsByJurisdictionsUtilityService.downloadRtfName(filePath, rtfName);
  }

  exportExcel() {
    this.exportExcelClicked = true;
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
    }
  }

  toggleReset() {
    return !(this.selectedJurisdictions.length > 0);
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }
}
