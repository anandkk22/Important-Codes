import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ReportsConstant } from '../infrastructure/reports.constant';

@Injectable()
export class BadFieldRuleAssignmentService {

    multiStateRecord = [];

    constructor(private http: HttpClient) { }

    public getFieldRuleAssignment() {
      return this.http.get(`${ReportsConstant.webApis.getFieldRuleAssignment}`);
    }

    public updateBadFieldRecords(data) {
      const badFieldRuleRecords = [];
      for (let i = 0; i < data.length; i++) {
        if (data[i].stateCode && data[i].stateCode !== 'Multi-State') {
          badFieldRuleRecords.push(data[i]);
        } else {
          if (data[i].stateCode !== null) {
            this.multiStateRecord.push(data[i]);
          }
        }
      }
      return badFieldRuleRecords;
    }

    public getSorterData(badFieldRuleAssignmentData, sortKey) {
      const sortedData = this.sortData(badFieldRuleAssignmentData, sortKey);
      for (let i = 0; i < this.multiStateRecord.length; i++) {
        sortedData.push(this.multiStateRecord[i]);
      }
      return sortedData;
    }

    sortData(data, key) {
      return data.sort((a, b) => 0 - (a[key]?.toLowerCase() > b[key]?.toLowerCase() ? -1 : 1));
    }
}
