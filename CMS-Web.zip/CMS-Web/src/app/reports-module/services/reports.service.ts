import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReportsConstant } from '../infrastructure/reports.constant';
@Injectable()
export class ReportsService {

  constructor(private http: HttpClient) { }

  getJurisdictions() {
    return this.http.get(`${ReportsConstant.webApis.getJurisdictions}`);
  }

  getLobs(adminMenuItem) {
    return this.http.get(`${ReportsConstant.webApis.getLobs}`.replace('{adminMenuItem}', adminMenuItem));
  }

  getActions() {
    return this.http.get(`${ReportsConstant.webApis.getActions}`);
  }

  getCircumstances() {
    return this.http.get(`${ReportsConstant.webApis.getCircumstances}`);
  }

  downloadFile(formattedPath) {
    return this.http.put(`${ReportsConstant.webApis.downloadFile}`.replace('{fileName}', formattedPath), '',
      { responseType: ReportsConstant.responseType.blobType as 'json', observe: 'response' });
  }

  getWithoutFormRule() {
    return this.http.get(`${ReportsConstant.webApis.withoutFormRule}`);
  }

  getMailtypes() {
    return this.http.get(`${ReportsConstant.webApis.getMailTypes}`);
  }

  getDaysNoticeData(listOfSelectedJurisdictions) {
    return this.http.post(`${ReportsConstant.webApis.getDaysNoticeReportData}`, listOfSelectedJurisdictions);
  }

  getWithoutFormRuleCount() {
    return this.http.get(`${ReportsConstant.webApis.withoutFormRuleCount}`);
  }

  getDaysNoticReportCount(listOfSelectedJurisdictions) {
    return this.http.post(`${ReportsConstant.webApis.daysNoticReportCount}`, listOfSelectedJurisdictions);
  }

  numberWithComma(num) {
    return num.toString().replace(/,/g, '').replace(ReportsConstant.numberWithComma, ',');
  }

}
