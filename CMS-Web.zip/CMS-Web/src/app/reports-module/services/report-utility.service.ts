import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';
import * as moment from 'moment';
import { ReportsConstant } from '../infrastructure/reports.constant';
import { saveAs } from 'file-saver';
import { PopupService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';

@Injectable()
export class ReportsUtilityService {

    constructor(
        private popupService: PopupService,
        private translate: TranslateService) { }

    pageSizeDropdown: HTMLElement;

    searchGridData(searchTerm, selectedJurisdictions, entrydata, copyData) {
        let selectedStates = [];
        searchTerm.trim();
        selectedStates = selectedJurisdictions;
        setTimeout(() => {
            this.loadUpadtedPageSizes();
        }, 0);
        if (selectedStates.length === 0 && searchTerm.length === 0) {
            entrydata = copyData;
        }
        else if (selectedStates.length > 0 && searchTerm && searchTerm.length > 0) {
            const data = copyData.filter(item => selectedStates.map(ele => ele.code).includes(item.stateCode));
            entrydata = data.filter(ele =>
                ele.whereConditionDescription.trim().toLowerCase().includes(searchTerm.trim().toLowerCase())
            );
        } else {
            if (selectedStates.length > 0) {
                entrydata =
                    copyData.filter(item => selectedStates.map(ele => ele.code).includes(item.stateCode));
            }
            if (searchTerm && searchTerm.length > 0) {
                entrydata = copyData.filter(ele =>
                    ele.whereConditionDescription.trim().toLowerCase().includes(searchTerm.trim().toLowerCase())
                );
            }
        }
        return entrydata;
    }

    addGroupName(data, type) {
        data.forEach(element => {
            element.all = type;
        });
        return data;
    }

    addMorePageSizes() {
        for (let i = 0; i < Constants.pageSizes.length; i++) {
            this.pageSizeDropdown[i].value = Constants.pageSizes[i].toString();
            this.pageSizeDropdown[i].innerHTML = Constants.pageSizes[i];
        }
    }

    loadUpadtedPageSizes() {
        setTimeout(function () {
            this.pageSizeDropdown = document.querySelector('#pagination-bar-dynamic .wk-field-select');
            this.addMorePageSizes();
        }.bind(this), 0);
    }

    addIsSelectedInGrid(gridData, selectedRow) {
        gridData.forEach(element => {
            if (selectedRow.findIndex(d => d.accountActionReasonId === element.accountActionReasonId) === -1) {
                element.isSelected = false;
            } else {
                element.isSelected = true;
            }
        });
        return gridData;
    }

    addIsSelectedInGridTrue(gridData) {
        gridData.forEach(element => {
            element.isSelected = true;
        });
        return gridData;
    }

    getJurisdictionsCodes(jurisdictions) {
        const jurisdictionsCodes = [];
        jurisdictions.forEach(element => {
            jurisdictionsCodes.push(element.code);
        });
        return jurisdictionsCodes;
    }

    getjurisdictionsCodes(daysNoticeData: any) {
        const jurisdictionsCodes = new Set();
        daysNoticeData.forEach(element => {
            jurisdictionsCodes.add(element.stateCode);
        });
        return jurisdictionsCodes;
    }

    getFilterGrid(alldata, value) {
        const filterValue = [];
        alldata.forEach(element => {
            if (element.circumstance.toLowerCase().includes(value.toLowerCase())) {
                filterValue.push(element);
            }
        });
        return filterValue;
    }

    addRowId(data) {
        let startVal = 1;
        data.forEach(element => {
            element.gridId = startVal++;
        });
        return data;
    }

    getTodayDateFileName() {
        return moment(new Date()).format(ReportsConstant.dateFormats.mmddyyyy);
    }

    todayDate() {
        return moment(new Date()).format(ReportsConstant.dateFormats.mmdyyyy);
    }

    loadFile(response: any, fileName: any) {
        saveAs(response.body, fileName);
    }

    sortAscendingByKey(key, array) {
        return array.sort(function (a, b) {
            const x = a[key] !== null && typeof a[key] === 'string' ? a[key].toLowerCase() : a[key];
            const y = b[key] !== null && typeof b[key] === 'string' ? b[key].toLowerCase() : b[key];
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        });
    }

    sortDescendingByKey(key, array) {
        return array.sort(function (a, b) {
          const x = a[key] !== null && typeof a[key] === 'string' ? a[key].toLowerCase() : a[key];
          const y = b[key] !== null && typeof b[key] === 'string' ? b[key].toLowerCase() : b[key];
            return ((x > y) ? -1 : ((x < y) ? 1 : 0));
        });
    }

    showAlertMessage(message) {
        this.popupService.showAlert({
            title: '',
            message: message,
            positiveLabel: this.translate.instant('BUTTON.OK'),
            negativeLabel: '',
        });
    }

    getSelectedIds(actions) {
        const actionIds = [];
        actions.forEach(element => {
            actionIds.push(element.id);
        });
        return actionIds;
    }

    getRecordsFormat() {
        const getRecords = document.getElementsByClassName('wk-pagination-results');
        const getTextContent = getRecords[0].textContent;
        const splitTextContent = getTextContent.split(' ');
        const getRecordReportTotalCount = this.numberWithCommas(splitTextContent[0]) + ' ' + splitTextContent[1] + ' '
            + this.numberWithCommas(splitTextContent[2]) + ' ' + splitTextContent[3] + ' ' + this.numberWithCommas(splitTextContent[4]) + ' '
            + splitTextContent[5];
        document.getElementsByClassName('wk-pagination-results')[0].innerHTML = getRecordReportTotalCount;
    }

    numberWithCommas(num) {
        return num.replace(ReportsConstant.numberWithComma, ',');
    }
}
