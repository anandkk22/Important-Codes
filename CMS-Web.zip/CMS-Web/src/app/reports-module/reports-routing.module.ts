import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { DaysNoticeReportComponent } from './components/days-notice-report/days-notice-report.component';
import { CheckMailTypeComponent } from './components/check-mail-type/check-mail-type.component';
import { ListFormsByJurisdictionActionComponent } from './components/list-forms-by-jurisdiction-action/list-forms-by-jurisdiction-action.component';
import { ListFormsByJurisdictionComponent } from './components/list-forms-by-jurisdiction/list-forms-by-jurisdiction.component';
import { PermittedReasonWithoutFormRulesComponent } from './components/permitted-reason-without-form-rules/permitted-reason-without-form-rules.component';
import { CheckDaysNoticeRulesComponent } from './components/check-days-notice-rules/check-days-notice-rules.component';
import { WizardCriteriaByFieldComponent } from './components/wizard-criteria-by-field/wizard-criteria-by-field-component';
import { WizardCriteriaByFormComponent } from './components/wizard-criteria-by-form/wizard-criteria-by-form-component';
import { ReportsMenuComponent } from './components/reports-menu/reports-menu.component';
import { BadFieldRuleAssignmentsComponent } from './components/bad-field-rule-assignments/bad-field-rule-assignments.component';
import { FormsMissingHelpsheetComponent } from './components/forms-missing-helpsheet/forms-missing-helpsheet.component';
import { RulesMarkedRegulatoryComponent } from './components/rules-marked-regulatory/rules-marked-regulatory.component';
import { AuthGuardService } from '@global/services/auth-guard.service';
import { FormsReferencedByCnrMatrixComponent } from './components/forms-referenced-by-cnr-matrix/forms-referenced-by-cnr-matrix.component';
import { NonReferencedFormsInMatrixComponent } from './components/non-referenced-forms-in-matrix/non-referenced-forms-in-matrix.component';
import { RulesSummaryReportComponent } from './components/rules-summary-report/rules-summary-report.component';
import { FormsMissingFieldsComponent } from './components/forms-missing-fields/forms-missing-fields.component';

const routes: Routes = [
  {
    path: AppConstants.uiRoutes.empty,
    component: ReportsMenuComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.listFormsByJurisdictionAction,
    component: ListFormsByJurisdictionActionComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.listFormsByJurisdiction,
    component: ListFormsByJurisdictionComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.PermittedReasonWithoutFormRulesComponent,
    component: PermittedReasonWithoutFormRulesComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.daysNoticeReport,
    component: DaysNoticeReportComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.checkDaysNoticeRules,
    component: CheckDaysNoticeRulesComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.checkMailType,
    component: CheckMailTypeComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.wizardCriteriaByField,
    component: WizardCriteriaByFieldComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.wizardCriteriaByForm,
    component: WizardCriteriaByFormComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.badFieldRuleAssignments,
    component: BadFieldRuleAssignmentsComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.formsMissingHelpsheet,
    component: FormsMissingHelpsheetComponent,
    canActivate: [AuthGuardService]
  },
  {path: AppConstants.uiRoutes.rulesMarkedRegulatory,
    component: RulesMarkedRegulatoryComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.formsReferencedByCNRMatrix,
    component: FormsReferencedByCnrMatrixComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.nonReferencedFormsInMatrix,
    component: NonReferencedFormsInMatrixComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.rulesSummaryReport,
    component: RulesSummaryReportComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.formsMissingFields,
    component: FormsMissingFieldsComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
