import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';

@Injectable()
export class ConfigurationsHttpService {

  constructor(
    private http: HttpClient,
    private popupService: PopupService,
    private translate: TranslateService) { }

  getJurisdictions() {
    return this.http.get(`${Constants.webApis.getJurisdictions}`);
  }

  getActions() {
    return this.http.get(`${Constants.webApis.getActions}`);
  }

  getLobs(adminMenuItem) {
    return this.http.get(`${Constants.webApis.getLobs}`.replace('{adminMenuItem}', adminMenuItem));
  }

  getCircumstances() {
    return this.http.get(`${Constants.webApis.getCircumstances}`);
  }

  updateDaysNotices(rowsData) {
    return this.http.put(`${Constants.webApis.updateDaysNotice}`, rowsData);
  }

  editReason(reasonId, reasonText) {
    return this.http.put(`${Constants.webApis.deleteReason}`.replace('{accountActionReasonId}', reasonId), reasonText);
  }

  updateLiveWizardMenuing() {
    return this.http.get(`${Constants.webApis.updateLiveWizardMenuing}`);
  }

  updateWizardMenuing() {
    return this.http.post(`${Constants.webApis.updateMenu}`, null);
  }

  showSuccessAlert(message) {
    this.popupService.showSuccess({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }

  showErrorAlert(message) {
    this.popupService.showAlert({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }

}
