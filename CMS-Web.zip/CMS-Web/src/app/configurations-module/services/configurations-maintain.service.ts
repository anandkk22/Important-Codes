import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import { ConfigurationsConstant } from '../infrastructure/configurations.constant';
import { ActionRequestData, checkKey, CircumstanceRequestData, ConfigurationMasterData} from '../infrastructure/models/configuration.model';

@Injectable()
export class ConfigurationsMaintainService {
  pageSizeDropdown: HTMLElement;
  constructor(private translate: TranslateService,
    private popupService: PopupService) { }
    loadUpadtedPageSizes() {
      setTimeout(function () {
          this.pageSizeDropdown = document.querySelector('#pagination-bar-dynamic .wk-field-select');
          this.addMorePageSizes();
      }.bind(this), 0);
  }
  addMorePageSizes() {
    for (let i = 0; i < Constants.pageSizes.length; i++) {
        this.pageSizeDropdown[i].value = Constants.pageSizes[i].toString();
        this.pageSizeDropdown[i].innerHTML = Constants.pageSizes[i];
    }
}
  addGroupName(data, type) {
    data.forEach(element => {
      element.all = type;
    });
    return data;
  }
  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > checkKey.threeOne && (charCode < checkKey.fourEight || charCode > checkKey.fiveSeven)) {
      return false;
    }
    return true;
  }
  getJurisdictionsForAdd(jurisdictions) {
    const jurisdictionsNeeds = [];
    jurisdictions.forEach(element => {
      const obj = {};
      obj[ConfigurationsConstant.editdaysProperties.stateCode] = element.code;
      obj[ConfigurationsConstant.editdaysProperties.stateName] = element.name;
      jurisdictionsNeeds.push(obj);
    });
    return jurisdictionsNeeds;
  }

  getActionsForAdd(action) {
    const actionsNeeds = [];
    action.forEach(element => {
      const obj = {};
      obj[ConfigurationsConstant.editdaysProperties.actionId] = element.id;
      obj[ConfigurationsConstant.editdaysProperties.actionDesc] = element.name;
      actionsNeeds.push(obj);
    });
    return actionsNeeds;
  }

  getSLobsForAdd(lobs) {
    const actionsNeeds = [];
    lobs.forEach(element => {
      const obj = {};
      obj[ConfigurationsConstant.editdaysProperties.lobId] = element.id;
      obj[ConfigurationsConstant.editdaysProperties.lob] = element.name;
      actionsNeeds.push(obj);
    });
    return actionsNeeds;
  }

  getCircumstanceForAdd(circumstance) {
    const circumstanceNeed = [];
    circumstance.forEach(element => {
      const obj = {};
      obj[ConfigurationsConstant.editdaysProperties.circumstanceId] = element.id;
      obj[ConfigurationsConstant.editdaysProperties.circumstanceDescription] = element.name;
      circumstanceNeed.push(obj);
    });
    return circumstanceNeed;
  }

  mergeAllFields(pairs, daysNoticeForm) {
    const pairsNeed = [];
    pairs.forEach(element => {
      const summary = { ...element[0], ...element[1], ...element[2], ...element[3], ...daysNoticeForm };
      pairsNeed.push(summary);
    });
    return pairsNeed;
  }

  getViewText(count) {
    if (count && count > 1) {
      return ConfigurationsConstant.viewText.were;
    } else {
      return ConfigurationsConstant.viewText.was;
    }
  }

  getFormatedUpdateDays(data, days) {
    const selectedRows = data.selectedRows;
    const updatedFormat = [];

    if (data.daysType === ConfigurationsConstant.editDaysType.minDays) {
      const minDays = Number(days);
      selectedRows.forEach(element => {
        const changeValue: any = {};
        changeValue.stateCode = element.stateCode;
        changeValue.lobId = element.lobId;
        changeValue.actionId = element.actionId;
        changeValue.whereConditionId = element.whereConditionId;
        changeValue.acctNum = element.accountNumber;
        changeValue.dayNotice1 = minDays;
        changeValue.dayNoticeMax = element.dayNoticeMax;
        updatedFormat.push(changeValue);
      });
    } else if (data.daysType === ConfigurationsConstant.editDaysType.maxDays) {

      const maxDays = Number(days);
      selectedRows.forEach(element => {
        const changeValue: any = {};
        changeValue.stateCode = element.stateCode;
        changeValue.lobId = element.lobId;
        changeValue.actionId = element.actionId;
        changeValue.whereConditionId = element.whereConditionId;
        changeValue.acctNum = element.accountNumber;
        changeValue.dayNotice1 = element.dayNotice;
        changeValue.dayNoticeMax = maxDays;
        updatedFormat.push(changeValue);
      });
    }
    return updatedFormat;
  }

  getJurisdictionsCodes(jurisdictions) {
    const jurisdictionsCodes = [];
    jurisdictions.forEach(element => {
      jurisdictionsCodes.push(element.code);
    });
    return jurisdictionsCodes;
  }

  getSelectedIds(actions) {
    const actionIds = [];
    actions.forEach(element => {
      actionIds.push(element.id);
    });
    return actionIds;
  }

  setIsSelectedFlag(notices) {
    return notices.map(notice => ({ ...notice, isSelected: false }));
  }

  getDeleteFormat(rows) {
    const deleteFormat = [];
    rows.forEach(element => {
      const rowVal = {};
      rowVal['stateCode'] = element.stateCode;
      rowVal['lobId'] = element.lobId;
      rowVal['actionId'] = element.actionId;
      rowVal['whereConditionId'] = element.whereConditionId;
      rowVal['acctNum'] = element.accountNumber;
      deleteFormat.push(rowVal);
    });
    return deleteFormat;
  }

  selectAllCheckbox(isAllChecked, data) {
    let selectedRows = [];
    if (isAllChecked) {
      data = data.map(ele => ({ ...ele, isSelected: isAllChecked }));
      selectedRows = data;
    } else {
      data = data.map(ele => ({ ...ele, isSelected: false }));
      selectedRows = data;
    }
    return selectedRows;
  }

  checkChange(data, event, index: any) {
    data[index].isSelected = event.target.checked;
    const selectedRows = data.filter(ele => ele.isSelected === true);
    return selectedRows;
  }

  checkIfAtleastOneRowSelected(selectedRows, data) {
    const selectedRowStatus = {
      isAtleastOneRowSelected: false,
      isAllChecked: false,
    };
    if (selectedRows.length === 0) {
      selectedRowStatus.isAtleastOneRowSelected = false;
      selectedRowStatus.isAllChecked = false;
    } else if (data.length === selectedRows.length) {
      selectedRowStatus.isAtleastOneRowSelected = false;
      selectedRowStatus.isAllChecked = true;
    } else if (selectedRows.length > 0 &&
      selectedRows.length < data.length) {
      selectedRowStatus.isAtleastOneRowSelected = true;
      selectedRowStatus.isAllChecked = false;
    } else {
      selectedRowStatus.isAtleastOneRowSelected = false;
      selectedRowStatus.isAllChecked = false;
    }
    return selectedRowStatus;
  }

  getAddUpdateCircumstanceRequestData(record, recordId = null) {
    let data: CircumstanceRequestData;
    if (record) {
      data = {
        'whereConditionDesc': record.description,
        'displayOrder': 0,
        'definition': record.definition
      };
      if (recordId !== null) {
        data.whereConditionID = recordId;
      }
    }
    return data;
  }
  getAddUpdateActionRequestData( record, action, recordId?) {
    let data: ActionRequestData;
    if (record) {
      if (action === 'add') {
        data = {
          'code': record.code,
          'description': record.description,
          'displayOrder': 0,
          'definition': record.definition
        };
      } else {
        data = {
          'code': record.code,
          'description': record.description,
          'definition': record.definition
        };
      }
      if (recordId !== null) {
        data.id = recordId;
      }
    }
    return data;
  }
  getConfigurationMasterData(sectionName) {
    let configurationMasterData: ConfigurationMasterData;
    switch (sectionName) {
      case ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName:
        configurationMasterData = {
          sectionName: ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName,
          headerName: ConfigurationsConstant.configurationSectionDetails.whereCondition.headerName,
          fieldsDetails: {
            description: '',
            definition: ''
          },
          defaultValues: {
            description: '',
            definition: ''
          },
          tableData: {
            columnData: [
              {
                field: ConfigurationsConstant.configurationSectionDetails.whereCondition.descriptionField,
                header: ConfigurationsConstant.configurationSectionDetails.whereCondition.descriptionHeader,
                width: ConfigurationsConstant.configurationSectionDetails.whereCondition.whereDescriptionHeader,
              },
              {
                field: ConfigurationsConstant.configurationSectionDetails.whereCondition.definitionField,
                header: ConfigurationsConstant.configurationSectionDetails.whereCondition.definitionHeader,
                width: ConfigurationsConstant.configurationSectionDetails.whereCondition.whereDefinitionHeader,
              },
              {
                field: ConfigurationsConstant.configurationSectionDetails.whereCondition.actionField,
                header: ConfigurationsConstant.configurationSectionDetails.whereCondition.actionHeader,
                width: ConfigurationsConstant.configurationSectionDetails.whereCondition.whereActionHeaderWidth,
              },
            ],
            rowData: [],
            gridRowSelected: []
          },
          isEdit: false
        };
        break;

        case ConfigurationsConstant.configurationSectionDetails.action.sectionName:
        configurationMasterData = {
          sectionName: ConfigurationsConstant.configurationSectionDetails.action.sectionName,
          headerName: ConfigurationsConstant.configurationSectionDetails.action.headerName,
          fieldsDetails: {
            code: '',
            description: '',
            definition: ''
          },
          defaultValues: {
            code: '',
            description: '',
            definition: ''
          },
          tableData: {
            columnData: [
              {
                field: ConfigurationsConstant.configurationSectionDetails.action.codeField,
                header: ConfigurationsConstant.configurationSectionDetails.action.codeHeader,
                width: ConfigurationsConstant.configurationSectionDetails.action.actionHeaderWidth,
              },
              {
                field: ConfigurationsConstant.configurationSectionDetails.action.descriptionField,
                header: ConfigurationsConstant.configurationSectionDetails.action.descriptionHeader,
                width: ConfigurationsConstant.configurationSectionDetails.action.actionDescriptionHeader,
              },
              {
                field: ConfigurationsConstant.configurationSectionDetails.action.definitionField,
                header: ConfigurationsConstant.configurationSectionDetails.action.definitionHeader,
                width: ConfigurationsConstant.configurationSectionDetails.action.actionDefinitionHeader,
              },
              {
                field: ConfigurationsConstant.configurationSectionDetails.action.actionField,
                header: ConfigurationsConstant.configurationSectionDetails.action.actionHeader,
                width: ConfigurationsConstant.configurationSectionDetails.action.actionHeaderWidth,

              }
            ],
            rowData: [],
            gridRowSelected: []
          },
          isEdit: false
        };
          break;

      case ConfigurationsConstant.configurationSectionDetails.lob.sectionName:
        configurationMasterData = {
          sectionName: ConfigurationsConstant.configurationSectionDetails.lob.sectionName,
          headerName: ConfigurationsConstant.configurationSectionDetails.lob.headerName,
          fieldsDetails: {
            lobAbbr: '',
            lob: '',
            definition: '',
            recordActive: false
          },
          defaultValues: {
            lobAbbr: '',
            lob: '',
            definition: '',
            recordActive: false
          },
          tableData: {
            columnData: [
              {
                field: ConfigurationsConstant.configurationSectionDetails.lob.lobAbbrivationField,
                header: ConfigurationsConstant.configurationSectionDetails.lob.lobAbbrivationHeader,
                width: ConfigurationsConstant.configurationSectionDetails.lob.lobAbbrHeaderWidth
              },
              {
                field: ConfigurationsConstant.configurationSectionDetails.lob.lobField,
                header: ConfigurationsConstant.configurationSectionDetails.lob.lobHeader,
                width: ConfigurationsConstant.configurationSectionDetails.lob.lobHeaderWidth
              },
              {
                field: ConfigurationsConstant.configurationSectionDetails.lob.lobDefinationField,
                header: ConfigurationsConstant.configurationSectionDetails.lob.lobDefinationHeader,
                width: ConfigurationsConstant.configurationSectionDetails.lob.lobDefinationHeaderWidth
              },
              {
                field: ConfigurationsConstant.configurationSectionDetails.lob.lobRecordStatusField,
                header: ConfigurationsConstant.configurationSectionDetails.lob.lobRecordStatusHeader,
                width: ConfigurationsConstant.configurationSectionDetails.lob.lobRecordStatusHeaderWidth
              },
              {
                field: ConfigurationsConstant.configurationSectionDetails.lob.lobActionField,
                header: ConfigurationsConstant.configurationSectionDetails.lob.lobActionHeader,
                width: ConfigurationsConstant.configurationSectionDetails.lob.lobRecordStatusHeaderWidth
              },
            ],
            rowData: [],
            gridRowSelected: []
          },
          isEdit: false
        };
        break;
    }

    return configurationMasterData;
  }
  sortAscending(array, key) {
    return array.sort(function (a, b) {
        const x = a[key] !== null && typeof a[key] === 'string' ? a[key].toLowerCase() : a[key];
        const y = b[key] !== null && typeof b[key] === 'string' ? b[key].toLowerCase() : b[key];
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
}

sortDescending(array, key) {
    return array.sort(function (a, b) {
      const x = a[key] !== null && typeof a[key] === 'string' ? a[key].toLowerCase() : a[key];
      const y = b[key] !== null && typeof b[key] === 'string' ? b[key].toLowerCase() : b[key];
        return ((x > y) ? -1 : ((x < y) ? 1 : 0));
    });
}
sortData(data, key, sortOrderDesc) {
    if (sortOrderDesc) {
     this.sortDescending(data, key);
    } else {
      this.sortAscending(data, key);
    }
  }

  scrollToTop() {
    document.getElementById('main-scroll').scrollIntoView();
  }

  showSuccessAlert(message) {
    this.popupService.showSuccess({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }
  showAlert(message) {
    this.popupService.showAlert({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }
  getRequestData(records) {
    const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body: records };
    return options;
  }

  numberWithComma(num) {
    return num.toString().replace(/,/g, '').replace(ConfigurationsConstant.numberWithComma, ',');
  }

  getEncodedUrl(href) {
    let encodedUrl = '';
    const urlValues = href.split('?');
    encodedUrl = `${urlValues[0]}?params=${encodeURIComponent(window.btoa(urlValues[1]))}`;
    return encodedUrl;
  }

  getDecodedParamData(searchData) {
    const decodedData = window.atob(decodeURIComponent(searchData));
    const data = decodedData.split('&');
    const paramData = {};
    data.forEach(i => {
      const obj = i.split('=');
      paramData[obj[0]] = obj[1];
    });
    return paramData;
  }
}
