import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ConfigurationsRoutingModule } from './configurations-routing.module';
import { MaintainReasonsComponent } from './components/maintain-reasons/maintain-reasons.component';
import { MaintainDaysComponent } from './components/maintain-days/maintain-days.component';
import { ConfigurationsHttpService } from './services/configurations-http.service';
import { ConfigurationsValidationService } from './services/configurations-validation.service';
import { DaysNoticeMinMaxComponent } from './components/days-notice-min-max/days-notice-min-max.component';
import { ConfigurationsMaintainService } from './services/configurations-maintain.service';
import { WhereConditionMaintenanceComponent } from './components/where-condition-maintenance/where-condition-maintenance.component';
import { NilsSharedModule } from '@wk/nils-shared';
import { environment } from '@env';
import { NgSelectModule } from '@ng-select/ng-select';
import { UtilityModule } from 'app/utility-module/utility-module.module';
import { MaintainReasonsEditComponent } from './components/maintain-reasons-edit/maintain-reasons-edit.component';
import { FieldRuleMaintenanceComponent } from './components/field-rule-maintenance/field-rule-maintenance.component';
import { AddMailTypeComponent } from './components/add-mail-type/add-mail-type.component';
import { ActionMaintenanceComponent } from './components/action-maintenance/action-maintenance.component';
import { LobMaintenanceComponent } from './components/lob-maintenance/lob-maintenance.component';
import { ConfigurationMenuComponent } from './components/configuration-menu/configuration-menu.component';
import { FieldMasterMaintenanceComponent } from './components/field-master-maintenance/field-master-maintenance.component';
import { WhereUsedModalComponent } from './components/where-used-modal/where-used-modal.component';
import { MaintainMailTypeComponent } from './components/maintain-mail-type/maintain-mail-type.component';
import { FieldRuleStepComponent } from './components/field-rule-step/field-rule-step.component';

@NgModule({
  declarations: [
    MaintainReasonsComponent,
    MaintainDaysComponent,
    DaysNoticeMinMaxComponent,
    WhereConditionMaintenanceComponent,
    MaintainReasonsEditComponent,
    MaintainMailTypeComponent,
    AddMailTypeComponent,
    ActionMaintenanceComponent,
    LobMaintenanceComponent,
    ConfigurationMenuComponent,
    FieldMasterMaintenanceComponent,
    WhereUsedModalComponent,
    FieldRuleMaintenanceComponent,
    FieldRuleStepComponent
  ],
  imports: [
    ConfigurationsRoutingModule,
    NilsSharedModule.loadConfig({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      commonApiUrl: environment.commonApiUrl,
      userGroupURL: '',
      feedbackEmail: environment.feedbackEmail,
      customerCareEmail: environment.customerCareEmail,
      productUrl: environment.productUrl
    }),
    NgSelectModule,
    UtilityModule
  ],
  providers: [
    ConfigurationsHttpService,
    ConfigurationsValidationService,
    ConfigurationsMaintainService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class ConfigurationsModule { }
