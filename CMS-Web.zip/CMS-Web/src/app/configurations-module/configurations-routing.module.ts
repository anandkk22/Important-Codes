import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { MaintainDaysComponent } from './components/maintain-days/maintain-days.component';
import { MaintainMailTypeComponent } from './components/maintain-mail-type/maintain-mail-type.component';
import { MaintainReasonsComponent } from './components/maintain-reasons/maintain-reasons.component';
import { WhereConditionMaintenanceComponent } from './components/where-condition-maintenance/where-condition-maintenance.component';
import { LobMaintenanceComponent } from './components/lob-maintenance/lob-maintenance.component';
import { ConfigurationMenuComponent } from './components/configuration-menu/configuration-menu.component';
import { FieldMasterMaintenanceComponent } from './components/field-master-maintenance/field-master-maintenance.component';
import { FieldRuleMaintenanceComponent } from './components/field-rule-maintenance/field-rule-maintenance.component';
import { ActionMaintenanceComponent } from './components/action-maintenance/action-maintenance.component';
import { FieldRuleStepComponent } from './components/field-rule-step/field-rule-step.component';
import { AuthGuardService } from '@global/services/auth-guard.service';

const routes: Routes = [
  {
    path: AppConstants.uiRoutes.empty,
    component: ConfigurationMenuComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.maintainReasons,
    component: MaintainReasonsComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.maintainDays,
    component: MaintainDaysComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.maintainMailType,
    component: MaintainMailTypeComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.actionMaintenance,
    component: ActionMaintenanceComponent,
    canActivate: [AuthGuardService]
   },
  {
    path: AppConstants.uiRoutes.whereConditionMaintenance,
    component: WhereConditionMaintenanceComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.lobMaintenance,
    component: LobMaintenanceComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.fieldMasterMaintenance,
    component: FieldMasterMaintenanceComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.fieldDependancyMaintenance,
    component: FieldRuleMaintenanceComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.fieldRuleSteps,
    component: FieldRuleStepComponent,
    canActivate: [AuthGuardService]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfigurationsRoutingModule { }
