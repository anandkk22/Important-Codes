import { environment } from '@env';

export class ConfigurationsConstant {
  static webApis = {
    imageUrl: 'assets/Images/WKLogo.png',
    getMaintainMailTypes: environment.apiUrl + 'MailType/WithoutFormRules'
  };

  static cnrPath = '/cnr/';
  static bulk = 'bulk';
  static single = 'single';

  static apiStatus = 422;

  static daysNotice = {
    allJurisdictions: 'All Jurisdictions',
    allLobs: 'All Line(s) of Business',
    allActions: 'All Actions',
    allCircumstance: 'All Circumstances',
  };

  static daysNoticeFormType = {
    display: 'display',
    addDays: 'addDays',
  };

  static maintainMailTypeForm = {
    display: 'display',
    addMailType: 'addMailType',
  };

  static adminMenuLobs = 2;

  static editdaysProperties = {
    stateCode: 'stateCode',
    stateName: 'stateName',
    actionId: 'actionId',
    actionDesc: 'actionDesc',
    lobId: 'lobId',
    lob: 'lob',
    circumstanceId: 'circumstanceId',
    circumstanceDescription: 'circumstanceDescription',
    daysNotice: 'daysNotice',
    daysNoticeMax: 'daysNoticeMax',
    defaults: 'defaults'
  };

  static editDaysType = {
    minDays: 'minDays',
    maxDays: 'maxDays',
    single: 'single',
    bulk: 'bulk',
    multiple: 'multiple',
    addMinMax: 'add',
  };

  static addMailType = {
    addMailType: 'add',
    noReload: 'noReload',
    reload: 'reload',
    maintainMailTypeOption: 'maintainMailTypeOption'
  };

  static maintainType = {
    allLobs: 'All Line(s) of Business',
    allActions: 'All Actions',
    allCircumstance: 'All Circumstances',
  };


  static mode = {
    add: 'add',
    edit: 'edit',
  };

  static editDaysReload = {
    noReload: 'noReload',
    reload: 'reload',
  };

  static viewText = {
    was: ' was',
    were: 's were',
  };

  static exportExcel = {
    exportName: 'MaintainDaysResult',
    exportMaintainMailTypeName: 'Maintain Mail Type ',
    exportMaintainMailReason: 'Maintain Reasons',
    exportMaintainWhereCondition: 'Where Condition Maintenance',
    exportMaintainAction: 'Action Maintenance',
    pageTitle: 'Maintain Days\' Notice',
    pageMaintainMailTypeTitle: 'Maintain Mail Type',
    pageMaintainMailReasonTitle: 'Maintain Reasons',
    pageMaintainWhereCondition: 'Where Condition Maintenance',
    pageMaintainAction: 'Action Maintenance',
    fileName: 'MaintainDaysResult',
    fileMaintainMailTypeName: 'Maintain Mail Type',
    fileMaintainReasonName: 'Maintain Reasons',
    fileMaintainWhereCondition: 'Where Condition Maintenance',
    fileMaintainAction:  'Action Maintenance',
    exportMailTypeName: 'MailTypeEntriesWithout',
    pageMailTypeTitle: 'Mail Type entries without corresponding Form Rules',
    fileNameMailType: 'Mail types without corresponding Form Rules ',
    exportLOBMaintenance: 'LOB Maintenance',
    exportLOBMaintenancePageTitle: 'LOB Maintenance',
    exportLOBMaintenanceFileName: 'LOB Maintenance',
    headers: [
      'Jurisdiction',
      'Action',
      'Line of Business',
      'Circumstance',
      'Minimum Days',
      'Maximum Days',
    ],
    headersMaintainMailType: [
      'Jurisdiction',
      'Action',
      'Line of Business',
      'Circumstance',
      'Mail Type',
    ],
    headersMaintainReason: [
      'Jurisdiction',
      'Action',
      'Line of Business',
      'Circumstance',
      'Reason',
    ],
    headersMaintainWhereCondition: [
      'Description',
      'Definition'
    ],
    headerLOBMaintenance: [
      'LOB Abbr',
      'LOB',
      'Definition',
      'Record Status'
    ],
    keys: [
      'stateCode',
      'actionDescription',
      'lob',
      'whereConditionDescription',
      'dayNotice',
      'dayNoticeMax',
    ],
    keysMaintainMailType: [
      'stateCode',
      'actionDescription',
      'lob',
      'whereConditionDescription',
      'mailType'
    ],
    keysMaintainReason: [
      'stateCode',
      'actionDescription',
      'lob',
      'whereConditionDescription',
      'reasonText'
    ],
    keysMaintainWhereCondition: [
      'whereConditionDesc',
      'definition'
    ],
    mailTypeHeader: [
      'Jurisdiction',
      'Action',
      'LOB',
      'Circumstance',
      'Mail Type'
    ],
    mailTypeKeys: [
      'stateCode',
      'actionCode',
      'lobAbbr',
      'whereConditionDescription',
      'mailType'
    ],
    headersMaintainAction: [
      'Code',
      'Description',
      'Definition'
    ],
    keysMaintainAction: [
      'code',
      'actionDesc',
      'definition'
    ],
    lobMaintenanceKeys: [
      'lobAbb',
      'name',
      'lobDef',
      'recordStatus'
    ]
  };

  static selecter = 'selecter';

  static configurationSectionDetails = {
    placeholder: 'Search by Description/Definition',
    searchBy: 'Search By ',
    description: 'Description ',
    actionTtile: 'Action ',
    code: 'Code',
    whereCondition: {
      sectionName: 'whereCondition',
      headerName: 'Where Condition',
      descriptionField: 'description',
      descriptionHeader: 'Description',
      definitionField: 'definition',
      definitionHeader: 'Definition',
      actionField: 'action',
      actionHeader: 'Action',
      whereActionHeaderWidth: '2%',
      whereDescriptionHeader: '10%',
      whereDefinitionHeader: '15%',
      placeholderText: 'Search by Description/Definition'
    },
    action: {
      sectionName: 'action',
      headerName: 'Action',
      codeField: 'code',
      codeHeader: 'Code',
      descriptionField: 'description',
      descriptionHeader: 'Description',
      definitionField: 'definition',
      definitionHeader: 'Definition',
      actionField: 'action',
      actionHeader: 'Action',
      actionHeaderWidth: '2%',
      actionDescriptionHeader: '10%',
      actionDefinitionHeader: '15%',
      searchByActionCode: 'Search By Action Code',
      searchByDescritption: 'Search By Description',
      actionDesc: 'actionDesc'
    },
    lob: {
      sectionName: 'lob',
      headerName: 'LOB',
      lobHeaderName: 'Line(s) of Business',
      lobAbbrivationField: 'lobAbbr',
      lobAbbrivationHeader: 'LOB Abbr',
      lobField: 'lob',
      lobHeader: 'LOB',
      lobDefinationField: 'definition',
      lobDefinationHeader: 'Definition',
      lobRecordStatusField: 'recordStatus',
      lobRecordStatusHeader: 'Record Status',
      lobActionField: 'action',
      lobActionHeader: 'Action',
      lobAbbrHeaderWidth: '3%',
      lobHeaderWidth: '15%',
      lobDefinationHeaderWidth: '40%',
      lobRecordStatusHeaderWidth: '5%',
      lobSearchPlaceholderText: 'Search by LOB',
      lobAbbrSearchPlaceholderText: 'Search by LOB Abbr',
      lobActiveOnlyFilter: 'activeLob',
      lobInactiveOnlyFilter: 'inactiveLob',
      recordStatusYes: 'Yes',
      recordStatusNo: 'No',
      lobAbbrivation: 'lobAbb',
      lobName: 'name',
      lobActiveOnlyFilterText: 'Active Only',
      lobInactiveOnlyFilterText: 'Inactive Only',
      active: 'Active',
      inactive: 'Inactive',
      all: 'All'
    },

  };
  static fieldMasterMaintenance = {
    fieldName: 'fieldName',
    label: 'label',
    maxLength: 'maxLength',
    displaySize: 'displaySize',
    displayGroup: 'displayGroup',
    recordActive: 'recordActive',
    displayControl: 'displayControl',
    fieldDisplayed: 'fieldDisplayed',
    stateCode: 'stateCode'
  };
    static  fieldRuleStep = {
      placeholderDialogType : 'Select Dialog Type',
      placeholderType: 'Select Type',
      placeholderStatus: 'Select Status',
      invalidStep: 'Please enter valid step number.',
      uniqueStepMsg : 'The step number has been used already for this rule. Please enter different step number.',
      step: 'ruleStep',
      fieldRuleId: 'fieldRuleId',
      field: 'fieldName',
      status: 'status',
      type: 'type',
      dialog_type: 'dialogType',
      dialog_text: 'dialogText',
      defaultValue: '10',
      na: 'N/A',
      message: 'Message',
      question:  'Question',
      if: 'IF',
      required: 'IT REQUIRES',
      then: 'THEN',
      checked: 'checked',
      unchecked : 'unchecked',
      blank: 'Blank',
      is_not_checked: 'Is Not Checked',
      is_checked: 'Is Checked',
      is_set_unchecked: 'Is set to Unchecked',
      is_set_checked: 'Is set to Checked',
      is_not_blank: 'Is Not Blank',
      is_blank: 'Is Blank',
      is_set_blank: 'Is set to Blank',
      q: 'Q',
      m: 'M',
      i: 'I',
      r: 'R',
      t: 'T',
      undefined: undefined,
      null: null,
      empty: '',
      minus: 'grrLable minus-tick',
      lable: 'grrLable',
      checked_true: 'checked==true',
      checked_false: 'checked==false',
      valueNot: 'value !=\'\'',
      valueNull: 'value ==\'\'',
      true: 'checked=true',
      false: 'checked=false',
      vnull: 'value=\'\'',
      statusData : [
        { name: 'Is Not Checked', value: 'Is Not Checked' },
        { name: 'Is Checked', value: 'Is Checked' },
        { name: 'Is Not Blank', value: 'Is Not Blank' },
        { name: 'Is Blank', value: 'Is Blank' },
        { name: 'Is set to Checked', value: 'Is set to Checked' },
        { name: 'Is set to Unchecked', value: 'Is set to Unchecked' },
        { name: 'Is set to Blank', value: 'Is set to Blank' }
      ],
      typeData: [
        { name: 'IF', value: 'I'},
        { name: 'IT REQUIRES', value: 'R'},
        { name: 'THEN', value: 'T'}
      ],
      dialogTypeData: [
        { name: 'N/A', value: '' },
        { name: 'Message', value: 'M' },
        { name: 'Question', value: 'Q' }
      ]


    };
  static fieldDependancyRules = {
    filterAllPotentialRules: 'All Potential Rules',
    filterActiveRules: 'Active Rules Only',
    activeRules: 'activeRules',
    title: 'Field Dependancy Rule Maintenance',
    fieldRuleDescription: 'FieldRuleDescription',
    template: 'template',
    placeHolder: 'Search Rule',
    fieldChange: 'FieldChange'

  };

  static backYellowClass = 'back-yellow';
  static accountActionReasonId = 'accountActionReasonId';

  static maintainMailTypeDropdown = [
    { id: 'R', name: 'Registered' },
    { id: 'C', name: 'Certified' },
    { id: 'S', name: 'Standard' },
    { id: 'N', name: 'None' }
  ];
  static numberWithComma = /\B(?=(\d{3})+(?!\d))/g;
}
