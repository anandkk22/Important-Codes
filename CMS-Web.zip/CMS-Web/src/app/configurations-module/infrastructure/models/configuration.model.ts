export enum checkKey {
  threeOne = 31,
  fourEight = 48,
  fiveSeven = 57
}

export interface ConfigurationMasterData {
  sectionName?: string;
  headerName?: string;
  fieldsDetails?: ConfigurationFieldsData;
  defaultValues?: ConfigurationFieldsData;
  tableData?: {
      columnData?: GridHeaderData[],
      rowData?: GridRowData[],
      gridRowSelected?: GridRowData[],
  };
  isEdit?: boolean;
  isExpanded?: boolean;
}

export interface ConfigurationFieldsData {
    description?: string;
    definition?: string;
    code?: string;
    lobAbbr?: string;
    lob?: string;
    recordActive?: boolean;
    recordStatus?: string;
}

export interface GridTableEmitData {
  mode?: string;
  rowIndex?: number;
  col?: GridHeaderData;
  row?: GridRowData;
  data?: ConfigurationFieldsData;
  gridData?: GridRowData[];
}

export enum ActionMode {
  add = 'add',
  save = 'save',
  edit = 'edit',
  cancel = 'cancel',
  reset = 'reset',
  updateLive = 'updateLive',
  updateStatus = 'updateStatus'
}
export interface GridHeaderData {
  field: string;
  header: string;
  width?: string;
}

export interface GridRowData {
  whereConditionId?: number;
  productId?: number;
  whereConditionDesc?: string;
  displayOrder?: number;
  definition?: string;
  recordActive?: boolean;
  definitionOriginal?: string;
  id?: string;
  name?: string;
  lobDef?: string;
  lobAbb?: string;
  lobType?: string;
  recordStatus?: string;
}

export interface CircumstanceRequestData {
  whereConditionID?: number;
  whereConditionDesc: string;
  displayOrder: number;
  definition: string;
}
export interface ActionRequestData {
  id?: number;
  actionDesc?: string;
  displayOrder?: number;
  definition?: string;
  code?: string;
  description?: string;
}

export interface ThresholdExceededData {
  isThresholdExceeded?: boolean;
  recordsCount?: number;
  thresholdCount?: number;
}

export interface ThresholdExceededReason {
  isThresholdExceeded?: boolean;
  thresholdCount?: number;
}
