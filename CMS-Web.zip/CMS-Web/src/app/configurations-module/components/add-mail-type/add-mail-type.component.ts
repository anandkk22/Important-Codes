import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';

@Component({
    selector: 'add-mail-type',
    templateUrl: './add-mail-type.component.html',
    styleUrls: ['./add-mail-type.component.scss'],
})
export class AddMailTypeComponent implements OnInit {
    @Input() data;
    viewRecordsView = false;
    isResult = false;
    failedRows = [];
    successRows = [];
    unsucessfulRecords: number;
    sucessfulRecords: number;
    showView = 'added';

    constructor(public activeModal: NgbActiveModal) {

    }
    ngOnInit() {
        if (this.data.operation === ConfigurationsConstant.mode.add) {
            this.failedRows = this.data.notAddedRecords;
            this.successRows = this.data.addedRecords;
            this.unsucessfulRecords = this.data.notAddedRecords.length || 0;
            this.sucessfulRecords = this.data.addedRecords.length || 0;
            this.isResult = true;
        }
    }

    viewRecords() {
        this.viewRecordsView = true;
        this.isResult = false;
    }

    successOk() {
        this.activeModal.close(ConfigurationsConstant.addMailType.reload);
    }

    cancelViewRecords() {
        this.failedRows = [];
        this.activeModal.close(ConfigurationsConstant.addMailType.reload);
    }
}
