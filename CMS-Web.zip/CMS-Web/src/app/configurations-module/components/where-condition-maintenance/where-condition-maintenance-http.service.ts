import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';

@Injectable()
export class WhereConditionMaintenanceHttpService {

  constructor(private http: HttpClient) { }

  addCircumstanceRecord(circumstanceDetails) {
    return this.http.post(`${Constants.webApis.addUpdateCircumstance}`, circumstanceDetails);
  }

  updateCircumstanceRecord(circumstanceDetails) {
    return this.http.put(`${Constants.webApis.addUpdateCircumstance}`, circumstanceDetails);
  }

  getAllCircumstanceRecords() {
    return this.http.get(`${Constants.webApis.getAllCircumstance}`);
  }

  updateLiveCircumstance() {
    return this.http.put(`${Constants.webApis.updateLiveCircumstance}`, null);
  }
}
