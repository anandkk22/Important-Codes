import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import '@wk/components/dist/accordion';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ActionMode, ConfigurationMasterData, GridRowData } from 'app/configurations-module/infrastructure/models/configuration.model';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { CmsConfigAddSectionComponent } from 'app/utility-module/cms-config-add-section/cms-config-add-section.component';
import { take } from 'rxjs/operators';
import { WhereConditionMaintenanceHttpService } from './where-condition-maintenance-http.service';

@Component({
  selector: 'app-where-condition-maintenance',
  templateUrl: './where-condition-maintenance.component.html',
  styleUrls: ['./where-condition-maintenance.component.scss'],
  providers: [WhereConditionMaintenanceHttpService]
})
export class WhereConditionMaintenanceComponent implements OnInit {

  @ViewChild(CmsConfigAddSectionComponent) child: CmsConfigAddSectionComponent;

  configurationMasterData: ConfigurationMasterData;
  recordId = null;
  isGridRowEditing = false;
  isDataAvailable = false;
  isUpdateLiveRequired = true;

  exportData: any = {
    exportName: ConfigurationsConstant.exportExcel.exportMaintainWhereCondition,
    pageTitle: ConfigurationsConstant.exportExcel.pageMaintainWhereCondition,
    fileName: ConfigurationsConstant.exportExcel.fileMaintainWhereCondition,
    data: {
      result: [],
      headers: ConfigurationsConstant.exportExcel.headersMaintainWhereCondition,
      keys: ConfigurationsConstant.exportExcel.keysMaintainWhereCondition
    },
  };

  constructor(
    private whereConditionMaintenanceHttpService: WhereConditionMaintenanceHttpService,
    private configurationsMaintainService: ConfigurationsMaintainService,
    private translate: TranslateService,
    private popupService: PopupService,
    private spinnerService: SpinnerService) { }

  ngOnInit(): void {
    this.configurationMasterData = this.configurationsMaintainService.getConfigurationMasterData(
      ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName);
    this.configurationMasterData.isExpanded = false;
    this.getAllCircumstanceRecords();
  }

  getAllCircumstanceRecords() {
    this.whereConditionMaintenanceHttpService.getAllCircumstanceRecords()
    .subscribe((res: GridRowData[]) => {
      if (res && res.length > 0) {
        this.configurationMasterData.tableData.rowData = res;
        this.exportData.data.result = res;
        this.isDataAvailable = true;
      }
    });
  }

  actionClick(event) {
    switch (event.mode) {
      case ActionMode.add:
        this.addCircumstanceRecord(event.data);
        break;

      case ActionMode.save:
        this.saveCircumstanceRecord(event.data);
        break;

      case ActionMode.cancel:
        this.onCancelClick();
        break;

        case ActionMode.reset:
        this.onRestClick();
        break;
    }
  }

  addCircumstanceRecord(record) {
    const data = this.configurationsMaintainService.getAddUpdateCircumstanceRequestData(record);
    this.whereConditionMaintenanceHttpService.addCircumstanceRecord(data)
    .subscribe(() => {
      this.isDataAvailable = false;
      this.getAllCircumstanceRecords();
      this.configurationMasterData.fieldsDetails.definition = '';
      this.configurationMasterData.fieldsDetails.description = '';
      this.spinnerService.stop();
      const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_ADDED_SUCCESS');
      this.configurationsMaintainService.showSuccessAlert(alertMessage);
    });
  }

  saveCircumstanceRecord(record) {
    const data = this.configurationsMaintainService.getAddUpdateCircumstanceRequestData(record, this.recordId);
    this.whereConditionMaintenanceHttpService.updateCircumstanceRecord(data)
    .subscribe(() => {
      this.isDataAvailable = false;
      this.getAllCircumstanceRecords();
      this.configurationMasterData.fieldsDetails.definition = '';
      this.configurationMasterData.fieldsDetails.description = '';
      this.configurationMasterData.defaultValues.definition = '';
      this.configurationMasterData.defaultValues.description = '';
      this.configurationMasterData.isEdit = false;
      this.configurationMasterData.isExpanded = false;
      this.isGridRowEditing = false;
      this.spinnerService.stop();
      const alertMessage =  this.translate.instant('MESSAGES.CONFIRMATION.RECORD_UPDATED_SUCCESS');
      this.configurationsMaintainService.showSuccessAlert(alertMessage);
    });
  }

  onCancelClick() {
    this.configurationMasterData.fieldsDetails.definition = '';
    this.configurationMasterData.fieldsDetails.description = '';
    this.configurationMasterData.isEdit = false;
    this.isGridRowEditing = false;
  }

  onRestClick() {
    if (this.configurationMasterData) {
      this.configurationMasterData.fieldsDetails.definition = this.configurationMasterData?.defaultValues?.definition;
      this.configurationMasterData.fieldsDetails.description = this.configurationMasterData?.defaultValues?.description;
    }
  }

  updateLiveCircumstance() {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message:  this.translate.instant('CONFIGURATION_MENU.ADD_FORM_COMMON_COMPONENT.UPDATE_LIVE_MESSAGE'),
      positiveLabel: this.translate.instant('BUTTON.CONFIRM'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.whereConditionMaintenanceHttpService.updateLiveCircumstance()
        .subscribe(() => {
          this.configurationsMaintainService.showSuccessAlert(this.translate.instant('CONFIGURATION_MENU.ADD_FORM_COMMON_COMPONENT.UPDATE_LIVE_SUCCESS_MESSAGE'));
         });
      }
    });
  }

  columnClicked(event) {
    if (event) {
      switch (event?.mode) {
        case ActionMode.edit:
          this.isGridRowEditing = true;
          this.configurationsMaintainService.scrollToTop();
          this.recordId = event.row?.whereConditionId;
          this.configurationMasterData.fieldsDetails.definition = event.row?.definition;
          this.configurationMasterData.fieldsDetails.description = event.row?.whereConditionDesc;
          this.configurationMasterData.defaultValues.definition = event.row?.definition;
          this.configurationMasterData.defaultValues.description = event.row?.whereConditionDesc;
          this.configurationMasterData.isEdit = true;
          this.configurationMasterData.isExpanded = true;
          break;

        case ActionMode.updateLive:
          this.updateLiveCircumstance();
          break;
      }
    }

  }
}
