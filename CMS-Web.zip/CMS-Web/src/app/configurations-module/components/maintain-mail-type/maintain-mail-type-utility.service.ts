import { Injectable } from '@angular/core';

@Injectable()
export class MaintainMailTypeUtilityService {

  constructor() { }

  addGroupName(data, type) {
    data.forEach(element => {
      element.all = type;
    });
    return data;
  }

  getSelectedIds(actions) {
    const actionIds = [];
    actions.forEach(element => {
      actionIds.push(element.id);
    });
    return actionIds;
  }

  setIsSelectedFlag(mailTypes) {
    return mailTypes.map(mailType => ({ ...mailType, isSelected: false }));
  }

  getDeleteFormat(rows) {
    const deleteFormat = [];
    rows.forEach(element => {
      const rowVal = {};
      rowVal['stateCode'] = element.stateCode;
      rowVal['lobId'] = element.lobId;
      rowVal['actionId'] = element.actionId;
      rowVal['whereConditionId'] = element.whereConditionId;
      deleteFormat.push(rowVal);
    });
    return deleteFormat;
  }

  selectAllCheckbox(isAllChecked, data) {
    let selectedRows = [];
    if (isAllChecked) {
      data = data.map(ele => ({ ...ele, isSelected: isAllChecked }));
      selectedRows = data;
    } else {
      data = data.map(ele => ({ ...ele, isSelected: false }));
      selectedRows = data;
    }
    return selectedRows;
  }

  checkChange(data, event, index: any) {
    data[index].isSelected = event.target.checked;
    const selectedRows = data.filter(ele => ele.isSelected === true);
    return selectedRows;
  }

  checkIfAtleastOneRowSelected(selectedRows, data) {
    const selectedRowStatus = {
      isAtleastOneRowSelected: false,
      isAllChecked: false,
    };
    if (selectedRows.length === 0) {
      selectedRowStatus.isAtleastOneRowSelected = false;
      selectedRowStatus.isAllChecked = false;
    } else if (data.length === selectedRows.length) {
      selectedRowStatus.isAtleastOneRowSelected = false;
      selectedRowStatus.isAllChecked = true;
    } else if (selectedRows.length > 0 &&
      selectedRows.length < data.length) {
      selectedRowStatus.isAtleastOneRowSelected = true;
      selectedRowStatus.isAllChecked = false;
    } else {
      selectedRowStatus.isAtleastOneRowSelected = false;
      selectedRowStatus.isAllChecked = false;
    }
    return selectedRowStatus;
  }
}
