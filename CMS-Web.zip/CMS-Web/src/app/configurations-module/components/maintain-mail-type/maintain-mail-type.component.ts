import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { take } from 'rxjs/operators';
import { FormGroup, FormControl } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import '@wk/components/dist/tooltip';
import { CmsSelectsComponent } from 'app/utility-module/cms-selects/cms-selects.component';
import { NgSelectComponent } from '@ng-select/ng-select';
import { AddMailTypeComponent } from '../add-mail-type/add-mail-type.component';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { MaintainMailTypeUtilityService } from './maintain-mail-type-utility.service';
import { MaintainMailTypeHttpService } from './maintain-mail-type-http.service';
import { Subject } from 'rxjs';
import { ThresholdExceededData } from 'app/configurations-module/infrastructure/models/configuration.model';

@Component({
  selector: 'maintain-mail-type',
  templateUrl: './maintain-mail-type.component.html',
  styleUrls: ['./maintain-mail-type.component.scss'],
  providers: [
    MaintainMailTypeUtilityService,
    MaintainMailTypeHttpService
  ]
})
export class MaintainMailTypeComponent implements OnInit {

  @ViewChild('selecter') ngselect: NgSelectComponent;
  @ViewChild(CmsSelectsComponent) child: CmsSelectsComponent;
  showHideMailType = false;
  maintainMailType = [];
  selectedJurisdictions = [];
  mailTypeOptions = [];
  allMailTypeOptions = [];
  allJurisdictions = [];
  isClickedDisplay = false;
  isAllChecked = false;
  isAtleastOneRowSelected = false;
  selectedRows = [];
  isResultAvl = false;
  isClickedMailType = false;
  exportExcelClicked = false;
  enableDisplayBtn = false;
  isFullWidth = true;
  enableButton = false;
  selectedRowStatus: any = {
    isAtleastOneRowSelected: false,
    isAllChecked: false
  };
  onCancelButtonClick: Subject<void> = new Subject<void>();
  isUpdateLiveActive = false;
  @ViewChild('updateLiveButton') updateLiveButton: ElementRef<HTMLElement>;

  exportData: any = {
    exportName: ConfigurationsConstant.exportExcel.exportMaintainMailTypeName,
    pageTitle: ConfigurationsConstant.exportExcel.pageMaintainMailTypeTitle,
    fileName: ConfigurationsConstant.exportExcel.fileMaintainMailTypeName,
    data: {
      result: [],
      headers: ConfigurationsConstant.exportExcel.headersMaintainMailType,
      keys: ConfigurationsConstant.exportExcel.keysMaintainMailType
    },
  };

  public maintainMailTypeForm: FormGroup = new FormGroup({
    maintainMailTypeOption: new FormControl('', )
  });


  constructor(private translate: TranslateService,
    private maintainMailTypeUtilityService: MaintainMailTypeUtilityService,
    private maintainMailTypeHttpService: MaintainMailTypeHttpService,
    private popupService: PopupService,
    private modalService: NgbModal,
    private configurationsMaintainService: ConfigurationsMaintainService,
    private spinnerService: SpinnerService) { }

  ngOnInit(): void {
    this.getMailTypeOptions();
  }

  toggleMailType() {
    this.showHideMailType = !this.showHideMailType;
  }

  changeDropdown(event) {
    this.enableDisplayBtn = event;
  }

  isResetDisable() {
    let isDisable = true;
    if ((this.child?.selectedCircumstances && this.child?.selectedCircumstances?.length > 0) ||
      (this.child?.selectedActions && this.child?.selectedActions?.length > 0) ||
      (this.child?.selectedJurisdictions && this.child?.selectedJurisdictions?.length > 0) ||
      (this.child?.selectedLobs && this.child?.selectedLobs?.length > 0)
    ) {
      isDisable = false;
    }
    return isDisable;
  }

  getMailTypeOptions() {
    this.mailTypeOptions = ConfigurationsConstant.maintainMailTypeDropdown;
  }

  onMailtypeChange(value) {
    this.allMailTypeOptions = value.id;
    this.maintainMailTypeForm.get(ConfigurationsConstant.addMailType.maintainMailTypeOption).setValue(this.allMailTypeOptions);
  }

  clearMailType() {
    this.allMailTypeOptions = [];
  }

  checkIsValidForm(mode) {
    if (mode === ConfigurationsConstant.maintainMailTypeForm.addMailType) {
      if (this.child.checkValidation() && this.maintainMailTypeForm.valid) {
        this.addMailType();
      }
    } else {
      if (this.child.checkValidation()) {
        this.displayMailType();
      }
    }
  }

  addMailType() {
    const addMailTypeData = {
      stateCode: [this.child.selectedJurisdictions],
      actionId: this.maintainMailTypeUtilityService.getSelectedIds(this.child.selectedActions),
      lobId: this.maintainMailTypeUtilityService.getSelectedIds(this.child.selectedLobs),
      whereConditionId: this.maintainMailTypeUtilityService.getSelectedIds(this.child.selectedCircumstances),
      mailType: this.maintainMailTypeForm.value.maintainMailTypeOption
    };
    this.maintainMailTypeHttpService.addMaintainMailType(addMailTypeData).subscribe((res: any) => {
      if (res) {
        const thresholdCount = this.configurationsMaintainService.numberWithComma(res.thresholdCount);
        const alertMessage =
          this.translate.instant('CONFIGURATION_MENU.MESSAGES.THRESHOLD_MESSAGE_CONFIG', { thresholdCount: thresholdCount });
        if (res.isThresholdExceeded) {
          this.isResultAvl = false;
          this.configurationsMaintainService.showAlert(alertMessage);
        } else {
          this.isClickedMailType = false;
          this.displayMailType();
          this.maintainMailTypeForm.get(ConfigurationsConstant.addMailType.maintainMailTypeOption).setValue('');
          const modalRef = this.modalService.open(AddMailTypeComponent);
          res.mailType = ConfigurationsConstant.addMailType.addMailType;
          res.operation = ConfigurationsConstant.mode.add;
          modalRef.componentInstance.data = res;
          modalRef.result.then(() => {
            this.allMailTypeOptions = [];
          });
        }
      }
    });
  }

  displayMailType() {
    this.maintainMailType = [];
    const jurisdictionsCodes = [this.child.selectedJurisdictions];
    const actionIds = this.maintainMailTypeUtilityService.getSelectedIds(this.child.selectedActions);
    const lobIds = this.maintainMailTypeUtilityService.getSelectedIds(this.child.selectedLobs);
    const circumstanceIds = this.maintainMailTypeUtilityService.getSelectedIds(this.child.selectedCircumstances);
    const maintainMailTypeData = {
      stateCode: jurisdictionsCodes,
      actionId: actionIds,
      lobId: lobIds,
      whereConditionId: circumstanceIds
    };
    this.maintainMailTypeHttpService.maintainTypeRequirementsCount(maintainMailTypeData).subscribe((response: ThresholdExceededData) => {
      if (response) {
        const thresholdCount = this.configurationsMaintainService.numberWithComma(response.thresholdCount);
        const alertMessage =
          this.translate.instant('CONFIGURATION_MENU.MESSAGES.THRESHOLD_MESSAGE_CONFIG', { thresholdCount: thresholdCount });
        if (response.isThresholdExceeded) {
          this.isResultAvl = false;
          this.configurationsMaintainService.showAlert(alertMessage);
        } else {
          this.maintainMailTypeHttpService.getAllMaintainMailType(maintainMailTypeData).subscribe((res: any) => {
            this.isResultAvl = true;
            this.maintainMailType = this.maintainMailTypeUtilityService.setIsSelectedFlag(res);
            this.selectedRows = [];
            this.checkIfAtleastOneRowSelected();
          });
        }
      }
    });
  }

  cancelDisplay() {
    this.maintainMailType = [];
    this.allMailTypeOptions = [];
    this.isResultAvl = false;
    this.showHideMailType = false;
    this.child.cancel();
    this.child.isSubmitClicked = false;
    this.enableDisplayBtn = false;
    this.isUpdateLiveActive = false;
  }

  selectAllCheckbox() {
    this.selectedRowStatus.isAtleastOneRowSelected = false;
    this.spinnerService.start();
    setTimeout(() => {
      this.selectedRows = this.maintainMailTypeUtilityService.selectAllCheckbox(this.selectedRowStatus.isAllChecked, this.maintainMailType);
      this.selectedRows.filter(ele => ele.isSelected === true).length > 0 ? this.enableButton = true : this.enableButton = false;
      this.maintainMailType = this.selectedRows;
      this.exportData.data.result = this.selectedRows;
      this.spinnerService.stop();
    }, 0);
  }

  checkChange(event, index) {
    this.selectedRows = this.maintainMailTypeUtilityService.checkChange(this.maintainMailType, event, index);
    this.selectedRows.length > 0 ? this.enableButton = true : this.enableButton = false;
    this.exportData.data.result = this.selectedRows;
    this.checkIfAtleastOneRowSelected();
  }

  checkIfAtleastOneRowSelected() {
    this.selectedRowStatus = this.maintainMailTypeUtilityService.checkIfAtleastOneRowSelected(this.selectedRows, this.maintainMailType);
  }

  singleDelete(record) {
    this.deleteRecord([record], ConfigurationsConstant.single);
  }

  bulkDelete() {
    this.deleteRecord(this.selectedRows, ConfigurationsConstant.bulk);
  }

  deleteRecord(row, type) {
    const expectedFormat = this.maintainMailTypeUtilityService.getDeleteFormat(row);
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: type === ConfigurationsConstant.bulk ?
        this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_BULK_DELETE') :
        this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_SINGLE_DELETE'),
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.maintainMailTypeHttpService.deleteMaintainMailType(expectedFormat)
          .subscribe(() => {
            const alertMessage = type === ConfigurationsConstant.bulk ?
              this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_DELETED') :
              this.translate.instant('MESSAGES.CONFIRMATION.RECORD_DELETED');
            this.configurationsMaintainService.showSuccessAlert(alertMessage);
            this.displayMailType();
          });
        this.enableButton = false;
      }
    });
  }

  exportExcel() {
    this.exportExcelClicked = true;
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
    }
    this.maintainMailType = this.maintainMailType.map(ele => ({ ...ele, isSelected: false }));
    this.selectedRowStatus.isAllChecked = false;
    this.selectedRowStatus.isAtleastOneRowSelected = false;
    this.enableButton = false;
  }

  updateToLive() {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: this.translate.instant('CONFIGURATION_MENU.MAINTAIN_MAIL_TYPE.UPDATE_LIVE_INFO',
        { stateCode: this.child.selectedJurisdictions }),
      positiveLabel: this.translate.instant('BUTTON.CONFIRM'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.maintainMailTypeHttpService.updateLive({
          stateCode: this.child.selectedJurisdictions
        })
          .subscribe(() => {
            const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.UPDATE_LIVE_SUCCESS',
              { stateCode: this.child.selectedJurisdictions });
            this.configurationsMaintainService.showSuccessAlert(alertMessage);
            this.enableButton = false;
            this.displayMailType();
          });
      }
      setTimeout(() => {
        const updateLiveBtnElement: HTMLElement = this.updateLiveButton.nativeElement;
        updateLiveBtnElement.blur();
      }, 100);
    });
  }

  isUpdateLiveBtnActive(event) {
    this.isUpdateLiveActive = event;
  }

}
