import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';

@Injectable()
export class MaintainMailTypeHttpService {

  constructor(private http: HttpClient,
    private configMaintainService: ConfigurationsMaintainService) { }

  getAllMaintainMailType(data) {
    return this.http.post(`${Constants.webApis.getMaintainMailType}`, data);
  }

  addMaintainMailType(data) {
    return this.http.post(`${Constants.webApis.addMaintainMailType}`, data);
  }

  deleteMaintainMailType(records) {
    const options = this.configMaintainService.getRequestData(records);
    return this.http.delete(`${Constants.webApis.deleteMaintainMailType}`, options);
  }

  updateLive(state) {
    return this.http.post(`${Constants.webApis.updateMailTypeLive}`, state);
  }

  maintainTypeRequirementsCount(data) {
    return this.http.post(`${Constants.webApis.mailTypeGetAllCount}`, data);
  }
}
