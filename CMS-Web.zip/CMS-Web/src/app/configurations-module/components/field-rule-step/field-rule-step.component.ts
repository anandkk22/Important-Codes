import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Constants } from '@global/infrastructure/constants';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { take } from 'rxjs/operators';
import { FieldRuleStepService } from './field-rule-step.service';
import { FieldRuleStep } from './fieldRuleStep.model';

@Component({
  selector: 'app-field-rule-step',
  templateUrl: './field-rule-step.component.html',
  styleUrls: ['./field-rule-step.component.scss'],
  providers: [FieldRuleStepService]
})
export class FieldRuleStepComponent implements OnInit {
  constructor(private activatedRoute: ActivatedRoute,
    private fb: FormBuilder,
    private configurationsMaintainService: ConfigurationsMaintainService,
    private fieldRuleStepService: FieldRuleStepService,
    private modalService: NgbModal,
    private spinnerService: SpinnerService,
    private translate: TranslateService,
    private popupService: PopupService) {
    this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.params) {
        const paramData = this.configurationsMaintainService.getDecodedParamData(params.params);
        if (Object.keys(paramData).length !== 0) {
          this.ruleStepId = paramData['ruleStepId'];
        }
      }
    });
  }

  isDataAvailable = false;
  ruleStepId: number;
  isEditRow = false;
  ruleStepsForm;
  isExpanded = false;
  selectedStatus;
  selectedRow = [];
  deleteArray = {
    'fieldRuleId': [],
    'ruleStep': []
  };
  isAllChecked = false;
  isAtleastOneSelected = false;
  fieldObj: FieldRuleStep = {};
  showYellow: any;
  placeholderDialogType = ConfigurationsConstant.fieldRuleStep.placeholderDialogType;
  placeholderType = ConfigurationsConstant.fieldRuleStep.placeholderType;
  placeholderStatus = ConfigurationsConstant.fieldRuleStep.placeholderStatus;
  statusData = ConfigurationsConstant.fieldRuleStep.statusData;
  masterData;
  isNoRecordFound = false;
  typeData = ConfigurationsConstant.fieldRuleStep.typeData;
  dialogTypeData = ConfigurationsConstant.fieldRuleStep.dialogTypeData;
  stepData = [];
  enteredRuleStep  = '';
  ngOnInit(): void {
    this.initForm();
    this.getRuleStepGridData();
  }
  formInIt() {
    this.ruleStepsForm = this.fb.group({
      ruleStep: [ConfigurationsConstant.fieldRuleStep.defaultValue, [Validators.required]],
      status: [, [Validators.required]],
      type: [, [Validators.required]],
      dialogType: [],
      fieldName: [ConfigurationsConstant.fieldRuleStep.empty, [Validators.required]],
      dialogText: [ConfigurationsConstant.fieldRuleStep.empty],
    });
  }
  initForm() {
    this.formInIt();
    this.isEditRow = false;
    this.showYellow = '';
    this.isExpanded = false;
    this.selectedRow = [];
    this.isAllChecked = false;
    this.isAtleastOneSelected = false;
    this.deleteArray.ruleStep = [];
    this.configurationsMaintainService.scrollToTop();
  }
  getClass() {
    return !this.isAllChecked && this.isAtleastOneSelected ?
      ConfigurationsConstant.fieldRuleStep.minus : ConfigurationsConstant.fieldRuleStep.lable;
  }
  getRuleStepGridData() {
    let value;
    this.stepData = [];
    this.fieldRuleStepService.getRuleStepData(this.ruleStepId)
      .subscribe((res: any) => {
        if (res && res.length > 0) {
          this.masterData = res;
          this.masterData.forEach(element => this.stepData.push(element.ruleStep));
          value = Math.round((this.masterData[res.length - 1].ruleStep) / 10) * 10;
          value = (this.masterData[res.length - 1].ruleStep >= value) ? value + 10 : value;
          this.getOnloaduniqueStep(value);
        }
        else {
          this.stepData = [];
          this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.step).setValue(10);
          this.isNoRecordFound = true;
          this.isDataAvailable = true;
        }
      });
  }
  getOnloaduniqueStep(value) {
    if (!this.stepData.includes(Number(value))) {
      ConfigurationsConstant.fieldRuleStep.defaultValue = value.toString();
      this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.step).setValue(value);
      this.isNoRecordFound = false;
      this.isDataAvailable = true;
    } else {
      this.getOnloaduniqueStep(value + 10);
    }
  }
  uniqueStep(step) {
    if (step) {
      if (Number(step) < 1) {
        const message = ConfigurationsConstant.fieldRuleStep.invalidStep;
        this.configurationsMaintainService.showAlert(message);
        return false;
      }
      else if (this.stepData.includes(Number(step))) {
        const message = ConfigurationsConstant.fieldRuleStep.uniqueStepMsg;
        this.configurationsMaintainService.showAlert(message);
        return false;
      } else {
        return true;
      }
    }
  }
  isManualExpanded() {
    this.formInIt();
    this.isExpanded = !this.isExpanded;
  }
  expandForm(event) {
    event.stopPropagation();
  }
  numberRegex(event) {
    const inp = String.fromCharCode(event.keyCode);
    const regEx = Constants.FieldMasterMaintenance.numberRegex;
    if (regEx.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  onlyNumber(): boolean {
    if (Number(this.enteredRuleStep)) {
      return true;
    } else {
      this.enteredRuleStep = '';
    }
    return false;
  }
  activityMethod(action, form?) {
    if (form && form.value) {
      const status = this.getFieldMapping(ConfigurationsConstant.fieldRuleStep.status, form.value.status);
      form.value.status = status;
      const type = (form.value.type === ConfigurationsConstant.fieldRuleStep.na) ? ConfigurationsConstant.fieldRuleStep.empty :
        this.getFieldMapping(ConfigurationsConstant.fieldRuleStep.type, form.value.type);
      form.value.type = type;
      const dialogType = this.getFieldMapping(ConfigurationsConstant.fieldRuleStep.dialog_type, form.value.dialogType);
      form.value.dialogType = dialogType;
      const request = { ...form.value, 'fieldRuleId': this.ruleStepId };
      switch (action) {
        case Constants.FieldMasterMaintenance.add: {
          const isUniqueStep = this.uniqueStep(request.ruleStep);
          if (isUniqueStep) {
            this.fieldRuleStepService.addRuleStepData(request)
              .subscribe((res) => {
                this.spinnerService.stop();
                const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_ADDED_SUCCESS');
                this.showSuccessAlert(message);
                this.isDataAvailable = false;
                this.initForm();
                this.getRuleStepGridData();
              });
          }
        }
          break;
        case Constants.FieldMasterMaintenance.update: {
          const updateRequest = { ...request, 'originalRuleStep': this.fieldObj.step };
          if (this.fieldObj.step === updateRequest.ruleStep) {
            this.fieldRuleStepService.updateRuleStepData(updateRequest)
              .subscribe(() => {
                this.spinnerService.stop();
                const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_UPDATED_SUCCESS');
                this.showSuccessAlert(message);
                this.isEditRow = false;
                this.isDataAvailable = false;
                this.initForm();
                this.getRuleStepGridData();

              });
          } else {
            const isUniqueStep = this.uniqueStep(updateRequest.ruleStep);
            if (isUniqueStep) {
              this.fieldRuleStepService.updateRuleStepData(updateRequest)
                .subscribe(() => {
                  this.spinnerService.stop();
                  const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_UPDATED_SUCCESS');
                  this.showSuccessAlert(message);
                  this.isEditRow = false;
                  this.isDataAvailable = false;
                  this.initForm();
                  this.getRuleStepGridData();

                });
            }
          }
        }
          break;
      }
    }

  }
  disableButton(action) {
    switch (action) {
      case Constants.switchCase.add: {
        return (!((this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.step).value !== this.fieldObj?.step) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.status).value !== this.fieldObj?.status) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.type).value !== this.fieldObj?.type) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.field).value !== this.fieldObj?.field)) ||
          !(this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.field).value.trim() !== '') ||
          !this.ruleStepsForm.valid);
      }
      case Constants.switchCase.update: {
        return (!((this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.step).value !== this.fieldObj?.step) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.status).value !== this.fieldObj?.status) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.type).value !== this.fieldObj?.type) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.field).value.trim() !== this.fieldObj?.field) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.dialog_type).value !== this.fieldObj?.dialog_type) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.dialog_text).value !== this.fieldObj?.dialog_text)) ||
          !(this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.field).value.trim() !== '')) ||
          !(this.ruleStepsForm.valid);
      }
      case Constants.switchCase.reset: {
        return !((this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.step).value !== this.fieldObj?.step) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.status).value !== this.fieldObj?.status) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.type).value !== this.fieldObj?.type) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.field).value !== this.fieldObj?.field) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.dialog_type).value !== this.fieldObj?.dialog_type) ||
          (this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.dialog_text).value !== this.fieldObj?.dialog_text));
      }
    }
  }
  cancelClick() {
    setTimeout(() => { this.isExpanded = false; }, 100);
    this.initForm();
  }
  singleDelete(record) {
    this.deleteArray.fieldRuleId.push(record.fieldRuleId);
    this.deleteArray.ruleStep.push(record.ruleStep);
    this.deleteRecord(this.deleteArray, ConfigurationsConstant.single);
  }

  bulkDelete() {
    this.selectedRow.filter(item => {
      this.deleteArray.fieldRuleId.push(item.fieldRuleId);
      this.deleteArray.ruleStep.push(item.ruleStep);
    });
    this.deleteRecord(this.deleteArray, ConfigurationsConstant.bulk);
  }

  deleteRecord(record, type) {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: type === ConfigurationsConstant.bulk ?
        this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_BULK_DELETE') :
        this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_SINGLE_DELETE'),
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.fieldRuleStepService.deleteRecords(record)
          .subscribe(() => {
            this.spinnerService.stop();
            const message = type === ConfigurationsConstant.bulk ?
              this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_DELETED') :
              this.translate.instant('MESSAGES.CONFIRMATION.RECORD_DELETED');
            this.showSuccessAlert(message);
            this.isDataAvailable = false;
            this.initForm();
            this.getRuleStepGridData();
            this.getOnloaduniqueStep(10);
          });
      }
    });
  }
  checkAllCheckbox() {
    if (this.isAllChecked) {
      this.checkAllcheckboxValue(this.isAllChecked);
    } else {
      this.selectedRow = [];
      this.isAtleastOneSelected = false;
      this.checkAllcheckboxValue(this.isAllChecked);
    }
    this.checkIfAtleastOneSelected();
  }

  checkAllcheckboxValue(isAllChecked) {
    this.masterData.forEach(element => {
      element.isSelected = isAllChecked;
      if (isAllChecked) {
        this.addToSelectedtable(element);
      }
    });
  }

  checkIfAtleastOneSelected() {
    if (this.selectedRow.length === 0) {
      this.isAtleastOneSelected = false;
      this.isAllChecked = false;
    } else if (this.masterData.length === this.selectedRow.length) {
      this.isAtleastOneSelected = false;
      this.isAllChecked = true;
    } else if ((this.masterData.length > this.selectedRow.length)
      && (this.selectedRow.length > 0)) {
      this.isAtleastOneSelected = true;
      this.isAllChecked = false;
    }
    else {
      this.isAtleastOneSelected = false;
      this.isAllChecked = false;
    }
  }

  addToSelectedtable(oneRow) {
    this.selectedRow.push(oneRow);
  }

  changeCheckbox(data, index) {
    data.isSelected = !data.isSelected;
    if (data.isSelected) {
      this.addToSelectedtable(data);
    } else {
      this.removeFromSelectedtable(data.ruleStep);
    }
    this.checkIfAtleastOneSelected();
  }

  removeFromSelectedtable(ruleStep) {
    const index = this.selectedRow.findIndex(d => d.ruleStep === ruleStep);
    this.selectedRow.splice(index, 1);
  }

  columnClicked(rowData, index) {
    this.isEditRow = true;
    if (rowData) {
      this.showYellow = index;
      rowData.index = index;
      this.getSelectedRow(rowData);
    }
  }

  getBackYellowClass(row) {
    return row?.index === this.showYellow ? ConfigurationsConstant.backYellowClass : ConfigurationsConstant.fieldRuleStep.empty;
  }
  getSelectedRow(row) {
    if (row) {
      this.fieldObj.step = row.ruleStep;
      this.fieldObj.field = row.fieldName;
      this.fieldObj.type = this.getFieldMapping(ConfigurationsConstant.fieldRuleStep.type, row.type);
      this.fieldObj.dialog_text = row.dialogText;
      this.fieldObj.dialog_type = this.getFieldMapping(ConfigurationsConstant.fieldRuleStep.dialog_type, row.dialogType);
      this.fieldObj.status = row.status;
      this.resetClick();
    }
    this.isExpanded = true;
    this.configurationsMaintainService.scrollToTop();
  }
  resetClick() {
    this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.field).setValue(this.fieldObj.field);
    this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.step).setValue(this.fieldObj.step);
    this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.type).setValue(this.fieldObj.type);
    this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.dialog_text).setValue(this.fieldObj.dialog_text);
    this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.dialog_type).setValue(this.fieldObj.dialog_type);
    this.ruleStepsForm.get(ConfigurationsConstant.fieldRuleStep.status).setValue(this.fieldObj.status);
  }
  showSuccessAlert(message) {
    this.popupService.showSuccess({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }
  getFieldMapping(field, value) {
    switch (field) {
      case ConfigurationsConstant.fieldRuleStep.status: {
        switch (value) {
          case ConfigurationsConstant.fieldRuleStep.is_checked: return ConfigurationsConstant.fieldRuleStep.checked_true;
          case ConfigurationsConstant.fieldRuleStep.is_not_checked: return ConfigurationsConstant.fieldRuleStep.checked_false;
          case ConfigurationsConstant.fieldRuleStep.is_not_blank: return ConfigurationsConstant.fieldRuleStep.valueNot;
          case ConfigurationsConstant.fieldRuleStep.is_blank: return ConfigurationsConstant.fieldRuleStep.valueNull;
          case ConfigurationsConstant.fieldRuleStep.is_set_checked: return ConfigurationsConstant.fieldRuleStep.true;
          case ConfigurationsConstant.fieldRuleStep.is_set_unchecked: return ConfigurationsConstant.fieldRuleStep.false;
          case ConfigurationsConstant.fieldRuleStep.is_set_blank: return ConfigurationsConstant.fieldRuleStep.vnull;
          case ConfigurationsConstant.fieldRuleStep.na: return ConfigurationsConstant.fieldRuleStep.na;
        }
      }
        break;
      case ConfigurationsConstant.fieldRuleStep.type: {
        switch (value) {
          case ConfigurationsConstant.fieldRuleStep.na: return ConfigurationsConstant.fieldRuleStep.na;
          case ConfigurationsConstant.fieldRuleStep.empty: return ConfigurationsConstant.fieldRuleStep.empty;
          case ConfigurationsConstant.fieldRuleStep.if: return ConfigurationsConstant.fieldRuleStep.i;
          case ConfigurationsConstant.fieldRuleStep.i: return ConfigurationsConstant.fieldRuleStep.i;
          case ConfigurationsConstant.fieldRuleStep.required: return ConfigurationsConstant.fieldRuleStep.r;
          case ConfigurationsConstant.fieldRuleStep.r: return ConfigurationsConstant.fieldRuleStep.r;
          case ConfigurationsConstant.fieldRuleStep.then: return ConfigurationsConstant.fieldRuleStep.t;
          case ConfigurationsConstant.fieldRuleStep.t: return ConfigurationsConstant.fieldRuleStep.t;
        }
      }
        break;
      case ConfigurationsConstant.fieldRuleStep.dialog_type: {
        switch (value) {
          case ConfigurationsConstant.fieldRuleStep.na: return ConfigurationsConstant.fieldRuleStep.empty;
          case ConfigurationsConstant.fieldRuleStep.empty: return ConfigurationsConstant.fieldRuleStep.empty;
          case ConfigurationsConstant.fieldRuleStep.m: return ConfigurationsConstant.fieldRuleStep.m;
          case ConfigurationsConstant.fieldRuleStep.message: return ConfigurationsConstant.fieldRuleStep.m;
          case ConfigurationsConstant.fieldRuleStep.question: return ConfigurationsConstant.fieldRuleStep.q;
          case ConfigurationsConstant.fieldRuleStep.q: return ConfigurationsConstant.fieldRuleStep.q;
          case ConfigurationsConstant.fieldRuleStep.undefined: return ConfigurationsConstant.fieldRuleStep.empty;
          case ConfigurationsConstant.fieldRuleStep.null: return ConfigurationsConstant.fieldRuleStep.empty;
        }
      }
    }

  }
}
