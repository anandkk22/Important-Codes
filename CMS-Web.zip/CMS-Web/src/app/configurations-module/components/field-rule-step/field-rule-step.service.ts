import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';
import { Observable } from 'rxjs';

@Injectable()
export class FieldRuleStepService {

  constructor(private http: HttpClient) { }

   getRuleStepData(ruleId) {
    return this.http.get(`${Constants.webApis.fieldRuleStep.getFieldRuleStep.replace ('{fieldRuleId}', ruleId)}`);
  }
   addRuleStepData(recordData) {
    return this.http.post(`${Constants.webApis.fieldRuleStep.addUpdateRuleStep}`, recordData);
  }
   updateRuleStepData(recordData) {
    return this.http.put(`${Constants.webApis.fieldRuleStep.addUpdateRuleStep}`, recordData);
  }
  deleteRecords(recordData) {
    const options = this.getRequestData(recordData);
    return this.http.delete(`${Constants.webApis.fieldRuleStep.deleteRecord}`, options);
  }
  getRequestData(records) {
    const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body: records };
    return options;
  }
}
