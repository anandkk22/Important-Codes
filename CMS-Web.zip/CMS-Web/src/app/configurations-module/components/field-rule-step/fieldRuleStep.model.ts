
export interface FieldRuleStep {
    ruleStepId?: number;
    fieldName?: string;
    status?: string;
    type?: string;
    dialog_type?: string;
    dialog_text?: string;
    field?: string;
    step?: string;
}
