import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';

@Injectable()
export class ActionMaintenanceHttpService {

  constructor(private http: HttpClient) { }

  getAllActionRecords() {
    return this.http.get(`${Constants.webApis.getAllAction}`);
  }
  addActionRecord(actionDetails) {
    return this.http.post(`${Constants.webApis.addUpdateAction}`, actionDetails);
  }
  updateActionRecord(actionDetails) {
    return this.http.put(`${Constants.webApis.addUpdateAction}`, actionDetails);
  }
}
