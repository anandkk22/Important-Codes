import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SpinnerService } from '@wk/nils-core';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ActionMode, ConfigurationMasterData, GridRowData } from 'app/configurations-module/infrastructure/models/configuration.model';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { CmsConfigAddSectionComponent } from 'app/utility-module/cms-config-add-section/cms-config-add-section.component';
import { ActionMaintenanceHttpService } from './action-maintenance-http.service';

@Component({
  selector: 'app-action-maintenance',
  templateUrl: './action-maintenance.component.html',
  styleUrls: ['./action-maintenance.component.scss'],
  providers: [ActionMaintenanceHttpService]
})
export class ActionMaintenanceComponent implements OnInit {

  @ViewChild(CmsConfigAddSectionComponent) child: CmsConfigAddSectionComponent;

  configurationMasterData: ConfigurationMasterData;
  recordId = null;
  isGridRowEditing = false;
  isDataAvailable = false;
  isUpdateLiveRequired = false;

  exportData: any = {
    exportName: ConfigurationsConstant.exportExcel.exportMaintainAction,
    pageTitle: ConfigurationsConstant.exportExcel.pageMaintainAction,
    fileName: ConfigurationsConstant.exportExcel.fileMaintainAction,
    data: {
      result: [],
      headers: ConfigurationsConstant.exportExcel.headersMaintainAction,
      keys: ConfigurationsConstant.exportExcel.keysMaintainAction
    },
  };

  constructor(
    private actionMaintenanceHttpService: ActionMaintenanceHttpService,
    private configurationsMaintainService: ConfigurationsMaintainService,
    private translate: TranslateService,
    private spinnerService: SpinnerService) { }
    ngOnInit(): void {
      this.configurationMasterData = this.configurationsMaintainService.getConfigurationMasterData(
        ConfigurationsConstant.configurationSectionDetails.action.sectionName);
      this.configurationMasterData.isExpanded = false;
      this.getAllActionRecords();
    }
    getAllActionRecords() {
      this.actionMaintenanceHttpService.getAllActionRecords()
      .subscribe((res: GridRowData[]) => {
        if (res && res.length > 0) {
          this.configurationMasterData.tableData.rowData = res;
          this.exportData.data.result = res;
          this.isDataAvailable = true;
        }
      });
    }
    actionClick(event) {
      switch (event.mode) {
        case ActionMode.add:
          this.addActionRecord(event.data);
          break;

        case ActionMode.save:
          this.saveActionRecord(event.data);
          break;

        case ActionMode.cancel:
          this.onCancelClick();
          break;

          case ActionMode.reset:
          this.onRestClick();
          break;
      }
    }
    addActionRecord(record) {
      const data = this.configurationsMaintainService.getAddUpdateActionRequestData(record, ConfigurationsConstant.mode.add);
      this.actionMaintenanceHttpService.addActionRecord(data)
      .subscribe(() => {
        this.isDataAvailable = false;
        this.getAllActionRecords();
        this.configurationMasterData.fieldsDetails.code = '';
        this.configurationMasterData.fieldsDetails.definition = '';
        this.configurationMasterData.fieldsDetails.description = '';
        this.configurationMasterData.isEdit = false;
        this.isGridRowEditing = false;
        this.spinnerService.stop();
        const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_ADDED_SUCCESS');
        this.configurationsMaintainService.showSuccessAlert(alertMessage);
      });
    }

    saveActionRecord(record) {
      this.configurationMasterData.isEdit = false;
      const data = this.configurationsMaintainService.getAddUpdateActionRequestData(record, 'update', this.recordId);
      this.actionMaintenanceHttpService.updateActionRecord(data)
      .subscribe(() => {
        this.isDataAvailable = false;
        this.getAllActionRecords();
        this.configurationMasterData.fieldsDetails.code = '';
        this.configurationMasterData.fieldsDetails.definition = '';
        this.configurationMasterData.fieldsDetails.description = '';
        this.configurationMasterData.isEdit = false;
        this.configurationMasterData.isExpanded = false;
        this.isGridRowEditing = false;
        this.spinnerService.stop();
        const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_UPDATED_SUCCESS');
        this.configurationsMaintainService.showSuccessAlert(alertMessage);
      });
    }
    onCancelClick() {
      this.configurationMasterData.fieldsDetails.code = '';
      this.configurationMasterData.fieldsDetails.definition = '';
      this.configurationMasterData.fieldsDetails.description = '';
      this.configurationMasterData.isEdit = false;
      this.isGridRowEditing = false;
    }

    onRestClick() {
      if (this.configurationMasterData && this.configurationMasterData?.defaultValues) {
        this.configurationMasterData.fieldsDetails.code = this.configurationMasterData?.defaultValues?.code;
        this.configurationMasterData.fieldsDetails.definition = this.configurationMasterData?.defaultValues?.definition;
        this.configurationMasterData.fieldsDetails.description = this.configurationMasterData?.defaultValues?.description;
      }
    }

  updateLiveAction() {
  }

  columnClicked(event) {
    if (event) {
      switch (event?.mode) {
        case ActionMode.edit:
          this.isGridRowEditing = true;
          this.configurationsMaintainService.scrollToTop();
          this.recordId = event?.row?.id;
          this.configurationMasterData.fieldsDetails.code = event?.row?.code;
          this.configurationMasterData.fieldsDetails.definition = event?.row?.definition;
          this.configurationMasterData.fieldsDetails.description =  event?.row?.actionDesc;
          this.configurationMasterData.defaultValues.code = event?.row?.code;
          this.configurationMasterData.defaultValues.definition = event?.row?.definition;
          this.configurationMasterData.defaultValues.description =  event?.row?.actionDesc;
          this.configurationMasterData.isEdit = true;
          this.configurationMasterData.isExpanded = true;
          break;

        case ActionMode.updateLive:
          this.updateLiveAction();
          break;
      }
    }
  }
}
