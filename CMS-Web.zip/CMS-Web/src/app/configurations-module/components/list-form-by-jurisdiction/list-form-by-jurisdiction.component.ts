import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'list-form-by-jurisdiction',
  templateUrl: './list-form-by-jurisdiction.component.html',
  styleUrls: ['./list-form-by-jurisdiction.component.scss']
})
export class ListFormByJurisdictionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
