import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';

@Injectable()
export class MaintainDaysHttpService {

  constructor(private http: HttpClient,
    private configMaintainService: ConfigurationsMaintainService) { }

  addDaysNotice(addNoticeData) {
    return this.http.post(`${Constants.webApis.addDaysNotice}`, addNoticeData);
  }

  getAllDaysNotice(noticeData) {
    return this.http.post(`${Constants.webApis.getAllDaysNotice}`, noticeData);
  }

  deleteDaysNotice(records) {
    const options = this.configMaintainService.getRequestData(records);
    return this.http.delete(`${Constants.webApis.deleteDaysNotice}`, options);
  }

  updateLive(state) {
    return this.http.post(`${Constants.webApis.updateLive}`, state);
  }

  daysNoticeRequirementsCount(noticeData) {
    return this.http.post(`${Constants.webApis.getdaysNoticeRequirementsCount}`, noticeData);
  }
}
