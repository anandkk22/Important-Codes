import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import '@wk/components/dist/accordion';
import '@wk/components/dist/tooltip';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { NgSelectComponent } from '@ng-select/ng-select';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { PopupService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DaysNoticeMinMaxComponent } from '../days-notice-min-max/days-notice-min-max.component';
import { take } from 'rxjs/operators';
import { ConfigurationsHttpService } from 'app/configurations-module/services/configurations-http.service';
import { MaintainDaysHttpService } from './maintain-days-http.service';
import { ThresholdExceededData } from 'app/configurations-module/infrastructure/models/configuration.model';

@Component({
  selector: 'app-maintain-days',
  templateUrl: './maintain-days.component.html',
  styleUrls: ['./maintain-days.component.scss'],
  providers: [MaintainDaysHttpService]
})
export class MaintainDaysComponent implements OnInit {

  @ViewChild('selecter') ngselect: NgSelectComponent;
  allDaysNotices = [];
  allJurisdictions = [];
  allActions = [];
  allLobs = [];
  selectedActions = [];
  selectedJurisdictions = [];
  selectedLobs = [];
  selectedCircumstances = [];
  allCircumstances = [];
  addDaysColumn = false;
  isClickedDisplay = false;
  isClickedAddDays = false;
  displayFormType = ConfigurationsConstant.daysNoticeFormType.display;
  addFormType = ConfigurationsConstant.daysNoticeFormType.addDays;
  isFoundFilterData = false;
  exportData: any = {
    exportName: ConfigurationsConstant.exportExcel.exportName,
    pageTitle: ConfigurationsConstant.exportExcel.pageTitle,
    fileName: ConfigurationsConstant.exportExcel.fileName,
    data: {
      result: [],
      headers: ConfigurationsConstant.exportExcel.headers,
      keys: ConfigurationsConstant.exportExcel.keys
    },
  };
  isAllChecked = false;
  exportExcelClicked = false;
  selectedRows = [];
  isResultAvl = false;
  isAtleastOneRowSelected = false;
  @ViewChild('updateLiveButton') updateLiveButton: ElementRef<HTMLElement>;

  public daysNoticeForm: FormGroup = new FormGroup({
    daysNotice: new FormControl('', [Validators.required]),
    daysNoticeMax: new FormControl(''),
  });

  constructor(private configMaintainService: ConfigurationsMaintainService,
    private popupService: PopupService,
    private translate: TranslateService,
    private modalService: NgbModal,
    private maintainDaysHttpService: MaintainDaysHttpService,
    private configurationsHttpService: ConfigurationsHttpService) { }

  ngOnInit(): void {
    this.getJurisdictions();
    this.getActions();
    this.getLobs();
    this.getCircumstances();
  }

  customSearchFn(term: string, item: any) {
    return item.name.toLocaleLowerCase().startsWith(term.toLocaleLowerCase());
   }

  getJurisdictions() {
    this.configurationsHttpService.getJurisdictions().subscribe((res: any) => {
      this.allJurisdictions = res;
    });
  }

  getActions() {
    this.configurationsHttpService.getActions().subscribe((res: any) => {
      this.allActions = this.configMaintainService.addGroupName(res, ConfigurationsConstant.daysNotice.allActions);
    });
  }

  getLobs() {
    this.configurationsHttpService.getLobs(ConfigurationsConstant.adminMenuLobs).subscribe((res: any) => {
      res = res.sort((a, b) => a?.name !== b?.name ? a?.name < b?.name ? -1 : 1 : 0);
      this.allLobs = this.configMaintainService.addGroupName(res, ConfigurationsConstant.daysNotice.allLobs);
    });
  }

  getCircumstances() {
    this.configurationsHttpService.getCircumstances().subscribe((res: any) => {
      this.allCircumstances = this.configMaintainService.addGroupName(res, ConfigurationsConstant.daysNotice.allCircumstance);
    });
  }
  displayDisabled() {
    return !(this.selectedCircumstances && this.selectedCircumstances.length && this.selectedLobs && this.selectedLobs.length
      && this.selectedActions && this.selectedActions.length && this.selectedJurisdictions && this.selectedJurisdictions.length);
  }
  toggleAddDays() {
    this.addDaysColumn = !this.addDaysColumn;
  }

  numberOnly(event): boolean {
    return this.configMaintainService.numberOnly(event);
  }

  checkIsValidForm(type) {
    this.isClickedDisplay = true;
    if (type === ConfigurationsConstant.daysNoticeFormType.addDays) {
      this.isClickedAddDays = true;
    }
    if (this.dropDownValid() && type === ConfigurationsConstant.daysNoticeFormType.display) {
      this.displayDays();
    } else if (this.dropDownValid() && type === ConfigurationsConstant.daysNoticeFormType.addDays && this.daysNoticeForm.valid) {
      this.addDays();
    }
  }

  addDays() {
    const addNoticeData = {
      stateCodes: [this.selectedJurisdictions],
      actionIds: this.configMaintainService.getSelectedIds(this.selectedActions),
      lobIds: this.configMaintainService.getSelectedIds(this.selectedLobs),
      whereConditionIds: this.configMaintainService.getSelectedIds(this.selectedCircumstances),
      dayNotice: Number(this.daysNoticeForm.value.daysNotice),
      dayNoticeMax: Number(this.daysNoticeForm.value.daysNoticeMax)
    };
    this.maintainDaysHttpService.addDaysNotice(addNoticeData).subscribe((res: any) => {
      if (res) {
        const thresholdCount = this.configMaintainService.numberWithComma(res.thresholdCount);
        const alertMessage =
          this.translate.instant('CONFIGURATION_MENU.MESSAGES.THRESHOLD_MESSAGE_CONFIG', { thresholdCount: thresholdCount });
        if (res.isThresholdExceeded) {
          this.isResultAvl = false;
          this.configMaintainService.showAlert(alertMessage);
        } else {
          this.isClickedAddDays = false;
          this.displayDays();
          this.daysNoticeForm.get(ConfigurationsConstant.editdaysProperties.daysNotice).setValue('');
          this.daysNoticeForm.get(ConfigurationsConstant.editdaysProperties.daysNoticeMax).setValue('');
          const modalRef = this.modalService.open(DaysNoticeMinMaxComponent);
          res.daysType = ConfigurationsConstant.editDaysType.addMinMax;
          res.operation = ConfigurationsConstant.mode.add;
          modalRef.componentInstance.data = res;
        }
      }
    });
  }

  dropDownValid() {
    const isValid = (this.selectedJurisdictions && this.selectedActions.length > 0
      && this.selectedLobs.length > 0 && this.selectedCircumstances.length > 0) ? true : false;
    return isValid;
  }

  displayDays() {
    this.isFoundFilterData = false;
    this.allDaysNotices = [];
    const jurisdictionsCodes = [this.selectedJurisdictions];
    const actionIds = this.configMaintainService.getSelectedIds(this.selectedActions);
    const lobIds = this.configMaintainService.getSelectedIds(this.selectedLobs);
    const circumstanceIds = this.configMaintainService.getSelectedIds(this.selectedCircumstances);
    const noticeData = {
      stateCodes: jurisdictionsCodes,
      actionIds: actionIds,
      lobIds: lobIds,
      whereConditionIds: circumstanceIds
    };
    this.maintainDaysHttpService.daysNoticeRequirementsCount(noticeData).subscribe((response: ThresholdExceededData) => {
      if (response) {
        const thresholdCount = this.configMaintainService.numberWithComma(response.thresholdCount);
        const alertMessage =
          this.translate.instant('CONFIGURATION_MENU.MESSAGES.THRESHOLD_MESSAGE_CONFIG', { thresholdCount: thresholdCount });
        if (response.isThresholdExceeded) {
          this.isResultAvl = false;
          this.configMaintainService.showAlert(alertMessage);
        } else {
          this.maintainDaysHttpService.getAllDaysNotice(noticeData).subscribe((res: any) => {
            this.isResultAvl = true;
            this.allDaysNotices = this.configMaintainService.setIsSelectedFlag(res);
            this.selectedRows = [];
            this.checkIfAtleastOneRowSelected();
          });
        }
      }
    });
  }

  clearJurisdictions() {
    this.selectedJurisdictions = [];
  }

  cancelDisplay() {
    this.allDaysNotices = [];
    this.selectedActions = [];
    this.selectedJurisdictions = [];
    this.selectedLobs = [];
    this.selectedCircumstances = [];
    this.isClickedDisplay = false;
    this.addDaysColumn = false;
    this.isResultAvl = false;
    this.isClickedAddDays = false;
    this.daysNoticeForm.reset();
  }

  singleEdit(row, type) {
    this.selectedRows = [];
    this.selectedRows.push(row);
    this.editDays(type, ConfigurationsConstant.single);
  }

  editDays(type, mode) {
    if (mode === ConfigurationsConstant.bulk && this.selectedRows.length === 0) {
      return;
    }
    const modalRef = this.modalService.open(DaysNoticeMinMaxComponent);
    const data = {
      daysType: type,
      mode: mode,
      selectedRows: this.selectedRows
    };
    modalRef.componentInstance.data = data;
    modalRef.result.then((userResponse) => {
      if (ConfigurationsConstant.editDaysReload.reload === userResponse) {
        this.displayDays();
        this.selectedRows = [];
      } else {
        this.selectedRows = [];
        this.isAllChecked = false;
        this.isAtleastOneRowSelected = false;
        data.selectedRows.forEach(ele => {
          if (ele.isSelected) {
            ele.isSelected = false;
          }
        });
      }
    });
  }

  exportExcel() {
    this.exportExcelClicked = true;
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
    }
    this.displayDays();
  }

  selectAllCheckbox() {
    if (this.isAllChecked) {
      this.allDaysNotices = this.allDaysNotices.map(notice => ({ ...notice, isSelected: this.isAllChecked }));
      this.selectedRows = this.allDaysNotices;
    } else {
      this.allDaysNotices = this.allDaysNotices.map(notice => ({ ...notice, isSelected: false }));
      this.selectedRows = [];
    }
    this.exportData.data.result = this.selectedRows;
    this.checkIfAtleastOneRowSelected();
  }

  checkChange(event, index) {
    this.allDaysNotices[index].isSelected = event.target.checked;
    this.selectedRows = this.allDaysNotices.filter(notice => notice.isSelected === true);
    this.exportData.data.result = this.selectedRows;
    this.checkIfAtleastOneRowSelected();
  }

  singleDelete(record) {
    this.deleteRecord([record], ConfigurationsConstant.single);
  }

  bulkDelete() {
    this.deleteRecord(this.selectedRows, ConfigurationsConstant.bulk);
  }

  deleteRecord(row, type) {
    const expectedFormat = this.configMaintainService.getDeleteFormat(row);
    const message = type === ConfigurationsConstant.bulk ?
      this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_BULK_DELETE') :
      this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_SINGLE_DELETE');
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.maintainDaysHttpService.deleteDaysNotice(expectedFormat)
          .subscribe(() => {
            const alertMessage = type === ConfigurationsConstant.bulk ?
              this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_DELETED') :
              this.translate.instant('MESSAGES.CONFIRMATION.RECORD_DELETED');
            this.configMaintainService.showSuccessAlert(alertMessage);
            this.displayDays();
          });
      }
    });
  }

  updateToLive() {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: this.translate.instant('CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.UPDATE_LIVE_INFO',
        { stateCode: this.selectedJurisdictions }),
      positiveLabel: this.translate.instant('BUTTON.CONFIRM'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.maintainDaysHttpService.updateLive({
          stateCode: this.selectedJurisdictions
        })
          .subscribe(() => {
            const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.UPDATE_LIVE_SUCCESS',
              { stateCode: this.selectedJurisdictions });
            this.configMaintainService.showSuccessAlert(alertMessage);
          });
      }

      setTimeout(() => {
        const updateLiveBtnElement: HTMLElement = this.updateLiveButton.nativeElement;
        updateLiveBtnElement.blur();
      }, 100);
    });
  }

  checkIfAtleastOneRowSelected() {
    if (this.selectedRows.length === 0) {
      this.isAtleastOneRowSelected = false;
      this.isAllChecked = false;
    } else if (this.allDaysNotices.length === this.selectedRows.length) {
      this.isAtleastOneRowSelected = false;
      this.isAllChecked = true;
    } else if (this.selectedRows.length > 0 &&
      this.selectedRows.length < this.allDaysNotices.length) {
      this.isAtleastOneRowSelected = true;
      this.isAllChecked = false;
    } else {
      this.isAtleastOneRowSelected = false;
      this.isAllChecked = false;
    }
  }
}
