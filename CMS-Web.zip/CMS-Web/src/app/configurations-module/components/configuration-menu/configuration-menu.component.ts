import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { environment } from '@env';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { SpinnerService } from '@wk/nils-core';
import { AppConstants } from 'app/app.constants';
import { ConfigurationsHttpService } from 'app/configurations-module/services/configurations-http.service';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';

@Component({
    selector: 'configuration-menu',
    templateUrl: './configuration-menu.component.html',
    styleUrls: ['./configuration-menu.component.scss'],
})
export class ConfigurationMenuComponent implements OnInit {
    alertMessage = '';
    inProgress = '';
    criteriaBasedRules = [AppConstants.uiRoutes.maintainDays, AppConstants.uiRoutes.maintainMailType,
    AppConstants.uiRoutes.maintainReasons];
    actionLobCircumConfig = [AppConstants.uiRoutes.actionMaintenance, AppConstants.uiRoutes.lobMaintenance,
    AppConstants.uiRoutes.whereConditionMaintenance];
    fieldsandRulesConfiguration = [AppConstants.uiRoutes.fieldDependancyMaintenance, AppConstants.uiRoutes.fieldMasterMaintenance];

    constructor(
        private configurationsHttpService: ConfigurationsHttpService,
        private translate: TranslateService,
        private modalService: NgbModal,
        private spinnerService: SpinnerService) { }

    ngOnInit(): void {
    }

    doNavigation(item) {
        if (item) {
            window.open(`${environment.appUrl}${AppConstants.uiRoutes.configurations}/${item}`);
        }
    }

    updateLiveWizardMenuing(inProgressModal) {
        this.modalService.open(inProgressModal, { size: FormsConstant.formRules.MD, scrollable: true, centered: true });
        this.inProgress = this.translate.instant('MESSAGES.CONFIRMATION.LIVE_WIZARD_MENUING_IS_IN_PROGRESS');
        this.configurationsHttpService.updateLiveWizardMenuing().subscribe(response => {
            if (response) {
                this.modalService.dismissAll();
                this.alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.LIVE_WIZARD_MENUING_UPDATED');
                this.configurationsHttpService.showSuccessAlert(this.alertMessage);
            }
        }, (err: HttpErrorResponse) => {
            if (err.status !== 200) {
                this.modalService.dismissAll();
                this.spinnerService.stop();
                const errorMessage = this.translate.instant('MESSAGES.CONFIRMATION.LIVE_WIZARD_MENUING_UPDATED_ERROR');
                this.configurationsHttpService.showErrorAlert(errorMessage);
            }
        });
    }

    updateWizardMenuing(inProgressModal) {
        this.modalService.open(inProgressModal, { size: FormsConstant.formRules.MD, scrollable: true, centered: true });
        this.inProgress = this.translate.instant('MESSAGES.CONFIRMATION.WIZARD_MENUING_IS_IN_PROGRESS');
        this.configurationsHttpService.updateWizardMenuing().subscribe((response: any) => {
            if (response === null) {
                this.modalService.dismissAll();
                const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.WIZARD_MENUING_UPDATED');
                this.configurationsHttpService.showSuccessAlert(alertMessage);
            }
        }, (err: HttpErrorResponse) => {
            if (err.status !== 200) {
                this.modalService.dismissAll();
                this.spinnerService.stop();
                const errorMessage = this.translate.instant('MESSAGES.CONFIRMATION.WIZARD_MENUING_UPDATED_ERROR');
                this.configurationsHttpService.showErrorAlert(errorMessage);
            }
        });
    }
}
