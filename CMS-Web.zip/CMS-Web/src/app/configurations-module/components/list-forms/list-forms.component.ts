import { Component, OnInit } from '@angular/core';
import '@wk/components/dist/accordion';

@Component({
  selector: 'app-list-forms',
  templateUrl: './list-forms.component.html',
  styleUrls: ['./list-forms.component.scss']
})
export class ListFormsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
