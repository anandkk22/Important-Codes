import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Constants } from '@global/infrastructure/constants';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { DisplayGroup, FieldMasterMaintenanceData } from 'app/configurations-module/components/field-master-maintenance/fieldMasterMaintenance.model ';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { FieldMasterMaintenanceService } from 'app/configurations-module/components/field-master-maintenance/field-master-maintenance.service';
import { WhereUsedModalComponent } from '../where-used-modal/where-used-modal.component';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';

@Component({
  selector: 'app-field-master-maintenance',
  templateUrl: './field-master-maintenance.component.html',
  styleUrls: ['./field-master-maintenance.component.scss'],
  providers: [FieldMasterMaintenanceService]
})
export class FieldMasterMaintenanceComponent implements OnInit {

  constructor(private fieldMasterMaintenanceService: FieldMasterMaintenanceService,
    private translate: TranslateService,
    private popupService: PopupService,
    private configurationsMaintainService: ConfigurationsMaintainService,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private spinnerService: SpinnerService) { }

  masterData: FieldMasterMaintenanceData[];
  isDataAvailable = false;
  fieldMasterForm;
  displayGroupData = Constants.FieldMasterMaintenance.displayGroup;
  fieldDisplayedData = Constants.FieldMasterMaintenance.fieldDisplayData;
  sortedData: DisplayGroup = {};
  isEditRow = false;
  fieldId: number;
  recordStatusData = [];
  fieldObj: FieldMasterMaintenanceData = {};
  isExpanded = false;
  isGotoLink = true;
  recordStatusFlag = false;
  showYellow: any;
  placeHolder = Constants.displayGroup;
  selecteGroupname = '';
  selectefieldDisplayed;
  enteredMaxlengh = '';
  enteredSize = '';
  ngOnInit(): void {
    this.getFieldMasterData();
    this.initForm();
  }
  initForm() {
    this.selectefieldDisplayed = this.fieldDisplayedData[0].code;
    this.fieldMasterForm = this.fb.group({
      fieldName: ['', [Validators.required]],
      label: ['', [Validators.required]],
      maxLength: [, [Validators.required]],
      displaySize: [, [Validators.required]],
      recordActive: [true],
      displayGroup: [],
      fieldDisplayed: [this.selectefieldDisplayed],
      displayControl: ['text']
    });
    this.isEditRow = false;
    this.showYellow = '';
    this.isExpanded = false;
    this.configurationsMaintainService.scrollToTop();
  }
  getFieldMasterData() {
    this.fieldMasterMaintenanceService.getFieldMasterMaintenanceData()
      .subscribe((res: FieldMasterMaintenanceData[]) => {
        if (res && res.length > 0) {
          this.masterData = res;
          this.sortedData = this.sortDatabyGroup(this.masterData);
          this.isDataAvailable = true;
        }
      });
  }
  getSelectedRow(row) {
    this.fieldObj.fieldName = row.fieldName;
    this.fieldObj.label = row.label;
    this.fieldObj.maxLength = row.maxLength;
    this.fieldObj.displayGroup = row.displayGroup === null ? Constants.FieldMasterMaintenance.displayGroupPolicy100Code : row.displayGroup;
    this.fieldObj.recordActive = row.recordActive;
    this.fieldObj.fieldDisplayed = (row.fieldDisplayed === Constants.FieldMasterMaintenance.yes) ? true : false;
    this.fieldObj.displayControl = (row.displayControl === Constants.FieldMasterMaintenance.textBox) ?
      Constants.FieldMasterMaintenance.text : Constants.FieldMasterMaintenance.checkBox;
    this.fieldObj.displaySize = row.displaySize;
    this.resetClick();
    this.isExpanded = true;
    this.configurationsMaintainService.scrollToTop();
  }

  disableButton(action) {
    switch (action) {
      case Constants.switchCase.add: {
        return (!((
        this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.fieldName).value !== this.fieldObj?.fieldName) ||
         (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.label).value !== this.fieldObj?.label) ||
          (Number(this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.maxLength).value) !== this.fieldObj?.maxLength) ||
          (Number(this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displaySize).value)
           !== this.fieldObj?.displaySize) ||
          (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displayGroup).value !==
            (this.fieldObj?.displayGroup && ''))) ||
          !this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.fieldName).value.trim() ||
          !this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.label).value.trim() ||
          !this.fieldMasterForm.valid);
      }
      case Constants.switchCase.update: {
        return (!(
        (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.fieldName).value.trim() !== this.fieldObj?.fieldName) ||
          (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.label).value.trim() !== this.fieldObj?.label) ||
          (Number(this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.maxLength).value) !== this.fieldObj?.maxLength) ||
          (Number(this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displaySize).value)
          !== this.fieldObj?.displaySize) ||
          (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displayGroup).value !== this.fieldObj?.displayGroup) ||
          (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.recordActive).value
            !== this.fieldObj?.recordActive) ||
          (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.fieldDisplayed).value
            !== this.fieldObj?.fieldDisplayed) ||
          (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displayControl).value
            !== this.fieldObj?.displayControl)) ||
            !this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.fieldName).value.trim() ||
            !this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.label).value.trim() ||
            !this.fieldMasterForm.valid);
      }
      case Constants.switchCase.reset: {
        return !((
        this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.fieldName).value.trim() !== this.fieldObj?.fieldName) ||
          (
          this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.label).value.trim() !== this.fieldObj?.label) ||
          (Number(this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.maxLength).value) !== this.fieldObj?.maxLength) ||
          (Number(this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displaySize).value)
          !== this.fieldObj?.displaySize) ||
    (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displayGroup).value !== this.fieldObj?.displayGroup) ||
          (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.recordActive).value !== this.fieldObj?.recordActive) ||
          (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.fieldDisplayed).value
            !== this.fieldObj?.fieldDisplayed) ||
          (this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displayControl).value !== this.fieldObj?.displayControl));
      }
    }

  }
  getBackYellowClass(row) {
    return row?.fieldId === this.showYellow ? ConfigurationsConstant.backYellowClass : '';
  }
  cancelClick() {
    setTimeout(() => { this.isExpanded = false; }, 100);
    this.initForm();
  }
  columnClicked(rowData) {
    this.isEditRow = true;
    if (rowData) {
      this.showYellow = rowData.fieldId;
      this.getSelectedRow(rowData);
      this.fieldId = rowData.fieldId;
    }
  }
  onlyNumber(key): boolean {
    const value = (key === ConfigurationsConstant.fieldMasterMaintenance.maxLength) ? this.enteredMaxlengh : this.enteredSize;
    if (Number(value) && Number(value) > 0) {
      return true;
    } else {
      if (key === ConfigurationsConstant.fieldMasterMaintenance.maxLength) {
        this.enteredMaxlengh = '';
      } else {
        this.enteredSize = '';
      }
    }
    return false;
  }
  isManualExpanded() {
    if (!this.isEditRow) {
      this.selecteGroupname = null;
      this.enteredMaxlengh = null;
      this.enteredSize = null;
    }
    this.isExpanded = !this.isExpanded;
  }
  expandForm(event) {
    event.stopPropagation();
  }

  resetClick() {
    this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.fieldName).setValue(this.fieldObj.fieldName);
    this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.label).setValue(this.fieldObj.label);
    this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.maxLength).setValue(this.fieldObj.maxLength);
    this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displayGroup).setValue(this.fieldObj.displayGroup);
    this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.recordActive).setValue(this.fieldObj.recordActive);
    this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.fieldDisplayed).setValue(this.fieldObj.fieldDisplayed);
    this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displayControl).setValue(this.fieldObj.displayControl);
    this.fieldMasterForm.get(ConfigurationsConstant.fieldMasterMaintenance.displaySize).setValue(this.fieldObj.displaySize);

  }
  addFieldData(form, action) {
    const request = form.value;
    request.displayGroup = JSON.parse(request.displayGroup);
    const request1 = {
      productId: 94,
      shortLabel: '1',
      hoverHelp: '1',
      displayOrder: null
    };
    const reqFinal = { ...request, ...request1 };
    switch (action) {
      case Constants.switchCase.add: {
        this.fieldMasterMaintenanceService.addFieldMasterMaintenanceData(reqFinal)
          .subscribe(() => {
            this.spinnerService.stop();
            const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_ADDED_SUCCESS');
            this.showSuccessAlert(message);
            this.isDataAvailable = false;
            this.initForm();
            this.getFieldMasterData();
          });
      }
        break;
      case Constants.switchCase.update: {
        reqFinal.fieldId = this.fieldId;
        this.fieldMasterMaintenanceService.updateFieldMasterMaintenanceData(reqFinal)
          .subscribe(() => {
            this.spinnerService.stop();
            const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_UPDATED_SUCCESS');
            this.showSuccessAlert(message);
            this.isEditRow = false;
            this.isDataAvailable = false;
            this.initForm();
            this.getFieldMasterData();
          });
      }
    }
  }
  isUpdateStatusButtonEnable() {
    if (this.sortedData) {
      if (this.recordStatusData.length > 0) {
        this.recordStatusFlag = false;
      } else {
        this.recordStatusFlag = true;
      }
    } else {
      this.recordStatusFlag = true;
    }
    return this.recordStatusFlag;
  }
  numberRegex(event) {
    const inp = String.fromCharCode(event.keyCode);
    if (inp) {
      const regEx = Constants.FieldMasterMaintenance.numberRegex;
      if (regEx.test(inp)) {
        return true;
      } else {
        event.preventDefault();
        return false;
      }
    }
  }
  onRecordStatusClick(record, row) {
    const updateStatusData = {
      'fieldId': row.fieldId,
      'status': row.recordActive
    };
    updateStatusData.status = record.target.checked;
    const recordFound = this.recordStatusData.findIndex(data => data.fieldId === updateStatusData.fieldId);
    if (recordFound < 0) {
      this.recordStatusData.push(updateStatusData);
    } else {
      if (this.recordStatusData.length > 0) {
        this.recordStatusData.splice(recordFound, 1);
      }
    }
  }
  updateStatus() {
    this.fieldMasterMaintenanceService.updateStatusData(this.recordStatusData)
      .subscribe(() => {
        this.isDataAvailable = false;
        this.getFieldMasterData();
        const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_UPDATED_SUCCESS');
        this.showSuccessAlert(message);
      });
      this.initForm();
    this.recordStatusFlag = true;
    this.recordStatusData = [];
  }
  getValue(group) {
    if (group.name.split('(')[0].trim() === 'Policy') {
      return group.name;
    } else {
      return group.name.split('(')[0];
    }
  }
  scrollToGroup(group) {
    document.getElementById(group.name).scrollIntoView({
      behavior: 'smooth'
    });
  }
  fieldWhereUsed(fieldData) {
    const fieldGroup = Object.keys(this.sortDatabyGroup([fieldData]))[0];
    this.fieldMasterMaintenanceService.whereUsedFieldName(fieldData.fieldName)
      .subscribe((res: any[]) => {
        if (res) {
          const modalRef = this.modalService.open(WhereUsedModalComponent);
          modalRef.componentInstance.data = res;
          modalRef.componentInstance.fieldGroup = fieldGroup;
          modalRef.componentInstance.fieldName = fieldData.fieldName;
        }
      });
  }

  getActievGroup(group) {
    if (this.sortedData && group) {
      for (const key in this.sortedData) {
        if (this.sortedData.hasOwnProperty(group.name)) {
          return Constants.FieldMasterMaintenance.textBlue;
        }
        else { return Constants.FieldMasterMaintenance.textBlack; }
      }
    }
  }
  sortDatabyGroup(masterData) {
    const sortArray: DisplayGroup = {};
    for (const item of masterData) {
      item.displayControl = (item.displayControl === Constants.FieldMasterMaintenance.textBox ||
        item.displayControl === Constants.FieldMasterMaintenance.text) ?
        Constants.FieldMasterMaintenance.textBox : Constants.FieldMasterMaintenance.checkBox;
      item.fieldDisplayed = (item.fieldDisplayed === true || item.fieldDisplayed === Constants.FieldMasterMaintenance.yes) ?
      Constants.FieldMasterMaintenance.yes : Constants.FieldMasterMaintenance.no;
      switch (item.displayGroup) {
        case 210:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.premiumAdjustment)) {
              sortArray[Constants.FieldMasterMaintenance.premiumAdjustment].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.premiumAdjustment] = [item];
            }
          }
          break;
        case 10:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.insurer)) {
              sortArray[Constants.FieldMasterMaintenance.insurer].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.insurer] = [item];
            }
          }
          break;
        case 20:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.producer)) {
              sortArray[Constants.FieldMasterMaintenance.producer].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.producer] = [item];
            }
          }
          break;
        case 30:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.insured)) {
              sortArray[Constants.FieldMasterMaintenance.insured].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.insured] = [item];
            }
          }
          break;
        case 1000:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.mortgagee)) {
              sortArray[Constants.FieldMasterMaintenance.mortgagee].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.mortgagee] = [item];
            }
          }
          break;
        case 1010:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.lienholder)) {
              sortArray[Constants.FieldMasterMaintenance.lienholder].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.lienholder] = [item];
            }
          }
          break;
        case 1020:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.certificateHolder)) {
              sortArray[Constants.FieldMasterMaintenance.certificateHolder].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.certificateHolder] = [item];
            }
          }
          break;
        case 1030:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.additionalParty)) {
              sortArray[Constants.FieldMasterMaintenance.additionalParty].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.additionalParty] = [item];
            }
          }
          break;
        case 1040:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.thirdParty)) {
              sortArray[Constants.FieldMasterMaintenance.thirdParty].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.thirdParty] = [item];
            }
          }
          break;
        case 1050:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.worksComp)) {
              sortArray[Constants.FieldMasterMaintenance.worksComp].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.worksComp] = [item];
            }
          }
          break;
        case 200:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.policy_200)) {
              sortArray[Constants.FieldMasterMaintenance.policy_200].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.policy_200] = [item];
            }
          }
          break;
        default:
          {
            if (sortArray.hasOwnProperty(Constants.FieldMasterMaintenance.policy_100)) {
              sortArray[Constants.FieldMasterMaintenance.policy_100].push(item);
            }
            else {
              sortArray[Constants.FieldMasterMaintenance.policy_100] = [item];
            }
          }
      }
    }
    return sortArray;
  }
  showSuccessAlert(message) {
    this.popupService.showSuccess({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }
}
