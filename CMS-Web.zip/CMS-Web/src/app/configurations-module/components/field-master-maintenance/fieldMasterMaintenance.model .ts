export interface FieldMasterMaintenanceData {
    fieldId?: number;
    productId?: number;
    fieldName?: string;
    label?: string;
    shortLabel?: string;
    displayControl?: string;
    hoverHelp?: string;
    displayGroup?: number;
    displayOrder?: number;
    displaySize?: number;
    maxLength?: number;
    recordActive?: boolean;
    fieldDisplayed?: boolean;
}
export interface DisplayGroup {
    'Policy (100)'?: [FieldMasterMaintenanceData];
    'Policy (200)'?: [FieldMasterMaintenanceData];
    'Premium Adjustment (210)'?: [FieldMasterMaintenanceData];
    'Insurer (10)'?: [FieldMasterMaintenanceData];
    'Producer (20)'?: [FieldMasterMaintenanceData];
    'Insured (30)'?: [FieldMasterMaintenanceData];
    'Mortgagee (1000)'?: [FieldMasterMaintenanceData];
    'Lienholder (1010)'?: [FieldMasterMaintenanceData];
    'Certificate Holder (1020)'?: [FieldMasterMaintenanceData];
    'Additional Interest (1030)'?: [FieldMasterMaintenanceData];
    'Third Party (1040)'?: [FieldMasterMaintenanceData];
    'Workers Comp (1050)'?: [FieldMasterMaintenanceData];
}
