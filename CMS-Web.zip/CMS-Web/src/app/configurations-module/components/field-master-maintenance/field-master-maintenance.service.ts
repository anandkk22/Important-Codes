import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';
import { Observable } from 'rxjs';

@Injectable()
export class FieldMasterMaintenanceService {

  constructor(private http: HttpClient) { }

   getFieldMasterMaintenanceData() {
    return this.http.get(`${Constants.webApis.getFieldMasterMaintenance}`);
  }
   addFieldMasterMaintenanceData(recordData) {
    return this.http.post(`${Constants.webApis.getFieldMasterMaintenance}`, recordData);
  }
   updateFieldMasterMaintenanceData(recordData) {
    return this.http.put(`${Constants.webApis.getFieldMasterMaintenance}`, recordData);
  }
   updateStatusData(recordData) {
    return this.http.put(`${Constants.webApis.updateStatusFieldMaster}`, recordData);
  }
   whereUsedFieldName(recordData) {
    return this.http.get(`${Constants.webApis.whereUsedFieldName}` + '/' + recordData);
  }
   downloadForm(formName): Observable<any> {
    return this.http.put(Constants.webApis.pdfForm.replace('{formName}', formName), '',
    { responseType: Constants.responseType.blobType as 'json', observe: 'response' });
  }
}
