import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { ConfigurationsHttpService } from 'app/configurations-module/services/configurations-http.service';

@Component({
  selector: 'days-notice-min-max',
  templateUrl: './days-notice-min-max.component.html',
  styleUrls: ['./days-notice-min-max.component.scss'],
})
export class DaysNoticeMinMaxComponent implements OnInit {
  @Input() data;
  daysHeading: any;
  daysFormName: any;
  daysFieldError: any;
  daysView = false;
  errorView = false;
  failedRows = [];
  successRows = [];
  sucessView = false;
  viewRecordsView = false;
  unsucessfulRecords: any;
  sucessfulRecords: any;
  viewText: any;
  showView = 'added';
  public daysMinMaxForm: FormGroup = new FormGroup({
    daysMinMax: new FormControl('', [Validators.required]),
  });
  isClickedMinMAxDays = false;
  selectedRows = [];
  isAddMinMaxHeadeing = false;
  isAddMinMax = false;
  backUpField = '';

  constructor(
    public activeModal: NgbActiveModal,
    private translate: TranslateService,
    private configMaintainService: ConfigurationsMaintainService,
    private configurationsHttpService: ConfigurationsHttpService) {}

  ngOnInit(): void {
    if (this.data.operation === ConfigurationsConstant.mode.add) {
      this.failedRows = this.data.notAddedRecords;
      this.successRows = this.data.addedRecords;
      this.unsucessfulRecords = this.data.notAddedRecords.length || 0;
      this.sucessfulRecords = this.data.addedRecords.length || 0;

      this.isAddMinMaxHeadeing = true;
      this.isAddMinMax = true;
    } else {
      this.daysView = true;
      this.errorView = false;
      this.isClickedMinMAxDays = false;
      if (this.data.mode === ConfigurationsConstant.single) {
        this.singleEdit();
      } else {
        this.bulkEdit();
      }
    }
  }

  singleEdit() {
    if (this.data.daysType === ConfigurationsConstant.editDaysType.minDays) {
      this.daysHeading = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.EDIT_MIN_DAYS'
      );
      this.daysFormName = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.MIN_DAYS_COL'
      );
      this.daysFieldError = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.MIN_DAYS_ERR'
      );
      this.daysMinMaxForm.setValue({
        daysMinMax: this.data.selectedRows[0].dayNotice,
      });
    } else {
      this.daysHeading = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.EDIT_MAX_DAYS'
      );
      this.daysFormName = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.MAX_DAYS_COL'
      );
      this.daysFieldError = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.MAX_DAYS_ERR'
      );
      this.daysMinMaxForm.setValue({
        daysMinMax: this.data.selectedRows[0].dayNoticeMax,
      });
    }
    this.backUpField = this.daysMinMaxForm.value.daysMinMax;
  }

  bulkEdit() {
    if (this.data.daysType === ConfigurationsConstant.editDaysType.minDays) {
      this.daysHeading = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.EDIT_MIN_DAYS'
      );
      this.daysFormName = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.MIN_DAYS_COL'
      );
      this.daysFieldError = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.MIN_DAYS_ERR'
      );
    } else {
      this.daysHeading = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.EDIT_MAX_DAYS'
      );
      this.daysFormName = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.MAX_DAYS_COL'
      );
      this.daysFieldError = this.translate.instant(
        'CONFIGURATION_MENU.DAYS_NOTICE_REQUIREMENTS.MAX_DAYS_ERR'
      );
    }
  }

  numberOnly(event): boolean {
    return this.configMaintainService.numberOnly(event);
  }

  updatedMinMaxDays() {
    this.isClickedMinMAxDays = true;
    if (this.daysMinMaxForm.valid) {
      const updateData = this.configMaintainService.getFormatedUpdateDays(
        this.data,
        this.daysMinMaxForm.value.daysMinMax
      );
      this.configurationsHttpService
        .updateDaysNotices(updateData)
        .subscribe(() => {
          this.daysView = false;
          this.successOk();
          const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_UPDATED_SUCCESS');
          this.configMaintainService.showSuccessAlert(alertMessage);
        });
    }
  }

  clearMinMAxDays() {
    this.daysMinMaxForm.get('daysMinMax').setValue(this.backUpField);
    this.isClickedMinMAxDays = false;
  }

  cancelUpdate() {
    this.activeModal.close(ConfigurationsConstant.editDaysReload.noReload);
  }

  cancelViewRecords() {
    this.failedRows = [];
    this.activeModal.close(ConfigurationsConstant.editDaysReload.reload);
  }

  successOk() {
    this.activeModal.close(ConfigurationsConstant.editDaysReload.reload);
  }

  viewRecords() {
    this.errorView = false;
    this.viewRecordsView = true;
    this.isAddMinMax = false;
  }
}
