import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ConfigurationsHttpService } from 'app/configurations-module/services/configurations-http.service';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';

@Component({
  selector: 'app-maintain-reasons-edit',
  templateUrl: './maintain-reasons-edit.component.html',
  styleUrls: ['./maintain-reasons-edit.component.scss']
})
export class MaintainReasonsEditComponent implements OnInit {

  @Input() data;
  editModal = false;

  public reasonForm: FormGroup = new FormGroup({
    reason: new FormControl('', [Validators.required]),
  });

  constructor(private activeModal: NgbActiveModal,
    private translate: TranslateService,
    private configMaintainService: ConfigurationsMaintainService,
    private configurationsHttpService: ConfigurationsHttpService) { }

  ngOnInit(): void {
    this.editModal = true;
    this.reasonForm.get('reason').setValue(this.data.reasonText);
  }

  cancel() {
    this.activeModal.close(ConfigurationsConstant.editDaysReload.noReload);
  }
  isDisabled() {
    return !(this.data.reasonText !== this.reasonForm.get('reason').value.trim() && this.reasonForm.get('reason').value.trim() !== '') ;
  }
  onSave() {
    this.configurationsHttpService.editReason(this.data.accountActionReasonId, {reasonText: this.reasonForm.get('reason').value})
      .subscribe(() => {
        this.editModal = false;
        this.activeModal.close(ConfigurationsConstant.editDaysReload.reload);
        const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_UPDATED_SUCCESS');
        this.configMaintainService.showSuccessAlert(alertMessage);
      });
  }

  onReset() {
    this.reasonForm.get('reason').setValue(this.data.reasonText);
  }


}
