import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Constants } from '@global/infrastructure/constants';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import '@wk/components/dist/accordion';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { AppConstants } from 'app/app.constants';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { take } from 'rxjs/operators';
import { WhereUsedModalComponent } from '../where-used-modal/where-used-modal.component';
import { FieldDependancyRuleService } from './field-dependancy-rule.service';

@Component({
  selector: 'app-field-rule-maintenance',
  templateUrl: './field-rule-maintenance.component.html',
  styleUrls: ['./field-rule-maintenance.component.scss'],
  providers: [FieldDependancyRuleService]
})
export class FieldRuleMaintenanceComponent implements OnInit {
  constructor(private fb: FormBuilder,
    private configurationsMaintainService: ConfigurationsMaintainService,
    private fieldDependancyRuleService: FieldDependancyRuleService,
    private modalService: NgbModal,
    private spinnerService: SpinnerService,
    private translate: TranslateService,
    private popupService: PopupService
  ) { }
  isAllChecked = false;
  isExpanded = false;
  isDataAvailable = false;
  isEditRow = false;
  FieldDependancyForm;
  selectedTemplate;
  isPaginationRequired = false;
  isNoRecordFound = false;
  showYellow: any;
  isNoSearchRecordFound = false;
  isSearched = false;
  searchKeyword = '';
  orderByDesc = true;
  masterData = [];
  responseData = [];
  templateData = [];
  placeholder = ConfigurationsConstant.fieldDependancyRules.placeHolder;
  disableFieldData = false;
  selectedRow = [];
  allComponents = [];
  isAtleastOneSelected = false;
  gridData;
  fieldObj = {
    template: '',
    FieldRuleDescription: '',
    fieldRuleID: ''
  };
  placeholder1 = 'Select template and change placeholders to appropriate field names';
  allData = [];
  paginationOptions: any = {
    currentPage: Constants.paginationOptions.currentPage,
    pageSize: Constants.paginationOptions.pageSize,
    totalItems: Constants.paginationOptions.totalItems,
  };
  ngOnInit(): void {
    this.getFieldMasterData();
    this.getFieldTemplateData();
    this.initForm();
  }
  clearForm() {
    this.FieldDependancyForm = this.fb.group({
      template: [],
      FieldRuleDescription: [''],
    });
    this.isEditRow = false;
    this.isExpanded = false;
    this.showYellow = '';
    this.configurationsMaintainService.scrollToTop();

  }
  initForm() {
   this.clearForm();
   this.selectedTemplate = this.placeholder1;
   this.selectedRow = [];
    this.isAllChecked = false;
    this.isAtleastOneSelected = false;
    this.searchKeyword  = '';
  }
  getFieldTemplateData() {
    this.fieldDependancyRuleService.getFieldTemplateData()
      .subscribe((res: any) => {
        if (res && res.length > 0) {
          this.templateData = res;
        }
        else {
          this.isNoRecordFound = true;
        }
      });
  }
  getFieldMasterData() {
    const request = {
      pageNumber: this.paginationOptions.currentPage,
      size: this.paginationOptions.pageSize,
      fieldruleDesc: this.searchKeyword,
      orderByDesc: this.orderByDesc
    };
    this.fieldDependancyRuleService.getFieldDependancyData(request)
      .subscribe((res: any) => {
        if (res && res.fieldRules && res.fieldRules.length > 0) {
          this.masterData = res.fieldRules;
          this.responseData = res.fieldRules;
          this.paginationOptions.totalItems = res.totalCount;
          this.isPaginationRequired = this.paginationOptions.totalItems > 200 ? true : false;
          if (this.isPaginationRequired) {
            this.loadPageSize();
          }
          this.masterData = this.fieldDependancyRuleService.loadGridCheckedData(this.masterData, this.selectedRow);
          this.isDataAvailable = true;
        }
        else if (this.searchKeyword) {
          this.isNoSearchRecordFound =  true;
        } else {
          this.isNoRecordFound = true;
        }
        this.checkIfAtleastOneSelected();
      });
  }
  getAllFieldMasterData() {
    const request = {
      pageNumber: 1,
      size: this.paginationOptions.totalItems,
      fieldruleDesc: this.searchKeyword,
      orderByDesc: this.orderByDesc
    };
    this.fieldDependancyRuleService.getFieldDependancyData(request)
      .subscribe((res: any) => {
        if (res && res.fieldRules && res.fieldRules.length > 0) {
          this.selectedRow = this.fieldDependancyRuleService.getAllRowChecked(res.fieldRules);
          this.masterData = this.fieldDependancyRuleService.getAllRowChecked(this.masterData);
          this.checkIfAtleastOneSelected();
        }
      });
  }
  loadPageSize() {
    this.configurationsMaintainService.loadUpadtedPageSizes();
  }

  getSelectedTemplate(template) {
    if (template) {
      this.FieldDependancyForm.get(ConfigurationsConstant.fieldDependancyRules.fieldRuleDescription).setValue(template);
    }
  }
  search() {
    this.paginationOptions.currentPage = 1;
    this.isSearched = this.showClearIcon();
    this.searchKeyword = this.searchKeyword.trim();
    this.selectedRow = [];
    if (this.isSearched) {
      this.getFieldMasterData();
    } else {
      this.resetSearch();
    }

  }

  showClearIcon() {
    return (this.searchKeyword && this.searchKeyword.trim()) ? true : false;
  }
  resetSearch() {
    this.paginationOptions.currentPage = 1;
    this.isSearched = false;
    this.searchKeyword = '';
    this.isNoSearchRecordFound = false;
    this.selectedRow = [];
    this.getFieldMasterData();
  }
  getSelectedRow(row) {
    this.disableFieldData = true;
    if (row) {
      this.fieldObj.fieldRuleID = row.fieldRuleID;
      this.fieldObj.FieldRuleDescription = row.fieldRuleDesc;
      this.resetClick();
    }
    this.isExpanded = true;
    this.configurationsMaintainService.scrollToTop();
  }
  columnClicked(rowData) {
    this.isEditRow = true;
    if (rowData) {
      this.showYellow = rowData.fieldRuleID;
      this.getSelectedRow(rowData);
    }
  }

  getBackYellowClass(row) {
    return row?.fieldRuleID === this.showYellow ? ConfigurationsConstant.backYellowClass : '';
  }

  onFieldRule(ev: any) {
    const description = ev.target.value.trim();
    if (description === '' && !this.isEditRow) {
      this.FieldDependancyForm.get(ConfigurationsConstant.fieldDependancyRules.fieldRuleDescription).setValue(description);
    }
  }

  disableButton(action) {
    switch (action) {
      case Constants.switchCase.add: {
        return (!((this.FieldDependancyForm.get(ConfigurationsConstant.fieldDependancyRules.template).value
        !== this.fieldObj?.template) ||
          (this.FieldDependancyForm.get(ConfigurationsConstant.fieldDependancyRules.fieldRuleDescription).value
           !== this.fieldObj?.FieldRuleDescription)) ||
          !this.FieldDependancyForm.valid);
      }
      case Constants.switchCase.update: {
        return (!(this.FieldDependancyForm.get(ConfigurationsConstant.fieldDependancyRules.fieldRuleDescription).value.trim()
        !== this.fieldObj?.FieldRuleDescription) ||
          !(this.FieldDependancyForm.get(ConfigurationsConstant.fieldDependancyRules.fieldRuleDescription).value.trim() !== null) ||
          !(this.FieldDependancyForm.get(ConfigurationsConstant.fieldDependancyRules.fieldRuleDescription).value.trim() !== '') ||
          !this.FieldDependancyForm.valid);
      }
      case Constants.switchCase.reset: {
        return (!(this.FieldDependancyForm.get(ConfigurationsConstant.fieldDependancyRules.fieldRuleDescription).value
        !== this.fieldObj?.FieldRuleDescription));
      }
    }

  }
  resetClick() {
    this.FieldDependancyForm.get(ConfigurationsConstant.fieldDependancyRules.fieldRuleDescription).
    setValue(this.fieldObj.FieldRuleDescription);
  }

  checkAllCheckbox() {
    if (this.isAllChecked) {
      this.selectedRow = [];
      this.getAllFieldMasterData();
    } else {
      this.selectedRow = [];
      this.masterData = this.fieldDependancyRuleService.getAllRowUnchecked(this.masterData);
    }
    this.checkIfAtleastOneSelected();
  }

  checkIfAtleastOneSelected() {
    if (this.selectedRow.length === 0) {
      this.isAtleastOneSelected = false;
      this.isAllChecked = false;
    } else if (this.paginationOptions.totalItems === this.selectedRow.length) {
      this.isAtleastOneSelected = false;
      this.isAllChecked = true;
    } else if ((this.paginationOptions.totalItems > this.selectedRow.length)
      && (this.selectedRow.length > 0)) {
      this.isAtleastOneSelected = true;
      this.isAllChecked = false;
    }
    else {
      this.isAtleastOneSelected = false;
      this.isAllChecked = false;
    }
  }

  addToSelectedtable(oneRow) {
    this.selectedRow.push(oneRow);
  }

  changeCheckbox(data) {
    data.isSelected = !data.isSelected;
    if (data.isSelected) {
      this.addToSelectedtable(data);
    } else {
      this.removeFromSelectedtable(data.fieldRuleID);
    }
    this.checkIfAtleastOneSelected();
  }

  removeFromSelectedtable(fieldRuleID) {
    const index = this.selectedRow.findIndex(d => d.fieldRuleID === fieldRuleID);
    this.selectedRow.splice(index, 1);
  }


  singleDelete(record) {
    const deleteArray = record.fieldRuleID;
    this.deleteRecord([deleteArray], ConfigurationsConstant.single);
  }

  bulkDelete() {
    const deleteArray = [];
    this.selectedRow.filter(item => { deleteArray.push(item.fieldRuleID); });
    this.deleteRecord(deleteArray, ConfigurationsConstant.editDaysType.bulk);
  }

  deleteRecord(record, type) {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: type === ConfigurationsConstant.bulk ?
        this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_BULK_DELETE') :
        this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_SINGLE_DELETE'),
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.fieldDependancyRuleService.deleteRecords(record)
          .subscribe(() => {
             this.spinnerService.stop();
          const message = type === ConfigurationsConstant.bulk ?
           this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_DELETED')  :
          this.translate.instant('MESSAGES.CONFIRMATION.RECORD_DELETED');
          this.showSuccessAlert(message);
          this.isDataAvailable = false;
          this.initForm();
          this.getFieldMasterData();
          });

      }
    });
  }
  fieldWhereUsed(fieldData) {
    fieldData.section = ConfigurationsConstant.fieldDependancyRules.title;
    this.fieldDependancyRuleService.whereUsedFieldName(fieldData.fieldRuleID)
      .subscribe((res: any[]) => {
        if (res) {
          const modalRef = this.modalService.open(WhereUsedModalComponent);
          modalRef.componentInstance.data = res;
          modalRef.componentInstance.fieldGroup = fieldData;
          modalRef.componentInstance.fieldName = fieldData.fieldRuleID;
        }
      });
  }
  activityMethod(action, form?) {
    delete form.value.template;
    form.value.evaluatedOn = ConfigurationsConstant.fieldDependancyRules.fieldChange;
    form.value.FieldRuleDescription = form.value.FieldRuleDescription?.trim();
    switch (action) {
      case Constants.FieldMasterMaintenance.add: {
        this.fieldDependancyRuleService.addFieldDependancyData(form.value)
          .subscribe(() => {
            this.spinnerService.stop();
            const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_ADDED_SUCCESS');
            this.showSuccessAlert(message);
            this.isDataAvailable = false;
            this.initForm();
            this.getFieldMasterData();
          });
      }
      break;
      case Constants.FieldMasterMaintenance.update: {
        const request = { ...form.value, 'fieldRuleID': this.fieldObj.fieldRuleID };
        this.fieldDependancyRuleService.updateFieldDependancyData(request)
          .subscribe(() => {
            this.spinnerService.stop();
            const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_UPDATED_SUCCESS');
            this.showSuccessAlert(message);
            this.isEditRow = false;
            this.isDataAvailable = false;
            this.initForm();
            this.getFieldMasterData();
          });
      }
      break;
    }

  }
  cancelClick() {
    setTimeout(() => { this.isExpanded = false; }, 100);
    this.clearForm();
  }
  isManualExpanded() {
    if (!this.isEditRow) {
      this.selectedTemplate = null;
    }
    this.isExpanded = !this.isExpanded;
  }
  expandForm(event) {
    event.stopPropagation();
  }

  sortBy(header) {
    this.orderByDesc = header;
    this.getFieldMasterData();
  }

  showSuccessAlert(message) {
    this.popupService.showSuccess({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }
  onPageClick(event) {
    this.paginationOptions.currentPage = event.detail;
    this.getFieldMasterData();
    this.loadPageSize();
  }
  pageSizeChange(event) {
    this.paginationOptions.currentPage = Constants.paginationOptions.currentPage;
    this.paginationOptions.pageSize = event.detail;
    this.getFieldMasterData();
    this.loadPageSize();
  }
  openRuleSteps(item) {
    if (item) {
      const path = AppConstants.uiRoutes.fieldRuleStepsUrl + item.fieldRuleID;
      const encodedUrl = this.configurationsMaintainService.getEncodedUrl(path);
      window.open(encodedUrl, FormsConstant.openChildWindow.fieldRuleStep, FormsConstant.openChildWindow.openChildWindow); return false;
    }
  }
}
