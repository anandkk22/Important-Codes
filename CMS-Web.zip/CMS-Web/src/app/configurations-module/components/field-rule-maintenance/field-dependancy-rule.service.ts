import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';
import { Observable } from 'rxjs';

@Injectable()
export class FieldDependancyRuleService {

  constructor(private http: HttpClient) { }

  getFieldTemplateData() {
    return this.http.get(`${Constants.webApis.fieldDependancyRule.getFieldTemplate}`);
  }
   getFieldDependancyData(record) {
     if (record.orderByDesc === '') {
      return this.http.get(`${Constants.webApis.fieldDependancyRule.getFieldDependancy
        .replace('{pNum}', record.pageNumber)
        .replace('{pSize}', record.size)
        .replace('{fieldruleDesc}', record.fieldruleDesc)}`);
     } else {
      return this.http.get(`${Constants.webApis.fieldDependancyRule.getFieldDependancyWithOrder
        .replace('{pNum}', record.pageNumber)
        .replace('{pSize}', record.size)
        .replace('{fieldruleDesc}', record.fieldruleDesc)
        .replace('{OrderByDesc}', record.orderByDesc)}`);
     }

  }
   addFieldDependancyData(recordData) {
    return this.http.post(`${Constants.webApis.fieldDependancyRule.addUpdateFieldDependancy}`, recordData);
  }
   updateFieldDependancyData(recordData) {
    return this.http.put(`${Constants.webApis.fieldDependancyRule.addUpdateFieldDependancy}`, recordData);
  }

   whereUsedFieldName(fieldRuleId) {
    return this.http.get(`${Constants.webApis.fieldDependancyRule.fieldRuleWhereUsed.replace('{fieldRuleId}', fieldRuleId)}`);
  }
   downloadForm(formName): Observable<any> {
    return this.http.put(Constants.webApis.getHelpForm.replace('{formName}', formName), '',
    { responseType: Constants.responseType.blobType as 'json', observe: 'response' });
  }
  deleteRecords(recordData) {
    const options = this.getRequestData(recordData);
    return this.http.delete(`${Constants.webApis.fieldDependancyRule.deleteRecord}`, options);
  }
  getRequestData(records) {
    const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body: records };
    return options;
  }

  getAllRowUnchecked(masterData) {
    masterData.forEach(element => {
      element.isSelected = false;
    });
    return masterData;
  }

  getAllRowChecked(masterData) {
    masterData.forEach(element => {
      element.isSelected = true;
    });
    return masterData;
  }

  loadGridCheckedData(masterData, selectedRow) {
    if (selectedRow.length > 0) {
      masterData.forEach(element => {
        if (selectedRow.some(e => e.fieldRuleID === element.fieldRuleID)) {
            Object.assign(element, {isSelected: true});
        } else {
            Object.assign(element, {isSelected: false});
        }
      });
    } else {
      masterData.forEach(element => {
        element.isSelected = false;
      });
    }
    return masterData;
  }

}
