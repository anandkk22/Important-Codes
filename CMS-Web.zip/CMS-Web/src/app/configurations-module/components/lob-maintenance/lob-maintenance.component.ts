import { Component, OnInit } from '@angular/core';
import { ActionMode, ConfigurationMasterData, GridRowData } from 'app/configurations-module/infrastructure/models/configuration.model';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { SpinnerService } from '@wk/nils-core';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { TranslateService } from '@ngx-translate/core';
import { LobMaintenanceHttpService } from './lob-maintenance-http.service';

@Component({
  selector: 'lob-maintenance',
  templateUrl: './lob-maintenance.component.html',
  styleUrls: ['./lob-maintenance.component.scss'],
  providers: [LobMaintenanceHttpService]
})
export class LobMaintenanceComponent implements OnInit {

  configurationMasterData: ConfigurationMasterData;
  recordId = null;
  isGridRowEditing = false;
  isDataAvailable = false;
  isUpdateLiveRequired = false;

  exportData: any = {
    exportName: ConfigurationsConstant.exportExcel.exportLOBMaintenance,
    pageTitle: ConfigurationsConstant.exportExcel.exportLOBMaintenancePageTitle,
    fileName: ConfigurationsConstant.exportExcel.exportLOBMaintenanceFileName,
    data: {
      result: [],
      headers: ConfigurationsConstant.exportExcel.headerLOBMaintenance,
      keys: ConfigurationsConstant.exportExcel.lobMaintenanceKeys
    },
  };

  constructor(private configurationsMaintainService: ConfigurationsMaintainService,
    private spinnerService: SpinnerService,
    private translate: TranslateService,
    private lobMaintenanceHttpService: LobMaintenanceHttpService) { }

  ngOnInit(): void {
    this.configurationMasterData = this.configurationsMaintainService.getConfigurationMasterData(
      ConfigurationsConstant.configurationSectionDetails.lob.sectionName);
    this.configurationMasterData.isExpanded = false;
    this.getLOBMaintenanceRecord();
  }

  getLOBMaintenanceRecord() {
    this.lobMaintenanceHttpService.getLobMaintenanceRecord()
    .subscribe((res: GridRowData[]) => {
      if (res && res.length > 0) {
        if (this.configurationMasterData && this.configurationMasterData.tableData) {
          this.configurationMasterData.tableData.rowData = res;
          this.exportData.data.result = res;
          this.isDataAvailable = true;
          if (this.configurationMasterData.sectionName === ConfigurationsConstant.configurationSectionDetails.lob.lobField) {
            let lobExportData: any;
            lobExportData =   this.configurationMasterData.tableData.rowData;
            for (let i = 0; i < lobExportData.length; i++) {
              if (lobExportData[i].recordActive) {
                lobExportData[i].recordStatus = ConfigurationsConstant.configurationSectionDetails.lob.recordStatusYes;
              } else {
                lobExportData[i].recordStatus = ConfigurationsConstant.configurationSectionDetails.lob.recordStatusNo;
              }
            }
          }
        }
      }
    });
  }

  actionClick(event) {
    switch (event.mode) {
      case ActionMode.add:
        this.addLOBRecord(event.data);
        break;

      case ActionMode.save:
        this.saveLobMaintenanceRecord(event.data);
        break;

      case ActionMode.cancel:
        this.onCancelClick();
        break;

        case ActionMode.reset:
        this.onResetClick();
        break;

        default:
        this.onResetClick();
        break;
    }
  }

  addLOBRecord(record) {
    const data = {
      'lobAbbrevation': record.lobAbbr,
      'lob': record.lob,
      'definition': record.definition
    };
    this.lobMaintenanceHttpService.addLobMaintenanceRecord(data).subscribe(res => {
      this.isDataAvailable = false;
      this.getLOBMaintenanceRecord();
      this.configurationMasterData.fieldsDetails.definition = '';
      this.configurationMasterData.fieldsDetails.lobAbbr = '';
      this.configurationMasterData.fieldsDetails.lob = '';
      this.spinnerService.stop();
      const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_ADDED_SUCCESS');
      this.configurationsMaintainService.showSuccessAlert(alertMessage);
    });
  }

  saveLobMaintenanceRecord(record) {
    const data = {
      'lobId': this.recordId,
      'lobAbbrevation': record.lobAbbr,
      'lob': record.lob,
      'definition': record.definition,
      'recordActive': record.recordActive
    };
    this.lobMaintenanceHttpService.updateLobMaintenanceRecord(data)
    .subscribe(() => {
      this.isDataAvailable = false;
      this.getLOBMaintenanceRecord();
      this.configurationMasterData.fieldsDetails.definition = '';
      this.configurationMasterData.fieldsDetails.lobAbbr = '';
      this.configurationMasterData.fieldsDetails.lob = '';
      this.configurationMasterData.defaultValues.definition = '';
      this.configurationMasterData.defaultValues.lobAbbr = '';
      this.configurationMasterData.defaultValues.lob = '';
      this.configurationMasterData.isEdit = false;
      this.configurationMasterData.isExpanded = false;
      this.isGridRowEditing = false;
      this.spinnerService.stop();
      const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_UPDATED_SUCCESS');
      this.configurationsMaintainService.showSuccessAlert(alertMessage);
    });
  }

  onCancelClick() {
    this.configurationMasterData.fieldsDetails.definition = '';
    this.configurationMasterData.fieldsDetails.lobAbbr = '';
    this.configurationMasterData.fieldsDetails.lob = '';
    this.configurationMasterData.isEdit = false;
    this.isGridRowEditing = false;
  }

  onResetClick() {
    this.configurationMasterData.fieldsDetails.definition = this.configurationMasterData.defaultValues.definition;
    this.configurationMasterData.fieldsDetails.lobAbbr = this.configurationMasterData.defaultValues.lobAbbr;
    this.configurationMasterData.fieldsDetails.lob =  this.configurationMasterData.defaultValues.lob;
  }

  columnClicked(event) {
    if (event) {
      switch (event?.mode) {
        case ActionMode.edit:
          this.isGridRowEditing = true;
          this.configurationsMaintainService.scrollToTop();
          this.recordId = event?.row?.id;
          this.configurationMasterData.defaultValues.lob = event?.row?.name;
          this.configurationMasterData.defaultValues.lobAbbr = event?.row?.lobAbb;
          this.configurationMasterData.defaultValues.definition = event?.row?.lobDef;
          this.configurationMasterData.fieldsDetails.definition = event?.row?.lobDef;
          this.configurationMasterData.fieldsDetails.lobAbbr = event?.row?.lobAbb;
          this.configurationMasterData.fieldsDetails.lob = event?.row?.name;
          this.configurationMasterData.fieldsDetails.recordActive = event?.row?.recordActive;
          this.configurationMasterData.isEdit = true;
          this.configurationMasterData.isExpanded = true;
          break;

        case ActionMode.updateStatus:
          this.isGridRowEditing = true;
          this.updateStatusLobMaintenance(event.gridData);
          break;
      }
    }
  }

  updateStatusLobMaintenance(record) {
    this.lobMaintenanceHttpService.updateRecordStatusForLob(record).subscribe(res => {
      this.isDataAvailable = false;
      this.getLOBMaintenanceRecord();
      this.spinnerService.stop();
      const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_UPDATED_SUCCESS');
      this.configurationsMaintainService.showSuccessAlert(alertMessage);
    });
  }

}
