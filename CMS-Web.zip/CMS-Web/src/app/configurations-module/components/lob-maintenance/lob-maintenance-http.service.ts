import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';

@Injectable()
export class LobMaintenanceHttpService {

  constructor(private http: HttpClient) { }

  getLobMaintenanceRecord() {
    return this.http.get(`${Constants.webApis.getLobMaintenance}`);
  }

  addLobMaintenanceRecord(lobDetails) {
    return this.http.post(`${Constants.webApis.addUpdateLobMaintenance}`, lobDetails);
  }

  updateRecordStatusForLob(lobData) {
    return this.http.put(`${Constants.webApis.updateRecordStatusLob}`, lobData);
  }

  updateLobMaintenanceRecord(lobData) {
    return this.http.put(`${Constants.webApis.addUpdateLobMaintenance}`, lobData);
  }
}
