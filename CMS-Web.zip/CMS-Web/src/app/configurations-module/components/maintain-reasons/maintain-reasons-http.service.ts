import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '@global/infrastructure/constants';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';

@Injectable()
export class MaintainReasonHttpService {

    constructor(private http: HttpClient,
        private configMaintainService: ConfigurationsMaintainService) { }

    getReasons(selection) {
        return this.http.post(`${Constants.webApis.getReasons}`, selection);
    }

    addReason(selection) {
        return this.http.post(`${Constants.webApis.addReason}`, selection);
    }

    deleteMaintainReason(records) {
        const options = this.configMaintainService.getRequestData(records);
        return this.http.delete(`${Constants.webApis.deleteMaintainReason}`, options);
    }

    updateLive(state) {
        return this.http.post(`${Constants.webApis.updateMaintainReasonLive}`, state);
    }

    maintainReasonRequirementsCount(data) {
        return this.http.post(`${Constants.webApis.getMaintainReasonsAllCount}`, data);
    }
}
