import { Injectable } from '@angular/core';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';

@Injectable()
export class MaintainReasonUtilityService {

    constructor() { }

    getDeleteFormat(rows) {
        const deleteFormat = [];
        rows.forEach(element => {
            const rowVal = {};
            rowVal[ConfigurationsConstant.accountActionReasonId] = element.accountActionReasonId;
            deleteFormat.push(rowVal);
        });
        return deleteFormat;
    }
}
