import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import '@wk/components/dist/accordion';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { MultiSelectsComponent } from 'app/utility-module/multi-selects/multi-selects.component';
import { MaintainReasonsEditComponent } from '../maintain-reasons-edit/maintain-reasons-edit.component';
import { take } from 'rxjs/operators';
import { HttpErrorResponse } from '@angular/common/http';
import { MaintainReasonUtilityService } from './maintain-reasons-utility.service';
import { MaintainReasonHttpService } from './maintain-reasons-http.service';
import { Subject } from 'rxjs';
import { ThresholdExceededData, ThresholdExceededReason } from 'app/configurations-module/infrastructure/models/configuration.model';

@Component({
  selector: 'app-maintain-reasons',
  templateUrl: './maintain-reasons.component.html',
  styleUrls: ['./maintain-reasons.component.scss'],
  providers: [
    MaintainReasonHttpService,
    MaintainReasonUtilityService
  ]
})
export class MaintainReasonsComponent implements OnInit {
  showHideReason = false;
  showGrid = false;
  exportExcelClicked = false;
  isFullWidth = true;
  selectCircumstanceLimit = true;
  onCancelButtonClick: Subject<void> = new Subject<void>();
  @ViewChild(MultiSelectsComponent) child: MultiSelectsComponent;
  @Output() checkValidationEvent = new EventEmitter();
  reasons = [];
  isLoading = false;
  selectedRows = [];
  enableButton = false;
  enableDisplayBtn = false;
  selectedRowStatus: any = {
    isAtleastOneRowSelected: false,
    isAllChecked: false
  };
  exportData: any = {
    exportName: ConfigurationsConstant.exportExcel.exportMaintainMailReason,
    pageTitle: ConfigurationsConstant.exportExcel.pageMaintainMailReasonTitle,
    fileName: ConfigurationsConstant.exportExcel.fileMaintainReasonName,
    data: {
      result: [],
      headers: ConfigurationsConstant.exportExcel.headersMaintainReason,
      keys: ConfigurationsConstant.exportExcel.keysMaintainReason
    },
  };
  isUpdateLiveActive = false;
  @ViewChild('updateLiveButton') updateLiveButton: ElementRef<HTMLElement>;

  public addReasonsForm: FormGroup = new FormGroup({
    reason: new FormControl('', [Validators.required, Validators.pattern(/[\S]/)])
  });

  get validateReasonField() {
    return this.addReasonsForm.controls;
  }

  constructor(
    private configMaintainService: ConfigurationsMaintainService,
    private modalService: NgbModal,
    private popupService: PopupService,
    private translate: TranslateService,
    private maintainReasonUtilityService: MaintainReasonUtilityService,
    private maintainReasonHttpService: MaintainReasonHttpService,
    private spinnerService: SpinnerService) { }

  ngOnInit(): void {
  }


  changeDropdown(event) {
    this.enableDisplayBtn = event;
  }

  toggleReasons() {
    this.showHideReason = !this.showHideReason;
  }

  checkIsValidForm(mode) {
    if (mode === ConfigurationsConstant.mode.add) {
      if (this.child.checkValidation() && this.addReasonsForm.valid) {
        this.addReasons();
      }
    } else {
      if (this.child.checkValidation()) {
        this.displayReasons();
      }
    }

  }

  cancelDisplay() {
    this.reasons = [];
    this.showGrid = false;
    this.showHideReason = false;
    this.child.cancel();
    this.child.isSubmitClicked = false;
    this.enableDisplayBtn = false;
    this.isUpdateLiveActive = false;
    this.onCancelButtonClick.next();
    this.addReasonsForm.reset();
  }

  displayReasons() {
    const selections = {
      stateCodes: [this.child.selectedJurisdictions],
      actionIds: this.configMaintainService.getSelectedIds(this.child.selectedActions),
      lobIds: this.configMaintainService.getSelectedIds(this.child.selectedLobs),
      whereConditionIds: this.configMaintainService.getSelectedIds(this.child.selectedCircumstances)
    };

    this.maintainReasonHttpService.maintainReasonRequirementsCount(selections).subscribe((response: ThresholdExceededData) => {
      if (response) {
        const thresholdCount = this.configMaintainService.numberWithComma(response.thresholdCount);
        const alertMessage =
          this.translate.instant('CONFIGURATION_MENU.MESSAGES.THRESHOLD_MESSAGE_CONFIG', { thresholdCount: thresholdCount });
        if (response.isThresholdExceeded) {
          this.showGrid = false;
          this.configMaintainService.showAlert(alertMessage);
        } else {
          this.maintainReasonHttpService.getReasons(selections).subscribe((res: any) => {
            this.showGrid = true;
            this.reasons = this.configMaintainService.setIsSelectedFlag(res);
            this.selectedRowStatus.isAllChecked = false;
            this.selectedRowStatus.isAtleastOneRowSelected = false;
            this.enableButton = false;
          },
            (errors: HttpErrorResponse) => {
              if (errors.status === ConfigurationsConstant.apiStatus) {
                this.reasons = [];
                this.checkIfAtleastOneRowSelected();
                this.showGrid = true;
              }
              this.spinnerService.stop();
            }
          );
        }
      }
    });
  }

  addReasons() {
    const selections = {
      stateCodes: [this.child.selectedJurisdictions],
      actionIds: this.configMaintainService.getSelectedIds(this.child.selectedActions),
      lobIds: this.configMaintainService.getSelectedIds(this.child.selectedLobs),
      whereConditionIds: this.configMaintainService.getSelectedIds(this.child.selectedCircumstances),
      reasonText: this.addReasonsForm.get('reason').value.trim()
    };
    this.maintainReasonHttpService.addReason(selections).subscribe((res: ThresholdExceededReason) => {
      if (res) {
        const thresholdCount = this.configMaintainService.numberWithComma(res.thresholdCount);
        const alertMessage =
          this.translate.instant('CONFIGURATION_MENU.MESSAGES.THRESHOLD_MESSAGE_CONFIG', { thresholdCount: thresholdCount });
        if (res.isThresholdExceeded) {
          this.configMaintainService.showAlert(alertMessage);
        } else {
          const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_ADDED_SUCCESS');
          this.configMaintainService.showSuccessAlert(message);
          this.displayReasons();
          this.addReasonsForm.controls['reason'].setValue('');
        }
      }
    });
  }

  editReason(reason) {
    const modalRef = this.modalService.open(MaintainReasonsEditComponent);
    modalRef.componentInstance.data = reason;
    modalRef.result.then((userResponse) => {
      if (ConfigurationsConstant.editDaysReload.reload === userResponse) {
        this.displayReasons();
      }
    });
  }

  selectAllCheckbox() {
    this.selectedRowStatus.isAtleastOneRowSelected = false;
    this.spinnerService.start();
    setTimeout(() => {
      this.selectedRows = this.configMaintainService.selectAllCheckbox(this.selectedRowStatus.isAllChecked, this.reasons);
      this.selectedRows.filter(ele => ele.isSelected === true).length > 0 ? this.enableButton = true : this.enableButton = false;
      this.reasons = this.selectedRows;
      this.exportData.data.result = this.selectedRows;
      this.spinnerService.stop();
    }, 0);
  }

  checkIfAtleastOneRowSelected() {
    this.selectedRowStatus = this.configMaintainService.checkIfAtleastOneRowSelected(this.selectedRows, this.reasons);
  }

  checkChange(event, index) {
    this.selectedRows = this.configMaintainService.checkChange(this.reasons, event, index);
    this.selectedRows.length > 0 ? this.enableButton = true : this.enableButton = false;
    this.exportData.data.result = this.selectedRows;
    this.checkIfAtleastOneRowSelected();
  }

  singleDelete(record) {
    this.deleteRecord([record], ConfigurationsConstant.single);
  }

  bulkDelete() {
    this.deleteRecord(this.selectedRows, ConfigurationsConstant.bulk);
  }

  deleteRecord(row, type) {
    const expectedFormat = this.maintainReasonUtilityService.getDeleteFormat(row);
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: type === ConfigurationsConstant.bulk ?
        this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_BULK_DELETE_REASON') :
        this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_SINGLE_DELETE_REASON'),
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.maintainReasonHttpService.deleteMaintainReason(expectedFormat.map(ele => ele.accountActionReasonId))
          .subscribe(() => {
            const alertMessage = type === ConfigurationsConstant.bulk ?
              this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_DELETED') :
              this.translate.instant('MESSAGES.CONFIRMATION.RECORD_DELETED');
            this.configMaintainService.showSuccessAlert(alertMessage);
            this.displayReasons();
          });
        this.enableButton = false;
        this.selectedRowStatus.isAtleastOneRowSelected = false;
        this.selectedRowStatus.isAllChecked = false;
      }
    });
  }

  exportExcel() {
    this.exportExcelClicked = true;
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
    }
    this.reasons = this.reasons.map(ele => ({ ...ele, isSelected: false }));
    this.selectedRowStatus.isAllChecked = false;
    this.selectedRowStatus.isAtleastOneRowSelected = false;
    this.enableButton = false;
  }

  updateToLive() {
    this.showConfirmation();
  }
  showConfirmation() {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: this.translate.instant('CONFIGURATION_MENU.REASON.UPDATE_LIVE_INFO', { stateCode: this.child.selectedJurisdictions }),
      positiveLabel: this.translate.instant('BUTTON.CONFIRM'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.maintainReasonHttpService.updateLive({
          stateCode: this.child.selectedJurisdictions
        })
          .subscribe(() => {
            const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.UPDATE_LIVE_SUCCESS',
              { stateCode: this.child.selectedJurisdictions });
            this.configMaintainService.showSuccessAlert(alertMessage);
          });
      }
      setTimeout(() => {
        const updateLiveBtnElement: HTMLElement = this.updateLiveButton.nativeElement;
        updateLiveBtnElement.blur();
      }, 100);
    });
  }

  isUpdateLiveBtnActive(event) {
    this.isUpdateLiveActive = event;
  }
}
