import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { FieldMasterMaintenanceService } from 'app/configurations-module/components/field-master-maintenance/field-master-maintenance.service';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-where-used-modal',
  templateUrl: './where-used-modal.component.html',
  styleUrls: ['./where-used-modal.component.scss'],
  providers: [FieldMasterMaintenanceService]
})
export class WhereUsedModalComponent implements OnInit {
  @Input() data;
  @Input() fieldGroup;
  @Input() fieldName;
  showWhereUsedModal = false;
  dependancySection = false;
  responseData = [];
  constructor(private activeModal: NgbActiveModal,
    private spinnerService: SpinnerService,
    private translate: TranslateService,
    private popupService: PopupService,
    private fieldMasterMaintenanceService: FieldMasterMaintenanceService,
    private configurationsMaintainService: ConfigurationsMaintainService) { }

  ngOnInit(): void {
    if (this.fieldGroup) {
      if (this.fieldGroup.section && (this.fieldGroup.section  ===  ConfigurationsConstant.fieldDependancyRules.title)) {
            this.fieldGroup = this.fieldGroup.fieldRuleDesc;
            this.dependancySection = true;
      } else {
        this.fieldGroup = this.fieldGroup.split('(')[0];
      }
    }
    this.fieldName = this.fieldName;
    this.responseData = this.data;
    this.responseData =
      this.configurationsMaintainService.sortAscending(this.responseData, ConfigurationsConstant.fieldMasterMaintenance.stateCode);
    this.showWhereUsedModal = (this.responseData) ? true : false;
  }
  closeModal() {
    this.activeModal.close();
  }
  downloadForm(formName) {
    this.fieldMasterMaintenanceService.downloadForm(formName)
    .subscribe(response => {
      if (response) {
        saveAs(response.body, formName);
      }
    },
    async (error) => {
      const message = JSON.parse(await error.error.text()).Message;
      this.showAlert(message);
      this.spinnerService.stop();
    });
  }

  showAlert(message) {
    this.popupService.showAlert({
      title: this.translate.instant('MESSAGES.CONFIRMATION.ALERT'),
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }
}
