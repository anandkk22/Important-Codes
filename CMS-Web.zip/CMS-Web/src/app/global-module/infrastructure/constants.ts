import { environment } from '../../../environments/environment';


export class Constants {

  static paginationOptions = {
    currentPage: 1,
    pageSize: 200,
    totalItems: 1000,
  };
  static pageSizes = [200, 400, 600, 800, 1000];
  static displayGroup = 'Select Display Group';
  static dateFormat = {
    excelDateFormat: 'MM-dd-yyyy',
  };

  static checkTypeMail = {
    allJurisdictions: 'All Jurisdictions',
};

  static selectedIds = {
    stateCode: 'stateCode',
    textBlocksChecked: 'textBlocksChecked'
  };

    static uiRoutes = {
        login: 'login',
        shop: 'shop',
        cart: 'cart'
    };

    static targetKey = {
      insource: 'insource',
      caseLaw: 'caseLaw'
    };

    static businessExceptions = {
        SessionExpired: 'SessionExpired',
        SessionKilled: 'SessionKilled',
        ErrorCode: 'ErrorCode',
        MessageCode: 'MessageCode'
    };
    static switchCase = {
      add: 'add',
      reset: 'reset',
      delete: 'delete',
      update: 'update'
    };

    static webApis = {
        antiForgeryToken: environment.apiUrl + 'AntiForgery/Token',
        getUserInfo: environment.portalUrl + 'Webservices/API/ICSAuth/connect/UserInfo',
        targetRedirect: environment.portalUrl + 'Webservices/API/ICSAuth/connect/TargetRedirect',
        redirectAPI: environment.portalUrl + 'index.aspx?Target=',
        getConfigData: environment.commonApiUrl + 'FrontendConfig',
        getJurisdictions: environment.apiUrl + 'State',
        getActions: environment.apiUrl + 'Action',
        getLobs: environment.apiUrl + 'LOB?adminMenuItem={adminMenuItem}',
        getCircumstances: environment.apiUrl + 'Circumstance',
        addDaysNotice: environment.apiUrl + 'DaysNotice',
        updateDaysNotice: environment.apiUrl + 'DaysNotice',
        getAllDaysNotice: environment.apiUrl + 'DaysNotice/Requirements',
        getdaysNoticeRequirementsCount: environment.apiUrl + 'DaysNotice/RequirementsCount',
        deleteDaysNotice: environment.apiUrl + 'DaysNotice',
        updateLive: environment.apiUrl + 'DaysNotice/UpdateLive',
        getReasons: environment.apiUrl + 'MaintainReasons/All',
        getMaintainReasonsAllCount:  environment.apiUrl + 'MaintainReasons/AllCount',
        addReason: environment.apiUrl + 'MaintainReasons',
        deleteReason: environment.apiUrl + 'MaintainReasons/{accountActionReasonId}',
        getMaintainMailType: environment.apiUrl + 'MailType/GetAll',
        deleteMaintainMailType: environment.apiUrl + 'MailType',
        addMaintainMailType: environment.apiUrl + 'MailType',
        updateMailTypeLive:  environment.apiUrl + 'MailType/UpdateLive',
        mailTypeGetAllCount: environment.apiUrl + 'MailType/Count',
        deleteMaintainReason: environment.apiUrl + 'MaintainReasons',
        updateMaintainReasonLive:  environment.apiUrl + 'MaintainReasons/UpdateLive',
        imageUrl: 'assets/Images/WKLogo.png',
        addUpdateCircumstance: environment.apiUrl + 'Circumstance',
        getAllCircumstance: environment.apiUrl + 'Circumstance/GetAll',
        updateLiveCircumstance: environment.apiUrl + 'Circumstance/UpdateLive',
        getAllAction: environment.apiUrl + 'Action/GetAll',
        addUpdateAction: environment.apiUrl + 'Action',
        getLobMaintenance: environment.apiUrl + 'LOB/GetAll',
        addUpdateLobMaintenance: environment.apiUrl + 'LOB',
        updateRecordStatusLob:  environment.apiUrl + 'LOB/Statuses',
        getFieldMasterMaintenance:  environment.apiUrl + 'FieldMaster',
        whereUsedFieldName: environment.apiUrl + 'FieldMaster/whereused',
        updateStatusFieldMaster: environment.apiUrl + 'FieldMaster/UpdateStatus',
        getHelpForm: environment.commonApiUrl + 'Download?file=authenticity_staging\\CNRWIP\\{formName}',
        fieldDependancyRule : {
          getFieldDependancy: environment.apiUrl + 'FieldRule?pageNumber={pNum}&pageSize={pSize}&fieldruleDesc={fieldruleDesc}',
          getFieldDependancyWithOrder: environment.apiUrl + 'FieldRule?pageNumber={pNum}&pageSize={pSize}&fieldruleDesc={fieldruleDesc}&OrderByDesc={OrderByDesc}',
          getFieldTemplate: environment.apiUrl + 'FieldRuleTemplate',
          fieldRuleWhereUsed: environment.apiUrl + 'FieldRule/{fieldRuleId}/WhereUsed',
          addUpdateFieldDependancy: environment.apiUrl + 'FieldRule',
          deleteRecord:  environment.apiUrl  + 'FieldRule'
        },
        fieldRuleStep: {
          getFieldRuleStep: environment.apiUrl + 'FieldRuleSteps/{fieldRuleId}',
          addUpdateRuleStep: environment.apiUrl + 'FieldRuleSteps',
          deleteRecord: environment.apiUrl + 'FieldRuleSteps'
        },
        updateLiveWizardMenuing: environment.apiUrl + 'UpdateMenu/Live',
        updateMenu: environment.apiUrl + 'UpdateMenu',
        pdfForm : environment.commonApiUrl + 'Download?file=authenticity_staging\\Dev\\cnrv4\\{formName}'
    };
    static responseType = {
      blobType: 'blob'
    };
    static textAllocationPlaceHolder = 'Search by Wizard Field/ Field Name';
    static queryString = {
        SessionExpired: 'SessionExpired=true'
    };

    static localStorageKeys = {
        sessionId: 'sessionId'
    };

    static cookies =
        {
            sessionId: 'SessionId',
            apiContext: 'apiContext'
        };

    static allowedPages = ['/insource/bookmark', '/insource/insource.asp', '/insource/showdoc.asp', '/insource/citedisplay.asp', '/insource/jurisdictions-value-added-table', '/', '/insource', '/insource/'];

    static subscriptionCodes = {
      stateFiling: 'AWSF',
      claims: 'AWC',
      contractProvisions: 'AWPD',
      marketAndConductLH: 'MCE',
      matrices: 'MTRX',
      glossary: 'GLOSS',
      insource: 'INSOURCE',
      caseLaw: 'CASELAW',
      cnrcms: 'CnrCms'
    };

    static productNameWithCode = {
        SF: 'State Filing',
        claims: 'Claims',
        contractProvision: 'Contract Provisions',
        mcelh: 'Market Conduct - L&H',
        matrices: 'Matrices',
        glossary: 'Glossary',
        insource: 'INsource',
        caseLaw: 'CaseLaw'
      };

    static pendoData = {
        'Email': '',
        'NilsPlatformRole': 'User',
        'CNRRole': 'None',
        'AccountID': 'WKFS',
        'AccountName': 'Wolters Kluwer Financial Services',
        'AccountType': 'Internal Account',
        'SoldToID': undefined,
        'SoldToName': undefined
    };

    static headerOptions = [
        {
          key: 'maintainForms',
          canviewInNewTab: false,
          title: 'Maintain Forms',
          isActive: true,
          url: 'form-maintenance',
          class: 'wk-nav-item',
          tab_title: 'OneSumX NILS Cancellation and Nonrenewal - Maintain Forms'
        },
        {
          key: 'configurations',
          canviewInNewTab: false,
          title: 'Configurations',
          isActive: true,
          url: 'configurations',
          class: 'wk-nav-item',
          subUrls: [
            'configurations/maintain-days',
            'configurations/maintain-mail-type',
            'configurations/maintain-reasons',
            'configurations/where-condition-maintenance',
            'configurations/action-maintenance',
            'configurations/lob-maintenance',
            'configurations/field-master-maintenance',
            'configurations/field-dependancy-rule',
            'configurations/field-rule-steps'
          ],
          tab_title: 'OneSumX NILS Cancellation and Nonrenewal - Configurations'
        },
        {
          key: 'reports',
          canviewInNewTab: false,
          title: 'Reports',
          isActive: true,
          url: 'reports',
          class: 'wk-nav-item',
          subUrls: [
            'reports/check-mail-type',
            'reports/list-forms-by-jurisdiction',
            'reports/list-forms-by-jurisdiction-action',
            'reports/wizard-criteria-by-field',
            'reports/wizard-criteria-by-form',
            'reports/permitted-reason-without-form-rules',
            'reports/check-days-notice-rules',
            'reports/days-notice-report',
            'reports/bad-field-rule-assignments',
            'reports/forms-missing-helpsheet',
            'reports/regulatory-rules',
            'reports/inactive-aweb-forms',
            'reports/non-referenced-matrix-forms',
            'reports/form-missing-fields',
            'reports/rules-summary-report'

          ],
          tab_title: 'OneSumX NILS Cancellation and Nonrenewal - Reports'
        },
        {
          key: 'compareTools',
          canviewInNewTab: false,
          title: 'Compare Tools',
          isActive: true,
          url: 'compare-tools',
          class: 'wk-nav-item',
          tab_title: 'OneSumX NILS Cancellation and Nonrenewal - Compare Tools'
        },
        {
          key: 'cnrPreview',
          canviewInNewTab: true,
          title: 'CNR Preview',
          isActive: false,
          url: 'preview-access',
          class: 'wk-nav-item',
        },
        {
          key: 'cnrAlerts',
          canviewInNewTab: false,
          title: 'CNR Alerts',
          isActive: true,
          url: 'user-alert',
          class: 'wk-nav-item',
          tab_title: 'OneSumX NILS Cancellation and Nonrenewal - CNR Alerts'
        }
      ];

      static fileTypes = {
        msexcel: 'application/ms-excel',
        excelExtension: '.xls',
      };

      static excelFile = {
        downloadExcel: 'downloadExcel'
      };
  static FieldMasterMaintenance = {
    displayGroup: [
      { name: 'Policy (100)', code: 100 },
      { name: 'Policy (200)', code: 200 },
      { name: 'Premium Adjustment (210)', code: 210 },
      { name: 'Insurer (10)', code: 10 },
      { name: 'Producer (20)', code: 20 },
      { name: 'Insured (30)', code: 30 },
      { name: 'Mortgagee (1000)', code: 1000 },
      { name: 'Lienholder (1010)', code: 1010 },
      { name: 'Certificate Holder (1020)', code: 1020 },
      { name: 'Additional Interest (1030)', code: 1030 },
      { name: 'Third Party (1040)', code: 1040 },
      { name: 'Workers Comp (1050)', code: 1050 }
    ],
    fieldDisplayData: [
      { name: 'Yes', code: true },
      { name: 'No', code: false }
    ],
    textBlue: 'text-blue',
    textBlack: 'text-black',
    textBox: 'Textbox',
    checkBox: 'Checkbox',
    text: 'text',
    policy: 'Policy (200)',
    policy_200: 'Policy (200)',
    policy_100: 'Policy (100)',
    worksComp: 'Workers Comp (1050)',
    thirdParty: 'Third Party (1040)',
    additionalParty: 'Additional Interest (1030)',
    certificateHolder: 'Certificate Holder (1020)',
    lienholder: 'Lienholder (1010)',
    mortgagee: 'Mortgagee (1000)',
    insured: 'Insured (30)',
    producer: 'Producer (20)',
    insurer: 'Insurer (10)',
    premiumAdjustment: 'Premium Adjustment (210)',
    add: 'add',
    update: 'update',
    delete: 'delete',
    numberRegex: /^[0-9]{1,5}$/,
    openBrace: ' (',
    closeBrace: ')',
    yes: 'Yes',
    no: 'No',
    displayGroupPolicy100Code: 100

  };

  static fieldOrderMaintenance = {
    update_field_order: 'Field Order Updated Successfully!',
    maxLength_update_success: 'Max Length Updated Successfully!',
    delete_customized_label: 'Are you sure you wish to delete the customized label?',
    delete_customized_label_success: 'Customized label deleted successfully!',
    add_customized_label: 'Customized Label(s) created successfully!',
    field_rules_updated: 'Rules updated successfully!',
    sync_rtfactionfield_updated: 'Fields sync up successfully!',
    update_customized_label: 'Are you sure you wish to update the customized label?',
    updated_customized_label_success: 'Customized label updated successfully!',
    label_Field_cannot_be_empty: 'Label Field cannot be empty.'
  };

  static tabTitles = [
    'CNR CMS - Welcome',
    'OneSumX NILS Cancellation and Nonrenewal - Maintain Forms',
    'OneSumX NILS Cancellation and Nonrenewal - Configurations',
    'OneSumX NILS Cancellation and Nonrenewal - Reports',
    'OneSumX NILS Cancellation and Nonrenewal - Compare Tools',
    'OneSumX NILS Cancellation and Nonrenewal - Tools Main Menu',
    'OneSumX NILS Cancellation and Nonrenewal - CNR Alerts'
  ];

  static displayGroupRange = {
    min : 100,
    max : 999
  };
}
