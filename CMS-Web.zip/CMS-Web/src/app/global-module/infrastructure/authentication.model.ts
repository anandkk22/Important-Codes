export class HeaderData {
  canDisplayHeader?: boolean;
  isUserAuthenticated?: boolean;
}
