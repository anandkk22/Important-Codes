import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { AuthService, LoggerService, SpinnerService } from '@core';
import { HttpClient } from '@angular/common/http';
import { Constants } from '@global/infrastructure/constants';
import { environment } from '@env';
import { UserInfoMock } from 'assets/Infrastructure/user-info-mock';
import { AppConstants } from 'app/app.constants';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';

@Injectable()
export class SharedDataService {
  private _sharedData = {};

  constructor(
    private logger: LoggerService,
    private authService: AuthService,
    private httpClient: HttpClient,
    private _spinnerService: SpinnerService,
    private _router: Router
  ) {
    this.logger.info('SharedDataService : constructor ');
  }

  populateCommonData(): Promise<any> {
    // Condition to mock the userInfo for local development
    if (environment.environmentName === 'Local') {
      this._sharedData = UserInfoMock;
      this.authService.setUserData(this._sharedData);
      if (this._sharedData && this._sharedData['authorities']?.includes(Constants.subscriptionCodes.cnrcms)) {
        this.getAntiforgeryToken().subscribe((token) => {
          this.getConfigData().subscribe((data) => {
            environment.feedbackEmail = data['feedbackEmail'];
            environment.phoneNumber = data['customerCarePhone'];
            environment.customerCareEmail = data['customerCareEmail'];
          });
        });
      } else if ((this._sharedData && this._sharedData['authorities'] &&
        !this._sharedData['authorities']?.includes(Constants.subscriptionCodes.cnrcms))) {
        this._router.navigate([AppConstants.uiRoutes.unauthorized]);
      } else {
        window.location.replace(`${environment.portalUrl}${AppConstants.uiRoutes.iweLogin}`);
      }

    } else {
      this._spinnerService.start();
      this.logger.info('SharedDataService : populateCommonData ');

      return new Promise<any>((resolve) => {
        this.httpClient.get(`${Constants.webApis.getUserInfo}`, {
          params: {
            'client_id': AppConstants.authData.clientId
          }
        })
          .subscribe(
            (successResponse: any) => {
              this._sharedData = successResponse;
              this.authService.setUserData(this._sharedData);
              this.logger.info('SharedDataService : populateCommonData : successResponse ' + successResponse);
              if (this._sharedData && this._sharedData['authorities']?.includes(Constants.subscriptionCodes.cnrcms)) {
                this.getAntiforgeryToken().subscribe((token) => {
                  this.getConfigData().subscribe((data) => {
                    environment.feedbackEmail = data['feedbackEmail'];
                    environment.phoneNumber = data['customerCarePhone'];
                    environment.customerCareEmail = data['customerCareEmail'];
                    this._spinnerService.stop();
                    resolve(true);
                  });
                });
              } else if ((this._sharedData && this._sharedData['authorities'] &&
                !this._sharedData['authorities']?.includes(Constants.subscriptionCodes.cnrcms))) {
                this._router.navigate([AppConstants.uiRoutes.unauthorized]);
                this._spinnerService.stop();
                resolve(true);
              } else {
                window.location.replace(`${environment.portalUrl}${AppConstants.uiRoutes.iweLogin}`);
                this._spinnerService.stop();
                resolve(true);
              }
            },
            (error) => {
              this._sharedData = UserInfoMock;
              this._spinnerService.stop();
              this.authService.setUserData(this._sharedData);
              resolve(true);
            });
      });
    }
  }

  redirectToTargetUrl() {
    const reqParams = {
      RedirectUri: `${window.location.href}`,
      ClientId: AppConstants.authData.clientId
    };
    this.getTargetUrl(reqParams).subscribe((result: any) => {
      if (result && result.target) {
        window.location.replace(`${environment.portalUrl}${result.target}`);
      }
    });
  }

  getTargetUrl(reqParams) {
    const result = this.httpClient.post(`${Constants.webApis.targetRedirect}`, reqParams);
    if (result) {
      return result;
    }
    return new Observable();

  }

  getUserInfo() {
    return this._sharedData;
  }

  setUserInfo(data) {
    this._sharedData = data;
  }

  handleError(errorResponse: any) {
    this.logger.info(
      '****** SharedDataService : populateCommonData : server returned error'
    );
    this.logger.info('errorResponse : ' + errorResponse);
  }

  getConfigData() {
    const result = this.httpClient.get(`${Constants.webApis.getConfigData}`);
    if (result) {
      return result;
    }
    return new Observable();
  }

  getAntiforgeryToken() {
    const result = this.httpClient.get(`${Constants.webApis.antiForgeryToken}`);
    if (result) {
      return result;
    }
    return new Observable();
  }
}
