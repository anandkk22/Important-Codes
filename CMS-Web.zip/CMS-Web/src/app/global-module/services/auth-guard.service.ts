import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  ResolveEnd
} from '@angular/router';

import {
  LoggerService,
  AuthService
} from '@core';
import { AppConstants } from 'app/app.constants';
import { AccessService } from './access.service';
import { SharedDataService } from './shared-data.service';
@Injectable()
export class AuthGuardService implements CanActivate {
  userInfo: any;
  isUserLoggedIn: boolean;

  constructor(
    private _router: Router,
    private _logger: LoggerService,
    private _authService: AuthService,
    private accessService: AccessService) {
    this._logger.info('AuthGuard : constructor ');
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    this.isUserLoggedIn = this._authService.isUserLoggedIn();

    if (this.isUserLoggedIn) {
      if (this.accessService.isUserAuthorized()) {
        return true;
      } else {
        this._router.navigate([AppConstants.uiRoutes.unauthorized]);
        return false;
      }
    } else {
      window.location.replace(`${environment.portalUrl}${AppConstants.uiRoutes.iweLogin}`);
      return false;
    }

  }
}
