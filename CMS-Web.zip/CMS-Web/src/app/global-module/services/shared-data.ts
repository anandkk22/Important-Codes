﻿export class SharedData {
  apiToken: string;
  emailId: string;
}
