import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { environment } from '@env';
import { NilsSharedModule } from '@wk/nils-shared';
import { UtilityModule } from 'app/utility-module/utility-module.module';
import { CompareToolsRoutingModule } from './compare-tools-routing.module';
import { CompareToolsComponent } from './components/compare-tools/compare-tools.component';

@NgModule({
    declarations: [
        CompareToolsComponent
    ],
    imports: [
      CompareToolsRoutingModule,
      FormsModule,
      NilsSharedModule.loadConfig({
        environmentName: environment.environmentName,
        portalUrl: environment.portalUrl,
        appUrl: environment.appUrl,
        apiUrl: environment.apiUrl,
        serverLogLevel: environment.serverLogLevel,
        logLevel: environment.logLevel,
        serverLoggingUrl: environment.serverLoggingUrl,
        commonApiUrl: environment.commonApiUrl,
        userGroupURL: '',
        feedbackEmail: environment.feedbackEmail,
        customerCareEmail: environment.customerCareEmail,
        productUrl: environment.productUrl
      }),
      UtilityModule
    ],
    providers: [

    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
  })
export class CompareToolsModule { }
