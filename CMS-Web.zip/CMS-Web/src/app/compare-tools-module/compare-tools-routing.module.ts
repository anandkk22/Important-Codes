import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '@global';
import { AppConstants } from 'app/app.constants';
import { CompareToolsComponent } from './components/compare-tools/compare-tools.component';

const routes: Routes = [
    {
      path: AppConstants.uiRoutes.empty,
      component: CompareToolsComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.compareTools,
      component: CompareToolsComponent,
      canActivate: [AuthGuardService]
    }
  ];
  @NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  export class CompareToolsRoutingModule { }
