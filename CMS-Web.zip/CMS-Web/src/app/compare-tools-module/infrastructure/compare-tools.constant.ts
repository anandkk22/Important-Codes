import { environment } from '@env';

export class CompareToolsConstant {
  static webApis = {
    deletedRowsFormRule: environment.apiUrl + 'CompareTools/DeletedFormRule?PageNo={pageNumber}&PageSize={pageSize}',
    addedRowsFormRule: environment.apiUrl + 'CompareTools/AddedFormRule?PageNo={pageNumber}&PageSize={pageSize}',
    updatedRowsFormRule: environment.apiUrl + 'CompareTools/UpdatedFormRule?PageNo={pageNumber}&PageSize={pageSize}',
    deletedRowsPermittedReasons: environment.apiUrl + 'CompareTool/DeletedPermittedReasons',
    addedRowsPermittedReasons: environment.apiUrl + 'CompareTool/AddedPermittedReasons',
    updatedRowsPermittedReasons: environment.apiUrl + 'CompareTool/UpdatedPermittedReasons',
    deletedRowsDaysNotice: environment.apiUrl + 'DaysNotice/CompareTools/DeletedRows',
    addedRowsDaysNotice: environment.apiUrl + 'DaysNotice/CompareTools/AddedRows',
    updatedRowsDaysNotice: environment.apiUrl + 'DaysNotice/CompareTools/UpdatedRows',
    deletedRowsMailTypes: environment.apiUrl + 'CompareTool/DeletedMailTypes',
    addedRowsMailTypes: environment.apiUrl + 'CompareTool/AddedMailTypes',
    updatedRowsMailTypes: environment.apiUrl + 'CompareTool/UpdatedMailTypes',
    exportFormActionExcel: environment.apiUrl + 'CompareTools/Export?ruleType={ruleType}'
  };

  static exportExcel = {
    exportName: 'MaintainDaysResult',
    exportMaintainMailTypeName: 'Maintain Mail Type ',
    exportMaintainMailReason: 'Changes to Form Rules since Wednesday backup',
    exportMaintainWhereCondition: 'Where Condition Maintenance',
    exportMaintainAction: 'Action Maintenance',
    pageTitle: 'Maintain Days\' Notice',
    pageMaintainMailTypeTitle: 'Maintain Mail Type',
    pageMaintainMailReasonTitle: 'Maintain Reasons',
    pageMaintainWhereCondition: 'Where Condition Maintenance',
    pageMaintainAction: 'Action Maintenance',
    fileName: 'MaintainDaysResult',
    fileMaintainMailTypeName: 'Maintain Mail Type',
    fileMaintainReasonName: 'Maintain Reasons',
    fileMaintainWhereCondition: 'Where Condition Maintenance',
    fileMaintainAction: 'Action Maintenance',
    exportMailTypeName: 'MailTypeEntriesWithout',
    pageMailTypeTitle: 'Mail Type entries without corresponding Form Rules',
    fileNameMailType: 'Mail Type entries without corresponding Form Rules ',
    exportLOBMaintenance: 'LOB Maintenance',
    exportLOBMaintenancePageTitle: 'LOB Maintenance',
    exportLOBMaintenanceFileName: 'LOB Maintenance',
    daysNoticeAdded: 'Newly added Days Notice Requirements since last back up',
    daysNoticeUpdated: 'Updated Days Notice Requirements since last back up',
    daysNoticeDeleted: 'Deleted Days Notice Requirements since last back up',
    permittedReasonAdded: 'Newly added Permitted Reasons since last back up',
    permittedReasonUpdated: 'Updated Permitted Reasons since last back up',
    permittedReasonDeleted: 'Deleted Permitted Reasons since last back up',
    mailTypeAdded: 'Newly Added Mail Types since last back up',
    mailTypeUpdated: 'Updated Mail Types since last back up',
    mailTypeDeleted: 'Deleted Mail Types since last back up',
    formRulesAdded: 'Newly Added Form rules since last back up',
    formRulesUpdated: 'Updated Form rules since last back up',
    formRulesDeleted: 'Deleted Form rules since last back up',


    formRulesHeaders: [
      'Jurisdiction',
      'Action',
      'LOB',
      'Circumstance',
      'RTF Name',
      'Field Name',
      'Defined?',
      'Default',
      'Input Reqd?',
      'Reg Reqd?',
      'Displayed?',
      'Active?'
    ],
    formRulesKeys: [
      'stateCode',
      'actionCode',
      'lobAbbrivation',
      'whereConditionDescription',
      'rtfName',
      'fieldName',
      'fieldDefined',
      'defaultValue',
      'inputRequired',
      'regulatoryRequirement',
      'fieldDisplayed',
      'recordActive'
    ],
    daysNoticeHeaders: [
      'Jurisdiction',
      'Action',
      'Line of Business',
      'Circumstance',
      'Minimum Days',
      'Maximum Days'
    ],
    daysNoticeKeys: [
      'stateCode',
      'actionCode',
      'lobAbbrevation',
      'whereConditionDescription',
      'daysNotice',
      'daysNoticeMax'
    ],
    mailTypeHeaders: [
      'Jurisdiction',
      'Action',
      'Line of Business',
      'Circumstance',
      'Mail Type'
    ],
    mailTypeKeys: [
      'stateCode',
      'actionCode',
      'lobAbbrevation',
      'whereConditionDescription',
      'mailType',
    ],
    permittedReasonKeys: [
      'stateCode',
      'actionCode',
      'lobAbbrevation',
      'whereConditionDescription',
      'reasonText'
    ],
    permittedReasonHeaders: [
      'Jurisdiction',
      'Action',
      'Line of Business',
      'Circumstance',
      'Reason'
    ],
  };
  static mailType = 'mailType';
  static daysNotice = 'daysNotice';
  static formRules = 'formRules';
  static permittedReason = 'permittedReason';
  static deleted = 'deleted';
  static states = {
    deleted: 'deleted',
    added: 'added',
    updated: 'updated'
  };

  static paginationOptions = {
    currentPage: 1,
    pageSize: 5000,
    totalItems: 2000
};
  static selectedCriteria = 'selectedCriteria';
  static total = 'Total';
  static rows = 'Row(s): ';
  static headers = 'Headers';
  static keys = 'Keys';
  static compareTools = 'compareTools';

  static pageSizes = [5000];

  static wednesdayBackup = 'Wednesday Back Up';
  static fileStart = {
    mailType: 'Mail Type',
    daysNotice: 'Days Notice',
    formRules: 'Form Rules',
    permittedReasons: 'Permitted Reasons'
  };

  static fileEnd = {
    deletedRule: 'Deleted Rules',
    newRule: 'New Rules',
    updatedRule: 'Updated Rules',
    deletedNotice: 'Deleted Notices',
    newNotice: 'New Notices',
    updatedNotice: 'Updated Notices',
    deletedMailType: 'Deleted Mail Type',
    newMailType: 'New Mail Type',
    updatedMailType: 'Updated Mail Type',
    deletedReasons: 'Deleted Reasons',
    newReasons: 'New Reasons',
    updatedReasons: 'Updated Reasons',
  };

  static xlsxFormat = '.xlsx';
  static xlsxType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  static stateId = {
    added: '0',
    deleted: '1',
    updated: '2'
  };

  static responseType = {
    blob: 'blob'
  };
}
