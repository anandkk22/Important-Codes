import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { CompareToolsConstant } from '../../infrastructure/compare-tools.constant';
import { environment } from '@env';
import { saveAs } from 'file-saver';

@Injectable()
export class CompareToolsService {
  pageSizeDropdown: HTMLElement;
  fileName = '';
  constructor(private http: HttpClient) { }

  getRows(currentCriteria, currentRow, pageNumber?, pageSize?) {
    switch (currentCriteria) {
      case CompareToolsConstant.formRules:
        this.fileName = CompareToolsConstant.wednesdayBackup + ' - ' + CompareToolsConstant.fileStart.formRules;
        switch (currentRow) {
          case CompareToolsConstant.states.deleted:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.deletedRule;
            return this.http.get(`${CompareToolsConstant.webApis.deletedRowsFormRule}`.replace('{pageNumber}', pageNumber).replace('{pageSize}', pageSize));
          case CompareToolsConstant.states.added:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.newRule;
            return this.http.get(`${CompareToolsConstant.webApis.addedRowsFormRule}`.replace('{pageNumber}', pageNumber).replace('{pageSize}', pageSize));
          case CompareToolsConstant.states.updated:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.updatedRule;
            return this.http.get(`${CompareToolsConstant.webApis.updatedRowsFormRule}`.replace('{pageNumber}', pageNumber).replace('{pageSize}', pageSize));
        }
        break;

      case CompareToolsConstant.daysNotice:
        this.fileName = CompareToolsConstant.wednesdayBackup + ' - ' + CompareToolsConstant.fileStart.daysNotice;
        switch (currentRow) {
          case CompareToolsConstant.states.deleted:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.deletedNotice;
            return this.http.get(`${CompareToolsConstant.webApis.deletedRowsDaysNotice}`);
          case CompareToolsConstant.states.added:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.newNotice;
            return this.http.get(`${CompareToolsConstant.webApis.addedRowsDaysNotice}`);
          case CompareToolsConstant.states.updated:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.updatedNotice;
            return this.http.get(`${CompareToolsConstant.webApis.updatedRowsDaysNotice}`);
        }
        break;

      case CompareToolsConstant.mailType:
        this.fileName = CompareToolsConstant.wednesdayBackup + ' - ' + CompareToolsConstant.fileStart.daysNotice;
        switch (currentRow) {
          case CompareToolsConstant.states.deleted:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.deletedMailType;
            return this.http.get(`${CompareToolsConstant.webApis.deletedRowsMailTypes}`);
          case CompareToolsConstant.states.added:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.newMailType;
            return this.http.get(`${CompareToolsConstant.webApis.addedRowsMailTypes}`);
          case CompareToolsConstant.states.updated:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.updatedMailType;
            return this.http.get(`${CompareToolsConstant.webApis.updatedRowsMailTypes}`);
        }
        break;

      case CompareToolsConstant.permittedReason:
        this.fileName = CompareToolsConstant.wednesdayBackup + ' - ' + CompareToolsConstant.fileStart.permittedReasons;
        switch (currentRow) {
          case CompareToolsConstant.states.deleted:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.deletedReasons;
            return this.http.get(`${CompareToolsConstant.webApis.deletedRowsPermittedReasons}`);
          case CompareToolsConstant.states.added:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.newReasons;
            return this.http.get(`${CompareToolsConstant.webApis.addedRowsPermittedReasons}`);
          case CompareToolsConstant.states.updated:
            this.fileName += ' - ' + CompareToolsConstant.fileEnd.updatedReasons;
            return this.http.get(`${CompareToolsConstant.webApis.updatedRowsPermittedReasons}`);
        }
        break;
    }
  }

  addMorePageSizes() {
    this.pageSizeDropdown[0].value = environment.compareToolsPageSize;
    this.pageSizeDropdown[0].innerHTML = environment.compareToolsPageSize;
  }

  loadUpadtedPageSizes() {
    setTimeout(function () {
      this.pageSizeDropdown = document.querySelector('#pagination-bar-dynamic .wk-field-select');
      this.addMorePageSizes();
    }.bind(this), 0);
  }

  download(ruleType) {
    return this.http.post(
      `${CompareToolsConstant.webApis.exportFormActionExcel}`
        .replace('{ruleType}', ruleType),
      {},
      { responseType: CompareToolsConstant.responseType.blob as 'json', observe: 'response' }
    );
  }

  loadFile(response: any, fileName: any) {
    const file = new Blob([response], { type: CompareToolsConstant.xlsxType});
    saveAs(file, fileName);
  }

  getFileName() {
    return this.fileName;
  }

  getCheckBoxNumber(currentRow) {
    switch (currentRow) {
      case CompareToolsConstant.states.added:
        return CompareToolsConstant.stateId.added;
      case CompareToolsConstant.states.deleted:
        return CompareToolsConstant.stateId.deleted;
      case CompareToolsConstant.states.updated:
        return CompareToolsConstant.stateId.updated;
    }
  }
}
