import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { CompareToolsConstant } from 'app/compare-tools-module/infrastructure/compare-tools.constant';
import { CompareToolsService } from 'app/compare-tools-module/components/compare-tools/compare-tools.service';
import { Subscription } from 'rxjs';
import { environment } from '@env';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
@Component({
  selector: 'app-compare-tools',
  templateUrl: './compare-tools.component.html',
  styleUrls: ['./compare-tools.component.scss'],
  providers: [CompareToolsService, FormsUtilityService]
})
export class CompareToolsComponent implements OnInit {
  criteriaForm: FormGroup;
  subscriptions: Subscription[] = [];
  selectedCriteria;
  selectedRow;
  rows = [];
  exportExcelClicked = false;
  isDataAvailable = false;
  isGridDataAvailable = false;
  exportData: any = {
    exportName: '',
    pageTitle: '',
    fileName: '',
    data: {
      result: [],
      headers: [],
      keys: []
    },
  };
  formRulesTotalCount = 0;
  criterias = {
    mailType: CompareToolsConstant.mailType,
    daysNotice: CompareToolsConstant.daysNotice,
    formRules: CompareToolsConstant.formRules,
    permittedReason: CompareToolsConstant.permittedReason
  };
  totalCount = 0;

  paginationOptions: any = {
    currentPage: CompareToolsConstant.paginationOptions.currentPage,
    pageSize: environment.compareToolsPageSize,
    totalItems: CompareToolsConstant.paginationOptions.totalItems,
  };
  fileName = '';
  isExportCompleted = true;
  disableButtons = false;

  constructor(private fb: FormBuilder,
    private compareToolsService: CompareToolsService,
    private formsUtilityService: FormsUtilityService,
    ) {
    this.criteriaForm = this.fb.group({
      selectedCriteria: [CompareToolsConstant.daysNotice]
    });
  }

  ngOnInit(): void {
    this.onCriteriaChanges();
    this.loadPageSize();
  }

  loadPageSize() {
    this.compareToolsService.loadUpadtedPageSizes();
  }

  onCriteriaChanges(): void {
    this.rows = [];
    this.paginationOptions.currentPage = CompareToolsConstant.paginationOptions.currentPage;
    this.disableButtons = true;
    this.selectedCriteria = this.criteriaForm.get(CompareToolsConstant.selectedCriteria).value;
    this.selectedRow = CompareToolsConstant.deleted;
    this.getRows(this.selectedCriteria, this.selectedRow);
  }

  onRowChanges(row): void {
    this.rows = [];
    this.paginationOptions.currentPage = CompareToolsConstant.paginationOptions.currentPage;
    this.disableButtons = true;
    this.selectedRow = row;
    this.getRows(this.selectedCriteria, this.selectedRow);
  }

  getRows(selectedCriteria, selectedRow) {
    this.isGridDataAvailable = false;

    this.compareToolsService.getRows(selectedCriteria, selectedRow, this.paginationOptions.currentPage, this.paginationOptions.pageSize)
      .subscribe((res: any) => {
        this.isDataAvailable = true;
        this.isGridDataAvailable = true;
        this.disableButtons = false;
        this.fileName = this.compareToolsService.getFileName();
        if (selectedCriteria === CompareToolsConstant.formRules) {
          this.rows = res.paginationData;
          this.totalCount = res.totalCount;
          this.loadPageSize();
        } else {
          this.rows = res;
          this.totalCount = res.length;
        }
        this.paginationOptions.totalItems = this.totalCount;

        if (this.totalCount > 0) {
          const headerRows = this.selectedCriteria + CompareToolsConstant.headers;
          const keys = this.selectedCriteria + CompareToolsConstant.keys;
          const pageTitle = this.selectedCriteria + this.titleCase(this.selectedRow);
          const resultsString = CompareToolsConstant.total + ' ' + this.titleCase(this.selectedRow) + ' '
            + CompareToolsConstant.rows + this.rows.length;
          this.exportData = {
            exportName: CompareToolsConstant.exportExcel[headerRows],
            pageTitle: CompareToolsConstant.exportExcel[pageTitle],
            fileName: this.fileName,
            excelFor: CompareToolsConstant.compareTools,
            data: {
              result: this.rows,
              resultCounts: resultsString,
              headers: CompareToolsConstant.exportExcel[headerRows],
              keys: CompareToolsConstant.exportExcel[keys]
            }
          };
        }

      });
  }

  exportExcel() {
    this.exportExcelClicked = true;

  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
    }
  }

  onPageClick(event) {
    this.paginationOptions.currentPage = event.detail;
    this.getRows(this.selectedCriteria, this.selectedRow);
    this.compareToolsService.loadUpadtedPageSizes();
  }

  pageSizeChange(event) {
    this.paginationOptions.currentPage = CompareToolsConstant.paginationOptions.currentPage;
    this.paginationOptions.pageSize = event.detail;
    this.getRows(this.selectedCriteria, this.selectedRow);
    this.compareToolsService.loadUpadtedPageSizes();
  }

  titleCase(string) {
    if (string && string?.length > 0) {
      return string[0].toUpperCase() + string.substr(1).toLowerCase();
    }
  }

  getFile() {
    this.isExportCompleted = false;
    const fileName = this.compareToolsService.getFileName();
    const selectedTabNumber = this.compareToolsService.getCheckBoxNumber(this.selectedRow);
    this.compareToolsService.download(selectedTabNumber).subscribe((response: any) => {
      this.isExportCompleted = true;
      if (response) {
        this.compareToolsService.loadFile(response.body, fileName + CompareToolsConstant.xlsxFormat);
      }
    }, async (error) => {
      this.isExportCompleted = true;
      const message = JSON.parse(await error.error.text()).Message;
      this.formsUtilityService.showAlert(message);
    });
  }
}
