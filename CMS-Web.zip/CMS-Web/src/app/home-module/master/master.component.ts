import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Event, NavigationEnd, Router } from '@angular/router';
import { AuthService, LoggerService } from '@core';
import { SharedDataService } from '@global';
import { HeaderData } from '@global/infrastructure/authentication.model';
import { Constants } from '@global/infrastructure/constants';
import { AccessService } from '@global/services/access.service';
import { AppConstants } from 'app/app.constants';
import { Subscription } from 'rxjs';

declare let pendo: any;
@Component({
  selector: 'app-master',
  templateUrl: './master.component.html',
  styleUrls: ['./master.component.css']
})
export class MasterComponent implements OnInit, OnDestroy {

  isUserLoggedIn = false;
  showHeaderFooter = false;
  headerData: any;
  displaySubHeader: HeaderData;
  cmsHeaderDetails = Constants.headerOptions;
  ActiveSubscription: Subscription;
  mailSubject = '';
  targetValue = Constants.targetKey.insource;
  displayPopup = false;
  popupData: any = {};
  feedbackEmail: String;
  showHeader = false;
  showFooter = false;
  cmsNavBarDetails = {
    cmsNavBar : true,
    isCmsChildWindow: false
  };

  constructor(
    private logger: LoggerService,
    private router: Router,
    private sharedDataService: SharedDataService,
    private authService: AuthService,
    private accessService: AccessService,
    private cd: ChangeDetectorRef) { }

  ngOnInit(): void {
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationEnd) {
        const userInfo = this.sharedDataService.getUserInfo();
        if (this.sharedDataService.getUserInfo()) {
          this.initializePendo(userInfo);
        }
      }
    });

    this.authService.triggerMessage.subscribe((res) => {
      if (res !== '') {
        this.displayPopup = true;
        this.popupData.message = res;
        this.cd.detectChanges();
      }
    });

    this.ActiveSubscription = this.accessService.headerDisplay.subscribe((result) => {
      this.displaySubHeader = result;
    });
    this.enableDisableHeaderFooter();
    this.headerData = this.sharedDataService.getUserInfo();
    this.isUserLoggedIn = this.authService.isUserLoggedIn();
    this.logger.info('MasterComponent : ngOnInit() ');
  }

  ngOnDestroy() {
    this.ActiveSubscription.unsubscribe();
  }

  initializePendo(sharedData: any) {
    try {
      const initializationObj = {
        visitor: {
          id: sharedData.sub,
          email: sharedData.email,
          full_name: sharedData.username,
          NILSrole: Constants.pendoData.NilsPlatformRole,
          CNRrole: Constants.pendoData.CNRRole
        },
        account: {
          id: Constants.pendoData.AccountID,
          accountName: Constants.pendoData.AccountName,
          soldTo: Constants.pendoData.SoldToID === undefined ? '' : Constants.pendoData.SoldToID,
          soldToName: Constants.pendoData.SoldToName === undefined ? '' : Constants.pendoData.SoldToName,
          type: Constants.pendoData.AccountType
        }
      };

      // Added logs for testing on Dev
      pendo.initialize(initializationObj);
    } catch (error) {
      // In case Pendo initialization errors out, we need to know the the reason why it failed
    }
  }

  exitModal(data: Boolean) {
    if (data) {
      this.displayPopup = false;
      this.cd.detectChanges();
    }
  }

  feedbackClicked(subject) {
    this.mailSubject = subject;
  }

  enableDisableHeaderFooter() {
    if (window.location.href.indexOf(AppConstants.uiRoutes.lobActions) > -1 ||
      window.location.href.indexOf(AppConstants.uiRoutes.formFieldDependencyRules) > -1 ||
      window.location.href.indexOf(AppConstants.uiRoutes.editForm) > -1 ||
      window.location.href.indexOf(AppConstants.uiRoutes.notes) > -1 ||
      window.location.href.indexOf(AppConstants.uiRoutes.formFieldTextAllocation) > -1 ||
      window.location.href.indexOf(AppConstants.uiRoutes.editForm) > -1 ||
      window.location.href.indexOf(AppConstants.uiRoutes.formJurisdiction) > -1 ||
      window.location.href.includes(AppConstants.uiRoutes.addEditFormUrl) ||
      window.location.href.includes(AppConstants.uiRoutes.fieldRuleStepsUrl) ||
      window.location.href.includes(AppConstants.uiRoutes.viewRulesUrl)) {
     this.cmsNavBarDetails.isCmsChildWindow = true;
    }
    else {
      this.cmsNavBarDetails.isCmsChildWindow = false;
    }
  }

}
