import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lob-action',
  templateUrl: './lob-action.component.html',
  styleUrls: ['./lob-action.component.scss']
})
export class LobActionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
