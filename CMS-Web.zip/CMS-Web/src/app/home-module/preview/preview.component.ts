import { AfterViewInit, Component, OnInit } from '@angular/core';
import { environment } from '@env';
import { AppConstants } from 'app/app.constants';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.scss']
})
export class PreviewComponent implements OnInit, AfterViewInit {

  constructor() { }

  ngOnInit() { }

  ngAfterViewInit() {
    this.redirectToPreview();
  }

  redirectToPreview() {
    const form = document.createElement('form');
    form.action = environment.portalUrl + AppConstants.cnrpreview.redirectUrl;
    form.method = AppConstants.cnrpreview.method;
    form.innerHTML = AppConstants.cnrpreview.innerHtml;
    document.body.append(form);
    form.submit();
  }
}
