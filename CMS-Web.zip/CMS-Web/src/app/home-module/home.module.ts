import { NgModule } from '@angular/core';
import { environment } from '@env';
import { NilsSharedModule } from '@wk/nils-shared';
import { MasterComponent } from './master/master.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { UnauthorizeComponent } from './unauthorize/unauthorize.component';
import { HomeComponent } from './home.component';
import { FormFieldRulesComponent } from './form-field-rules/form-field-rules.component';
import { LobActionComponent } from './lob-action/lob-action.component';
import { PreviewComponent } from './preview/preview.component';

@NgModule({
  declarations: [
    HomeComponent,
    MasterComponent,
    PageNotFoundComponent,
    UnauthorizeComponent,
    FormFieldRulesComponent,
    LobActionComponent,
    PreviewComponent
  ],
  imports: [
    NilsSharedModule.loadConfig({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      commonApiUrl: environment.commonApiUrl,
      userGroupURL: '',
      feedbackEmail: environment.feedbackEmail,
      customerCareEmail: environment.customerCareEmail,
      productUrl: environment.productUrl
    }),
  ],
  exports: [
    MasterComponent
  ]
})
export class HomeModule { }
