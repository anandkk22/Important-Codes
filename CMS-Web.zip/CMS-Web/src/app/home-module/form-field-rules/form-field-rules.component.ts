import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-field-rules',
  templateUrl: './form-field-rules.component.html',
  styleUrls: ['./form-field-rules.component.scss']
})
export class FormFieldRulesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
