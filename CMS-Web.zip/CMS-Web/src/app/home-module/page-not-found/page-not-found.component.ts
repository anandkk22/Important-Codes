﻿import { Component } from '@angular/core';

@Component({
    selector: 'page-not-found',
    template: `<div class="empty-page">The page you are looking for cannot be found. Please check the URL.</div>`
})
export class PageNotFoundComponent {

    constructor() {
    }

}
