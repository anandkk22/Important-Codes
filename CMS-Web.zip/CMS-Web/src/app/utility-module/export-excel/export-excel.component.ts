import { Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild } from '@angular/core';
import { environment } from '@env';
import { Constants } from '@global/infrastructure/constants';
import { TranslateService } from '@ngx-translate/core';
import { AppConstants } from 'app/app.constants';
import * as fileSaver from 'file-saver';

@Component({
  selector: 'export-excel-utility',
  templateUrl: './export-excel.component.html',
  styleUrls: ['./export-excel.component.scss']
})
export class ExportExcelComponent implements OnInit, OnChanges {
  @Input() exportExcelClicked: any;
  @Output() excelDownloaded = new EventEmitter();
  @Input() exportData: any;
  @Input() isFullWidth: boolean;
  @Input() helpSheet: boolean;
  @ViewChild(Constants.excelFile.downloadExcel) components: ElementRef<HTMLElement>;

  imageUrl = '';
  pageTitle = '';
  currentYear;
  today;
  formsCount;
  jurisdictionsCount;

  constructor(private translate: TranslateService) { }

  ngOnInit(): void {
    this.today = new Date();
    this.currentYear = this.today.getFullYear();
    this.imageUrl = environment.portalUrl + AppConstants.cnrPath + AppConstants.webApis.imageUrl;
    this.pageTitle = this.translate.instant(this.exportData?.pageTitle);
  }

  ngOnChanges() {
    if (this.exportExcelClicked) {
      this.exportExcel();
    }
  }

  exportExcel() {
    const fileName = this.exportData.fileName + Constants.fileTypes.excelExtension;
    const formattedHTML = this.getFormattedHtml();
    this.download(formattedHTML, fileName);
  }

  download(data, fileName) {
    const blob = new Blob([data], { type: Constants.fileTypes.msexcel });
    fileSaver.saveAs(blob, fileName);
    this.excelDownloaded.emit(true);
  }

  getFormattedHtml() {
    let formattedHTML = null;
    formattedHTML = this.components?.nativeElement.innerHTML;
    return formattedHTML;
  }
}
