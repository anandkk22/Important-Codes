import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import '@wk/components/dist/accordion';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ActionMode, ConfigurationFieldsData, ConfigurationMasterData, GridTableEmitData } from 'app/configurations-module/infrastructure/models/configuration.model';

@Component({
  selector: 'cms-config-add-section',
  templateUrl: './cms-config-add-section.component.html',
  styleUrls: ['./cms-config-add-section.component.scss']
})
export class CmsConfigAddSectionComponent implements OnInit {

  @Input() configurationMasterData: ConfigurationMasterData;
  @Output() actionClick = new EventEmitter<GridTableEmitData>();

  fieldsData: ConfigurationFieldsData;
  defaultData: ConfigurationFieldsData;
  isDataAvailable = false;
  lobHeaderName = ConfigurationsConstant.configurationSectionDetails.lob.lobHeader;
  lobName = ConfigurationsConstant.configurationSectionDetails.lob.lobField;
  whereConditionName = ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName;
  actionName = ConfigurationsConstant.configurationSectionDetails.action.sectionName;

  constructor() { }

  ngOnInit(): void {
    this.fieldsData = this.configurationMasterData?.fieldsDetails;
    this.defaultData = this.configurationMasterData?.defaultValues;
    this.isDataAvailable = true;
  }

  trimFormValue(field) {
    this.fieldsData[field] = this.fieldsData[field].trim();
  }

  disableAddButton() {
    let isDisable = true;
    switch (this.configurationMasterData?.sectionName) {
      case ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName:
        if (this.fieldsData?.definition !== null && this.fieldsData?.definition !== '' &&
        this.fieldsData?.description !== null && this.fieldsData?.description !== '') {
          isDisable = false;
        }
        break;

      case ConfigurationsConstant.configurationSectionDetails.action.sectionName:
        if (this.fieldsData?.code !== null && this.fieldsData?.code !== '' &&
        this.fieldsData?.description !== null && this.fieldsData?.description !== '') {
          isDisable = false;
        }
        break;

      case ConfigurationsConstant.configurationSectionDetails.lob.sectionName:
        if (this.fieldsData?.lobAbbr !== null && this.fieldsData?.lobAbbr !== '' &&
        this.fieldsData?.lob !== null && this.fieldsData?.lob !== '') {
          isDisable = false;
        }
        break;
    }
    return isDisable;
  }

  onActionClick(action: string) {
    switch (action) {
      case ActionMode.add:
        this.actionClick.emit({
          mode: ActionMode.add,
          data: this.fieldsData
        });
        break;

      case ActionMode.save:
        this.actionClick.emit({
          mode: ActionMode.save,
          data: this.fieldsData
        });
        break;

      case ActionMode.cancel:
        this.collapseWkAccordianPanel();
        this.actionClick.emit({
          mode: ActionMode.cancel,
        });
        break;

        case ActionMode.reset:
        this.actionClick.emit({
          mode: ActionMode.reset,
        });
        break;

      default:
        this.actionClick.emit({
          mode: '',
          data: this.fieldsData
        });
        break;
    }
  }

  disableEditButton() {
    let isDisable = true;
    switch (this.configurationMasterData?.sectionName) {
      case ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName:
        if ((this.fieldsData?.definition !== this.defaultData?.definition ||
        this.fieldsData?.description !==  this.defaultData?.description) &&
        (this.fieldsData?.definition !== null && this.fieldsData?.definition !== '' &&
        this.fieldsData?.description !== null && this.fieldsData?.description !== '')) {
          isDisable = false;
        }
        break;

      case ConfigurationsConstant.configurationSectionDetails.action.sectionName:
        if ((this.fieldsData?.code !== this.defaultData?.code ||
        this.fieldsData?.description !== this.defaultData?.description ||
        this.fieldsData?.definition !== this.defaultData?.definition)
        &&
        (this.fieldsData?.code !== null && this.fieldsData?.code !== '' &&
        this.fieldsData?.description !== null && this.fieldsData?.description !== '')) {
          isDisable = false;
        }
        break;

      case ConfigurationsConstant.configurationSectionDetails.lob.sectionName:
        if (this.fieldsData?.definition !== this.defaultData?.definition) {
            isDisable = false;
        }
        break;
    }
    return isDisable;
  }

  disableResetButton() {
    let isDisable = true;
    switch (this.configurationMasterData?.sectionName) {
      case ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName:
        if (this.fieldsData?.definition !== this.defaultData?.definition ||
        this.fieldsData?.description !==  this.defaultData?.description) {
          isDisable = false;
        }
        break;

      case ConfigurationsConstant.configurationSectionDetails.action.sectionName:
        if (this.fieldsData?.code !== this.defaultData?.code ||
        this.fieldsData?.description !== this.defaultData?.description ||
        this.fieldsData?.definition !== this.defaultData?.definition) {
          isDisable = false;
        }
        break;

      case ConfigurationsConstant.configurationSectionDetails.lob.sectionName:
        if (this.fieldsData?.definition !== this.defaultData?.definition) {
            isDisable = false;
        }
        break;
    }
    return isDisable;
  }

  isManualExpanded() {
    this.configurationMasterData.isExpanded = !this.configurationMasterData.isExpanded;
  }

  expandForm(event) {
    event.stopPropagation();
  }

  collapseWkAccordianPanel() {
    setTimeout(() => { this.configurationMasterData.isExpanded = false; }, 100);
  }
}
