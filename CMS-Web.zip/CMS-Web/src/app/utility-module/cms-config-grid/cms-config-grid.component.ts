import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import '@wk/components/dist/accordion';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ActionMode, ConfigurationMasterData, GridHeaderData, GridRowData, GridTableEmitData } from 'app/configurations-module/infrastructure/models/configuration.model';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { SpinnerService } from '@wk/nils-core';

@Component({
  selector: 'cms-config-grid',
  templateUrl: './cms-config-grid.component.html',
  styleUrls: ['./cms-config-grid.component.scss']
})
export class CmsConfigGridComponent implements OnInit, OnChanges {

  @Input() configurationMasterData: ConfigurationMasterData;
  @Input() exportData;
  @Input() isGridRowEditing;
  @Output() columnClick = new EventEmitter<GridTableEmitData>();
  @Input() isUpdateLiveRequired;
  searchKeyword: string;
  gridData: any;
  exportExcelClicked = false;
  isFullWidth = true;
  enableButton = false;
  showYellow: any;
  sortOrderDesc = true;
  placeholder = ConfigurationsConstant.configurationSectionDetails.placeholder;
  recordStatusData = [];
  lobActiveFilterText = ConfigurationsConstant.configurationSectionDetails.lob.lobActiveOnlyFilterText;
  lobInactiveFilterText = ConfigurationsConstant.configurationSectionDetails.lob.lobInactiveOnlyFilterText;
  isSearched = false;
  actionHeaderName = ConfigurationsConstant.configurationSectionDetails.action.sectionName;
  whereConditionHeaderName = ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName;
  lobName = ConfigurationsConstant.configurationSectionDetails.lob.sectionName;
  whereConditionName = ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName;
  actionName = ConfigurationsConstant.configurationSectionDetails.action.sectionName;
  descriptionField = ConfigurationsConstant.configurationSectionDetails.whereCondition.descriptionField;
  codeField = ConfigurationsConstant.configurationSectionDetails.action.codeField;
  lobAbbrField = ConfigurationsConstant.configurationSectionDetails.lob.lobAbbrivationField;
  viewFilterFalg = true;
  viewFilterValue = ConfigurationsConstant.configurationSectionDetails.lob.all;

  constructor(private configurationsMaintainService: ConfigurationsMaintainService,
    private spinnerService: SpinnerService) { }

  ngOnInit(): void {
    if (this.configurationMasterData && this.configurationMasterData?.tableData) {
      this.gridData = this.configurationMasterData?.tableData?.rowData;
      this.placeholder = (this.configurationMasterData?.sectionName ===
        ConfigurationsConstant.configurationSectionDetails.action.actionField)
      ? ConfigurationsConstant.configurationSectionDetails.searchBy +
      ConfigurationsConstant.configurationSectionDetails.actionTtile +
       ConfigurationsConstant.configurationSectionDetails.code : this.placeholder;

      this.updateLobPlaceHolder();
      if (this.configurationMasterData?.sectionName === ConfigurationsConstant.configurationSectionDetails.lob.lobField) {
        this.configurationMasterData.headerName = ConfigurationsConstant.configurationSectionDetails.lob.lobHeaderName;
        this.sortOrderDesc = false;
        this.configurationsMaintainService.sortData(
        this.configurationMasterData.tableData.rowData,
        ConfigurationsConstant.configurationSectionDetails.lob.lobAbbrivation,
        this.sortOrderDesc);
      }
      if (this.configurationMasterData?.sectionName === ConfigurationsConstant.configurationSectionDetails.action.actionField) {
        this.configurationMasterData.headerName = ConfigurationsConstant.configurationSectionDetails.action.actionHeader;
        this.sortOrderDesc = false;
        this.configurationsMaintainService.sortData(
        this.configurationMasterData.tableData.rowData,
        ConfigurationsConstant.configurationSectionDetails.action.codeField,
        this.sortOrderDesc);
      }
    }
  }
  getPlaceholder(action) {
    this.placeholder = (action === ConfigurationsConstant.configurationSectionDetails.code) ?
     ConfigurationsConstant.configurationSectionDetails.searchBy + ConfigurationsConstant.configurationSectionDetails.actionTtile + action :
     ConfigurationsConstant.configurationSectionDetails.searchBy + action;
     this.resetSearch();
  }
  ngOnChanges() {
    if (!this.isGridRowEditing) {
      this.showYellow = '';
    }
  }
  exportExcel() {
    this.exportExcelClicked = true;
  }
  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
    }
    this.enableButton = false;
  }
  columnClicked(col: GridHeaderData, row: GridRowData, action?: string, ) {
    switch (action) {
      case ActionMode.edit:
        this.configurationsMaintainService.scrollToTop();
        this.showYellow = row.whereConditionId ? row.whereConditionId : row.id;
        this.columnClick.emit({
          mode: ActionMode.edit,
          col,
          row,
        });
        break;

      case ActionMode.updateLive:
        this.columnClick.emit({
            mode: ActionMode.updateLive
        });
        break;

      case ActionMode.updateStatus:
        this.columnClick.emit({
          mode: ActionMode.updateStatus,
          gridData: this.recordStatusData
        });
        break;

      default:
        this.columnClick.emit({
          mode: '',
          col,
          row,
        });
        break;
    }
  }

  isEnableButton() {
    this.enableButton = this.configurationMasterData && this.configurationMasterData?.tableData?.rowData.length > 0 ? false : true;
    return this.enableButton;
  }

  isUpdateStatusButtonEnable() {
    let recordStatusFlag = false;
    if (this.configurationMasterData && this.configurationMasterData?.tableData?.rowData.length > 0) {
      if (this.recordStatusData.length > 0) {
        recordStatusFlag = false;
      } else {
        recordStatusFlag = true;
      }
    } else {
      recordStatusFlag = true;
    }
    return recordStatusFlag;
  }

  search() {
    this.isSearched = this.searchKeyword ? true : false;

    this.searchKeyword = this.searchKeyword.trim();
    switch (this.configurationMasterData?.sectionName) {
      case ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName:
        this.configurationMasterData.tableData.rowData = this.gridData
          .filter(x =>
            (
              x.whereConditionDesc?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase()) ||
              x.definition?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase())
            )
          );
        this.exportData.data.result = this.configurationMasterData?.tableData?.rowData;

        break;

      case ConfigurationsConstant.configurationSectionDetails.action.sectionName:
        if (this.placeholder === ConfigurationsConstant.configurationSectionDetails.action.searchByActionCode) {
          this.configurationMasterData.tableData.rowData = this.gridData
          .filter(x =>
            (
              x.code?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase())
            )
          );
        } else if (this.placeholder === ConfigurationsConstant.configurationSectionDetails.action.searchByDescritption) {
          this.configurationMasterData.tableData.rowData = this.gridData
          .filter(x =>
            (
              x.actionDesc?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase())
            )
          );
        }
      this.exportData.data.result = this.configurationMasterData?.tableData?.rowData;
        break;

      case ConfigurationsConstant.configurationSectionDetails.lob.sectionName:
        if (this.placeholder === ConfigurationsConstant.configurationSectionDetails.lob.lobAbbrSearchPlaceholderText) {
          this.filterLOBDataByAbbr();
        } else if (this.placeholder === ConfigurationsConstant.configurationSectionDetails.lob.lobSearchPlaceholderText) {
          this.filterLOBDataByName();
        }
        this.exportData.data.result = this.configurationMasterData?.tableData?.rowData;
        if (this.configurationMasterData?.tableData?.rowData.length === 0) {
          this.viewFilterFalg = true;
        }
        break;
    }
  }

  filterLOBDataByAbbr() {
    if (this.viewFilterValue ===  ConfigurationsConstant.configurationSectionDetails.lob.active) {
      this.configurationMasterData.tableData.rowData = this.gridData
      .filter(x => (x.lobAbb?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase()) && x.recordActive ) );
    } else if (this.viewFilterValue ===  ConfigurationsConstant.configurationSectionDetails.lob.inactive) {
      this.configurationMasterData.tableData.rowData = this.gridData
      .filter(x => (x.lobAbb?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase()) && !x.recordActive ) );
    } else {
      this.configurationMasterData.tableData.rowData = this.gridData
      .filter(x =>
        (
          x.lobAbb?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase())
        )
      );
    }
  }

  filterLOBDataByName() {
    if (this.viewFilterValue ===  ConfigurationsConstant.configurationSectionDetails.lob.active) {
      this.configurationMasterData.tableData.rowData = this.gridData
      .filter(x => (x.name?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase()) && x.recordActive) );
    } else if (this.viewFilterValue ===  ConfigurationsConstant.configurationSectionDetails.lob.inactive) {
      this.configurationMasterData.tableData.rowData = this.gridData
      .filter(x => (x.name?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase()) && !x.recordActive) );
    } else {
      this.configurationMasterData.tableData.rowData = this.gridData
      .filter(x =>
        (
          x.name?.toLowerCase().includes(this.searchKeyword.trim().toLowerCase())
        )
      );
    }
  }

  resetSearch() {
    this.isSearched = false;
    this.searchKeyword = null;
    this.viewFilterFalg = true;
    this.filterLOBRecord();
  }

  filterLOBRecord() {

    if (this.configurationMasterData && this.configurationMasterData.tableData) {
      if (this.viewFilterValue ===  ConfigurationsConstant.configurationSectionDetails.lob.active) {
        this.configurationMasterData.tableData.rowData = this.gridData
        .filter(x => (x.recordActive) );
      }

      else if (this.viewFilterValue ===  ConfigurationsConstant.configurationSectionDetails.lob.inactive) {
        this.configurationMasterData.tableData.rowData = this.gridData
        .filter(x => (!x.recordActive) );
      }

      else {
        this.configurationMasterData.tableData.rowData = this.gridData;
      }

      this.exportData.data.result = this.configurationMasterData.tableData.rowData;
    }

  }

  sortColumns(key, isDesc) {
    this.sortOrderDesc = isDesc;
    switch (this.configurationMasterData?.sectionName) {
      case ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName:
        this.configurationsMaintainService.sortData(
          this.configurationMasterData?.tableData?.rowData, 'whereConditionDesc', this.sortOrderDesc);
        this.exportData.data.result = this.configurationMasterData?.tableData?.rowData;
        break;

      case ConfigurationsConstant.configurationSectionDetails.action.sectionName:

        if (key === ConfigurationsConstant.configurationSectionDetails.action.codeField) {
          this.configurationsMaintainService.sortData(
            this.configurationMasterData?.tableData?.rowData,
            ConfigurationsConstant.configurationSectionDetails.action.codeField, this.sortOrderDesc);
        } else if ( key === ConfigurationsConstant.configurationSectionDetails.action.descriptionField) {
          this.configurationsMaintainService.sortData(
            this.configurationMasterData?.tableData?.rowData,
            ConfigurationsConstant.configurationSectionDetails.action.actionDesc, this.sortOrderDesc);
        }
        this.exportData.data.result = this.configurationMasterData?.tableData?.rowData;
        break;
      case ConfigurationsConstant.configurationSectionDetails.lob.sectionName:
        if (key === ConfigurationsConstant.configurationSectionDetails.lob.lobAbbrivationField) {
          this.configurationsMaintainService.sortData(
            this.configurationMasterData?.tableData?.rowData,
            ConfigurationsConstant.configurationSectionDetails.lob.lobAbbrivation, this.sortOrderDesc);
        } else if ( key === ConfigurationsConstant.configurationSectionDetails.lob.lobField) {
          this.configurationsMaintainService.sortData(
            this.configurationMasterData?.tableData?.rowData,
            ConfigurationsConstant.configurationSectionDetails.lob.lobName, this.sortOrderDesc);
        }
        this.exportData.data.result = this.configurationMasterData?.tableData?.rowData;
        break;
    }

    this.sortOrderDesc = !this.sortOrderDesc;
  }

  getBackYellowClass(row) {
    let classData = '';
    switch (this.configurationMasterData?.sectionName) {
      case ConfigurationsConstant.configurationSectionDetails.whereCondition.sectionName:
        classData = row.whereConditionId === this.showYellow ? ConfigurationsConstant.backYellowClass : '';
        break;
      case ConfigurationsConstant.configurationSectionDetails.action.sectionName:
          classData = row.id === this.showYellow ? ConfigurationsConstant.backYellowClass : '';
          break;
      case ConfigurationsConstant.configurationSectionDetails.lob.sectionName:
        classData = row.id === this.showYellow ? ConfigurationsConstant.backYellowClass : '';
        break;
    }
    return classData;
  }

  showClearIcon() {
    return (this.searchKeyword && this.searchKeyword.trim()) ? true : false;
  }

  onRecordStatusClick(record, row: GridRowData) {
    const updateStatusData = {
      'lobId': row.id,
      'status': false
    };
    updateStatusData.status = record.target.checked;
    const recordFound = this.recordStatusData.findIndex(data => data.lobId === updateStatusData.lobId);
    if (recordFound < 0) {
      this.recordStatusData.push(updateStatusData);
    } else {
      if (this.recordStatusData.length > 0) {
        this.recordStatusData.splice(recordFound, 1);
      }
    }
  }

  viewAllFilterChange(event) {
    const updatedRowData = JSON.parse(JSON.stringify(this.configurationMasterData));
    if (this.configurationMasterData && this.configurationMasterData.tableData) {
      this.configurationMasterData.tableData.rowData = this.gridData;
      if (event.target.value === ConfigurationsConstant.configurationSectionDetails.lob.lobInactiveOnlyFilter) {
        this.viewFilterValue =  ConfigurationsConstant.configurationSectionDetails.lob.inactive;
        this.configurationMasterData.tableData.rowData = this.configurationMasterData.tableData.rowData
          .filter(data => data.recordActive === false);
      } else if (event.target.value === ConfigurationsConstant.configurationSectionDetails.lob.lobActiveOnlyFilter) {
        this.viewFilterValue =  ConfigurationsConstant.configurationSectionDetails.lob.active;
        this.configurationMasterData.tableData.rowData = this.configurationMasterData.tableData.rowData
          .filter(data => data.recordActive === true);
      } else {
        this.viewFilterValue =  ConfigurationsConstant.configurationSectionDetails.lob.all;
        this.spinnerService.start();
        const updatedData = JSON.parse(JSON.stringify(this.configurationMasterData));
        this.configurationMasterData.tableData.rowData = updatedData.tableData.rowData;
        setTimeout(() => {
          this.spinnerService.stop();
        }, 500);
      }
      this.searchKeyword = null;
      this.exportData.data.result = this.configurationMasterData.tableData.rowData;
      this.recordStatusData = [];
    }
  }

  updateLobPlaceHolder(record?: string) {
    if (this.configurationMasterData.sectionName === ConfigurationsConstant.configurationSectionDetails.lob.lobField) {
      if (record) {
        this.placeholder =  record;
      } else {
        this.placeholder = ConfigurationsConstant.configurationSectionDetails.lob.lobAbbrSearchPlaceholderText;
      }
    }
  }

  onLobSearchValueChange(event) {
    this.placeholder = ConfigurationsConstant.configurationSectionDetails.lob.lobAbbrSearchPlaceholderText;
    if (event.target.value === ConfigurationsConstant.configurationSectionDetails.lob.lobField) {
      this.placeholder = ConfigurationsConstant.configurationSectionDetails.lob.lobSearchPlaceholderText;
    }
    this.resetSearch();
  }
}
