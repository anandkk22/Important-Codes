import { Component, Input, OnInit } from '@angular/core';
import { SpinnerService } from '@wk/nils-core';

@Component({
  selector: 'app-spin',
  templateUrl: './spin.component.html',
  styleUrls: ['./spin.component.scss']
})
export class SpinComponent implements OnInit {
  @Input() isDataNotAvailable;

  constructor(private spinnerService: SpinnerService) { }

  ngOnInit(): void {
  }

  showSpinner() {
    this.spinnerService.start();
  }

  hideSpinner() {
    this.spinnerService.stop();
  }

}
