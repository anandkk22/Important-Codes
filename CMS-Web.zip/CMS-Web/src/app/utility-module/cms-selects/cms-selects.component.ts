import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { NgSelectComponent } from '@ng-select/ng-select';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { ConfigurationsHttpService } from 'app/configurations-module/services/configurations-http.service';
import { ConfigurationsMaintainService } from 'app/configurations-module/services/configurations-maintain.service';
import { forkJoin, Observable, Subscription } from 'rxjs';

@Component({
  selector: 'cms-selects',
  templateUrl: './cms-selects.component.html',
  styleUrls: ['./cms-selects.component.scss']
})
export class CmsSelectsComponent implements OnInit, OnDestroy {

  @ViewChild(ConfigurationsConstant.selecter) ngselect: NgSelectComponent;
  @Output() changeDropdown = new EventEmitter();
  @Input() multiJurisdiction;
  @Input() isSelectionNotMandatory;
  @Input() selectCircumstanceLimit;
  private onCancelBtnClickSubscription: Subscription;
  @Input() cancelBtn: Observable<void>;
  selectedCicumstanceData = [];
  enableButton = false;
  allJurisdictions = [];
  selectedJurisdictions = [];
  @Output() isUpdateLiveActive = new EventEmitter();

  allActions = [];
  selectedActions = [];

  allLobs = [];
  selectedLobs = [];

  allCircumstances = [];
  selectedCircumstances = [];

  isDataAvailable = false;
  isSubmitClicked = false;
  adminMenuItem = 2;
  @Input() isCancelButtonRequired;

  constructor(private configurationsHttpService: ConfigurationsHttpService,
    private configMaintainService: ConfigurationsMaintainService) { }

  ngOnInit(): void {
    this.fetchData();
    if (this.isCancelButtonRequired) {
      this.onCancelBtnClickSubscription = this.cancelBtn.subscribe(() => this.resetCircumstance());
    }
  }

  customSearchFn(term: string, item: any) {
    return item.name.toLocaleLowerCase().startsWith(term.toLocaleLowerCase());
   }

  fetchData() {
    const fetchJurisdictions = this.configurationsHttpService.getJurisdictions();
    const fetchActions = this.configurationsHttpService.getActions();
    const fetchLobs = this.configurationsHttpService.getLobs(this.adminMenuItem);
    const fetchCircumstances = this.configurationsHttpService.getCircumstances();
    forkJoin([fetchJurisdictions, fetchActions, fetchLobs, fetchCircumstances]).subscribe(
      (res: any) => {
        if (res) {
          this.allJurisdictions =
            this.multiJurisdiction ? (this.configMaintainService.addGroupName(res[0],
              ConfigurationsConstant.daysNotice.allJurisdictions)) : res[0];
          this.allActions = this.configMaintainService.addGroupName(res[1], ConfigurationsConstant.daysNotice.allActions);
          this.allLobs = this.configMaintainService.addGroupName(res[2].sort(this.compare), ConfigurationsConstant.daysNotice.allLobs);
          this.allCircumstances = this.configMaintainService.addGroupName(res[3].sort(this.compare), this.selectCircumstanceLimit ? null
            : ConfigurationsConstant.daysNotice.allCircumstance);
          this.isDataAvailable = true;
        }
      }
    );
  }

  checkValidation() {
    this.isSubmitClicked = true;
    if (this.selectedJurisdictions.length > 0 &&
      this.selectedActions.length > 0 &&
      this.selectedLobs.length > 0 &&
      this.selectedCircumstances.length > 0) {
      return true;
    } else {
      return false;
    }
  }

  cancel() {
    this.selectedActions = [];
    this.selectedJurisdictions = [];
    this.selectedLobs = [];
    this.selectedCircumstances = [];
    this.isSubmitClicked = false;
  }

  onSelectionChange() {
    const checkLength = {
      selectedActions: this.selectedActions.length,
      selectedCircumstances: this.selectedCircumstances.length,
      selectedJurisdictions: this.selectedJurisdictions.length,
      selectedLobs: this.selectedLobs.length
    };
    if (checkLength.selectedJurisdictions > 0) {
      this.isUpdateLiveActive.emit(true);
    } else {
      this.isUpdateLiveActive.emit(false);
    }
    if (checkLength.selectedActions === 0 || checkLength.selectedCircumstances === 0
      || checkLength.selectedJurisdictions === 0 || checkLength.selectedLobs === 0) {
      this.changeDropdown.emit(false);
    } else {
      this.changeDropdown.emit(true);
    }
  }

  compare(a, b) {
    if (a.name < b.name) {
      return -1;
    }
    if (a.name > b.name) {
      return 1;
    }
    return 0;
  }

  onCircumstanceChange() {
    if (this.selectCircumstanceLimit) {
      const selectedItems = this.selectedCircumstances.map(x => x.id);
      this.selectedCicumstanceData = this.allCircumstances.filter((p) => !selectedItems.includes(p.id));
      this.selectedCicumstanceData.forEach((item) => {
        if (this.selectedCircumstances.length >= 5) {
          item.disabled = true;
        } else {
          item.disabled = false;
        }
      });
    } else {
      this.resetCircumstance();
    }
  }

  resetCircumstance() {
    this.selectedCicumstanceData.forEach((item) => {
      item.disabled = false;
    });
  }

  ngOnDestroy() {
    if (this.isCancelButtonRequired) {
      this.onCancelBtnClickSubscription.unsubscribe();
    }
  }
}
