import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { environment } from '@env';
import { NilsSharedModule } from '@wk/nils-shared';
import { CommonModule } from '@angular/common';
import { ExportExcelComponent } from './export-excel/export-excel.component';
import { TranslateModule } from '@ngx-translate/core';
import { CmsSelectsComponent } from './cms-selects/cms-selects.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { CmsConfigAddSectionComponent } from './cms-config-add-section/cms-config-add-section.component';
import { CmsConfigGridComponent } from './cms-config-grid/cms-config-grid.component';
import { UnauthorizeCMSAccessComponent } from './unauthorize-cms-access/unauthorize-cms-access.component';
import { SpinComponent } from './spin/spin.component';
import { MultiSelectsComponent } from './multi-selects/multi-selects.component';
import { ValidateInputDirective } from './directives/validate-input.directive';

@NgModule({
  declarations: [
    ExportExcelComponent,
    CmsSelectsComponent,
    CmsConfigAddSectionComponent,
    CmsConfigGridComponent,
    UnauthorizeCMSAccessComponent,
    SpinComponent,
    MultiSelectsComponent,
    ValidateInputDirective
  ],
  imports: [
    CommonModule,
    NilsSharedModule.loadConfig({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      commonApiUrl: environment.commonApiUrl,
      userGroupURL: '',
      feedbackEmail: environment.feedbackEmail,
      customerCareEmail: environment.customerCareEmail,
      productUrl: environment.productUrl
    }),
    TranslateModule.forChild(),
    NgSelectModule
  ],
  exports: [
    ExportExcelComponent,
    CmsSelectsComponent,
    CmsConfigAddSectionComponent,
    CmsConfigGridComponent,
    UnauthorizeCMSAccessComponent,
    SpinComponent,
    MultiSelectsComponent,
    ValidateInputDirective
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class UtilityModule { }
