import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthorize-cms-access',
  templateUrl: './unauthorize-cms-access.component.html',
  styleUrls: ['./unauthorize-cms-access.component.scss']
})
export class UnauthorizeCMSAccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
