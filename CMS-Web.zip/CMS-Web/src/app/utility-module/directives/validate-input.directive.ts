import { Directive, ElementRef, HostListener } from '@angular/core';
import { AppConstants } from 'app/app.constants';

@Directive({
  selector: '[validateInput]',
})
export class ValidateInputDirective {
  constructor(private el: ElementRef) { }

  @HostListener('keypress', ['$event'])
  onKeyPress(event) {
    const inputValue = event.target.value + event.key;
    if (inputValue.match(AppConstants.pentestRegex.htmlTagsRegex) ||
        inputValue.match(AppConstants.pentestRegex.specialCharactersRegex)) {
      event.preventDefault();
    }
  }

  @HostListener('paste', ['$event'])
  onTextPaste(event: ClipboardEvent) {
    event.preventDefault();
    const pasteData = event.clipboardData.getData('text/plain')
    .replace(AppConstants.pentestRegex.htmlTagsRegex, '')
    .replace(AppConstants.pentestRegex.notSpecialCharacter, ''); // change regex
    document.execCommand('insertHTML', false, pasteData);
  }

  @HostListener('focusout', ['$event'])
  onFocusout(event) {

  }
}
