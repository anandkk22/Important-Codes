import { Injectable } from '@angular/core';

@Injectable()
export class UserAlertUtilityService {
    pageSizeDropdown: HTMLElement;

    addGroupName(data, type) {
        data.forEach(element => {
            element.all = type;
        });
        return data;
    }

    copyScriptToClipBoard(scriptText: any) {
        const selectBox = document.createElement('textarea');
        selectBox.style.position = 'fixed';
        selectBox.style.left = '0';
        selectBox.style.top = '0';
        selectBox.style.opacity = '0';
        selectBox.value = scriptText;
        document.body.appendChild(selectBox);
        selectBox.focus();
        selectBox.select();
        document.execCommand('copy');
        document.body.removeChild(selectBox);
    }

    getEmailAddressString(data) {
        let emailAddressString = '';
        if (data && data.length > 0) {
            emailAddressString = data.map(x => x.email).join('; ');
        }
        return emailAddressString;
    }

    getPayloadData(data, key) {
        return data.map(
            function(item) {
                return item[key];
            }
        );
    }

    getSelectedDataByKey(data, key) {
        let selectedData = '';
        if (data) {
            selectedData = data.map(x => x[key]).join(', ');
        }
        return selectedData;
    }
}
