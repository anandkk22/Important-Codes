import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UserAlertConstant } from '../infrastructure/user-alert.constant';
@Injectable()
export class UserAlertHttpService {

  constructor(private http: HttpClient) { }

  getJurisdictions() {
    return this.http.get(`${UserAlertConstant.webApis.getUserAlertJurisdictions}`);
  }

  getLobs() {
    return this.http.get(`${UserAlertConstant.webApis.getUserAlertLobs}`);
  }

  getUserAlerts(requestData) {
    return this.http.post(`${UserAlertConstant.webApis.getUserAlerts}`, requestData);
  }
}
