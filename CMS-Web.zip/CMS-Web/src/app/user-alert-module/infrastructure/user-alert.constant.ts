import { environment } from '@env';

export class UserAlertConstant {

    static webApis = {
        getUserAlertJurisdictions: environment.apiUrl + 'State/UserAlerts',
        getUserAlertLobs: environment.apiUrl + 'LOB/UserAlerts/Lob',
        getUserAlerts: environment.apiUrl + 'UserAlert'
    };

    static cnlAlertHeaderValues = ['Account Name', 'Email Address', 'User Name'];
    static cnlAlertHeaderKeys = ['accountName', 'email', 'userName'];
    static alertTypes = [
        {key: 'fe', name: 'FE Alert'},
        {key: 'other', name: 'Other Alerts'}
    ];
    static exportData = {
        exportName: 'CNR Alerts',
        pageTitle: 'CNR Alerts',
        fileName: 'Other Alerts'
    };
    static cnlAlertButtons = {
        display: 'display',
        reset: 'reset'
    };
    static feAlertKey = 'fe';
    static userAlertDataKeys = {
        code: 'code',
        type: 'type'
    };

    static lobDropdownValues =
    [
        {
          'type': 'C',
          'name': 'Commercial Lines'
        },
        {
          'type': 'P',
          'name': 'Personal Lines'
        },
        {
          'type': 'WC',
          'name': 'Workers\' Comp'
        }
    ];
}

