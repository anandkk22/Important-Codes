import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { AuthGuardService } from '@global/services/auth-guard.service';
import { UserAlertComponent } from './components/user-alert/user-alert.component';

const routes: Routes = [
  {
    path: AppConstants.uiRoutes.empty,
    component: UserAlertComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.userAlert,
    component: UserAlertComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserAlertRoutingModule { }
