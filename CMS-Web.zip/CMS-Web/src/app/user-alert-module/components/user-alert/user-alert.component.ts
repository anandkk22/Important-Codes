import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import '@wk/components/dist/accordion';
import { UserAlertConstant } from 'app/user-alert-module/infrastructure/user-alert.constant';
import { UserAlertHttpService } from 'app/user-alert-module/services/user-alert-http.service';
import { UserAlertUtilityService } from 'app/user-alert-module/services/user-alert-utility.service';
import { forkJoin } from 'rxjs';

@Component({
    selector: 'app-user-alert',
    templateUrl: './user-alert.component.html',
    styleUrls: ['./user-alert.component.scss']
})

export class UserAlertComponent implements OnInit {

    allJurisdictions = [];
    selectedJurisdictions = [];
    allLobs = [];
    selectedLobs = [];
    allAlertType = [];
    selectedAlert = [];
    isDataAvailable = false;
    cnrAlertData;
    copyEmailAddressText: String = '';
    exportExcelClicked: boolean;
    exportData: any = {
        exportName: UserAlertConstant.exportData.exportName,
        pageTitle: UserAlertConstant.exportData.pageTitle,
        fileName: UserAlertConstant.exportData.fileName,
        data: {
            result: [],
            headers: UserAlertConstant.cnlAlertHeaderValues,
            keys: UserAlertConstant.cnlAlertHeaderKeys
        }
    };
    selectedJurisdictionData: String;
    selectedLobsData: String;
    isExpanded = true;

    constructor(
        private popupService: PopupService,
        private translate: TranslateService,
        private userAlertUtilityService: UserAlertUtilityService,
        private userAlertHttpService: UserAlertHttpService) { }

    ngOnInit(): void {
        this.fetchSelectionData();
    }

    fetchSelectionData() {
        const jurisdictionOption = this.translate.instant('CNL_ALERT.ALL_JURISDICTION');
        const lobOption = this.translate.instant('CNL_ALERT.ALL_LOBS');
        this.userAlertHttpService.getJurisdictions().subscribe((res: any) => {
            if (res) {
                this.allJurisdictions = this.userAlertUtilityService.addGroupName(res, jurisdictionOption);
            }
        });
        this.allLobs = this.userAlertUtilityService.addGroupName(UserAlertConstant.lobDropdownValues, lobOption);
        this.allAlertType = UserAlertConstant.alertTypes;
    }

    displayAlerts() {
        const params = {
            'stateCodes': this.userAlertUtilityService.getPayloadData(this.selectedJurisdictions, UserAlertConstant.userAlertDataKeys.code),
            'types':  this.userAlertUtilityService.getPayloadData(this.selectedLobs, UserAlertConstant.userAlertDataKeys.type)
        };
        this.userAlertHttpService.getUserAlerts(params).subscribe(res => {
            if (res) {
                this.cnrAlertData = res;
                this.exportData.data.result = this.cnrAlertData;
                this.copyEmailAddressText = this.userAlertUtilityService.getEmailAddressString(this.cnrAlertData);
                this.selectedJurisdictionData = this.userAlertUtilityService.getSelectedDataByKey(this.selectedJurisdictions, 'code');
                this.selectedLobsData = this.userAlertUtilityService.getSelectedDataByKey(this.selectedLobs, 'name');
                this.isDataAvailable = true;
                this.isExpanded = false;
            }
        });
    }

    reset() {
        this.isDataAvailable = false;
        this.selectedJurisdictions = [];
        this.selectedLobs = [];
        this.selectedAlert = [];
        this.exportData.data.result = [];
        this.cnrAlertData = [];
        this.isExpanded = true;
    }

    copyEmailAddress() {
        this.userAlertUtilityService.copyScriptToClipBoard(this.copyEmailAddressText);
    }

    isButtonDisable(buttonType) {
        let isDisable = true;
        if (buttonType === UserAlertConstant.cnlAlertButtons.display &&
            ((this.selectedJurisdictions && this.selectedJurisdictions.length > 0) &&
            (this.selectedLobs && this.selectedLobs.length > 0) &&
            (this.selectedAlert && this.selectedAlert.length > 0)
            )) {
                isDisable = false;
            }

        if (buttonType === UserAlertConstant.cnlAlertButtons.reset &&
            ((this.selectedJurisdictions && this.selectedJurisdictions.length > 0) ||
            (this.selectedLobs && this.selectedLobs.length > 0) ||
            (this.selectedAlert && this.selectedAlert.length > 0)
            )) {
                isDisable = false;
            }
        return isDisable;
    }

    exportExcel() {
        this.exportExcelClicked = true;
    }

    excelDownloaded(status) {
        if (status) {
            this.exportExcelClicked = false;
        }
    }

    checkAlertType(event) {
        if (event.key === UserAlertConstant.feAlertKey) {
            this.popupService.showAlert({
                title: '',
                message: this.translate.instant('CNL_ALERT.FE_ALERT_MESSAGE'),
                positiveLabel: this.translate.instant('BUTTON.OK'),
                negativeLabel: '',
              });
            this.selectedAlert = [];
        }
    }

    isManualExpanded() {
        this.isExpanded = !this.isExpanded;
    }
}
