import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserAlertRoutingModule } from './user-alert-routing.module';
import { NilsSharedModule } from '@wk/nils-shared';
import { environment } from '@env';
import { NgSelectModule } from '@ng-select/ng-select';
import { UtilityModule } from 'app/utility-module/utility-module.module';
import { UserAlertHttpService } from './services/user-alert-http.service';
import { UserAlertUtilityService } from './services/user-alert-utility.service';
import { UserAlertComponent } from './components/user-alert/user-alert.component';

@NgModule({
  declarations: [
    UserAlertComponent
  ],
  imports: [
    CommonModule,
    UserAlertRoutingModule,
    NilsSharedModule.loadConfig({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      commonApiUrl: '',
      userGroupURL: '',
      feedbackEmail: environment.feedbackEmail,
      customerCareEmail: environment.customerCareEmail,
      productUrl: environment.productUrl
    }),
    NgSelectModule,
    UtilityModule
  ],
  providers: [
    UserAlertHttpService,
    UserAlertUtilityService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class UserAlertModule { }
