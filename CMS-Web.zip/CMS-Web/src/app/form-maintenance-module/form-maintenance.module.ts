import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { NilsSharedModule } from '@wk/nils-shared';
import { environment } from '@env';
import { NgSelectModule } from '@ng-select/ng-select';
import { MaintainFormsComponent } from './components/maintain-forms/maintain-forms.component';
import { FormMaintenanceRoutingModule } from './form-maintenance-routing.module';
import { FormsComponent } from './components/forms/forms.component';
import { EditFormComponent } from './components/edit-form/edit-form.component';
import { FormFieldDependencyRulesComponent } from './components/form-field-dependency-rules/form-field-dependency-rules.component';
import { FormFieldTextAllocationComponent } from './components/form-field-text-allocation/form-field-text-allocation.component';
import { FormsService } from './services/forms.service';
import { FormsUtilityService } from './services/forms-utility.service';
import { FieldDependencyRuleHttpService } from './components/form-field-dependency-rules/form-field-dependency-rules-http.service';
import { LobActionMatrixFormComponent } from './components/lob-action-matrix-form/lob-action-matrix-form.component';
import { LobActionMarixService } from './services/log-action-matrix.service';
import { NotesComponent } from './components/notes/notes.component';
import { MoreNotesComponent } from './components/notes/more-notes/more-notes.component';
import { ViewFormJurisdictionsComponent } from './components/view-form-jurisdictions/view-form-jurisdictions.component';
import { ViewFormJurisdictionsService } from './components/view-form-jurisdictions/view-form-jurisdictions.service';
import { AddEditFormComponent } from './components/add-edit-form/add-edit-form.component';
import { AddEditFormsService } from './services/add-edit-form.service';
import { ViewRulesComponent } from './components/rules/view-rules.component';
import { RulesFieldMaintenanceComponent } from './components/rules/field-maintenance/field-maintenance.component';
import { FieldOrderMaintenanceComponent } from './components/field-order-maintenance/field-order-maintenance.component';
import { ViewWipFormFileComponent } from './components/add-edit-form/view-wip-form-file/view-wip-form-file.component';
import { CopyRulesFromComponent } from './components/rules/copy-rules-from/copy-rules-from.component';
import { FormStatusComponent } from './components/form-status/form-status.component';
import { MultistateHelpsheetPublishComponent } from './components/multistate-helpsheet-publish/multistate-helpsheet-publish.component';
import { UploadFileComponent } from './components/add-edit-form/upload-file/upload-file.component';


@NgModule({
    declarations: [
      MaintainFormsComponent,
      FormsComponent,
      EditFormComponent,
      FormFieldDependencyRulesComponent,
      FormFieldTextAllocationComponent,
      LobActionMatrixFormComponent,
      NotesComponent,
      MoreNotesComponent,
      ViewFormJurisdictionsComponent,
      AddEditFormComponent,
      ViewRulesComponent,
      RulesFieldMaintenanceComponent,
      FieldOrderMaintenanceComponent,
      ViewWipFormFileComponent,
      CopyRulesFromComponent,
      FormStatusComponent,
      MultistateHelpsheetPublishComponent,
      UploadFileComponent
    ],
    imports: [
      FormMaintenanceRoutingModule,
      NgSelectModule,
      NilsSharedModule.loadConfig({
        environmentName: environment.environmentName,
        portalUrl: environment.portalUrl,
        appUrl: environment.appUrl,
        apiUrl: environment.apiUrl,
        serverLogLevel: environment.serverLogLevel,
        logLevel: environment.logLevel,
        serverLoggingUrl: environment.serverLoggingUrl,
        commonApiUrl: environment.commonApiUrl,
        userGroupURL: '',
        feedbackEmail: environment.feedbackEmail,
        customerCareEmail: environment.customerCareEmail,
        productUrl: environment.productUrl
      }),
      NgSelectModule,
    ],
    providers: [
      FormsService,
      FormsUtilityService,
      FieldDependencyRuleHttpService,
      LobActionMarixService,
      ViewFormJurisdictionsService,
      AddEditFormsService
    ],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
  })
  export class FormMaintenanceModule { }
