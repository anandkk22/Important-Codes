
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { take } from 'rxjs/operators';
import { ViewFormJurisdictionsService } from '../../view-form-jurisdictions/view-form-jurisdictions.service';
import { RulesService } from '../rules.service';

@Component({
  selector: 'copy-rules-from',
  templateUrl: './copy-rules-from.component.html',
  styleUrls: ['./copy-rules-from.component.scss'],
  providers: [RulesService]
})
export class CopyRulesFromComponent implements OnInit {

    @Input() copyRulesFrom;
    @Input() currentRtfName;
    @Input() currentFormId;
    @Input() stateCode;
    selectedRtfName: any;
    selected = null;
    isCopyFromCopied = false;

    constructor(public activeModal: NgbActiveModal,
        private spinnerService: SpinnerService,
        private translate: TranslateService,
        private popupService: PopupService,
        private rulesService: RulesService) { }

    ngOnInit(): void {
    }

    onRtfSelected(i, rtfName) {
        this.selected = i;
        this.selectedRtfName = rtfName;
        this.isCopyFromCopied = true;
    }

    copRules() {
        if (this.selectedRtfName && this.currentRtfName) {
            this.activeModal.close(FormsConstant.fieldMaintenanceControls.close);
            const newMessage = this.translate.instant('MAINTAIN_FORMS.COPY_RULES_FROM_SD.COPY_CONFIRMATION_MESSAGE') +
                this.translate.instant(this.selectedRtfName) + this.translate.instant('MESSAGES.CONFIRMATION.COPY_RULES_FROM_MESSAGE');
            this.rulesService.showConfirmation(newMessage).subscribe(res => {
                if (res) {
                    this.onConfirmCopyRules(this.currentRtfName, this.selectedRtfName);
                }
            });
        }
    }

    cancel() {
        this.activeModal.close(FormsConstant.fieldMaintenanceControls.close);
    }

    showAlert(message) {
        this.popupService.showAlert({
            title: this.translate.instant('MESSAGES.CONFIRMATION.ALERT'),
            message: message,
            positiveLabel: this.translate.instant('BUTTON.OK'),
            negativeLabel: '',
        });
    }

    onConfirmCopyRules(currentRtfName, selectedRtfName) {
        const data = {
            'formId': this.currentFormId,
            'rtfName': currentRtfName,
            'copyForm': selectedRtfName,
            'stateCode': this.stateCode
        };
        this.rulesService.copyRulesFrom(data).subscribe(response => {
            if (response.status === 200) {
                this.popupService.showSuccess({
                    title: '',
                    message: this.translate.instant('MAINTAIN_FORMS.COPY_RULES_FROM_SD.COPY_SUCCESS_MESSAGE'),
                    positiveLabel: this.translate.instant('BUTTON.OK'),
                    negativeLabel: '',
                });
            }
        }, async (error) => {
            const message = error.error.Message;
            this.showAlert(message);
            this.spinnerService.stop();
            });

    }
}
