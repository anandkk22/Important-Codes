import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Constants } from '@global/infrastructure/constants';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { RulesService } from '../rules.service';

@Component({
  selector: 'rules-field-maintenance',
  templateUrl: './field-maintenance.component.html',
  styleUrls: ['./field-maintenance.component.scss'],
  providers: [RulesService]
})
export class RulesFieldMaintenanceComponent implements OnInit {
  @Input() fieldMaster;
  fieldMaintenanceForm: FormGroup;
  allDisplayControls = [];
  allfieldDisplayed = [];
  allDisplayGroups = [];
  maxLength = null;
  displayOrder = null;
  displaySize = null;

  constructor(
    public activeModal: NgbActiveModal,
    private formBuilder: FormBuilder,
    private rulesService: RulesService) { }

  ngOnInit(): void {
    this.allDisplayControls = FormsConstant.allDisplayControls;
    this.allfieldDisplayed = FormsConstant.fieldDisplayed;
    this.allDisplayGroups = Constants.FieldMasterMaintenance.displayGroup;
    this.fieldMaintenanceAttributes();
    this.getFieldMasterAttributesById();
    this.maxLength = this.fieldMaintenanceForm.get(FormsConstant.fieldMaintenanceControls.maxLength).value;
    this.displayOrder = this.fieldMaintenanceForm.get(FormsConstant.fieldMaintenanceControls.displayOrder).value;
    this.displaySize = this.fieldMaintenanceForm.get(FormsConstant.fieldMaintenanceControls.displaySize).value;
  }

  cancel() {
    this.activeModal.close(FormsConstant.fieldMaintenanceControls.close);
  }

  fieldMaintenanceAttributes() {
    this.fieldMaintenanceForm = this.formBuilder.group({
      fieldName: ['', [Validators.required]],
      label: ['', [Validators.required]],
      displayControl: [FormsConstant.fieldMaintenanceControls.textbox],
      displayOrder: [null, [Validators.required]],
      maxLength: [null, [Validators.required]],
      displaySize: [null],
      displayGroup: ['', [Validators.required]],
      fieldDisplayed: [FormsConstant.fieldMaintenanceControls.yes, [Validators.required]],
      rtfActionFieldID: [this.fieldMaster.rtfActionFieldID],
    });
  }

  getFieldMasterAttributesById() {
    Object.keys(this.fieldMaintenanceForm.controls).forEach((key) => {
      if (typeof (this.fieldMaintenanceForm.controls.displayOrder) !== 'string') {
        this.fieldMaintenanceForm.controls.displayOrder.setValue(this.fieldMaster.displayOrder.toString());
      }
      if (typeof (this.fieldMaintenanceForm.controls.maxLength) !== 'string') {
        this.fieldMaintenanceForm.controls.maxLength.setValue(this.fieldMaster.maxLength.toString());
      }
      if (typeof (this.fieldMaintenanceForm.controls.displaySize) !== 'string') {
        this.fieldMaintenanceForm.controls.displaySize.setValue(this.fieldMaster.displaySize.toString());
      }
      this.fieldMaintenanceForm.get(key).setValue(this.fieldMaster[key]);
    });
  }

  restrictNumber(event: any) {
    const pattern = FormsConstant.regExpression.number;
    const inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  restrict(event) {
    if (isNaN(Number(this.fieldMaintenanceForm.get(FormsConstant.fieldMaintenanceControls.maxLength).value))) {
      this.fieldMaintenanceForm.get(FormsConstant.fieldMaintenanceControls.maxLength).setValue(this.maxLength);
    }
    if (isNaN(Number(this.fieldMaintenanceForm.get(FormsConstant.fieldMaintenanceControls.displayOrder).value))) {
      this.fieldMaintenanceForm.get(FormsConstant.fieldMaintenanceControls.displayOrder).setValue(this.displayOrder);
    }
    if (isNaN(Number(this.fieldMaintenanceForm.get(FormsConstant.fieldMaintenanceControls.displaySize).value))) {
      this.fieldMaintenanceForm.get(FormsConstant.fieldMaintenanceControls.displaySize).setValue(this.displaySize);
    }
    event.preventDefault();
  }


  cleanForm(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((key) => {
      formGroup.get(key).setValue(formGroup.get(key).value.trim());
    });
  }

  onSave() {
    const sendData = this.rulesService.sendData(this.fieldMaintenanceForm.value);
    this.rulesService.saveFieldMaintenance(sendData).subscribe(res => {
      if (res === null) {
        const alertMessage = FormsConstant.fieldMaintenanceControls.saveSuccesAlert;
        this.rulesService.showSuccessAlert(alertMessage);
      }
      this.activeModal.close(FormsConstant.fieldMaintenanceControls.saved);
    });
  }

  reset() {
    this.getFieldMasterAttributesById();
  }

}
