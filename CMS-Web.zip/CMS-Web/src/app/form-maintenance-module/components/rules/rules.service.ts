import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { saveAs } from 'file-saver';
import { take } from 'rxjs/operators';

@Injectable()
export class RulesService {

    constructor(
        private http: HttpClient,
        private popupService: PopupService,
        private translate: TranslateService) { }

    getFilePath(formStatus) {
        let filePath = '';
        formStatus === FormsConstant.formRules.pw ? filePath = FormsConstant.downloadPdf.cnrpdf :
            filePath = FormsConstant.downloadPdf.cnrpdfWip;
        return filePath;
    }

    loadFile(response: any, fileName: any) {
        saveAs(response.body, fileName);
    }

    getFormRuleActions() {
        return this.http.get(`${FormsConstant.webApis.formRuleActions}`);
    }

    actionCodeandDesc(data) {
        const formRuleActions = [];
        for (let i = 0; i < data.length; i++) {
            formRuleActions.push({
                id: data[i].id,
                actionDesc: data[i].actionDesc,
                codeandName: data[i].code + ' - ' + data[i].actionDesc
            });
        }
        return formRuleActions;
    }

    getFormRuleLobs() {
        return this.http.get(`${FormsConstant.webApis.formRuleLobs}`);
    }

    lobAbrandName(data) {
        const formRuleLobs = [];
        for (let i = 0; i < data.length; i++) {
            formRuleLobs.push({
                id: data[i].id,
                name: data[i].name,
                abbrandName: data[i].abbr + ' - ' + data[i].name
            });
        }
        return formRuleLobs;
    }

    getFormRule(formId, stateCode, actionId, lobId) {
        return this.http.get(`${FormsConstant.webApis.formRule}${formId}${FormsConstant.formRules.stateCode}${stateCode}${FormsConstant.formRules.actionId}${actionId}${FormsConstant.formRules.lobId}${lobId}`);
    }

    getCircumstance() {
        return this.http.get(`${FormsConstant.webApis.circumstance}`);
    }

    getGotoFields(formId) {
        return this.http.get(`${FormsConstant.webApis.gotoField}`.replace('formId', formId));
    }

    scrollIntoView(isGotoLink, gotoView) {
        isGotoLink = true;
        document.getElementById(gotoView).scrollIntoView({
            behavior: 'smooth'
        });
    }

    getFieldMaintenance(fieldId) {
        return this.http.get(`${FormsConstant.webApis.fieldMaster}${fieldId}`);
    }

    sendData(data) {
        const refactorData = {
            fieldName: data.fieldName,
            label: data.label,
            displayControl: data.displayControl,
            displayOrder: Number(data.displayOrder),
            maxLength: Number(data.maxLength),
            displaySize: Number(data.displaySize),
            displayGroup: data.displayGroup,
            fieldDisplayed: data.fieldDisplayed,
            rtfActionFieldID: data.rtfActionFieldID
        };
        return refactorData;
    }

    getCopyRulesTo(stateCode, rtfName, actionId) {
        return this.http.get(`${FormsConstant.webApis.copyRulesTo}${stateCode}${FormsConstant.formRules.rtfName}${rtfName}${FormsConstant.formRules.actionId}${actionId}`);
    }

    copyRule(data) {
        return this.http.post(`${FormsConstant.webApis.copyRule}`, data, { observe: 'response' });
    }

    saveFieldMaintenance(data) {
        return this.http.put(`${FormsConstant.webApis.saveFieldMaintenance}`, data);
    }

    showSuccessAlert(message) {
        this.popupService.showSuccess({
            title: '',
            message: message,
            positiveLabel: this.translate.instant('BUTTON.OK'),
            negativeLabel: '',
        });
    }

    getCopyRulesFrom(stateCode, rtfName) {
        return this.http.get(`${FormsConstant.webApis.copyRulesFrom}${stateCode}${FormsConstant.formRules.rtfName}${rtfName}`);
    }

  showAlert(message) {
    this.popupService.showAlert({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }
    updateLive(data) {
        return this.http.post(`${FormsConstant.webApis.updateLiveRule}`, data);
    }
    copyRulesFrom(data) {
        return this.http.post(`${FormsConstant.webApis.copyRules}`, data, { observe: 'response' });
    }

    sendUpdatedRuleData(data) {
        const sendData = [];
        for (let i = 0; i < data.length; i++) {
            sendData.push({
                rtfactionFieldId: data[i].rtfactionFieldId,
                fieldDefined: data[i].fieldDefined,
                defaultValue: data[i].defaultValue,
                inputRequired: data[i].inputRequired,
                regulatoryRequirement: data[i].regulatoryRequirement,
                effectiveDateBegin: data[i].effectiveDateBegin,
                recordActive: true,
                whereConditionId: data[i].whereConditionId,
                copyGroupId: data[i].copyGroupId,
            });
        }
        return sendData;
    }

    bulkRuleUpdate(data) {
        return this.http.put(`${FormsConstant.webApis.bulkRuleUpdate}`, data, { observe: 'response' });
    }

    bulkRuleUpdates(data) {
        return this.http.put(`${FormsConstant.webApis.bulkRuleUpdates}`, data, { observe: 'response' });
    }

    sendRowDataToDelete(data) {
        const sendData = [{
            rtfActionFieldId: data.rtfactionFieldId,
            fieldDefined: data.fieldDefined,
            inputRequired: data.inputRequired,
            regulatoryRequirement: data.regulatoryRequirement,
            defaultValue: data.defaultValue,
            whereConditionID: data.whereConditionId,
            effectiveDateBegin: data.effectiveDateBegin,
            recordActive: false,
            copyGroupId: data.copyGroupId,
            copyToLobIds: []
        }];
        return sendData;
    }

    delete(data) {
        return this.http.put(`${FormsConstant.webApis.deleteRule}`, data);
    }

    deleteOnCopyRulesTo(data) {
        const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body: data };
        return this.http.delete(`${FormsConstant.webApis.bulkRuleUpdate}`, options);
    }

    showConfirmationAlert(anyMessage, positiveLabel, negativeLabel) {
        return this.popupService.showConfirmation({
            title: this.translate.instant('MESSAGES.CONFIRMATION.ALERT'),
            message: anyMessage,
            positiveLabel: this.translate.instant(positiveLabel),
            negativeLabel: this.translate.instant(negativeLabel),
        }).pipe(take(1));
    }

    clearExistingRules(data) {
        return this.http.post(`${FormsConstant.webApis.clearExistingRules}`, data, { observe: 'response' });
    }

    showConfirmation(anyMessage: any) {
        return this.popupService.showConfirmation({
            title: this.translate.instant('MESSAGES.CONFIRMATION.ALERT'),
            message: anyMessage,
            positiveLabel: this.translate.instant('BUTTON.CONFIRM'),
            negativeLabel: this.translate.instant('BUTTON.CANCEL'),
        }).pipe(take(1));
    }

    showFirstTwoCircumstances(arr, old_index, new_index) {
        if (new_index >= arr.length) {
            let k = new_index - arr.length + 1;
            while (k--) {
                arr.push(undefined);
            }
        }
        arr.splice(new_index, 0, arr.splice(old_index, 1)[0]);
        return arr;
    }
}
