import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { AddEditForm } from 'app/form-maintenance-module/infrastructure/models/addEdit.model';
import { Circumstance, FieldMaintenance, FormRule, FormRulesAction, FormRulesLobs } from 'app/form-maintenance-module/infrastructure/models/rules.model';
import { FormsService } from 'app/form-maintenance-module/services/forms.service';
import { RulesFieldMaintenanceComponent } from './field-maintenance/field-maintenance.component';
import { RulesService } from './rules.service';
import { AppConstants } from 'app/app.constants';
import { CopyRulesFromComponent } from './copy-rules-from/copy-rules-from.component';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { take } from 'rxjs/operators';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';

@Component({
    selector: 'view-rules',
    templateUrl: './view-rules.component.html',
    styleUrls: ['./view-rules.component.scss'],
    providers: [RulesService]
})
export class ViewRulesComponent implements OnInit {
    constructor(
        private formsService: FormsService,
        private activatedRoute: ActivatedRoute,
        private rulesService: RulesService,
        private modalService: NgbModal,
        private translate: TranslateService,
        private spinnerService: SpinnerService,
        private formBuilder: FormBuilder,
        private popupService: PopupService,
        private formsUtilityService: FormsUtilityService
    ) { }
    private _formId: number;
    private _formStateCode: string;
    formAttribute: any;
    formRuleActions = [];
    formRuleLobs = [];
    selectedAction = [];
    selectedLob = [];
    formRules: FormRule[] = [];
    viewRuleForm: FormGroup;
    headings = [];
    circumstance = [];
    gotoFields = [];
    viewFields = [];
    cloneformRules = [];
    selectedOption;
    isGotoLink = true;
    noRecords = false;
    fieldMaintenance = {};
    selectedGotoFields;
    selectedActionName = '';
    selectedLobName = '';
    copyRulesTo = [];
    receivedFromCopyTo = {
        isCopyToCopied: false,
        lobs: [],
    };
    selectedLobOption: any;
    copyRulesFrom: any;
    CopyRtfActionFieldId: number;
    isFormDirty = false;
    selectedActionOption: any;
    selectedActionId = 0;
    previousSelectedActionOption;
    previousSelectedLobOption;
    onloadGridValue;
    copiedRuleRTFActionFieldId = 0;
    isCopyClicked = false;
    userAction = false;
    copyRulesToForm: FormGroup;
    initialValues: any;
    sendSelectedLobs = [];
    selectedCopyRuleToLobs = [];
    isAllClear = false;
    maxRtfactionFieldId: number;
    isSaved = false;
    formStatus;
    stateForm: boolean;
    rtfName: string;
    isCopyRulesClicked = false;
    updateLiveConfirmed = false;
    isRuleExists = false;
    formPublished = false;
    isFieldsDefinedOnly = false;
    ngOnInit() {
        this.activatedRoute.queryParams.subscribe(params => {
            if (params && params.params) {
                const paramData = this.formsUtilityService.getDecodedParamData(params.params);
                if (Object.keys(paramData).length !== 0) {
                    this._formId = Number(paramData[FormsConstant.addEditFormControls.formId]);
                    this._formStateCode = paramData[FormsConstant.notesUrl.stateCode];
                    this.stateForm = this.formsUtilityService.isFormPublished(paramData[FormsConstant.addEditFormControls.awebPublished],
                        paramData[FormsConstant.addEditFormControls.wkfsPublished],
                        paramData[FormsConstant.addEditFormControls.custPublished]);
                    this.rtfName = paramData['formFile'];
                    this.getFormAttributesById();
                }
            }
        });
        this.headings = [...FormsConstant.viewRuletableHeading];
        this.getFormRuleActions();
        this.getFormRuleLobs();
        this.getActionStatus();
    }

    customSearchFn(term: string, item: any) {
        return item.name.toLocaleLowerCase().startsWith(term.toLocaleLowerCase());
    }

    getActionStatus() {
        this.formsService.getActionStatus(this._formId, this._formStateCode, this.rtfName).subscribe((response: any) => {
            if (response) {
                this.isRuleExists = response.rulesExists;
                this.formPublished = response.formPublished;
            }
        });
    }

    viewRulesFom(rules: any[]) {
        return new FormGroup({
            formRules: new FormArray(rules.map((rule) => this.getFormRuleAttributes(rule)))
        });
    }

    getFormRuleAttributes(formRule: any) {
        return new FormGroup({
            fieldName: new FormControl(formRule.fieldName || ''),
            rtfactionFieldId: new FormControl(formRule.rtfactionFieldId || 0),
            label: new FormControl(formRule.label || ''),
            fieldDefined: new FormControl(formRule.fieldDefined || false),
            defaultValue: new FormControl(formRule.defaultValue || ''),
            boxNo: new FormControl(formRule.boxNo || null),
            copyGroupId: new FormControl(formRule.copyGroupId || 0),
            inputRequired: new FormControl(formRule.inputRequired || false),
            regulatoryRequirement: new FormControl(formRule.regulatoryRequirement || false),
            effectiveDateBegin: new FormControl(formRule.effectiveDateBegin || ''),
            whereConditionId: new FormControl(formRule.whereConditionId || 0),
        });
    }

    getFormAttributesById() {
        this.formsService.getFormAttributesById(this._formId).subscribe((response: AddEditForm) => {
            if (response) {
                this.formAttribute = response.form;
                this.formatCopyRulesTo();
            }
        });
    }

    formatCopyRulesTo() {
        this.rulesService.getCopyRulesTo(this._formStateCode, this.formAttribute.formFile, this.selectedActionId)
            .subscribe((response: any[]) => {
            for (let i = 0; i < response.length; i++) {
                this.copyRulesTo.push({
                    abbr: response[i].abbr,
                    id: response[i].id,
                    name: response[i].name,
                    isChecked: false,
                });
            }
            this.createCopyRulesToForm();
            this.patchCopyRulesToFormValues(this.copyRulesTo);
        });
    }

    patchCopyRulesToFormValues(data: any) {
        const array = this.copyRulesToForm.get(FormsConstant.formRules.copyRulesToControl) as FormArray;
        array.clear();
        data.forEach((item, index) => {
            array.push(this.initializeCopyRulesToForm(item));
        });
    }

    downloadFile(rtfName) {
        const filePath = this.rulesService.getFilePath(this.formAttribute.formStatus);
        this.formsService.download(filePath, rtfName).subscribe(response => {
            if (response) {
                this.rulesService.loadFile(response, rtfName);
            }
        });
    }

    getFormRuleActions() {
        this.rulesService.getFormRuleActions().subscribe((res: FormRulesAction) => {
            this.formRuleActions = this.rulesService.actionCodeandDesc(res);
        });
    }

    getFormRuleLobs() {
        this.rulesService.getFormRuleLobs().subscribe((res: FormRulesLobs) => {
            this.formRuleLobs = this.rulesService.lobAbrandName(res);
        });
    }

    onActionChange(event) {
        this.selectedActionId = event.id;
        this.isFieldsDefinedOnly = false;
        if (this.isFormDirty) {
            this.selectedActionOption = event.codeandName;
            const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_DO_YOU_WANT_TO_PROCEED');
            const positiveLabel = this.translate.instant('BUTTON.YES');
            const negativeLabel = this.translate.instant('BUTTON.NO');
            this.rulesService.showConfirmationAlert(alertMessage, positiveLabel, negativeLabel).subscribe((response) => {
                if (response) {
                    this.onActionSelection(event);
                    this.isFormDirty = false;
                    this.clearAllLobsFromCopyRulesTo();
                } else {
                    this.selectedActionOption = this.previousSelectedActionOption;
                }
            });
        } else {
            this.onActionSelection(event);
            this.clearAllLobsFromCopyRulesTo();
        }
        this.selectedGotoFields = null;
    }

    onActionSelection(event) {
        this.selectedAction = [];
        if (this.selectedLob.length > 0) {
            this.selectedLob = [];
            this.formRules = [];
            this.selectedLobOption = null;
            this.noRecords = false;
        }
        this.selectedAction.push(event.id);
        this.selectedActionName = event.actionDesc;
        this.getFormRule();
    }

    onLobChange(event) {
        this.isFieldsDefinedOnly = false;
        const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_DO_YOU_WANT_TO_PROCEED');
        const positiveLabel = this.translate.instant('BUTTON.YES');
        const negativeLabel = this.translate.instant('BUTTON.NO');
        if (this.isFormDirty) {
            this.selectedLobOption = event.abbrandName;
            this.rulesService.showConfirmationAlert(alertMessage, positiveLabel, negativeLabel).subscribe((response) => {
                if (response) {
                    this.onLobSelection(event);
                    this.getFormRule();
                    this.isFormDirty = false;
                    this.clearAllLobsFromCopyRulesTo();
                } else {
                    this.selectedLobOption = this.previousSelectedLobOption;
                }
            });
        } else {
            this.onLobSelection(event);
            this.getFormRule();
            this.clearAllLobsFromCopyRulesTo();
        }
        this.selectedGotoFields = null;
    }

    onLobSelection(event) {
        this.receivedFromCopyTo.isCopyToCopied = false;
        this.selectedLob = [];
        this.selectedLob.push(event.id);
        this.selectedLobName = event.name;
    }

    clearAllLobsFromCopyRulesTo() {
        this.copyRulesToForm.value.copyRulesToControl.forEach(ele => {
            if (ele.isChecked) {
                ele.isChecked = false;
            }
        });
        this.patchCopyRulesToFormValues(this.copyRulesToForm.value.copyRulesToControl);
        this.selectedCopyRuleToLobs.length = 0;
        this.isCopyRulesClicked = false;
        this.clearAll();
        this.cancel();
    }

    getFormRule() {
        if (this.selectedAction.length > 0 && this.selectedLob.length > 0) {
            this.getGotoFields();
            this.getCircumstance();
            this.viewFields = [...FormsConstant.formRulesViewfields];
            this.selectedOption = this.viewFields[0].name;
            this.rulesService.getFormRule(this._formId, this._formStateCode, this.selectedAction, this.selectedLob)
                .subscribe((response: FormRule[]) => {
                    this.formRules = [];
                    if (response && response.length > 0) {
                        this.noRecords = false;
                        this.formRules = response;
                        this.cloneformRules = Array.from(this.formRules);
                        this.viewRuleForm = this.viewRulesFom(this.formRules);
                        this.onloadGridValue = this.viewRuleForm.value;
                        const getLatestId = this.formRules.map(ele => ele.rtfactionFieldId);
                        this.maxRtfactionFieldId = Math.max(...getLatestId);
                    }
                    else {
                        this.noRecords = true;
                    }
                });
        }
        if (this.isSaved) {
            setTimeout(() => {
                this.rulesService.scrollIntoView(this.isSaved, this.maxRtfactionFieldId);
            }, 1000);
        }
        this.isSaved = false;
    }

    getCircumstance() {
        this.rulesService.getCircumstance().subscribe((circumstance: Circumstance[]) => {
            this.circumstance = circumstance;
            const findGenObj = this.circumstance.filter(ele => ele.id === FormsConstant.formRules.generatlCircumstance);
            const findActionObj = this.circumstance.filter(ele => ele.id === FormsConstant.formRules.actionDuetoConsumerReport);
            if (findGenObj.length) {
                const findGenId = findGenObj[0].id;
                const getGenId = this.circumstance.findIndex(ele => ele.id === findGenId);
                this.rulesService.showFirstTwoCircumstances(this.circumstance, getGenId, 0);
            }
            if (findActionObj.length) {
                const findActionId = findActionObj[0].id;
                const getActionId = this.circumstance.findIndex(ele => ele.id === findActionId);
                this.rulesService.showFirstTwoCircumstances(this.circumstance, getActionId, 1);
            }
        });
    }

    getGotoFields() {
        this.rulesService.getGotoFields(this._formId).subscribe((response: any[]) => {
            this.gotoFields = response;
        });
    }

    onViewFieldsChange(event) {
        this.isFieldsDefinedOnly = false;
        if (event.lable) {
            this.formRules = this.formRules.filter(ele => ele.fieldDefined);
            if (this.formRules.length === 0) {
                this.isFieldsDefinedOnly = true;
            }
        } else {
            this.formRules = this.cloneformRules;
        }
    }

    onGotoFieldSelect(event) {
        this.rulesService.scrollIntoView(this.isGotoLink, event);
    }

    openFieldMaintenance(rtfactionFieldId) {
        this.rulesService.getFieldMaintenance(rtfactionFieldId).subscribe((response: FieldMaintenance) => {
            this.fieldMaintenance = response;
        });
        setTimeout(() => {
            const modalRef = this.modalService.open(RulesFieldMaintenanceComponent,
                { size: FormsConstant.formRules.xl, scrollable: true, centered: true });
            modalRef.componentInstance.fieldMaster = this.fieldMaintenance;
            modalRef.result.then((data) => {
                if (data === 'saved') {
                    this.getFormRule();
                }
            });
        }, 1000);
    }

    reset() {
        this.getFormRule();
        this.isFormDirty = false;
        this.isCopyClicked = false;
        this.selectedGotoFields = null;
    }

    getCopyRulesTo(copyRulesToModal) {
        this.isCopyRulesClicked = true;
        const modalRef = this.modalService.open(copyRulesToModal, {
            size: FormsConstant.formRules.MD, scrollable: true, centered: true, backdrop: 'static',
            keyboard: false
        });
    }

    createCopyRulesToForm() {
        this.copyRulesToForm = this.formBuilder.group(this.createCopyRulesToFormGroup());
        const index = this.copyRulesTo.findIndex(ele => ele.id === this.selectedLob[0]);
        this.copyRulesTo.splice(index, 1);
    }

    createCopyRulesToFormGroup() {
        return {
            copyRulesToControl: this.formBuilder.array([
                this.initializeCopyRulesToForm(this.copyRulesTo)
            ])
        };
    }

    initializeCopyRulesToForm(data: any): FormGroup {
        return this.formBuilder.group({
            name: data.name,
            id: data.id,
            isChecked: data.isChecked
        });
    }

    getSelectedLobs(selectedId, isChecked) {
        if (isChecked) {
            this.selectedCopyRuleToLobs.push(selectedId);
        } else {
            const index = this.selectedCopyRuleToLobs.indexOf(selectedId.id);
            this.selectedCopyRuleToLobs.splice(index, 1);
        }
    }

    selectedLobs() {
        const copyRulesToData = { ... this.copyRulesToForm.value };
        this.initialValues = { ... this.copyRulesToForm.value };
        const getSelectedIds = copyRulesToData.copyRulesToControl.filter(ele => ele.isChecked).map(ele => ele.id);
        getSelectedIds.push(this.selectedLob[0]);
        this.sendSelectedLobs = [...new Set(getSelectedIds)];
        this.receivedFromCopyTo.isCopyToCopied = true;
        this.receivedFromCopyTo.lobs = this.sendSelectedLobs;
        this.isCopyRulesClicked = true;
        this.modalService.dismissAll();
    }

    updateSingleRule(rule, i) {
        let selectedLobInCopyTo = this.sendSelectedLobs;
        selectedLobInCopyTo = selectedLobInCopyTo.filter(lob => lob !== this.selectedLob[0]);

        if (selectedLobInCopyTo.length > 0) {
            const fieldDefined = this.viewRuleForm.controls.formRules.value[i].fieldDefined;
            const whereConditionId = this.viewRuleForm.controls.formRules.value[i].whereConditionId;
            const inputRequired = this.viewRuleForm.controls.formRules.value[i].inputRequired;
            const regulatoryRequirement = this.viewRuleForm.controls.formRules.value[i].regulatoryRequirement;
            const sendData = {
                rtfactionFieldId: rule.rtfactionFieldId,
                recordActive: true,
                fieldDefined: fieldDefined,
                inputRequired: inputRequired,
                defaultValue: this.viewRuleForm.controls.formRules.value[i].boxNo ?
                    this.viewRuleForm.controls.formRules.value[i].defaultValue ?
                    this.viewRuleForm.controls.formRules.value[i].defaultValue = FormsConstant.formRules.checked :
                    this.viewRuleForm.controls.formRules.value[i].defaultValue = '' :
                    this.viewRuleForm.controls.formRules.value[i].defaultValue,
                whereConditionId: whereConditionId,
                regulatoryRequirement: regulatoryRequirement,
                effectiveDateBegin: rule.effectiveDateBegin,
                copyRulesToLobs: selectedLobInCopyTo
            };
            this.rulesService.bulkRuleUpdate(sendData).subscribe((res) => {
                if (res && res.status === 200) {
                    this.getFormRule();
                    this.isFormDirty = false;
                }
            });
        } else {
            return false;
        }
    }

    cancel() {
        if (this.initialValues === undefined) {
            this.copyRulesTo = [];
            this.formatCopyRulesTo();
            this.selectedCopyRuleToLobs.length = 0;
            this.isCopyRulesClicked = false;
            this.modalService.dismissAll();
        }
        if (this.isAllClear) {
            this.copyRulesToForm.value.copyRulesToControl.forEach(ele => {
                if (ele.isChecked) {
                    ele.isChecked = false;
                }
            });
            this.isAllClear = false;
        } else {
            this.copyRulesToForm.reset(this.initialValues);
            this.selectedCopyRuleToLobs.length = this.initialValues.copyRulesToControl.filter(ele => ele.isChecked).length;
            if (!this.selectedCopyRuleToLobs.length) {
                this.isCopyRulesClicked = false;
            }
        }
        this.modalService.dismissAll();
    }

    clearAll() {
        this.isAllClear = true;
        this.isCopyRulesClicked = false;
        const lobs = this.copyRulesToForm.value.copyRulesToControl;
        lobs.forEach(ele => {
            if (ele.isChecked) {
                ele.isChecked = false;
            }
        });
        this.copyRulesToForm.value.copyRulesToControl = lobs;
        this.patchCopyRulesToFormValues(this.copyRulesToForm.value.copyRulesToControl);
        this.selectedCopyRuleToLobs.length = this.copyRulesToForm.value.copyRulesToControl.filter(ele => ele.isChecked).length;
        this.receivedFromCopyTo.isCopyToCopied = false;
        this.initialValues = undefined;
        this.sendSelectedLobs.length = 0;
    }

    onCopy(rule) {
        this.onGotoFieldSelect(FormsConstant.formRules.goToBottom);
        if (this.receivedFromCopyTo.isCopyToCopied) {
            this.isSaved = true;
            this.copiedRuleRTFActionFieldId = rule.rtfactionFieldId;
            const sendData = {
                copiedRuleRTFActionFieldId: this.copiedRuleRTFActionFieldId,
                fieldDefined: rule.fieldDefined,
                inputRequired: rule.inputRequired,
                defaultValue: rule.defaultValue,
                whereConditionId: rule.whereConditionId,
                copyGroupId: rule.copyGroupId,
                regulatoryRequirement: rule.regulatoryRequirement,
                effectiveDateBegin: rule.effectiveDateBegin,
                copyToLobIds: this.receivedFromCopyTo.lobs
            };
            this.rulesService.copyRule(sendData).subscribe(() => {
                this.getFormRule();
            });
            setTimeout(() => {
                this.rulesService.scrollIntoView(this.isSaved, this.maxRtfactionFieldId);
            }, 1000);
            this.isFormDirty = false;
        } else {
            this.isCopyClicked = true;
            this.userAction = true;
            this.isFormDirty = true;
            this.previousSelectedActionOption = this.selectedActionOption;
            this.previousSelectedLobOption = this.selectedLobOption;
            this.CopyRtfActionFieldId = rule.rtfactionFieldId;
            const newCopy = {
                fieldName: rule.fieldName,
                rtfactionFieldId: null,
                label: rule.label,
                fieldDefined: rule.fieldDefined,
                defaultValue: rule.defaultValue,
                boxNo: rule.boxNo,
                copyGroupId: rule.copyGroupId,
                inputRequired: rule.inputRequired,
                regulatoryRequirement: rule.regulatoryRequirement,
                effectiveDateBegin: rule.effectiveDateBegin,
                whereConditionId: rule.whereConditionId
            };
            this.copiedRuleRTFActionFieldId = rule.rtfactionFieldId;
            this.formRules.push(newCopy);
            this.viewRuleForm = this.viewRulesFom(this.formRules);
        }
    }
    checkFormStatus() {
        return !this.stateForm;
    }
    update() {
        if (this.viewRuleForm) {
            const data = this.viewRuleForm.value.formRules;
            const sendData = this.rulesService.sendUpdatedRuleData(data);
            this.rulesService.bulkRuleUpdates(sendData).subscribe((res) => {
                if (res && res.status === 200) {
                    if (this.updateLiveConfirmed) {
                        this.updateLiveRule();
                    } else {
                        const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.UPDATED_SUCCESSFULLY');
                        this.rulesService.showSuccessAlert(alertMessage);
                    }
                    this.getFormRule();
                    this.isFormDirty = false;
                    this.updateLiveConfirmed = false;
                }
            });
        } else if (this.updateLiveConfirmed) {
            this.updateLiveRule();
        }

    }
    updateLive() {
        this.popupService.showConfirmation({
            title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
            message: this.translate.instant('MAINTAIN_FORMS.RULES.UPDATE_LIVE_CONFIRMATION',
                { formId: this._formId, stateCode: this._formStateCode, rtfName: this.rtfName }),
            positiveLabel: this.translate.instant('BUTTON.OK'),
            negativeLabel: this.translate.instant('BUTTON.CANCEL'),
        }).pipe(take(1)).subscribe(res => {
            if (res) {
                this.updateLiveConfirmed = true;
                this.spinnerService.start();
                this.updateLiveRule();
            }
        });

    }
    updateLiveRule() {
        const sendData = {
            'formId': this._formId,
            'stateCode': this._formStateCode,
            'rtfName': this.rtfName
        };
        this.rulesService.updateLive(sendData).subscribe(() => {
            const alertMessage = this.translate.instant('MAINTAIN_FORMS.RULES.UPDATE_LIVE_SUCCESS',
                { stateCode: this._formStateCode, rtfName: this.rtfName });
            this.rulesService.showSuccessAlert(alertMessage);
        });
        this.updateLiveConfirmed = false;
    }

    deleteRule(data) {
        const positiveLabel = this.translate.instant('BUTTON.OK');
        const negativeLabel = this.translate.instant('BUTTON.CANCEL');
        let selectedLobInCopyTo = this.sendSelectedLobs;
        selectedLobInCopyTo = selectedLobInCopyTo.filter(lob => lob !== this.selectedLob[0]);
        if (selectedLobInCopyTo.length) {
            const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RULES_DELETE_CONFIRMATION');
            const sendToDelete = {
                rtfActionfieldId: data.rtfactionFieldId,
                copyToLobIds: selectedLobInCopyTo
            };
            this.rulesService.showConfirmationAlert(alertMessage, positiveLabel, negativeLabel).subscribe((response) => {
                if (response) {
                    this.rulesService.deleteOnCopyRulesTo(sendToDelete).subscribe(() => {
                        this.deteteSuccessMsg(this.translate.instant('MESSAGES.CONFIRMATION.RULES_DELETED_SUCCEESSFULLY'));
                    });
                }
            });
        } else {
            const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RULE_DELETE_CONFIRMATION');
            const sendData = this.rulesService.sendRowDataToDelete(data);
            this.rulesService.showConfirmationAlert(alertMessage, positiveLabel, negativeLabel).subscribe((res) => {
                if (res) {
                    this.rulesService.delete(sendData).subscribe(() => {
                        this.deteteSuccessMsg(this.translate.instant('MESSAGES.CONFIRMATION.RULE_DELETED_SUCCEESSFULLY'));
                    });
                }
            });
        }
    }

    deteteSuccessMsg(msg) {
        const alertMessage = msg;
        this.rulesService.showSuccessAlert(alertMessage);
        this.getFormRule();
    }

    save(formGroup: FormGroup, i) {
        this.userAction = true;
        this.isSaved = true;
        this.isCopyClicked = false;
        const rowData = formGroup.value.formRules[i];
        const sendDataToSave = {
            copiedRuleRTFActionFieldId: this.copiedRuleRTFActionFieldId,
            fieldDefined: rowData.fieldDefined,
            inputRequired: rowData.inputRequired,
            defaultValue: rowData.defaultValue,
            whereConditionId: rowData.whereConditionId,
            copyGroupId: rowData.copyGroupId,
            regulatoryRequirement: rowData.regulatoryRequirement,
            effectiveDateBegin: rowData.effectiveDateBegin,
            copyToLobIds: this.selectedLob
        };
        this.rulesService.copyRule(sendDataToSave).subscribe((res) => {
            if (res && res.status === 200) {
                const alertMessage = this.translate.instant('MESSAGES.CONFIRMATION.RULE_ADDED_SUCCESSFULLY');
                this.rulesService.showSuccessAlert(alertMessage);
                this.getFormRule();
            }
        });
        this.isFormDirty = false;
    }

    discard() {
        this.isFormDirty = false;
        this.isCopyClicked = false;
        this.userAction = true;
        this.getFormRule();
    }

    onChangeForm(formGroup: FormGroup) {
        const formValues = formGroup.value;
        const newformValues = [];
        for (let i = 0; i < formValues.formRules.length; i++) {
            newformValues.push({
                fieldName: formValues.formRules[i].fieldName,
                rtfactionFieldId: formValues.formRules[i].rtfactionFieldId,
                label: formValues.formRules[i].label,
                fieldDefined: formValues.formRules[i].fieldDefined,
                defaultValue:
                    formValues.formRules[i].boxNo ?
                        formValues.formRules[i].defaultValue ? formValues.formRules[i].defaultValue = FormsConstant.formRules.checked :
                            formValues.formRules[i].defaultValue = '' :
                        formValues.formRules[i].defaultValue,
                boxNo: formValues.formRules[i].boxNo,
                copyGroupId: formValues.formRules[i].copyGroupId,
                inputRequired: formValues.formRules[i].inputRequired,
                regulatoryRequirement: formValues.formRules[i].regulatoryRequirement,
                effectiveDateBegin: formValues.formRules[i].effectiveDateBegin,
                whereConditionId: formValues.formRules[i].whereConditionId
            });
        }
        this.isFormDirty = !(JSON.stringify(this.onloadGridValue.formRules) === JSON.stringify(newformValues));
        this.previousSelectedActionOption = this.selectedActionOption;
        this.previousSelectedLobOption = this.selectedLobOption;
    }



    fieldOrderMaintenance() {
        const rtfName = this.formAttribute.formFile ? this.formAttribute.formFile : this.formAttribute.uniformNo;
        const formId = '' + this._formId;
        const stateCode = this._formStateCode;
        const href = AppConstants.fieldOrderMaintenanceURL.replace('formID', formId)
            .replace('RTFNAME', rtfName).replace('stCode', stateCode);
        const encodedUrl = this.formsUtilityService.getEncodedUrl(href);
        window.open(encodedUrl, FormsConstant.openChildWindow.fieldOrderMaintenance,
            FormsConstant.openChildWindow.openChildWindow); return false;
    }

    getcopyRulesFrom() {
        if (this._formStateCode && this.formAttribute.formFile) {
            this.rulesService.getCopyRulesFrom(this._formStateCode, this.formAttribute.formFile).subscribe((response: any[]) => {
                this.copyRulesFrom = response;
                const modalRef = this.modalService.open(CopyRulesFromComponent,
                    { size: FormsConstant.formRules.xl, scrollable: true, centered: true });
                modalRef.componentInstance.copyRulesFrom = this.copyRulesFrom;
                modalRef.componentInstance.currentRtfName = this.formAttribute.formFile;
                modalRef.componentInstance.currentFormId = this._formId;
                modalRef.componentInstance.stateCode = this._formStateCode;
            }, async (error) => {
                const message = error.error.Message;
                this.rulesService.showAlert(message);
                this.spinnerService.stop();
            });
        }
    }

    disableUpdate() {
        if (this.isFormDirty) {
            if (!this.isCopyClicked) {
                return !this.isFormDirty || this.receivedFromCopyTo.isCopyToCopied;
            } else {
                return !this.userAction;
            }
        } else {
            return this.isCopyRulesClicked;
        }
    }

    clearExistingRules() {
        const clearRulesConfirmMessage = this.translate.instant('MESSAGES.CONFIRMATION.CLEAR_EXISTING_RULES_MESSAGE');
        const clearRuleData = {
            'formId': this._formId,
            'stateCode': this._formStateCode,
            'rtfName': this.formAttribute.formFile
        };
        this.rulesService.showConfirmation(clearRulesConfirmMessage).subscribe(response => {
            if (response) {
                this.rulesService.clearExistingRules(clearRuleData).subscribe(res => {
                    if (res.status === 200) {
                        this.getFormRule();
                    }
                });
            }
        });


    }

}
