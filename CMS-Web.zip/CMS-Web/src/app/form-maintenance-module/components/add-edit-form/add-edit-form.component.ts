import { Component, OnInit, OnChanges, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import '@wk/components/dist/tooltip';
import '@wk/components/dist/accordion';
import { FormsService } from 'app/form-maintenance-module/services/forms.service';
import { TranslateService } from '@ngx-translate/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { AddEditFormsService } from 'app/form-maintenance-module/services/add-edit-form.service';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { take } from 'rxjs/operators';
import { AddEditForm, FormComponents } from 'app/form-maintenance-module/infrastructure/models/addEdit.model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { isArray } from 'rxjs/internal-compatibility';
import { ViewWipFormFileComponent } from 'app/form-maintenance-module/components/add-edit-form/view-wip-form-file/view-wip-form-file.component';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
import { saveAs } from 'file-saver';
import { UploadFileComponent } from './upload-file/upload-file.component';
@Component({
  selector: 'app-edit-add-form',
  templateUrl: './add-edit-form.component.html',
  styleUrls: ['./add-edit-form.component.scss']
})
export class AddEditFormComponent implements OnInit, OnChanges {
  constructor(
    private formsService: FormsService,
    private activatedRoute: ActivatedRoute,
    private translate: TranslateService,
    private formBuilder: FormBuilder,
    private addEditFormsService: AddEditFormsService,
    private popupService: PopupService,
    private spinnerService: SpinnerService,
    private modalService: NgbModal,
    private formsUtilityService: FormsUtilityService
  ) { }
  @ViewChild('formFile') formFile;
  @ViewChild('helpFile') helpFile;
  @ViewChild('pdfFile') pdfFile;

  private _formId: number;
  private _stateCode: string;
  addEditForm: FormGroup;
  createForm: any;
  allPaperSizes = [];
  heading = '';
  pageTitle = '';
  dateObsolete;
  invalidDateObsolete = false;
  maxDate;
  hideShow = false;
  isFormDirty = false;
  initialDate = '';
  gridData: FormComponents[] = [];
  isChecked = false;
  selectedRow = [];
  allComponents = [];
  isAtleastOneSelected = false;
  gridDetails = {
    columnNames: FormsConstant.editFormComponentsColNames,
    gridDataKeys: FormsConstant.editFormComponentsGridDataKeys,
  };
  updateLiveConfirmed = false;
  allPgeType = [];
  addForms: FormGroup;
  submitted = false;
  isOtherField = false;
  otherComponentValue = '';
  otherComponentType = FormsConstant.addEditFormControls.others;
  isEditRecord = false;
  editDefaultValues;
  disabledAddComponentLink = false;
  disableAddBtn = false;
  editFormLabel = FormsConstant.addComponentLabel;
  private _formIdParam: number;
  fileNameLists = [];
  viewFormListData = {
    data: [],
    id: 0,
  };
  isHelpFileFound = false;
  isPDFFileFound = false;
  isFormFileFound = false;
  uploadedFile;
  uploadedFileName;
  helpFileData;
  pdfFileData;
  formFileData;
  showYellow: any = '';
  isGridRowEdit = false;
  isFormPublished;
  formStatus;
  isFormAdded = false;
  allEditionYears = [];
  fontSize = FormsConstant.addEditFormControls.fontSize;
  editionMonth = FormsConstant.addEditFormControls.editionMonth;
  tooltipText;
  previousFormFile;
  previousHelpFile;
  enteredFileName = '';
  ngOnInit(): void {
    this.maxDate = new Date(10000, 0, 1).toISOString().slice(0, 10);
    this.allPaperSizes = FormsConstant.addEditFormPaperSize;

    this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.params) {
        const paramData = this.formsUtilityService.getDecodedParamData(params.params);
        if (Object.keys(paramData).length !== 0) {
          this._formId = Number(paramData[FormsConstant.addEditFormControls.formId]);
          this._formIdParam = Number(paramData[FormsConstant.addEditFormControls.formId]);
          this._stateCode = (paramData[FormsConstant.addEditFormControls.stateCode]);
          this.isFormPublished = this.formsUtilityService.isFormPublished(paramData[FormsConstant.addEditFormControls.awebPublished],
            paramData[FormsConstant.addEditFormControls.wkfsPublished], paramData[FormsConstant.addEditFormControls.custPublished]);
          this.getFormDetails(this._formId);
        }
      }
    });

    this.disabledAddComponentBtn();
    this.addEditFormAttribute();
    this.allComponents = FormsConstant.addEditFormCustomComponentTypeControl;
    this.allPgeType = FormsConstant.addComponentPageType;
    this.addFormData();
    this.changeAddComponentLabel();
    this.fileNameLists = [...FormsConstant.viewFileNameList];
    this.allEditionYears = this.addEditFormsService.getEditionYear();
    this.tooltipText = this.translate.instant('MAINTAIN_FORMS.ADD_EDIT_FORM.UNIFORM_NO_TOOLTIP_TEXT');

  }
  ngOnChanges() {
    if (!this.isGridRowEdit) {
      this.showYellow = '';
    }
  }

  addEditFormAttribute() {
    this.addEditForm = this.formBuilder.group({
      uniformNo: ['', [Validators.required]],
      baseForm: ['', [Validators.required]],
      editionMonth: [null, [Validators.required, Validators.max(FormsConstant.maxNumbers.maxMonths)]],
      editionYear: ['', [Validators.required]],
      fontSize: [null, [Validators.required]],
      title: ['', [Validators.required]],
      formFile: [''],
      pdfFile: [''],
      stateCode: [this._stateCode],
      helpFile: [''],
      currentEdition: [true],
      dateObsolete: [''],
      paperSize: [FormsConstant.addEditFormControls.letter],
      formSize: [''],
      helpFileData: [''],
      pdfFileData: [''],
      formFileData: ['']

    });
  }
  onSelectFile(files) {
    const modalRef = this.modalService.open(UploadFileComponent);
    modalRef.componentInstance.files = files;
    modalRef.componentInstance.addEditForm = this.addEditForm;
    modalRef.componentInstance.createForm = this.createForm;
    modalRef.result.then((data) => {
      this.isFileFound(data);
    });
  }
  isFileFound(data) {
    if (data && data.FormFile && data.FormFile.name) {
      this.isFormFileFound = data.FormFile.name === this.addEditForm.get(FormsConstant.uploadFile.formFile).value;
      this.createForm.formFile = data.FormFile.name;

    } else if (data && data.HelpFile && data.HelpFile.name) {
      this.isHelpFileFound = data.HelpFile.name === this.addEditForm.get(FormsConstant.uploadFile.helpFile).value;
      this.createForm.helpFile = data.HelpFile?.name;
    }
    else if (data && data.PDFFile && data.PDFFile.name) {
      this.isPDFFileFound = data.PDFFile.name === this.addEditForm.get(FormsConstant.uploadFile.pdfFile).value;
      this.createForm.pdfFile = data.PDFFile.name;
    }
  }
  checkFileNameExists(files) {
    this.enteredFileName = files.target.value;
    if (files.target.id ===  FormsConstant.uploadFile.formfile) {
      files.target.id = FormsConstant.uploadFile.formFile;
    }
    else if (files.target.id ===  FormsConstant.uploadFile.helpfile) {
      files.target.id = FormsConstant.uploadFile.helpFile;
    }
   this.formFile.nativeElement.value = '';
   this.helpFile.nativeElement.value = '';
     if (this.enteredFileName) {
      const fileFormat = this.enteredFileName.split('.');
      const fileExtension = this.enteredFileName.substring(this.enteredFileName.indexOf('.') + 1).toLowerCase();
      if ((files.target.id === FormsConstant.uploadFile.helpFile) &&
        ((fileExtension !== FormsConstant.uploadFile.doc) && (fileExtension !== FormsConstant.uploadFile.docx))) {
          this.isHelpFileFound = false;
          this.addEditForm.get(FormsConstant.uploadFile.helpFile).setValue(null);
          this.createForm.helpFile = null;
          this.formsUtilityService.showAlert(this.translate.instant('MAINTAIN_FORMS.EDIT_FORM.INVALID_HELP_FILE_NAME',
          { name: fileFormat[0] }));
      } else if (files.target.id === FormsConstant.uploadFile.formFile &&
        ((fileExtension !== FormsConstant.uploadFile.doc) && (fileExtension !== FormsConstant.uploadFile.rtf) &&
          (fileExtension !== FormsConstant.uploadFile.docx))) {
        this.isFormFileFound = false;
        this.addEditForm.get(FormsConstant.uploadFile.formFile).setValue(null);
        this.createForm.formFile = null;
        this.formsUtilityService.showAlert(this.translate.instant('MAINTAIN_FORMS.EDIT_FORM.INVALID_FORM_FILE_NAME'));
      } else {
        this.addEditForm.get(files.target.id).setValue(this.enteredFileName);
        if (files.target.id === FormsConstant.uploadFile.helpFile) {
          this.createForm.helpFile = this.enteredFileName;
          this.helpFileData = this.enteredFileName;
          this.addEditForm.markAsDirty();
          if (this.previousHelpFile !== this.enteredFileName) {
           this.addEditFormsService.isFormFileExists(this.enteredFileName).subscribe(res => {
             if (res) {
               this.addEditForm.get(FormsConstant.uploadFile.helpFile).setValue(this.enteredFileName);
                this.isHelpFileFound = true;
             } else {
               this.isHelpFileFound = false;
             }
           });
           this.previousHelpFile = this.enteredFileName;
      }

        } else if (files.target.id === FormsConstant.uploadFile.formFile) {
          this.createForm.formFile = this.enteredFileName;
          this.formFileData = this.enteredFileName;
          this.createForm.formFileData = null;
          this.addEditForm.markAsDirty();
          if (this.previousFormFile !== this.enteredFileName) {
               this.addEditFormsService.isFormFileExists(this.enteredFileName).subscribe(res => {
                 if (res) {
                   this.addEditForm.get(FormsConstant.uploadFile.formFile).setValue(this.enteredFileName);
                   this.isFormFileFound = true;
                 } else {
                   this.isFormFileFound = false;
                 }
               });
          }
          this.addEditForm.get(FormsConstant.uploadFile.pdfFile).setValue(fileFormat[0] + ('.pdf'));

          this.addEditFormsService.isPDFFileExists(this.addEditForm.get(FormsConstant.uploadFile.pdfFile).value).subscribe(res => {
            if (res) {
              this.isPDFFileFound = true;
              this.createForm.pdfFile = this.addEditForm.get(FormsConstant.uploadFile.pdfFile).value;
            } else {
              this.isPDFFileFound = false;
            }
          });
        }
        this.previousFormFile = this.enteredFileName;
      }
     } else {
      if ( files.target.id === FormsConstant.uploadFile.helpFile) {
        this.createForm.helpFile = null;
        this.isHelpFileFound = false;
        this.previousHelpFile = '';
      }
      if ( files.target.id === FormsConstant.uploadFile.formFile) {
        this.createForm.formFile = null;
        this.isFormFileFound = false;
        this.previousFormFile = '';
      }

    }
   }

  cancelFile() {
    this.uploadedFile = null;
    this.uploadedFileName = this.translate.instant('MESSAGES.CONFIRMATION.FILE_NOT_FOUND');
  }
  disableSave() {
    return (this.addEditForm.invalid || !this.isFormDirty);
  }

  onSave() {
    if (this.addEditForm.valid) {
      if (this.addEditForm.controls.helpFile.value !== null && this.addEditForm.controls.helpFile.value.length) {
        const helpFileName = this.addEditForm.controls.helpFile.value.substr(0, this.addEditForm.controls.helpFile.value.lastIndexOf('.'));
        if (helpFileName.substr(helpFileName.length - 2) !== FormsConstant.uploadFile.rh) {
          this.popupService.showAlert({
            title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
            message: this.translate.instant('MAINTAIN_FORMS.EDIT_FORM.INVALID_HELP_FILE_NAME', { name: helpFileName }),
            positiveLabel: this.translate.instant('BUTTON.OK'),
            negativeLabel: '',
          });
          return;
        }
      }
      if (this._formId === 0) {
        this.addEditFormsService.getUniformNoStatus(this.addEditForm.controls.uniformNo.value).subscribe(isUniformNoExists => {
          if (isUniformNoExists) {
            this.popupService.showAlert({
              title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
              message: this.translate.instant('MAINTAIN_FORMS.ADD_EDIT_FORM.UNIFORM_NO') + this.addEditForm.controls.uniformNo.value +
                this.translate.instant('MAINTAIN_FORMS.ADD_EDIT_FORM.ALREADY_EXIST_UNIFORM_NO'),
              positiveLabel: this.translate.instant('BUTTON.OK'),
              negativeLabel: '',
            });
          } else {
            this.addRecord();
          }
        });
      } else {
        this.updateRecord();
      }
    }
  }
  addEditFormPayload() {
    const request = {
      ...this.addEditForm.value,
      'helpFileData': this.helpFileData?.name ? this.helpFileData : '',
      'pdfFileData': this.pdfFileData?.name ? this.pdfFileData : '',
      'formFileData': this.formFileData?.name ? this.formFileData : '',
      'helpFileName': this.addEditForm.value.helpFile, // this.helpFileData?.name ? this.helpFileData.name : this.createForm.helpFile,
      'pdfFileName': this.pdfFileData?.name ? this.pdfFileData.name : this.createForm.pdfFile,
      'formFileName': this.formFileData?.name ? this.formFileData.name : this.createForm.formFile
    };
    request.editionYear = Number(this.formsUtilityService.convertTwoDigitEditionYear(request.editionYear));
    return request;
  }
  addRecord() {
    const data = this.addEditFormPayload();
    this.addEditFormsService.addForm(data).subscribe(res => {
      if (res) {
        const alertMessage = this.addEditForm.controls.uniformNo.value +
          this.translate.instant('MESSAGES.CONFIRMATION.ADDED_SUCCESS');
        this.formsUtilityService.showSuccessAlert(alertMessage);
        this._formId = Number(res);
        this._formIdParam = Number(res);
      }
      this.hideShow = false;
      this.isFormDirty = false;
      this.isFormAdded = true;
      for (const key in this.createForm) {
        if (this.createForm?.hasOwnProperty(key) && this.addEditForm?.value?.hasOwnProperty(key)) {
          this.createForm[key] = this.addEditForm?.value[key];
        }
      }
      this.getFormAttricutesById();
    });
  }
  updateLiveAttributePayload() {
    const payload = {
      'formId': this._formId,
      'editionMonth': Number(this.addEditForm.value.editionMonth),
      'editionYear': Number(this.addEditForm.value.editionYear > 99 ?
      this.formsUtilityService.convertTwoDigitEditionYear(this.addEditForm.value.editionYear)
        : this.addEditForm.value.editionYear),
      'title': this.addEditForm.value.title,
      'stateCode': this._stateCode
    };
    return payload;
  }
  updateRecord() {
    const data = this.addEditFormPayload();
    this.addEditFormsService.updateForm(data, this._formId).subscribe(res => {
      if (!this.disableSave() && this.updateLiveConfirmed) {
        this.updateLiveFormAttribute();
      } else {
        if (res === null) {
          const message = this.addEditForm.controls.uniformNo.value +
            this.translate.instant('MESSAGES.CONFIRMATION.UPDATED_SUCCESS');
          this.formsUtilityService.showSuccessAlert(message);
        }
      }
      this.isFormDirty = false;
    });
  }
  resetCreateForm() {
    this.formFile.nativeElement.value = '';
    this.helpFile.nativeElement.value = '';
    this.pdfFile.nativeElement.value = '';
    this.previousHelpFile = '';
    this.previousFormFile = '';
    for (const key in this.createForm) {
      if (this.createForm?.hasOwnProperty(key) && this.addEditForm?.value?.hasOwnProperty(key)) {
        this.createForm[key] = this.addEditForm?.value[key];
      }
    }
    }

  cancel() {
    this.addEditForm.reset();
    this.resetCreateForm();
    this.isPDFFileFound = false;
    this.isHelpFileFound = false;
    this.isFormFileFound = false;
    this.addEditForm.get(FormsConstant.addEditFormControls.currentEdition).setValue(true);
    this.addEditForm.get(FormsConstant.addEditFormControls.paperSize).setValue(FormsConstant.addEditFormControls.letter);
    this.addEditFormAttribute();
  }

  ondateObsoleteChange() {
    this.dateObsolete = this.addEditForm.get(FormsConstant.addEditFormControls.dateObsolete).value;
    this.invalidDateObsolete = !(moment(this.dateObsolete, FormsConstant.dateFormat.yymmddFormat, true).isValid());
    if (this.invalidDateObsolete) {
      this.addEditForm.get(FormsConstant.addEditFormControls.dateObsolete).reset();
    }
  }

  onPaste(key) {
    this.addEditFormsService.onPaste(key, this.addEditForm.get(FormsConstant.addEditFormControls.editionMonth),
      this.addEditForm.get(FormsConstant.addEditFormControls.fontSize));
  }

  restrictNumber(event: any) {
    const pattern = FormsConstant.regExpression.number;
    const inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  getFormAttricutesById() {
    this.formsService.getFormAttributesById(this._formId).subscribe((formValue: AddEditForm) => {
      this.initialDate = formValue.form.dateObsolete;
      this.createForm = formValue.form;
      this.formStatus = this.createForm.formStatus;
      this.gridData = formValue.formComponents;
      Object.keys(this.addEditForm.controls).forEach((key) => {
        if (key === FormsConstant.addEditFormControls.editionMonth || key === FormsConstant.addEditFormControls.fontSize) {
          this.addEditForm.controls.editionMonth.setValue(formValue.form.editionMonth?.toString());
          this.addEditForm.controls.fontSize.setValue(formValue.form.fontSize?.toString());
        } else {
          this.addEditForm.get(key).setValue(this.createForm[key]);
        }
        this.addEditForm.controls.paperSize.setValue(formValue.form.formSize);
      });
      if (this.createForm.helpFile) {
        this.createForm.helpFileData = this.createForm.helpFile;
        this.helpFileData = this.createForm.helpFile;
        this.addEditForm.get('helpFileData').setValue(this.uploadedFile);
      }
      this.isHelpFileFound = this.createForm.isHelpFileFound;

      if (this.createForm.pdfFile) {
        this.createForm.pdfFileData = this.createForm.pdfFile;
        this.pdfFileData = this.createForm.pdfFile;
        this.addEditForm.get('pdfFileData').setValue(this.uploadedFile);
      }
      this.isPDFFileFound = this.createForm.isPDFFileFound;

      if (this.createForm.formFile) {
        this.createForm.formFileData = this.createForm.formFile;
        this.addEditForm.get('formFileData').setValue(this.uploadedFile);
        this.formFileData = this.createForm.formFile;
      }
      this.isFormFileFound = this.createForm.isFormFileFound;

    });
  }

  reset() {

    this.resetCreateForm();
    this.getFormAttricutesById();
    this.isFormDirty = false;
  }

  cleanForm(formGroup: FormGroup) {
    this.addEditForm.dirty ? this.isFormDirty = true : this.isFormDirty = false;
    Object.keys(formGroup.controls).forEach((key) => {
      formGroup.get(key).setValue(formGroup.get(key).value?.trim());
    });
  }

  private getFormDetails(formId) {
    if (formId === 0) {
      this.createForm = {
        baseForm: null,
        currentEdition: true,
        dateObsolete: null,
        editionMonth: null,
        editionYear: null,
        fontSize: null,
        formFile: null,
        paperSize: FormsConstant.addEditFormControls.letter,
        helpFile: null,
        pdfFile: null,
        title: null,
        uniformNo: null,
      };
      this.hideShow = true;
      this.isFormAdded = false;
    } else {
      this.hideShow = false;
      this.isFormAdded = true;
      this.getFormAttricutesById();
    }
  }

  openComponentDetails(contentModalOverlay) {
    this.isEditRecord = false;
    const modalRef = this.modalService.open(contentModalOverlay, { size: 'lg', scrollable: true, centered: true });
  }

  checkAllCheckbox() {
    if (this.isChecked) {
      this.checkAllcheckboxValue(this.isChecked);
    } else {
      this.selectedRow = [];
      this.isAtleastOneSelected = false;
      this.checkAllcheckboxValue(this.isChecked);
    }
    this.checkIfAtleastOneSelected();
  }

  checkAllcheckboxValue(isChecked) {
    this.gridData.forEach(element => {
      element.isSelected = isChecked;
      if (isChecked) {
        this.addToSelectedtable(element);
      }
    });
  }

  checkIfAtleastOneSelected() {
    if (this.selectedRow.length === 0) {
      this.isAtleastOneSelected = false;
      this.isChecked = false;
    } else if (this.gridData.length === this.selectedRow.length) {
      this.isAtleastOneSelected = false;
      this.isChecked = true;
    } else if ((this.gridData.length > this.selectedRow.length)
      && (this.selectedRow.length > 0)) {
      this.isAtleastOneSelected = true;
      this.isChecked = false;
    }
    else {
      this.isAtleastOneSelected = false;
      this.isChecked = false;
    }
  }

  addToSelectedtable(oneRow) {
    this.selectedRow.push(oneRow);
  }

  changeCheckbox(data) {
    data.isSelected = !data.isSelected;
    if (data.isSelected) {
      this.addToSelectedtable(data);
    } else {
      this.removeFromSelectedtable(data.gridId);
    }
    this.checkIfAtleastOneSelected();
  }

  removeFromSelectedtable(gridId) {
    const index = this.selectedRow.findIndex(d => d.gridId === gridId);
    this.selectedRow.splice(index, 1);
  }

  deleteComponentRecord(data, action) {
    data = !isArray(data) ? [data] : data;
    const deleteParams = this.addEditFormsService.getDeleteRecords(this._formId, data);

    const confimationMessage = action === ConfigurationsConstant.bulk ?
      this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_BULK_DELETE') :
      this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM_SINGLE_DELETE',
        { componentType: this.getComponentName(data[0].componentType) });

    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: confimationMessage,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.formsService.deleteFormComponent(deleteParams).subscribe(response => {
          deleteParams.componentType.forEach(component => {
            const recordFound = this.gridData.findIndex(item => item.componentType === component);
            this.gridData.splice(recordFound, 1);
          });

          const successMessage = action === ConfigurationsConstant.bulk ?
            this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_DELETED') :
            this.getComponentName(data[0].componentType) +
            this.translate.instant('MESSAGES.CONFIRMATION.DELETED_SUCCESS');

          this.formsUtilityService.showSuccessAlert(successMessage);
          this.selectedRow = [];
          this.isAtleastOneSelected = false;
          this.isChecked = false;
          this.uncheckAllcheckboxValue();
        });
      }
    });

  }

  uncheckAllcheckboxValue() {
    this.gridData.forEach(element => {
      element.isSelected = false;
    });
  }

  onComponentChange(ev) {
    if (ev.name === this.otherComponentType) {
      this.isOtherField = true;
    } else {
      this.isOtherField = false;
    }
  }

  addFormData() {
    this.addForms = this.formBuilder.group({
      component: [null, [Validators.required]],
      rtfSectionStarts: [null],
      rtfSectionEnds: [null],
      pdfSectionStarts: [null, [Validators.required]],
      pdfSectionEnds: [null, [Validators.required]],
      pageOrder: [null, [Validators.required]],
      standalone: [null],
      copies: [1, [Validators.required]],
      pageType: ['S']
    });
  }

  onSubmit() {
    this.submitted = true;
    const self = this;
    if (this.addForms.valid) {
      const bodyObj = this.getAddEditAPIObj();
      this.addEditFormsService.addComponentData(this._formId, bodyObj).subscribe((res: any) => {
        this.addForms.reset();
        this.modalService.dismissAll();
        const alertMessage = this.getComponentName(bodyObj.componentType) + this.translate.instant('MESSAGES.CONFIRMATION.ADDED_SUCCESS');
        this.popupService.showSuccess({
          title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
          message: alertMessage,
          positiveLabel: this.translate.instant('BUTTON.OK'),
          negativeLabel: this.translate.instant('BUTTON.CANCEL'),
        }).pipe(take(1)).subscribe((data: any) => {
          if (data) {
            self.gridData.unshift(bodyObj);
            self.gridData.sort((a, b) => a.pageOrder - b.pageOrder);
          }
        });
        this.addFormData();
      });
    }
  }
  downloadForm(formName, fileType) {
    const filePath = this.formsUtilityService.getFilePath(this.formStatus, fileType);
    this.formsService.download(filePath, formName)
      .subscribe(response => {
        if (response) {
          saveAs(response.body, formName);
        }
      },
        async (error) => {
          const message = JSON.parse(await error.error.text()).Message;
          this.formsUtilityService.showAlert(message);
          this.spinnerService.stop();
        });
  }
  changeAddComponentLabel() {
    if (this._formIdParam === 0) {
      this.editFormLabel = FormsConstant.addComponentLabel;
    } else {
      this.editFormLabel = FormsConstant.editComponentLabel;
    }
  }

  disabledAddComponentBtn() {
    if (this._formId === 0) {
      this.disabledAddComponentLink = true;
    } else {
      this.disabledAddComponentLink = false;
    }
    return this.disabledAddComponentLink;
  }

  refreshGridData(alertMessage) {
    this.formsUtilityService.showSuccessAlert(alertMessage);
    this.getFormDetails(this._formId);
  }

  isFormValid() {
    if (this.isOtherField && this.otherComponentValue === '') {
      return this.addForms.valid;
    }
    return !this.addForms.valid;
  }

  onOtherComponentValueChange(ev) {
    this.otherComponentValue = ev.target.value;
    if (this.otherComponentValue) {
      this.isFormValid();
    }
  }

  resetForm() {
    this.submitted = false;
    this.isGridRowEdit = false;
    this.showYellow = '';
    this.addForms.reset();
    this.modalService.dismissAll();
    this.addFormData();
  }

  getComponentName(code) {
    switch (code) {
      case FormsConstant.componentDetails.CertholderCode:
        return FormsConstant.componentDetails.CertholderName;
      case FormsConstant.componentDetails.AddIntCode:
        return FormsConstant.componentDetails.AddIntName;
      case FormsConstant.componentDetails.TpCode:
        return FormsConstant.componentDetails.TpName;
      default:
        return code;
    }
  }

  editFormComponentDetails(contentModalOverlay, rowDetails) {
    this.isGridRowEdit = true;
    this.isEditRecord = true;
    this.showYellow = rowDetails.componentType;
    this.editDefaultValues = rowDetails;
    const modalRef = this.modalService.open(contentModalOverlay, { size: 'lg', scrollable: true, centered: true });
    this.setFormValues(rowDetails);
  }

  getBackYellowClass(row) {
    return (row.componentType === this.showYellow ? ConfigurationsConstant.backYellowClass : '');
  }

  onReset() {
    this.setFormValues(this.editDefaultValues);
  }

  onComponentUpdate() {
    if (this.addForms.valid) {
      const bodyObj = this.getAddEditAPIObj();
      this.addEditFormsService.addComponentData(this._formId, bodyObj).subscribe((res: any) => {
        this.isEditRecord = false;
        this.isGridRowEdit = false;
        this.addForms.reset();
        this.modalService.dismissAll();
        this.showYellow = '';
        const alertMessage = this.getComponentName(bodyObj.componentType) + this.translate.instant('MESSAGES.CONFIRMATION.UPDATED_SUCCESS');
        this.refreshGridData(alertMessage);
        this.addForms.controls.component.enable();
        this.addFormData();
      });
    }
  }

  setFormValues(rowDetails) {
    this.addForms.controls.component.setValue(rowDetails.componentType);
    this.addForms.controls.pageOrder.setValue(rowDetails.pageOrder);
    this.addForms.controls.standalone.setValue(rowDetails.standaloneEnabled);
    this.addForms.controls.rtfSectionStarts.setValue(rowDetails.rtfSectionStart);
    this.addForms.controls.rtfSectionEnds.setValue(rowDetails.rtfSectionEnd);
    this.addForms.controls.pdfSectionStarts.setValue(rowDetails.pdFpageStart);
    this.addForms.controls.pdfSectionEnds.setValue(rowDetails.pdFpageEnd);
    this.addForms.controls.copies.setValue(rowDetails.copies);
    this.addForms.controls.pageType.setValue(rowDetails.pageType === ' ' ? null : rowDetails.pageType);
  }

  getAddEditAPIObj() {
    const bodyObj = {
      'componentType': this.addForms.value.component,
      'pageOrder': this.addForms.value.pageOrder ? Number(this.addForms.value.pageOrder) : 0,
      'standaloneEnabled': this.addForms.value.standalone,
      'rtfSectionStart': this.addForms.value.rtfSectionStarts ? Number(this.addForms.value.rtfSectionStarts) : 0,
      'rtfSectionEnd': this.addForms.value.rtfSectionEnds ? Number(this.addForms.value.rtfSectionEnds) : 0,
      'pdFpageStart': this.addForms.value.pdfSectionStarts ? Number(this.addForms.value.pdfSectionStarts) : 0,
      'pdFpageEnd': this.addForms.value.pdfSectionEnds ? Number(this.addForms.value.pdfSectionEnds) : 0,
      'copies': this.addForms.value.copies ? Number(this.addForms.value.copies) : 0,
      'pageType': this.addForms.value.pageType === ' ' ? null : this.addForms.value.pageType
    };
    return bodyObj;
  }

  enableSaveButton(buttonType) {
    let isDisable = false;
    if (
      (this.addForms.value.component !== this.editDefaultValues.componentType) ||
      (this.addForms.value.pageOrder !== this.editDefaultValues.pageOrder) ||
      (this.addForms.value.standalone !== this.editDefaultValues.standaloneEnabled) ||
      (this.addForms.value.rtfSectionStarts !== this.editDefaultValues.rtfSectionStart) ||
      (this.addForms.value.rtfSectionEnds !== this.editDefaultValues.rtfSectionEnd) ||
      (this.addForms.value.pdfSectionStarts !== this.editDefaultValues.pdFpageStart) ||
      (this.addForms.value.pdfSectionEnds !== this.editDefaultValues.pdFpageEnd) ||
      (this.addForms.value.copies !== this.editDefaultValues.copies) ||
      (this.addForms.value.pageType !== (this.editDefaultValues.pageType === ' ' ? null : this.editDefaultValues.pageType))
    ) {
      isDisable = (buttonType === 'save' && this.addForms.valid) || (buttonType === 'reset') ? false : true;
    } else {
      isDisable = true;
    }
    return isDisable;
  }
  openFormFileList(resData) {
    this.addEditFormsService.getViewFileList(resData.id).subscribe((response: any) => {
      const viewFileList = {
        data: response,
        id: resData.id,
        name: resData.name
      };
      const modalRef = this.modalService.open(ViewWipFormFileComponent);
      modalRef.componentInstance.viewFileList = viewFileList;
    });
  }

  addEditRestrictNumber(event: any) {
    const pattern = FormsConstant.addEditComponentRegExpression.number;
    const inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      event.preventDefault();
    }
  }
  updateLiveAttributes() {

    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: this.translate.instant('MAINTAIN_FORMS.ADD_EDIT_FORM.UPDATE_LIVE_CONFIRMATION'),
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        if (!this.disableSave()) {
          this.updateLiveConfirmed = true;
          this.onSave();
        } else {
          this.updateLiveFormAttribute();
        }
      }
    });
  }
  updateLiveFormAttribute() {
    this.addEditFormsService.updateLiveFormAttributes(this.updateLiveAttributePayload()).subscribe(() => {
      const alertMessage = this.translate.instant('MAINTAIN_FORMS.ADD_EDIT_FORM.UPDATE_LIVE_SUCCESS');
      this.formsUtilityService.showSuccessAlert(alertMessage);
    },
      async (error) => {
        const message = this.translate.instant('MAINTAIN_FORMS.ADD_EDIT_FORM.UPDATE_LIVE_FAILURE');
        this.addEditFormsService.showAlert(message);
        this.spinnerService.stop();
      });

  }
  updateLiveComponent() {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: this.translate.instant('MAINTAIN_FORMS.EDIT_FORM.UPDATE_LIVE_CONFIRMATION'),
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.addEditFormsService.updateLiveComponent(this._formId).subscribe(() => {
          const alertMessage = this.translate.instant('MAINTAIN_FORMS.EDIT_FORM.UPDATE_LIVE_SUCCESS');
          this.formsUtilityService.showSuccessAlert(alertMessage);
        });
      }
    });
  }
}


