import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
import { FormsService } from 'app/form-maintenance-module/services/forms.service';

@Component({
  selector: 'app-view-wip-form-file',
  templateUrl: './view-wip-form-file.component.html',
  styleUrls: ['./view-wip-form-file.component.scss'],
  providers: [FormsService]
})
export class ViewWipFormFileComponent implements OnInit {

  @Input() viewFileList;
  fileId: number;
  data;
  constructor(
    private formsService: FormsService,
    public activeModal: NgbActiveModal,
    private popupService: PopupService,
    private translate: TranslateService,
    private spinnerService: SpinnerService,
    private formsUtilityService: FormsUtilityService
  ) { }



  ngOnInit(): void {
    this.fileId = this.viewFileList.id;
    this.data = this.viewFileList.data.sort();

  }

  cancel() {
    this.activeModal.close(FormsConstant.fieldMaintenanceControls.close);
  }
  downloadFile(fileName) {
    fileName = fileName.replace(FormsConstant.downloadViewFiles.hash, FormsConstant.downloadViewFiles.replaceHash)
    .replace(FormsConstant.downloadViewFiles.space, FormsConstant.downloadViewFiles.replaceSpace);
    let filePath;
    switch (this.fileId) {
      case 0:
        filePath =  FormsConstant.downloadViewFiles.wipFormFile;
       break;
      case 1:
        filePath = FormsConstant.downloadViewFiles.currentFormFile;
        break;
      case 2:
        filePath = FormsConstant.downloadViewFiles.wipPdfFile;
        break;
      case 3:
        filePath =  FormsConstant.downloadViewFiles.currentPdfFile;
        break;
      case 4:
        filePath = FormsConstant.downloadViewFiles.wipHelpFile;
        break;
      default:
        filePath = FormsConstant.downloadViewFiles.currentHelpFile;

    }

    this.formsService.download(filePath, fileName).subscribe(response => {
     this.formsService.loadFile(response, fileName);
     this.spinnerService.stop();
      }, (err: HttpErrorResponse) => {
      if (err.status === 422) {
        this.popupService.showAlert({
          title: '',
          message: this.translate.instant('MESSAGES.CONFIRMATION.FILE_NOT_FOUND'),
          positiveLabel: this.translate.instant('BUTTON.OK'),
          negativeLabel: ''
        });
      }
      this.spinnerService.stop();
    });
  }
}
