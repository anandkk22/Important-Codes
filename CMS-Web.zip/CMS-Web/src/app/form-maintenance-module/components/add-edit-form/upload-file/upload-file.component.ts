import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { SpinnerService } from '@wk/nils-core';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
import { FormsService } from 'app/form-maintenance-module/services/forms.service';

@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.scss'],
  providers: []
})
export class UploadFileComponent implements OnInit {
  constructor(
    private translate: TranslateService,
    public activeModal: NgbActiveModal,
    private formsUtilityService: FormsUtilityService,
    private spinnerService: SpinnerService,
    private formsService: FormsService) { }
  @Input() files;
  @Input() addEditForm;
  @Input() createForm;
  selectedFile;
  isAvailable = true;
  uploadedFileName;
  validFormFileFound = false;
  validPdfFileFound = false;
  validHelpFileFound = false;
  showFormFile = false;
  showPdfFile = false;
  showHelpFile = false;
pdf;
  ngOnInit(): void {
    this.checkFileType();
  }

  onSelectFile(files) {
    this.files = files;
    this.selectedFile = this.files.target.files.item(0);
    this.uploadedFileName = this.selectedFile?.name;

    if (this.uploadedFileName) {
      const fileFormat = this.uploadedFileName.split('.');
      const fileExtension = this.uploadedFileName.substring(this.uploadedFileName.indexOf('.') + 1).toLowerCase();
      if ((this.files.target.id === FormsConstant.uploadFile.helpFile) &&
        ((fileExtension !== FormsConstant.uploadFile.doc) && (fileExtension !== FormsConstant.uploadFile.docx))) {
        this.validHelpFileFound = false;
        this.formsUtilityService.showAlert(this.translate.instant('MAINTAIN_FORMS.EDIT_FORM.INVALID_HELP_FILE_FORMAT',
          { name: fileFormat[0] }));
      } else if (this.files.target.id === FormsConstant.uploadFile.pdfFile && fileExtension !== FormsConstant.uploadFile.pdf) {
        this.validPdfFileFound = false;
        this.formsUtilityService.showAlert(this.translate.instant('MAINTAIN_FORMS.EDIT_FORM.INVALID_PDF_FILE_FORMAT'));
      } else if (this.files.target.id === FormsConstant.uploadFile.formFile &&
        ((fileExtension !== FormsConstant.uploadFile.doc) && (fileExtension !== FormsConstant.uploadFile.rtf) &&
          (fileExtension !== FormsConstant.uploadFile.docx))) {
        this.validFormFileFound = false;
        this.formsUtilityService.showAlert(this.translate.instant('MAINTAIN_FORMS.EDIT_FORM.INVALID_FORM_FILE_FORMAT'));
      } else {
        if (this.files.target.id === FormsConstant.uploadFile.helpFile) {
          this.createForm.helpFileData = this.selectedFile;
          if (this.addEditForm.value.helpFile) {
            if (this.addEditForm.value.helpFile !== this.uploadedFileName) {
            } else {
              this.createForm.helpFile = this.uploadedFileName;
            }
          } else {
            this.createForm.helpFile = this.uploadedFileName;
          }
          this.validHelpFileFound = true;
          this.addEditForm.markAsDirty();
        } else if (this.files.target.id === FormsConstant.uploadFile.pdfFile) {
          this.validPdfFileFound = true;
          if (this.addEditForm.value.pdfFile !== this.uploadedFileName) {
          } else {
          }
          this.createForm.pdfFileData = this.selectedFile;
          this.createForm.pdfFile = this.uploadedFileName;

          this.addEditForm.markAsDirty();
        } else if (this.files.target.id === FormsConstant.uploadFile.formFile) {
          this.createForm.formFileData = this.selectedFile;
          if (this.addEditForm.value.formFile) {
            if (this.addEditForm.value.formFile !== this.uploadedFileName) {
            } else {
              this.createForm.formFile = this.uploadedFileName;
            }
          } else {
            this.createForm.formFile = this.uploadedFileName;
          }
          this.validFormFileFound = true;
          this.addEditForm.markAsDirty();
        }
      }
    }
  }
  checkFileType() {
    if (this.files.target.id === FormsConstant.uploadFile.helpFile) {
      this.showFiles(false, true, false);
    } else if (this.files.target.id === FormsConstant.uploadFile.formFile) {
       this.showFiles(true, false, false);
    } else if (this.files.target.id === FormsConstant.uploadFile.pdfFile) {
      this.showFiles(false, false, true);
    }
  }
  showFiles(formFile, helpFile, pdfFile) {
    this.showFormFile = formFile,
    this.showHelpFile = helpFile,
    this.showPdfFile =  pdfFile;
  }
  onUpload() {
    this.isAvailable = false;
    if (this.showFormFile) {
      this.serviceAPIHandler(this.selectedFile, null, null, 'MAINTAIN_FORMS.EDIT_FORM.FORM_FILE_UPLOAD_SUCCESS');
    } else if (this.showHelpFile) {
      this.serviceAPIHandler(null, this.selectedFile, null, 'MAINTAIN_FORMS.EDIT_FORM.HELP_FILE_UPLOAD_SUCCESS');
    } else if (this.showPdfFile) {
        this.serviceAPIHandler(null, null, this.selectedFile, 'MAINTAIN_FORMS.EDIT_FORM.PDF_FILE_UPLOAD_SUCCESS');
    }
  }
  serviceAPIHandler(form, help, pdf, successmsg) {
    const request = {
      FormFile: form,
      HelpFile: help,
      PDFFile: pdf
    };
    this.formsService.uploadFile(request).subscribe(() => {
      this.formsUtilityService.showSuccessAlert(this.translate.instant(successmsg));
      this.activeModal.close(request);
    });

  }  cancel() {
    this.activeModal.close();

  }
}
