import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-multistate-helpsheet-publish',
  templateUrl: './multistate-helpsheet-publish.component.html',
  styleUrls: ['./multistate-helpsheet-publish.component.scss']
})
export class MultistateHelpsheetPublishComponent implements OnInit {
  @Input() data: any;

  constructor(
    public activeModal: NgbActiveModal
  ) {}

  ngOnInit() { }

  onConfirm() {
    this.activeModal.close(true);
  }

  onCancel() {
    this.activeModal.close(false);
  }
}
