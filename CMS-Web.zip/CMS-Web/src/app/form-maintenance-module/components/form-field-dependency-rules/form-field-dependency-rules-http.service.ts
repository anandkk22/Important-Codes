import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';


@Injectable()
export class FieldDependencyRuleHttpService {

    constructor(private http: HttpClient) { }

    getCopyRuleData(formId) {
      return this.http.get(`${ReportsConstant.webApis.getFieldDependancyCopyRule}`.replace('{formId}', formId));
    }

    getRuleData(formId, rtfName) {
      return this.http.get(`${ReportsConstant.webApis.getFieldDependencyRule}`
      .replace('{formId}', formId)
      .replace('{RtfName}', rtfName));
    }

    updateRuleData(formId, ruleSetPayload) {
      return this.http.put(`${ReportsConstant.webApis.updateFieldDependencyRule}`.replace('{formId}', formId), ruleSetPayload);
    }

    copyPriorRuleData(copyRulePayload) {
      return this.http.put(`${ReportsConstant.webApis.copyPriorRuleData}`, copyRulePayload);
    }

    filterRulesData(event: any, ruleSetData: any, activeRules: any) {
        if (ruleSetData) {
            if (event === activeRules) {
                ruleSetData = ruleSetData.filter((data: any) => data.isFieldRuleSelected === true);
            }
        }
        return ruleSetData;
    }
}
