import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { FieldDependencyRuleHttpService } from './form-field-dependency-rules-http.service';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { AppConstants } from 'app/app.constants';
import '@wk/components/dist/accordion';
import { PopupService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';

@Component({
  selector: 'app-form-field-dependency-rules',
  templateUrl: './form-field-dependency-rules.component.html',
  styleUrls: ['./form-field-dependency-rules.component.scss']
})
export class FormFieldDependencyRulesComponent implements OnInit, OnDestroy {

  constructor(
    private activatedRoute: ActivatedRoute,
    private fieldDependencyRuleService: FieldDependencyRuleHttpService,
    private popupService: PopupService,
    private formsUtilityService: FormsUtilityService,
    private translate: TranslateService) { }

  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  activeSubscription: Subscription;
  activeRuleSubscription: Subscription;
  copyRuleData = [];
  copyRuleDataObject = [];
  ruleSetData = [];
  ruleSetAllPotentialData = [];
  selectFormCopyRuleValue: string = null;
  activeFormID: string = null;
  fileName: string = null;
  isRuleTableAvailable = true;
  initialRuleSetData = [];
  isExpanded = false;
  isNoRecordFound: boolean;
  filterAllPotentialRules = ConfigurationsConstant.fieldDependancyRules.filterAllPotentialRules;
  filterActiveRules = ConfigurationsConstant.fieldDependancyRules.filterActiveRules;
  activeRules = ConfigurationsConstant.fieldDependancyRules.filterActiveRules;
  activeRulesFilter = '';
  selectedFilename;
  isAllChecked = false;
  isAtleastOneRowSelected = false;
  isFilterDataAvailable = false;
  isCopyRulesVisible = true;
  selectedFilterList = [this.filterAllPotentialRules, this.filterActiveRules];
  selectedFilterName = this.filterAllPotentialRules;
  activeRuleData = [];

  ngOnInit(): void {
    this.isNoRecordFound = false;

    this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.params) {
        const paramData = this.formsUtilityService.getDecodedParamData(params.params);
        if (Object.keys(paramData).length !== 0) {
          this.activeFormID = paramData['formId'];
          this.fileName = paramData['fileName'];
        }
      }
    });

    this.getCopyRuleData();
    this.getRuleData();
  }

  getCopyRuleData() {
    this.activeSubscription = this.fieldDependencyRuleService.getCopyRuleData(this.activeFormID).subscribe((res: any) => {
      if (res && res.length) {
        this.isCopyRulesVisible = true;
        this.copyRuleDataObject = res;
        this.copyRuleData = this.sortData(res, 'rtfName');
      } else {
        this.isCopyRulesVisible = false;
      }
    });
  }

  getRuleData() {
    this.activeRuleSubscription = this.fieldDependencyRuleService.getRuleData(this.activeFormID, this.fileName).subscribe((res: any) => {
      if (res && res.length) {
        if (this.activeRulesFilter === this.activeRules) {
          this.ruleSetData = res.filter((data: any) => data.isFieldRuleSelected === true);
          if (this.ruleSetData.length > 0) {
            this.isAtleastOneRowSelected = true;
            this.isNoRecordFound = false;
          } else {
            this.isNoRecordFound = true;
          }
        } else {
          this.ruleSetData = res;
        }
        this.activeRuleData = res.filter((data: any) => data.isFieldRuleSelected === true);
        this.ruleSetAllPotentialData = res;
        this.isFilterDataAvailable = true;
        this.initialRuleSetData = JSON.parse(JSON.stringify(this.ruleSetData));
      } else {
        this.isNoRecordFound = true;
        this.isRuleTableAvailable = false;
      }
      this.checkForSelectedRows();
    });
  }

  checkForSelectedRows() {
    let isCheckActive = true;
    this.isAtleastOneRowSelected = false;
    this.ruleSetData.forEach((data) => {
      if (data.isFieldRuleSelected) {
        this.isAtleastOneRowSelected = true;
      } else {
        isCheckActive = false;
      }
    });
    if (isCheckActive && this.ruleSetData.length > 0) {
      this.isAllChecked = true;
    } else {
      this.isAllChecked = false;
    }
  }

  clickedBox(checkedRuleSetId) {
    this.ruleSetData.forEach((ruleSet) => {
      if (ruleSet.fieldRuleID === checkedRuleSetId) {
        ruleSet.isFieldRuleSelected = !ruleSet.isFieldRuleSelected;
      }
      this.checkForSelectedRows();
    });
  }

  clickedAllBox() {
    if (this.isAllChecked) {
      this.ruleSetData.forEach((ruleSet) => {
        ruleSet.isFieldRuleSelected = true;
      });
      this.isAllChecked = true;
    } else {
      this.ruleSetData.forEach((ruleSet) => {
        ruleSet.isFieldRuleSelected = false;
      });
      this.isAllChecked = false;
    }
    this.checkForSelectedRows();
  }
  updateRuleSetRecords() {
    this.ruleSetData.forEach((ruleSet) => {
      ruleSet.rtfName = this.fileName;
    });
    this.fieldDependencyRuleService.updateRuleData(this.activeFormID, this.ruleSetData).subscribe((res) => {
      this.getRuleData();
      if (this.activeRulesFilter === this.activeRules) {
        let counter = 0;
        this.ruleSetData.forEach((data) => {
          if (data.isFieldRuleSelected) {
            counter++;
          }
          if (counter === 0) {
            this.isRuleTableAvailable = false;
            this.isNoRecordFound = true;
          }
        });
      }
      this.popupService.showSuccess({
        title: '',
        message: this.translate.instant('MAINTAIN_FORMS.FORM_FIELD_DEPENDENCY_RULE.RULES_UPDATES_MSG') + this.fileName,
        positiveLabel: this.translate.instant('BUTTON.OK'),
        negativeLabel: '',
      });
    });
  }

  resetRuleSetRecords() {
    this.ruleSetData =  JSON.parse(JSON.stringify(this.initialRuleSetData));
    this.checkForSelectedRows();
    this.formsUtilityService.scrollToTop();
  }

  viewAllFilterChange(event) {
    this.getRuleData();
    this.activeRulesFilter = event;
    this.ruleSetData = this.fieldDependencyRuleService.filterRulesData(event, this.ruleSetAllPotentialData, this.activeRules);
    this.initialRuleSetData = JSON.parse(JSON.stringify(this.ruleSetData));
    if (this.ruleSetData.length === 0) {
      this.isRuleTableAvailable = false;
      this.isFilterDataAvailable = true;
      this.isNoRecordFound = true;
    } else {
      this.isRuleTableAvailable = true;
      this.isNoRecordFound = false;
    }
    this.checkForSelectedRows();
  }

  sortData(data, key) {
    return data.sort((a, b) => 0 - (a[key]?.toLowerCase() > b[key]?.toLowerCase() ? 1 : -1));
  }

  isManualExpanded() {
    this.isExpanded = !this.isExpanded;
  }

  expandForm(event) {
    event.stopPropagation();
  }

  copyPriorRules() {
    const copyRulePayload = {
      'currentVersionFormId': this.activeFormID,
      'currentVersionRTFName': this.fileName,
      'previousVersionFormId': this.selectedFilename,
    };

    let priorFileName;
    this.copyRuleDataObject.forEach((copyRule) => {
      if (copyRule.formID === this.selectedFilename) {
        priorFileName = copyRule.rtfName;
      }
    });

    this.fieldDependencyRuleService.copyPriorRuleData(copyRulePayload).subscribe((res) => {
      this.getRuleData();
      this.popupService.showSuccess({
        title: '',
        message: this.translate.instant('MAINTAIN_FORMS.FORM_FIELD_DEPENDENCY_RULE.COPY_PRIOR_RULES_SUCCESS_MESSAGE')
        + priorFileName + this.translate.instant('MAINTAIN_FORMS.FORM_FIELD_DEPENDENCY_RULE.TO') + this.fileName,
        positiveLabel: this.translate.instant('BUTTON.OK'),
        negativeLabel: '',
      });
    });
    this.onCancelClick();
  }

  onCancelClick() {
    this.isExpanded = !this.isExpanded;
    this.selectedFilename = null;
  }

  printRules() {
    window.print();
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
    this.activeRuleSubscription.unsubscribe();
  }

}
