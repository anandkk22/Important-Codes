import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import '@wk/components/dist/tooltip';
import '@wk/components/dist/accordion';
import { AppConstants } from 'app/app.constants';
import { FormsService } from 'app/form-maintenance-module/services/forms.service';
import { ReportsConstant } from 'app/reports-module/infrastructure/reports.constant';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-edit-form',
  templateUrl: './edit-form.component.html',
  styleUrls: ['./edit-form.component.scss']
})
export class EditFormComponent implements OnInit {

  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  editFormValues: any;
  allPaperSizes = [];
  allComponents = [];
  gridData = [];
  selectedRow = [];
  isChecked = false;
  isAtleastOneSelected = false;
  gridDetails = {
    columnNames: ReportsConstant.editFormComponentsColNames,
    gridDataKeys: ReportsConstant.editFormComponentsGridDataKeys,
  };
  constructor(
    private formsService: FormsService,
    private activatedRoute: ActivatedRoute,
    private modalService: NgbModal,
  ) { }

  ngOnInit(): void {
    this.allPaperSizes = [{ name: 'Letter', code: '1' }, { name: 'Legal', code: '2' }];
    this.allComponents = [{ name: 'Insured', code: '1' }, { name: 'Third Party', code: '2' },
    { name: 'Mortgagee', code: '3' }, { name: 'Certificate Holder', code: '4' }, { name: 'Lineholder', code: '5' },
    { name: 'Additional Interest', code: '6' }, { name: 'WCC', code: '7' }];
    this.activatedRoute.queryParams.subscribe(params => {
      this.formsService.getFormAttributesById(params.formId).subscribe((formValue: any) => {
        this.editFormValues = formValue.form;
        this.gridData = formValue.formComponents;
      });
    });
  }

  openComponentDetails(contentModalOverlay) {
    const modalRef = this.modalService.open(contentModalOverlay, { size: 'lg', scrollable: true, centered: true });

  }

  checkAllCheckbox() {
    if (this.isChecked) {
      this.checkAllcheckboxValue();
    } else {
      this.selectedRow = [];
      this.isAtleastOneSelected = false;
    }
    this.checkIfAtleastOneSelected();
  }

  checkAllcheckboxValue() {
    this.gridData.forEach(element => {
      element.isSelected = true;
      this.addToSelectedtable(element);
    });
    this.isAtleastOneSelected = true;
  }

  checkIfAtleastOneSelected() {
    if (this.selectedRow.length === 0) {
      this.isAtleastOneSelected = false;
      this.isChecked = false;
    } else if (this.gridData.length === this.selectedRow.length) {
      this.isAtleastOneSelected = false;
      this.isChecked = true;
    } else if ((this.gridData.length > this.selectedRow.length)
      && (this.selectedRow.length > 0)) {
      this.isAtleastOneSelected = true;
      this.isChecked = false;
    }
    else {
      this.isAtleastOneSelected = false;
      this.isChecked = false;
    }
  }

  addToSelectedtable(oneRow) {
    this.selectedRow.push(oneRow);
  }

  changeCheckbox(data) {
    data.isSelected = !data.isSelected;
    if (!data.isSelected) {
      this.removeFromSelectedtable(data.gridId);
    } else if (data.isSelected) {
      this.addToSelectedtable(data);
    }
    this.checkIfAtleastOneSelected();
  }

  removeFromSelectedtable(gridId) {
    const index = this.selectedRow.findIndex(d => d.gridId === gridId);
    this.selectedRow.splice(index, 1);
  }
}
