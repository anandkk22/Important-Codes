import { Component, OnInit, ViewChild } from '@angular/core';
import { FormsService } from 'app/form-maintenance-module/services/forms.service';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { Router } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { select, Store } from '@ngrx/store';
import { FormsActions } from 'app/form-maintenance-module/state/action/forms.actions';
import { NgSelectComponent } from '@ng-select/ng-select';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
@Component({
  selector: 'app-maintain-forms',
  templateUrl: './maintain-forms.component.html',
  styleUrls: ['./maintain-forms.component.scss']
})
export class MaintainFormsComponent implements OnInit {
  @ViewChild('selecter') ngselect: NgSelectComponent;
  allJurisdictions = [];
  formTypes = FormsConstant.formType;
  isClickedSearch = false;
  selectedformTypes = [];
  selectedJurisdictions = [];
  isDataAvalailable = false;
  constructor(
    private formsService: FormsService,
    private router: Router,
    private formStore: Store<{reducer}>,
    private formsUtilityService: FormsUtilityService,
  ) {
    this.formStore.pipe(select('reducer')).subscribe((values) => {
      if (values) {
        this.selectedformTypes = values.maintainFormTypes;
        this.selectedJurisdictions = values.maintainJurisdictions;
      }
    });
   }

  ngOnInit(): void {
    this.getJurisdictions();
  }

  customSearchFn(term: string, item: any) {
    return item.name.toLocaleLowerCase().startsWith(term.toLocaleLowerCase());
   }

  getJurisdictions() {
  this.formsService.getJurisdictions().subscribe((res: any) => {
      if (res) {
        this.allJurisdictions = res;
        this.isDataAvalailable = true;
      }
    });
  }

  search() {
    const stateName  = this.formsUtilityService.getStateName(this.allJurisdictions, this.selectedJurisdictions);
    this.isClickedSearch = true;
    const data = {
      maintainFormTypes: this.selectedformTypes,
      maintainJurisdictions: this.selectedJurisdictions,
      maintainJurisdictionsName: stateName
    };
    this.formStore.dispatch(new FormsActions(data));
    this.router.navigateByUrl(AppConstants.uiRoutes.formsList);
  }

  reset() {
    this.isClickedSearch = false;
    this.selectedformTypes = [];
    this.selectedJurisdictions = [];
  }

}
