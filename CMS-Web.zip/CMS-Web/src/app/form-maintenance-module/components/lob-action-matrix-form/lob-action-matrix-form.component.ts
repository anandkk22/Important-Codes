import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { LobActionMarixService } from 'app/form-maintenance-module/services/log-action-matrix.service';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { SpinnerService } from '@wk/nils-core';
import { PopupService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { forkJoin, Subscription } from 'rxjs';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';


@Component({
  selector: 'app-lob-action-matrix-form',
  templateUrl: './lob-action-matrix-form.component.html',
  styleUrls: ['./lob-action-matrix-form.component.scss']
})
export class LobActionMatrixFormComponent implements OnInit {
  Object = Object;
  lobActionMatrix = {};
  actionMatrix = [];
  formId: Number;
  stateCode: string;
  formFile: string;
  uniformNo: string;
  formStatus: string;
  awebPublished: boolean;
  wkfsPublished: boolean;
  custPublished: boolean;
  formLOBAction = [];
  actionItems = [];
  formLobActionItems = [];
  objectKeys = [];
  objectValues = [];
  objectKeysnValues = [];
  updatedActionMatrix = [];
  updatedata = {
    'formId': 0,
    'stateCode': '',
    'rtfName': '',
    'lobActions': [],
    'isAWEBPublished': false,
    'isWKFSPublished': false,
    'isCUSTPublished': false,
    'formStatus': ''
  };
  subscriptions: Subscription[] = [];
  formLOBActions: any;
  isActionsDeleted: boolean;
  selectedLobs = [];
  constructor(
    private lobActionMarixService: LobActionMarixService,
    private activatedRoute: ActivatedRoute,
    private spinnerService: SpinnerService,
    private popupService: PopupService,
    private translate: TranslateService,
    private formsUtilityService: FormsUtilityService) { }

  ngOnInit() {
    this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.params) {
        const paramData = this.formsUtilityService.getDecodedParamData(params.params);
        if (Object.keys(paramData).length !== 0) {
          this.formId = paramData['formId'];
          this.stateCode = paramData['stateCode'];
          this.formFile = paramData['formFile'] !== 'null' ? paramData['formFile'] : null;
          this.uniformNo = paramData['uniformNo'] !== 'null' ? paramData['uniformNo'] : null;
          this.formStatus = paramData['formStatus'];
          this.awebPublished = JSON.parse(paramData['awebPublished']);
          this.wkfsPublished = JSON.parse(paramData['wkfsPublished']);
          this.custPublished = JSON.parse(paramData['custPublished']);
        }
      }
    });
    this.updatedata.formId = Number(this.formId);
    this.updatedata.rtfName = this.formFile;
    this.updatedata.stateCode = this.stateCode;
    this.updatedata.formStatus = this.formStatus;
    this.updatedata.isAWEBPublished = this.awebPublished;
    this.updatedata.isWKFSPublished = this.wkfsPublished;
    this.updatedata.isCUSTPublished = this.custPublished;
    this.getInitialData();
  }

  getInitialData() {
    const lobExceptCPR = this.lobActionMarixService.getLobExceptCPR();
    const actionMatrix = this.lobActionMarixService.getActionMatrix();
    const formLOBActions = this.lobActionMarixService.getFormLOBAction(this.formId, this.stateCode);
    this.subscriptions.push(forkJoin([lobExceptCPR, actionMatrix, formLOBActions]).subscribe(
      (res: any) => {
        if (res) {
          this.getLobExceptCPRData(res[0]);
          this.getActionMatrixData(res[1]);
          this.getFormLOBActionData(res[2]);
        }
      }
    ));
  }

  getLobExceptCPRData(response) {
    this.lobActionMatrix = response;
    this.objectKeys = Object.keys(this.lobActionMatrix);
    this.objectKeys = this.objectKeys.map(i => Number(i));
    this.objectValues = Object.values(this.lobActionMatrix);
    for (let i = 0; i < this.objectKeys.length; i++) {
      this.objectKeysnValues.push(
        {
          objectKeys: this.objectKeys[i],
          objectValues: this.objectValues[i],
        }
      );
    }
  }

  getFormLOBActionData(response) {
    if (response) {
      this.formLOBAction = response;
      for (let i = 0; i < this.formLOBAction.length; i++) {
        for (let j = 0; j < this.objectKeysnValues.length; j++) {
          if (this.formLOBAction[i].lobId === this.objectKeysnValues[j][FormsConstant.lobObjectKeys.objectKeys]) {
            this.formLobActionItems.push({
              lobId: this.formLOBAction[i].lobId,
              objectValues: this.objectKeysnValues[j].objectValues,
              actionIds: this.formLOBAction[i].actionIds,
            });
          }
        }
      }
      this.formLobActionItems = this.formLobActionItems.sort((a, b) =>
        (a.objectValues > b.objectValues) ? 1 : (b.objectValues > a.objectValues) ? -1 : 0);
      this.updatedActionMatrix = JSON.parse(JSON.stringify(this.formLobActionItems));
    }
  }

  getActionMatrixData(response) {
    this.actionMatrix = response;
    this.actionMatrix = this.actionMatrix.sort((a, b) => (a.id > b.id) ? 1 : (b.id > a.id) ? -1 : 0);
  }

  isChecked(actionIds, i) {
    const indexValue = actionIds.includes(i + 1);
    return indexValue;
  }

  onPrintClick() {
    window.print();
  }

  onActionChecked(i, rowIndex) {
    const actionIdIndex = i + 1;
    if (this.formLobActionItems[rowIndex].actionIds.includes(actionIdIndex)) {
      const index = this.formLobActionItems[rowIndex].actionIds.indexOf(actionIdIndex);
      this.formLobActionItems[rowIndex].actionIds.splice(index, 1);
    } else {
      this.formLobActionItems[rowIndex].actionIds.push(actionIdIndex);
    }
  }

  resetActionLOB() {
    this.spinnerService.start();
    this.formLobActionItems = JSON.parse(JSON.stringify(this.updatedActionMatrix));
    this.isActionsDeleted = false;
    setTimeout(() => {
      this.spinnerService.stop();
    }, 1000);
  }

  updateLobActions() {
    for (let i = 0; i < this.formLobActionItems.length; i++) {
      const lobAction = {
        'lobId': this.formLobActionItems[i].lobId,
        'actionIds': this.formLobActionItems[i].actionIds
      };
      this.updatedata.lobActions.push(lobAction);
    }
    this.lobActionMarixService.updateLOBActions(this.updatedata).subscribe((res: any) => {
      const alertMessage = this.translate.instant('MAINTAIN_FORMS.LOB_ACTIONS.LOB_SUCCESS');
      this.popupService.showSuccess({
        title: '',
        message: alertMessage,
        positiveLabel: this.translate.instant('BUTTON.OK'),
        negativeLabel: '',
      });
      this.getInitialData();
      this.resetLobActionForm();
    });
  }

  resetLobActionForm() {
    this.actionMatrix = [];
    this.formLobActionItems = [];
    this.lobActionMatrix = [];
    this.objectKeys = [];
    this.objectValues = [];
    this.objectKeysnValues = [];
    this.formLOBAction = [];
    this.actionItems = [];
    this.updatedActionMatrix = [];
    this.selectedLobs = [];
    this.updatedata = {
      'formId': this.updatedata.formId,
      'stateCode': this.stateCode,
      'rtfName': this.formFile,
      'lobActions': [],
      'isAWEBPublished': this.awebPublished,
      'isWKFSPublished': this.wkfsPublished,
      'isCUSTPublished': this.custPublished,
      'formStatus': this.formStatus
    };
    this.updatedata.formId = Number(this.formId);
    this.updatedata.rtfName = this.formFile;
    this.updatedata.stateCode = this.stateCode;
  }
}
