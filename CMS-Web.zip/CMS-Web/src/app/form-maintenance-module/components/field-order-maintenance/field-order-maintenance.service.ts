import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';

@Injectable()
export class FieldOrderMaintenanceService {
    constructor(
        private http: HttpClient
        ) { }

    getFieldOrderData(formId: any, rtfName: any, stateCode: any) {
        const url = FormsConstant.webApis.fieldOrdersMaintenance.replace('formId', formId);
        return this.http.get(url.replace('RTFNAME', rtfName).replace('stateCode', stateCode));
    }
    fieldOrderData() {
        return this.http.post(`${FormsConstant.webApis.updateFieldOrder}`, '');
    }

    updateFieldOrderValue(actionDetails) {
        return this.http.put(`${FormsConstant.webApis.updateFieldOrder}`, actionDetails);
    }

    updateMaxLengthValue(actionDetails) {
        return this.http.put(`${FormsConstant.webApis.updateFieldOrder}`, actionDetails);
    }

    getActionData(formId, rtfName) {
        const url = FormsConstant.webApis.manageLabelAction.replace('formId', formId);
        return this.http.get(url.replace('RTFName', rtfName));
    }

    getLobData(formId, rtfName) {
        const url = FormsConstant.webApis.manageLabelLob.replace('formId', formId);
        return this.http.get(url.replace('RTFName', rtfName));
    }

    getCircumstanceData(formId, rtfName) {
        const url = FormsConstant.webApis.manageLabelCircumstance.replace('formId', formId);
        return this.http.get(url.replace('RTFName', rtfName));
    }

    getUniversalLable(formId, rtfName, fieldname, stateCode) {
        const url = FormsConstant.webApis.universalLabel.replace('formId', formId)
        .replace('rtfName', rtfName).replace('fieldname', fieldname).replace('stateCode', stateCode);
        return this.http.get(url);
    }

    getCustomizedLabel(formId, rtfName, fieldname, stCode) {
        const url = FormsConstant.webApis.customizedLabel.replace('formId', formId)
        .replace('rtfName', rtfName).replace('fieldname', fieldname).replace('stCode', stCode);
        return this.http.get(url);
    }

    updateUniversaleLabel(dataObj) {
        const url = FormsConstant.webApis.updateUniversalLabel;
        return this.http.put(url, dataObj);
    }

    updateCustomizedManageLabel(dataObj) {
        const url = FormsConstant.webApis.updateCustomizedManageLabel;
        return this.http.post(url, dataObj);
    }

    updateLabel(data) {
        const url = FormsConstant.webApis.updateLabel;
        return this.http.put(url, data);
    }

    updateFieldOrderRule(data) {
        const url = FormsConstant.webApis.updateFieldOrderRule;
        return this.http.put(url, data);
    }

    syncRTFActionField() {
        const url = FormsConstant.webApis.syncRTFActionField;
        const body = {};
        return this.http.post(url, body);
    }

    updateDisplayGroup(updateGroup) {
        const url = FormsConstant.webApis.updateDisplayGroup;
        return this.http.put(url, updateGroup);
    }
}
