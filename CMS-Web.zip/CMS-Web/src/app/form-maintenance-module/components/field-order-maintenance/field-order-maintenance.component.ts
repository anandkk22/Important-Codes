import { Component, OnChanges, OnInit } from '@angular/core';
import '@wk/components/dist/accordion';
import { FieldOrderMaintenanceService } from './field-order-maintenance.service';
import { ActivatedRoute } from '@angular/router';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PopupService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { take } from 'rxjs/operators';
import { Constants } from '@global/infrastructure/constants';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
@Component({
  selector: 'field-order-maintenance',
  templateUrl: './field-order-maintenance.component.html',
  styleUrls: ['./field-order-maintenance.component.scss'],
  providers: [FieldOrderMaintenanceService]
})
export class FieldOrderMaintenanceComponent implements OnInit, OnChanges {

  fieldOrderData = [];
  private _formId: string;
  rtfName: string;
  fieldOrderInputValue: any;
  maxLengthInputValue: any;
  isExpanded = false;
  isManageLabelAccordian = false;
  selectedManageLabel: string;
  isAddLabel = false;
  selectedInsurerName;
  universalLabel = '';
  updatedUniversaleLabel = '';
  updatedUniversaleLabelStatus = false;
  selectedRowForFieldName = '';
  resetBtnFlag = true;
  saveBtnFlag = true;
  stateCode = '';
  customizedLabelData = [];
  cloneCustomizedLabelData = [];
  isGridRowEditing = false;
  showYellow: any = '';
  updateFieldOrder = {
    'formId': 0,
    'fieldName': '',
    'rtfName': '',
    'maxLength': 0,
    'displayOrder': 0
  };
  displayGroupData = Constants.FieldMasterMaintenance.displayGroup;
  modifiedDisplayGroupData = [];
  selectedfieldName;
  selectedDisplayGroup;
  changeDisplayGroup = null;
  customizedLabel;
  isDisplayGroupAccordian = false;
  isDisplayGroupExpanded = false;
  isDataAvailable = false;
  customLabelChange = false;

  constructor(private fieldOrderService: FieldOrderMaintenanceService,
    private activatedRoute: ActivatedRoute,
    private modalService: NgbModal,
    private translate: TranslateService,
    private formsUtilityService: FormsUtilityService,
    private popupService: PopupService) { }

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.params) {
        const paramData = this.formsUtilityService.getDecodedParamData(params.params);
        if (Object.keys(paramData).length !== 0) {
          this._formId = paramData['formId'];
          this.rtfName = paramData['rtfName'];
          this.stateCode = paramData['stateCode'];
        }
      }
    });

    this.loadFieldOrderData();
    this.showYellow = '';
  }

  ngOnChanges() {
    if (!this.isGridRowEditing) {
      this.showYellow = '';
    }
  }

  getBackYellowClass(row) {
    return (row.fieldName === this.showYellow ? ConfigurationsConstant.backYellowClass : '');
  }

  loadFieldOrderData() {
    this.fieldOrderService.fieldOrderData().subscribe(() => {
      this.getFieldOrderData();
    });
  }

  getFieldOrderData() {
    this.fieldOrderService.getFieldOrderData(this._formId, this.rtfName, this.stateCode).subscribe((res: any) => {
      const fielRes = this.sortFieldOrderData(res, 'displayOrder');
      this.fieldOrderData = this.formsUtilityService.fieldOrderDataStatus(fielRes);
      this.isDataAvailable = true;
    });
  }

  sortFieldOrderData(data, key) {
    return data.sort((a, b) => 0 - (a[key] < b[key] ? 1 : -1));
  }

  openComponentDetails(fieldOrderModel, fieldOrderData, modelFlag) {
    this.selectedRowForFieldName = fieldOrderData.fieldName;
    this.updateFieldOrder.formId = Number(this._formId);
    this.updateFieldOrder.rtfName = this.rtfName;
    this.updateFieldOrder.maxLength = fieldOrderData.maxLength;
    this.updateFieldOrder.fieldName = fieldOrderData.fieldName;
    this.updateFieldOrder.displayOrder = fieldOrderData.displayOrder;
    if (modelFlag === 'fieldOrder') {
      this.fieldOrderInputValue = fieldOrderData.displayOrder;
    } else if (modelFlag === 'maxLength') {
      this.maxLengthInputValue = fieldOrderData.maxLength;
    }
    const modalRef = this.modalService.open(fieldOrderModel, { size: 'md', scrollable: true, centered: true });
  }

  resetForm() {
    this.modalService.dismissAll();
  }

  onFieldOrderValueChange(ev) {
    this.fieldOrderInputValue = ev.target.value;
  }

  updateFieldOrderValue() {
    this.updateFieldOrder.displayOrder = this.fieldOrderInputValue;
    this.fieldOrderService.updateFieldOrderValue(this.updateFieldOrder).subscribe((res: any) => {
      this.resetForm();
      this.getFieldOrderData();
      const alertMessage = Constants.fieldOrderMaintenance.update_field_order;
      this.popupService.showSuccess({
        title: '',
        message: alertMessage,
        positiveLabel: this.translate.instant('BUTTON.OK'),
        negativeLabel: '',
      });
    });
  }

  onMaxLengthValueChange(ev) {
    this.maxLengthInputValue = ev.target.value;
  }

  updateMaxLengthValue() {
    this.updateFieldOrder.maxLength = this.maxLengthInputValue;
    this.fieldOrderService.updateMaxLengthValue(this.updateFieldOrder).subscribe((res: any) => {
      this.resetForm();
      this.getFieldOrderData();
      const alertMessage = Constants.fieldOrderMaintenance.maxLength_update_success;
      this.popupService.showSuccess({
        title: '',
        message: alertMessage,
        positiveLabel: this.translate.instant('BUTTON.OK'),
        negativeLabel: '',
      });
    });
  }

  isManualExpanded() {
    this.isExpanded = !this.isExpanded;
  }

  expandForm(event) {
    event.stopPropagation();
  }

  collapseWkAccordianPanel() {
    setTimeout(() => { this.isExpanded = false; }, 100);
    this.isAddLabel = false;
    this.showYellow = '';
    this.resetManageLabel();
  }

  onManageLabelClick(fieldOrderData) {
    this.selectedInsurerName = fieldOrderData.fieldName;
    this.selectedDisplayGroup = fieldOrderData.displayGroup;
    this.isManageLabelAccordian = true;
    this.isExpanded = true;
    this.selectedManageLabel = fieldOrderData.fieldName;
    this.customizedLabelData = [];
    this.formsUtilityService.scrollToTop();
    this.getDataForActionLobCircumstance();
    this.showYellow = fieldOrderData.fieldName;
    this.resetManageLabel();
  }

  getDataForActionLobCircumstance() {
    this.isGridRowEditing = true;
  }

  getCustomizedLable() {
    this.fieldOrderService.getCustomizedLabel(this._formId, this.rtfName, this.selectedInsurerName, this.stateCode)
      .subscribe((res: any) => {
        this.customizedLabelData = res;
        this.cloneCustomizedLabelData  = JSON.parse(JSON.stringify(res));
      });
  }

  onCustomizedLabelChange() {
    this.customLabelChange = !(JSON.stringify(this.cloneCustomizedLabelData) === JSON.stringify(this.customizedLabelData));
  }

  updateLabel(data) {
    const newLabel = data.label.trim();
    if (newLabel === FormsConstant.empty) {
      this.popupService.showAlert({
        title: '',
        message: Constants.fieldOrderMaintenance.label_Field_cannot_be_empty,
        positiveLabel: this.translate.instant('BUTTON.OK'),
        negativeLabel: '',
      });
    } else {
      const updatedLabel = {
        'rtfActionFieldId': [data.rtfActionFieldId],
        'newLabel': newLabel
      };
      const alertMessage = Constants.fieldOrderMaintenance.update_customized_label;
      const succesMessage = Constants.fieldOrderMaintenance.updated_customized_label_success;
      this.popupService.showConfirmation({
        title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
        message: alertMessage,
        positiveLabel: this.translate.instant('BUTTON.OK'),
        negativeLabel: this.translate.instant('BUTTON.CANCEL'),
      }).pipe(take(1)).subscribe(res => {
        if (res) {
          this.fieldOrderService.updateLabel(updatedLabel).subscribe(() => {
            this.showSuccessAlert(succesMessage);
            this.getCustomizedLable();
            this.getFieldOrderData();
            this.customLabelChange = false;
          });
        }
      });
    }
  }

  onChangeUniversalLabel(value) {
    this.updatedUniversaleLabel = value.trim();
    if (this.updatedUniversaleLabel.length) {
      this.resetBtnFlag = false;
    }
  }

  resetManageLabel() {
    this.isExpanded = true;
    this.updatedUniversaleLabel = '';
    this.resetBtnFlag = true;
    this.customLabelChange = false;
    this.getCustomizedLable();
  }

  getResetFlag() {
    let resetFlag = true;
    if (this.updatedUniversaleLabel !== '' || this.customLabelChange) {
      resetFlag = false;
    }
    return resetFlag;
  }

  getSaveBtnFlag() {
    let saveBtnFlag = true;
    if (this.updatedUniversaleLabel !== '') {
      saveBtnFlag = false;
    }
    return saveBtnFlag;
  }

  saveManageLabel() {
    const data = {
      rtfActionFieldId: this.customizedLabelData.map(ele => ele.rtfActionFieldId),
      newLabel: this.updatedUniversaleLabel.trim(),
    };

    this.fieldOrderService.updateLabel(data).subscribe(() => {
      const succesMessage = this.translate.instant('MAINTAIN_FORMS.RULES.FIELD_MAINTENANCE.UNIVERSAL_LABEL_TEXT_BULK') +
        this.translate.instant('MESSAGES.CONFIRMATION.UPDATED_SUCCESS');
      this.showSuccessAlert(succesMessage);
      this.getCustomizedLable();
      this.getFieldOrderData();
      this.updatedUniversaleLabel = '';
    });
  }

  updateUniversalLabel(data) {
    this.fieldOrderService.updateUniversaleLabel(data).subscribe((res: any) => {
      this.showYellow = '';
      const message = this.translate.instant('MAINTAIN_FORMS.RULES.FIELD_MAINTENANCE.UNIVERSAL_LABEL_TEXT') +
        this.translate.instant('MESSAGES.CONFIRMATION.UPDATED_SUCCESS');
      this.showSuccessAlert(message);
    });
  }

  updateCustomizedLabel(data) {
    const successMessage = Constants.fieldOrderMaintenance.add_customized_label;
    this.fieldOrderService.updateCustomizedManageLabel(data).subscribe((res: any) => {
      this.showYellow = '';
      this.isAddLabel = false;
      this.showSuccessAlert(successMessage);
      this.getCustomizedLable();
      this.resetManageLabel();
      this.getFieldOrderData();
    });
  }

  showSuccessAlert(message) {
    this.popupService.showSuccess({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }

  printRules() {
    window.print();
  }

  restrictNumber(event: any) {
    const pattern = FormsConstant.addEditComponentRegExpression.number;
    const inputChar = String.fromCharCode(event.charCode);
    if (!pattern.test(inputChar)) {
      event.preventDefault();
    }
  }

  syncFieldWithActionRTFField() {
    const fieldOrderRule = {
      'rtfName': this.rtfName,
      'formId': this._formId,
      'stateCode': this.stateCode
    };
    this.fieldOrderService.updateFieldOrderRule(fieldOrderRule).subscribe((res) => {
      const message = Constants.fieldOrderMaintenance.sync_rtfactionfield_updated;
      this.showSuccessAlert(message);
      this.getFieldOrderData();
    });
  }

  openDisplayGroup(fieldOrderData) {
    if (fieldOrderData) {
      this.showYellow = fieldOrderData.fieldName;
      this.formsUtilityService.scrollToTop();
      this.isDisplayGroupAccordian = true;
      this.isDisplayGroupExpanded = true;
      this.selectedfieldName = fieldOrderData?.fieldName;
      this.selectedDisplayGroup = fieldOrderData?.displayGroup;
      this.customizedLabel = fieldOrderData?.customizedLabel;
      this.modifiedDisplayGroupData = this.formsUtilityService.getModifiedDisplayGroupData(
        this.displayGroupData, this.selectedDisplayGroup);
    }
  }

  generateDisplayGroup(displayGroupNumber) {
    return this.formsUtilityService.getGenerateDisplayGroupName(this.displayGroupData, displayGroupNumber);
  }

  saveGroup() {
    const updateGroup = {
      formId: Number(this._formId),
      rtfName: this.rtfName,
      fieldName: this.selectedfieldName,
      stateCode: this.stateCode,
      displayGroup: Number(this.changeDisplayGroup)
    };
    this.fieldOrderService.updateDisplayGroup(updateGroup).subscribe((res) => {
      this.getFieldOrderData();
      this.collapseDGAccordianPanel();
    });
  }

  resetGroup() {
    this.changeDisplayGroup = null;
  }

  getResetGroupFlag() {
    return this.changeDisplayGroup === null;
  }

  isManualDisplayGroupExpanded() {
    this.isDisplayGroupExpanded = !this.isDisplayGroupExpanded;
  }

  collapseDGAccordianPanel() {
    setTimeout(() => { this.isDisplayGroupExpanded = false; }, 100);
    this.changeDisplayGroup = null;
    this.isDisplayGroupAccordian = false;
    this.showYellow = '';
  }

  onPaste(ev, fieldname) {
    const value = ev.target.value;
    if (Number(value)) {
      return true;
    } else {
      if (fieldname === 'fieldOrder') {
        this.fieldOrderInputValue = '';
      } else {
        this.maxLengthInputValue = '';
      }
    }
    return false;
  }

  isPolicyOrPremium(fieldOrderData) {
    return (fieldOrderData.displayGroup >= Constants.displayGroupRange.min &&
      fieldOrderData.displayGroup <= Constants.displayGroupRange.max) ||
      (fieldOrderData.displayGroup === Constants.FieldMasterMaintenance.displayGroup[2].code) ? true : false;
  }
}
