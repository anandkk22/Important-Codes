import { Injectable } from '@angular/core';

@Injectable()
export class FormStatusUtilityService {

  constructor() { }

  disableCloseButton(isValidateClicked, isValidateDataAvailable, isFormLoadClicked, isLoadFormDataAvailable) {

    let disableCloseButton = false;

    if (isValidateClicked && !isValidateDataAvailable) {
      disableCloseButton = true;
    }
    else if (isFormLoadClicked && !isLoadFormDataAvailable) {
      disableCloseButton = true;
    }
    else {
      disableCloseButton = false;
    }

    return disableCloseButton;
  }
}
