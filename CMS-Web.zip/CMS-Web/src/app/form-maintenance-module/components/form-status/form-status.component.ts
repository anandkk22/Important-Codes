import { Component, OnInit, Input, AfterViewInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { SpinnerService } from '@wk/nils-core';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { FormsService } from 'app/form-maintenance-module/services/forms.service';
import { PopupService } from '@wk/nils-core';
import { take } from 'rxjs/operators';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
import { FormStatusUtilityService } from './form-status-utility.service';
@Component({
  selector: 'app-form-status',
  templateUrl: './form-status.component.html',
  styleUrls: ['./form-status.component.scss'],
  providers: [FormStatusUtilityService]
})
export class FormStatusComponent implements OnInit, AfterViewInit {

  @Input() allStatus;
  @Input() formType;
  @Input() formData;
  @Input() previousStatus;
  @Input() stateCode;
  @Input() stateName;
  selectedStatus;
  formFile = FormsConstant.filetype.formFile;
  helpFile = FormsConstant.filetype.helpFile;
  statusModel = false;
  validateModel = false;
  pdfFormName: any;
  copyTypes = FormsConstant.copyTypes;
  copyType = FormsConstant.copyTypes[0];
  validatedData: any;
  isValidateClicked = false;
  validationMessage: any;
  isFormValid = false;
  showRtfErrors = false;
  showInvalidErrors = false;
  rtfErrors: any;
  invalidErrors: any;
  isApiError = false;
  apiErrorMessage: any;
  isValidateDataAvailable = false;
  payload: any;
  isFormLoadClicked = false;
  uniformNo: any;
  formPageCount: any;
  isLoadFormDataAvailable = false;
  loadFormData: any;
  loadFormMessage: any;
  showNewFields = false;
  showMissingFields = false;
  newFields: any;
  missingFields: any;
  isLoadApiError = false;
  loadApiErrorMessage: any;
  disableRadio = false;
  formLoadSuccess = false;
  showFormLoadSuccessMessage = false;

  constructor(private activeModal: NgbActiveModal,
    private formsService: FormsService,
    private translate: TranslateService,
    private formsUtilityService: FormsUtilityService,
    private spinnerService: SpinnerService,
    private popupService: PopupService,
    private formStatusUtilityService: FormStatusUtilityService) { }

  ngOnInit(): void {
    const addedClickable = this.formsUtilityService.addingClickable(this.allStatus);
    this.allStatus = this.formsUtilityService.enablePW(addedClickable, this.previousStatus);

    if (this.formData.custPublished) {
      this.allStatus = this.formsUtilityService.enableFormStatusForSubsequentPublish(addedClickable);
    }

    this.selectedStatus = this.previousStatus;
    this.statusModel = true;
    if (this.formData) {
      this.pdfFormName = this.formData.formFile.split('.')[0];
    }
  }

  ngAfterViewInit(): void {
    if (this.previousStatus) {
      const stateKey = this.previousStatus === FormsConstant.filestatus.PW ?
        FormsConstant.filestatus.LCUST : this.previousStatus;
      document.getElementById(stateKey).scrollIntoView({
        behavior: 'smooth'
      });
    }
  }

  closeModal() {
    this.statusModel = false;
    this.validateModel = false;
    if (this.formLoadSuccess) {
      this.changeStatus();
    } else {
      this.activeModal.close();
    }
  }

  setStatus(status) {
    if (status.key === FormsConstant.filestatus.PAWEB &&
        this.formType === FormsConstant.filetype.formFile &&
        this.previousStatus !==  FormsConstant.filestatus.PL &&
        !this.formData.custPublished) {
          this.popupService.showAlert({
            title: this.translate.instant('MESSAGES.CONFIRMATION.ALERT'),
            message: this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_LOAD_PRIOR_PUBLISHING'),
            positiveLabel: this.translate.instant('BUTTON.OK'),
            negativeLabel: '',
          });
    } else if (status.key === FormsConstant.filestatus.PAWEB &&
      this.formType === FormsConstant.filetype.helpFile &&
      this.previousStatus !==  FormsConstant.filestatus.DY &&
      !this.formData.custPublished) {
        this.popupService.showAlert({
          title: this.translate.instant('MESSAGES.CONFIRMATION.ALERT'),
          message: this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.PUBLISHING_PRIOR_PUBLISH'),
          positiveLabel: this.translate.instant('BUTTON.OK'),
          negativeLabel: '',
        });
    } else if (status.clickable) {
      this.selectedStatus = status.key;
    }
  }

  confirmToSaveStatus() {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: this.translate.instant('MAINTAIN_FORMS.FORM_MAINTENANCE.ARE_YOU_CHANGE_STATUS'),
      positiveLabel: this.translate.instant('BUTTON.YES'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.saveStatus();
      }
    });
  }

  saveStatus() {
    if (this.selectedStatus === FormsConstant.filestatus.PL) {
      this.checkPDFLoad();
    } else if (this.selectedStatus === FormsConstant.filestatus.PAWEB) {
      this.validatePAWEBStatus();
    } else {
      this.toSaveStatus();
    }
  }

  checkPDFLoad() {
    if (this.formData.formFile === null || this.formData.formFile === FormsConstant.compareValue.textNull) {
      this.showAlert(this.translate.instant('MAINTAIN_FORMS.FORM_MAINTENANCE.PLEASE_UPLOAD_FILE'));
    } else {
      this.statusModel = false;
      this.validateModel = true;
    }
  }

  validatePAWEBStatus() {
    switch (this.formType) {
      case FormsConstant.filetype.formFile:
        if (this.formData.formFileFound) {
          this.toSaveStatus();
        } else {
          this.showAlert(FormsConstant.validate.formFileValidation);
        }
        break;
      case FormsConstant.filetype.helpFile:
        if (this.formData.helpFileFound) {
          this.toSaveStatus();
        } else {
          this.showAlert(FormsConstant.validate.helpFileValidation);
        }
        break;
    }
  }

  showAlert(message) {
    this.popupService.showAlert({
      title: this.translate.instant('MESSAGES.CONFIRMATION.ALERT'),
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
    this.activeModal.close();
  }

  toSaveStatus() {
    switch (this.formType) {
      case FormsConstant.filetype.formFile:
        this.saveFormFileStatus();
        break;
      case FormsConstant.filetype.helpFile:
        this.saveHelpFileStatus();
        break;
    }
  }

  saveFormFileStatus() {
    this.formsService.changeFormFileStatus(this.formData.formId, this.selectedStatus, this.stateCode).subscribe((response: any) => {
        this.formStatusEmail();
    });
  }

  saveHelpFileStatus() {
    this.formsService.changeHelpFileStatus(this.formData.formId, this.selectedStatus, this.stateCode).subscribe((response: any) => {
        this.formStatusEmail();
    });
  }

  formStatusEmail() {
    const needEmail = this.formsUtilityService.isNeedEmail(this.selectedStatus);
    const uniformNo = this.formData.uniformNo;
    const fileName = this.formType === FormsConstant.filetype.formFile ? this.formData.formFile : this.formData.helpFile;
    const fromStatusName = this.formsUtilityService.getFromStatusName(this.allStatus, this.previousStatus);
    const toStatusName = this.formsUtilityService.getFromStatusName(this.allStatus, this.selectedStatus);
    this.statusModel = false;
    this.validateModel = false;
    this.popupService.showSuccess({
      title: '',
      message: (this.formType === FormsConstant.filetype.formFile ?
      this.translate.instant('MAINTAIN_FORMS.FORM_MAINTENANCE.STATUS_OF_THE') :
      this.translate.instant('MAINTAIN_FORMS.FORM_MAINTENANCE.STATUS_OF_THE_HELP'))
      + uniformNo +
      this.translate.instant('MAINTAIN_FORMS.FORM_MAINTENANCE.CHANGED_FROM') + fromStatusName +
      this.translate.instant('MAINTAIN_FORMS.FORM_MAINTENANCE.TO') + toStatusName +
      this.translate.instant('MAINTAIN_FORMS.FORM_MAINTENANCE.SUCCESSFULLY'),
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
    if (needEmail) {
      this.formsService.formStatusEmail(this.selectedStatus, this.formType).subscribe((response: any) => {
        if (response) {
          const url = this.formsService.getEmailUrl(response, this.stateCode, fileName);
          document.location.href = url;
        }
      });
    }

    let returnFormsData = {
      formStatus: this.selectedStatus,
      formId: this.formData.formId,
      formType: this.formType
    };

    returnFormsData = this.formsUtilityService
    .getFormHelpArchiveStatus(returnFormsData, this.selectedStatus, this.previousStatus, this.formType);

    this.activeModal.close(returnFormsData);
  }

  validateForm() {
    this.isValidateClicked = true;
    this.formLoadSuccess = false;
    this.disableRadio = true;
    if (this.formData) {
      this.uniformNo = this.formData.uniformNo;
      this.payload = {
        'copyType': this.copyTypes.indexOf(this.copyType),
        'stateCode': this.stateCode,
        'pdfFormName': this.pdfFormName.concat('.pdf')
      };
      this.formsService.validateFormRules(this.payload).subscribe(response => {
        if (response && response.body && response.status === 200) {
          this.isValidateDataAvailable = true;
          this.validatedData = response.body;
          this.validationMessage = this.validatedData.message;
          this.formPageCount = this.validatedData.pageCount;
          this.isFormValid = this.validatedData.isValid;
          if (Object.keys(this.validatedData.fieldMasterErrors).length === 0 &&
              Object.keys(this.validatedData.fieldRuleErrors).length !== 0) {
            this.showRtfErrors = true;
            this.rtfErrors = this.validatedData.fieldRuleErrors;
          }
          else if (Object.keys(this.validatedData.fieldMasterErrors).length !== 0) {
            this.showInvalidErrors = true;
            this.invalidErrors = this.validatedData.fieldMasterErrors;
          }
          if (this.copyType === this.copyTypes[2]) {
            this.formLoadSuccess = true;
          }
        }
      }, (error) => {
        this.isValidateDataAvailable = true;
        this.isApiError = true;
        this.apiErrorMessage = error.error.Message;
        this.spinnerService.stop();
      });
    }
  }

  formLoad() {
    this.formLoadSuccess = false;
    this.isValidateClicked = false;
    this.isFormLoadClicked = true;

    this.formsService.loadFormRules(this.payload).subscribe((res: any) => {
      if (res && res.body && res.status === 200) {
        this.isLoadFormDataAvailable = true;
        this.loadFormData = res.body;
        this.loadFormMessage = this.loadFormData.message;
        this.formLoadSuccess = true;
        this.showFormLoadSuccessMessage = true;

        if (this.loadFormData.newFields.length !== 0) {
            this.showNewFields = true;
            this.newFields = this.loadFormData.newFields;
        }

        else if (this.loadFormData.missingRuleFields.length !== 0) {
            this.showMissingFields = true;
            this.missingFields = this.loadFormData.missingRuleFields;
        }
      }
    }, (error) => {
      this.isLoadFormDataAvailable = true;
      this.isLoadApiError = true;
      this.loadApiErrorMessage = error.error.Message;
      this.spinnerService.stop();
    });
  }

  changeStatus() {
    let returnFormsData = {
      formStatus: this.selectedStatus,
      formId: this.formData.formId,
      formType: this.formType
    };

    returnFormsData = this.formsUtilityService
    .getFormHelpArchiveStatus(returnFormsData, this.selectedStatus, this.previousStatus, this.formType);

    this.activeModal.close(returnFormsData);
  }

  disableClose() {

    return this.formStatusUtilityService.disableCloseButton(this.isValidateClicked,
      this.isValidateDataAvailable, this.isFormLoadClicked, this.isLoadFormDataAvailable);
  }

}
