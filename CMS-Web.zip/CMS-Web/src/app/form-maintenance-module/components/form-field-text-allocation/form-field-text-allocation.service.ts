

import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';

@Injectable()
export class FormFieldTextAllocationService {
    constructor(private http: HttpClient) { }

  getFormTextAllocationData(request) {
     return this.http.get(`${FormsConstant.webApis.getFormTextAllocation.replace('{formId}', request.formId)}`
     + '?rtfName=' + request.rtfName);
   }
  getWizardFieldData(request) {
    return this.http.get(`${FormsConstant.webApis.getWizardFieldData}` + '?FormId=' + request.formId
     + '&RTFName=' + request.rtfName);
  }
  getFieldNameData(request) {
    return this.http.get(`${FormsConstant.webApis.getFieldNameData}` +
     '?FormId=' + request.formId  + '&RTFName=' + request.rtfName + '&wizardField=' + request.wizardField);
  }
  addFieldData(requestData) {
    return this.http.post(`${FormsConstant.webApis.addUpdateFormTextAllocation}`, requestData );
  }
  updateFieldData(requestData) {
    return this.http.put(`${FormsConstant.webApis.addUpdateFormTextAllocation}`, requestData );
  }
  updateStatus(allocationId) {
    return this.http.put(`${FormsConstant.webApis.updateStatusFormTextAllocation}`, allocationId);
  }
  deletRecord(allocationId) {
    return this.http.delete(`${FormsConstant.webApis.deleteRecord.replace('{allocationId}', allocationId)}`, );
  }
  updateLive(rtfName) {
    return this.http.put(`${FormsConstant.webApis.updateLiveFormTextAllocation.replace('{rtfName}', rtfName)}`, '');
  }
}
