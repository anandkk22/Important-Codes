import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Constants } from '@global/infrastructure/constants';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { ConfigurationsConstant } from 'app/configurations-module/infrastructure/configurations.constant';
import { FormTextAllocationData } from 'app/form-maintenance-module/infrastructure/models/forms.model';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
import { FormFieldTextAllocationService } from './form-field-text-allocation.service';
import '@wk/components/dist/accordion';
import { AppConstants } from 'app/app.constants';
import { NgSelectComponent } from '@ng-select/ng-select';
import { take } from 'rxjs/operators';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';

@Component({
  selector: 'app-form-field-text-allocation',
  templateUrl: './form-field-text-allocation.component.html',
  styleUrls: ['./form-field-text-allocation.component.scss'],
  providers: [FormFieldTextAllocationService]
})
export class FormFieldTextAllocationComponent implements OnInit {
  @ViewChild('selecter') ngselect: NgSelectComponent;
  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  formID: number;
  isExpanded = false;
  isEditRow = false;
  textAllocForm;
  isDataAvailable = false;
  rtfName: string;
  isPaginationRequired = false;
  searchKeyword;
  masterData;
  placeholder = Constants.textAllocationPlaceHolder;
  wizardData = [];
  fieldData = [];
  disableFieldData = true;
  isSearched = false;
  fieldObj: FormTextAllocationData = {};
  recordStatusData = [];
  responseData = [];
  recordStatusFlag = false;
  formData;
  stateCode;
  uniformNo;
  isNoRecordFound = false;
  showYellow: any;
  isNoSearchRecordFound = false;
  isFormPublished;
  selectedWizard;
  formStatus: string;
  formsList = {
    formID: '',
    rtfName: '',
    uniformNo: '',
    stateCode: '',
    edit: 'false'
  };
  selectedField ;
  enteredData = '';
  constructor(private fb: FormBuilder,
    private formsUtilityService: FormsUtilityService,
    private formFieldTextAllocationService: FormFieldTextAllocationService,
    private spinnerService: SpinnerService,
    private translate: TranslateService,
    private popupService: PopupService,
    private activatedRoute: ActivatedRoute ) {
    }
  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.params) {
        const paramData = this.formsUtilityService.getDecodedParamData(params.params);
        if (Object.keys(paramData).length !== 0) {
          this.formsList.formID = paramData[FormsConstant.addEditFormControls.formId];
          this.formsList.stateCode = paramData[FormsConstant.notesUrl.stateCode];
          this.formsList.uniformNo = paramData[FormsConstant.notesUrl.uniformno];
          this.isFormPublished = this.formsUtilityService.isFormPublished(paramData[FormsConstant.addEditFormControls.awebPublished],
            paramData[FormsConstant.addEditFormControls.wkfsPublished], paramData[FormsConstant.addEditFormControls.custPublished]);
          this.formsList.rtfName = paramData['formFile'];
        }
      }
    });

    this.initForm();
    this.getData();
    this.getWizardData();
  }
  formInIt() {
    this.textAllocForm = this.fb.group({
      rtfName: [this.formsList.rtfName],
      wizardField: [],
      fieldName: [],
      fieldLength: [],
      recordActive: [true]
    });
  }
  initForm() {
   this.formInIt();
    this.disableFieldData = true;
    this.showYellow = '';
    this.fieldData = [];
    this.isEditRow = false;
    this.isExpanded = false;
    this.selectedWizard = null;
    this.selectedField = null;
    this.formsUtilityService.scrollToTop();
  }

  createRequest() {
    const request  = {
      'rtfName': this.formsList.rtfName,
      'formId': this.formsList.formID
    };
    return request;
  }
  getData() {
    this.formFieldTextAllocationService.getFormTextAllocationData(this.createRequest())
    .subscribe((res: []) => {
      if (res && res.length > 0) {
        this.masterData = res;
        this.responseData = this.masterData;
        this.isPaginationRequired = this.masterData.length > 200 ? true : false;
        this.isNoRecordFound = false;
        this.isDataAvailable = true;
      } else {
        this.isNoRecordFound = true;
      }
    });
  }
  getWizardData() {
    this.formFieldTextAllocationService.getWizardFieldData(this.createRequest())
    .subscribe((res: any) => {
      if (res) {
        this.wizardData = res;
        this.isDataAvailable = true;
      }
    });
  }
  getSelectedWizard(wizard) {
    if (wizard) {
      this.disableFieldData = false;
      this.textAllocForm.get(FormsConstant.formTextAllocation.fieldName).setValue([]);
      this.getFieldNameData(wizard);
    }
  }
  getFieldNameData(wizard) {
    const request  = {...this.createRequest(), 'wizardField' : wizard};
    this.formFieldTextAllocationService.getFieldNameData(request)
    .subscribe((res: any) => {
      if (res && res.length > 0) {
        this.fieldData = res;
        this.isDataAvailable = true;
      }
    });
  }
  sortAscending(header: any) {
    this.masterData = this.formsUtilityService.sortAscending(header, this.masterData);
    }
  sortDescending(header: any) {
      this.masterData = this.formsUtilityService.sortDescending(header, this.masterData);
  }
  numberRegex(event) {
    const inp = String.fromCharCode(event.keyCode);
    const regEx = Constants.FieldMasterMaintenance.numberRegex;
    if (regEx.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }
  onlyNumber(): boolean {
    if (Number(this.enteredData) && Number(this.enteredData) > 0) {
      return true;
    } else {
      this.enteredData = '';
    }
    return false;
  }
  activityMethod(action, form?) {
    form.value.fieldLength = Number(form.value.fieldLength);
    switch (action) {
      case Constants.FieldMasterMaintenance.add: {
          /* Commented API integration for now DO NOT DELETE*/
        this.formFieldTextAllocationService.addFieldData(form.value)
        .subscribe((res) => {
            this.spinnerService.stop();
            const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_ADDED_SUCCESS');
            this.showSuccessAlert(message);
            this.isDataAvailable = false;
            this.initForm();
            this.getData();
        },
        async (error) => {
          const message = error.error.Message;
          this.formsUtilityService.showAlert(message);
          this.spinnerService.stop();
        });
      }
      break;
      case Constants.FieldMasterMaintenance.update: {
        const request = {...form.value, 'allocationId': this.fieldObj.allocationId};
          /* Commented API integration for now DO NOT DELETE*/
        this.formFieldTextAllocationService.updateFieldData(request)
          .subscribe(() => {
            this.spinnerService.stop();
            const  message = this.translate.instant('MESSAGES.CONFIRMATION.RECORD_UPDATED_SUCCESS');
            this.showSuccessAlert(message);
            this.isEditRow = false;
            this.isDataAvailable = false;
            this.initForm();
            this.getData();
          });
      }
      break;
    case Constants.FieldMasterMaintenance.delete: {
       /* Commented API integration for now DO NOT DELETE*/
     /*  this.formFieldTextAllocationService.deletRecord(form.allocationId)
        .subscribe(() => {
          this.spinnerService.stop();
          const  message =  this.translate.instant('MESSAGES.CONFIRMATION.RECORD_DELETED');
          this.showSuccessAlert(message);
          this.isEditRow = false;
          this.isDataAvailable = false;
          this.initForm();
          this.getData();
        },
         async (error) => {
          const message = error.error.Message;
          this.formsUtilityService.showAlert(message);
          this.spinnerService.stop();
        }); */

  }
}
  }
  isManualExpanded() {
    this.formInIt();
    this.isExpanded = !this.isExpanded;
  }
  cancelClick() {
    setTimeout(() => { this.isExpanded = false; }, 100);
    this.initForm();
  }
  expandForm(event) {
    event.stopPropagation();
  }
  search() {
    this.isSearched = this.showClearIcon();
    this.searchKeyword = this.searchKeyword.trim();
    this.masterData = this.responseData.filter(x => (
      x.wizardField?.toLowerCase().includes(this.searchKeyword.toLowerCase()) ||
      x.fieldName?.toLowerCase().includes(this.searchKeyword.toLowerCase())
    ));
    if (!this.masterData.length) {
      this.isNoSearchRecordFound =  true;
    } else {
      this.isNoSearchRecordFound =  false;
    }
  }

  showClearIcon() {
    return (this.searchKeyword && this.searchKeyword.trim());
  }
  resetSearch() {
    this.isSearched = false;
    this.searchKeyword = null;
    this.isNoSearchRecordFound = false;
    this.masterData = this.responseData;
  }
  columnClicked(rowData) {
    this.isEditRow = true;
    this.showYellow = rowData?.allocationId;
    this.getSelectedRow(rowData);
  }

  getBackYellowClass(row) {
    return row?.allocationId === this.showYellow ? ConfigurationsConstant.backYellowClass : '';
  }
  isUpdateStatusButtonEnable() {
    if (!this.isNoRecordFound) {
      if (this.recordStatusData.length > 0) {
        this.recordStatusFlag = false;
      } else {
        this.recordStatusFlag = true;
      }
    } else {
      this.recordStatusFlag = true;
    }
    return this.recordStatusFlag;
  }

  updateStatus() {
     /* Commented API integration for now DO NOT DELETE*/
    this.formFieldTextAllocationService.updateStatus(this.recordStatusData)
    .subscribe((res) => {
      this.isDataAvailable = false;
      const message = this.translate.instant('MESSAGES.CONFIRMATION.RECORDS_UPDATED_SUCCESS');
      this.showSuccessAlert(message);
      this.getData();
    });
    this.initForm();
    this.recordStatusFlag = false;
    this.recordStatusData = [];
  }
  onRecordStatusClick(record, row) {
    const updateStatusData = {
      allocationId: row.allocationId,
      status: row.recordActive,
      rtfName: this.formsList.rtfName
    };
    updateStatusData.status = record.target.checked;
    const recordFound = this.recordStatusData.findIndex(data => data.allocationId === updateStatusData.allocationId);
    if (recordFound < 0) {
      this.recordStatusData.push(updateStatusData);
    } else {
      if (this.recordStatusData.length > 0) {
        this.recordStatusData.splice(recordFound, 1);
      }
    }
  }
  getSelectedRow(row) {
    this.disableFieldData = true;
    this.fieldObj.fieldName = row?.fieldName;
    this.fieldObj.wizardField = row?.wizardField;
    this.fieldObj.fieldLength = row?.fieldLength;
    this.fieldObj.recordActive = row?.recordActive;
    this.fieldObj.rtfname = row?.rtfname;
    this.fieldObj.allocationId = row?.allocationId;
    this.resetClick();

    this.isExpanded = true;
    this.formsUtilityService.scrollToTop();
  }
  disableButton(action) {
    switch (action) {
      case Constants.switchCase.add: {
        return (!((this.textAllocForm.get(FormsConstant.formTextAllocation.fieldName).value !== this.fieldObj?.fieldName) ||
        (this.textAllocForm.get(FormsConstant.formTextAllocation.wizardField).value !== this.fieldObj?.wizardField) ||
        (Number(this.textAllocForm.get(FormsConstant.formTextAllocation.fieldLength).value) !== this.fieldObj?.fieldLength) ||
        (this.textAllocForm.get(FormsConstant.formTextAllocation.rtfName).value !== this.fieldObj?.rtfname)) ||
         !this.textAllocForm.valid);
      }
      case Constants.switchCase.update: {
        return (!((this.textAllocForm.get(FormsConstant.formTextAllocation.fieldName).value !== this.fieldObj?.fieldName) ||
        (this.textAllocForm.get(FormsConstant.formTextAllocation.wizardField).value !== this.fieldObj?.wizardField) ||
        (Number(this.textAllocForm.get(FormsConstant.formTextAllocation.fieldLength).value) !== this.fieldObj?.fieldLength) ||
        (this.textAllocForm.get(FormsConstant.formTextAllocation.rtfName).value !== this.fieldObj?.rtfname) ||
        (this.textAllocForm.get(FormsConstant.formTextAllocation.recordActive).value !== this.fieldObj?.recordActive)) ||
         !this.textAllocForm.valid);
      }
      case Constants.switchCase.reset: {
        return (!((this.textAllocForm.get(FormsConstant.formTextAllocation.fieldName).value !== this.fieldObj?.fieldName) ||
        (this.textAllocForm.get(FormsConstant.formTextAllocation.wizardField).value !== this.fieldObj?.wizardField) ||
        (Number(this.textAllocForm.get(FormsConstant.formTextAllocation.fieldLength).value) !== this.fieldObj?.fieldLength) ||
        (this.textAllocForm.get(FormsConstant.formTextAllocation.rtfName).value !== this.fieldObj?.rtfname) ||
        (this.textAllocForm.get(FormsConstant.formTextAllocation.recordActive).value !== this.fieldObj?.recordActive)));
       }
    }

  }
  resetClick() {
    this.fieldData = [];
    this.textAllocForm.get(FormsConstant.formTextAllocation.fieldName).setValue(this.fieldObj.fieldName);
    this.textAllocForm.get(FormsConstant.formTextAllocation.wizardField).setValue(this.fieldObj.wizardField);
    this.textAllocForm.get(FormsConstant.formTextAllocation.fieldLength).setValue(this.fieldObj.fieldLength);
    this.textAllocForm.get(FormsConstant.formTextAllocation.rtfName).setValue(this.fieldObj.rtfname);
    this.textAllocForm.get(FormsConstant.formTextAllocation.recordActive).setValue(this.fieldObj.recordActive);
    this.fieldData.push(this.fieldObj.fieldName);
  }
  showSuccessAlert(message) {
    this.popupService.showSuccess({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }
  updateLive() {
        this.popupService.showConfirmation({
            title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
            message: this.translate.instant('MAINTAIN_FORMS.FORM_FIELD_TEXT_ALLOCATION_MAINTAINENCE.UPDATE_LIVE_CONFIRMATION',
            {stateCode: this.formsList.stateCode, rtfName: this.formsList.rtfName}),
            positiveLabel: this.translate.instant('BUTTON.OK'),
            negativeLabel: this.translate.instant('BUTTON.CANCEL'),
          }).pipe(take(1)).subscribe(res => {
            if (res) {
                this.formFieldTextAllocationService.updateLive( this.formsList.rtfName).subscribe(() => {
                    const alertMessage = this.translate.
                    instant('MAINTAIN_FORMS.FORM_FIELD_TEXT_ALLOCATION_MAINTAINENCE.UPDATE_LIVE_SUCCESS',
                    {stateCode: this.formsList.stateCode, rtfName: this.formsList.rtfName});
                    this.formsUtilityService.showSuccessAlert(alertMessage);
                });
            }
          });

}
}

