import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { FormsService } from 'app/form-maintenance-module/services/forms.service';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { take } from 'rxjs/operators';
import { SharedDataService } from '@global';

@Component({
  selector: 'app-notes',
  templateUrl: './notes.component.html',
  styleUrls: ['./notes.component.scss']
})
export class NotesComponent implements OnInit {
  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  baseForm: string;
  stateCode: string;
  formId;
  allNotes;
  notesForm;
  formNoteHead = FormsConstant.notes.addNote;
  addHead = FormsConstant.notes.addNote;
  editHead = FormsConstant.notes.editNote;
  charactersLeft = FormsConstant.notes.charactersLeft;
  addForm = true;
  editNoteOldText = null;
  showYellow = null;
  expanded = false;
  AllEditions;
  selectedUniformNumber;
  editions;
  noteId = null;
  accountNo = null;
  noteTextStatus = false;
  uniformno;
  allNotesTotal;

  constructor(
    private activatedRoute: ActivatedRoute,
    private formsService: FormsService,
    private fb: FormBuilder,
    private translate: TranslateService,
    private spinnerService: SpinnerService,
    private popupService: PopupService,
    private formsUtilityService: FormsUtilityService,
    private sharedDataService: SharedDataService,
    ) {
      this.notesForm = this.fb.group({
        noteText: ['', [Validators.required]]
      });
     }

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.params) {
        const paramData = this.formsUtilityService.getDecodedParamData(params.params);
        if (Object.keys(paramData).length !== 0) {
          this.formId = Number(paramData[FormsConstant.addEditFormControls.formId]);
          this.stateCode = paramData[FormsConstant.notesUrl.stateCode];
          this.uniformno = paramData[FormsConstant.notesUrl.uniformno];
          this.baseForm =  paramData[FormsConstant.notesUrl.baseForm];
        }
      }
    });
    this.getuserId();

    this.getAllTheNotes();
    this.headingShow(this.addForm);
  }

  getuserId() {
    const userInfo: any = this.sharedDataService.getUserInfo();
    this.accountNo = userInfo.sub;
  }

  headingShow(addForm) {
    this.formNoteHead = addForm ? this.addHead : this.editHead;
  }

  getAllTheNotes() {
    this.formsService.getAllNotes(this.baseForm, this.stateCode).subscribe(response => {
      this.allNotesTotal = response;
      this.allNotes = this.formsUtilityService.getModifiedNotes(response, this.uniformno);
      this.AllEditions = this.formsUtilityService.getModifiedNotesHeading(this.allNotes, this.formId);
      this.editions = this.formsUtilityService.addGroupName(this.AllEditions, FormsConstant.notes.allEditions);
      this.selectedUniformNumber = this.editions;
    });
  }

  onChangeUniformNumber() {
    const formIds = this.formsUtilityService.getFormIds(this.selectedUniformNumber);
    const uniformNumbers = this.formsUtilityService.getUniformNumbers(this.selectedUniformNumber);
    const unifromNotes = {
      uniformNumber : uniformNumbers,
      formId : formIds
    };
    this.formsService.getNotesSelects(unifromNotes).subscribe(response => {
      const notes = this.formsUtilityService.getModifiedNotes(response, this.uniformno);
      this.allNotes = this.formsUtilityService.getFilteredNotes(notes, uniformNumbers);
    });
  }

  addNote() {
    if (this.notesForm.valid) {
      const addNotes = {
        formId : this.formId,
        noteText : this.notesForm.value.noteText
      };
      this.formsService.addFormNotes(addNotes).subscribe(response => {
        this.notesForm.reset();
        this.popupService.showSuccess({
          title: '',
          message: this.translate.instant('MAINTAIN_FORMS.NOTES.NOTE_ADDED_SUCCESS') + this.uniformno,
          positiveLabel: this.translate.instant('BUTTON.OK'),
          negativeLabel: '',
        });
        this.cancelNote();
        this.getAllTheNotes();
      }, (err: HttpErrorResponse) => {
        if (err.status === 422) {
          this.formsUtilityService.showAlert(this.translate.instant(err.error.Message));
          this.spinnerService.stop();
        }
      });
    }
  }

  resetNote() {
    if (this.addForm) {
      this.notesForm.reset();
    } else {
      this.notesForm.get(FormsConstant.notes.noteText).setValue(this.editNoteOldText);
    }
  }

  deleteNote(noteId) {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: this.translate.instant('MAINTAIN_FORMS.NOTES.DELETE_NOTE_CONFIRMATION') + this.uniformno + FormsConstant.notesValues.questin,
      positiveLabel: this.translate.instant('BUTTON.CONFIRM'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.formsService.deleteNotes(noteId).subscribe(response => {
          this.popupService.showSuccess({
            title: '',
            message: this.translate.instant('MAINTAIN_FORMS.NOTES.NOTE_DELETED'),
            positiveLabel: this.translate.instant('BUTTON.OK'),
            negativeLabel: '',
        });
          this.getAllTheNotes();
        });
      }
    });

  }

  editNote(noteId, noteText) {
    this.expanded = true;
    document.getElementById('main-scroll').scrollIntoView();
    this.showYellow = noteId;
    this.editNoteOldText = noteText;
    this.addForm = false;
    this.headingShow(this.addForm);
    this.notesForm.reset();
    this.notesForm.get(FormsConstant.notes.noteText).setValue(noteText);
    this.noteId = noteId;
  }

  updateNote() {
    this.showYellow = null;
    const updateNotes = {
      noteId : this.noteId,
      noteText : this.notesForm.value.noteText,
      status: true
    };
    this.formsService.updateNote(updateNotes).subscribe(response => {
      this.noteId = null;
      this.popupService.showSuccess({
        title: '',
        message: this.translate.instant('MAINTAIN_FORMS.NOTES.NOTE_FOR') + this.uniformno + this.translate.instant('MAINTAIN_FORMS.NOTES.NOTES_UPDATED_SUCCESS'),
        positiveLabel: this.translate.instant('BUTTON.OK'),
        negativeLabel: '',
      });
      this.cancelNote();
      this.getAllTheNotes();
    });
  }

  cancelNote() {
    this.expanded = false;
    this.showYellow = null;
    this.addForm = true;
    this.editNoteOldText = null;
    this.notesForm.reset();
    this.headingShow(this.addForm);
  }

  isManualExpanded() {
    this.expanded = !this.expanded;
  }

  expandForm(event) {
    event.stopPropagation();
  }

  changeNoteText() {
    const NoteValue = this.notesForm.value.noteText.trim().length;
    this.noteTextStatus = NoteValue > 0;
  }

  addButtonStatusCheck() {
    return this.noteTextStatus && this.notesForm.valid;
  }

  editButtonStatusCheck() {
    return this.noteTextStatus && this.notesForm.valid && this.editNoteOldText !== this.notesForm.value.noteText;
  }

  showEditDelete(noteUserId, noteFormId) {
    return this.accountNo === noteUserId && this.formId === noteFormId;
  }

  resetStatusCheck() {
    return this.editNoteOldText === this.notesForm.value.noteText;
  }
}
