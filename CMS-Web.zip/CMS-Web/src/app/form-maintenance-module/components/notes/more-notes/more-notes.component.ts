import { Component, OnInit, Input } from '@angular/core';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
@Component({
  selector: 'more-notes',
  templateUrl: './more-notes.component.html',
  styleUrls: ['./more-notes.component.scss']
})
export class MoreNotesComponent implements OnInit {
  @Input() note;
  noteText;
  isReadMore = true;
  readMore = FormsConstant.moreNotes.readMore;
  readLess = FormsConstant.moreNotes.readLess;
  constructor() { }

  ngOnInit(): void {
    this.textLength(this.isReadMore);
  }

  showText() {
     this.isReadMore = !this.isReadMore;
     this.textLength(this.isReadMore);
  }

  textLength(isReadMore) {
    if (isReadMore) {
      this.noteText = this.note.substr(FormsConstant.moreNotes.zero, FormsConstant.moreNotes.lengthOfChar);
    } else {
      this.noteText = this.note;
    }
  }

  tripleDots(isReadMore) {
    return isReadMore ? FormsConstant.moreNotes.threeDots : FormsConstant.moreNotes.empty;
  }

  checkLength(noteText) {
    return noteText.length > FormsConstant.moreNotes.lengthOfChar ? true : false;
  }

}
