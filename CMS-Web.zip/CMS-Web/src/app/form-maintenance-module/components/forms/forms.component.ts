import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { select, Store } from '@ngrx/store';
import { FormsActions } from 'app/form-maintenance-module/state/action/forms.actions';
import { FormsService } from 'app/form-maintenance-module/services/forms.service';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { forkJoin, Subscription } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormStatusComponent } from 'app/form-maintenance-module/components/form-status/form-status.component';
import { HttpErrorResponse } from '@angular/common/http';
import { MultistateHelpsheetPublishComponent } from '../multistate-helpsheet-publish/multistate-helpsheet-publish.component';
@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.scss']
})
export class FormsComponent implements OnInit, OnDestroy {
  formsModel;
  formsList = [];
  foundList = false;
  allFormFileStatus;
  allHelpFileStatus;
  formFileStatus;
  helpFileStatus;
  subscriptions: Subscription[] = [];
  storeSubscription: any;
  isLoading = true;
  formFile = FormsConstant.filetype.formFile;
  helpFile = FormsConstant.filetype.helpFile;
  cmsNavBar = false;
  constructor(
    private router: Router,
    private formStore: Store<{ reducer }>,
    private formsService: FormsService,
    private formsUtilityService: FormsUtilityService,
    private spinnerService: SpinnerService,
    private popupService: PopupService,
    private translate: TranslateService,
    private activeModal: NgbModal
  ) {
    this.storeSubscription = this.formStore.pipe(select('reducer')).subscribe((values) => {
      if (values) {
        this.formsModel = values;
      } else {
        this.router.navigateByUrl(AppConstants.uiRoutes.formMaintenance);
      }
    });
  }

  ngOnInit(): void {
    this.getInitialData();
    this.getByStatesForm();
  }

  back() {
    const params = { ...this.formsModel };
    this.formStore.dispatch(new FormsActions(params));
    this.router.navigateByUrl(AppConstants.uiRoutes.formMaintenance);
  }

  getByStatesForm() {
    this.formsList = [];
    this.foundList = false;
    this.isLoading = true;
    this.spinnerService.start();
    const formsListRequest = {
      formStatus: Number(this.formsModel.maintainFormTypes),
      stateCodes: [this.formsModel.maintainJurisdictions]
    };
    this.formsService.getByStates(formsListRequest).subscribe((res: any) => {
      this.isLoading = false;
      this.spinnerService.stop();
      if (res) {
        this.formsList = res;
        this.formsList = this.formsUtilityService.getValidEditionYear(this.formsList);
        this.foundList = true;
      }
    });
  }

  getInitialData() {
    const formStates = this.formsService.getFormAllStatus();
    const helpStates = this.formsService.getHelpAllStatus();
    this.subscriptions.push(forkJoin([formStates, helpStates]).subscribe(
      (res: any) => {
        if (res) {
          this.allFormFileStatus = this.formsUtilityService.convertStatus(res[0]);
          this.allHelpFileStatus = this.formsUtilityService.convertStatus(res[1]);
          this.formFileStatus = this.formsUtilityService.convertStatus(res[0]);
          this.helpFileStatus = this.formsUtilityService.convertStatus(res[1]);
        }
      }
    ));
  }

  getLines(commercialLines, personalLines, workersComp, miscellaneous) {
    return this.formsUtilityService.getLines(commercialLines, personalLines, workersComp, miscellaneous);
  }

  getFile(fileName, status, fileType) {
    const filePath = this.formsUtilityService.getFilePath(status, fileType);
    this.formsService.download(filePath, fileName).subscribe((response: any) => {
      if (response) {
        this.formsUtilityService.loadFile(response, fileName);
      }
    }, async (error) => {
      const message = JSON.parse(await error.error.text()).Message;
      this.formsUtilityService.showAlert(message);
      this.spinnerService.stop();
    });
  }

  getFormStatus(status) {
    return this.formsUtilityService.getStatus(this.allFormFileStatus, status);
  }

  getHelpStatus(status) {
    return this.formsUtilityService.getStatus(this.allHelpFileStatus, status);
  }

  update(formDetails) {
    if (formDetails.formStatus === FormsConstant.filestatus.AR && formDetails.helpStatus === FormsConstant.filestatus.AR) {
      this.archiveForm(formDetails);
    } else {
      const isSubsequentPublish = formDetails.custPublished;
      const isValidForm = this.formsUtilityService.validateFormDetails(formDetails, isSubsequentPublish);
      const isMultistateHelpPublish = isSubsequentPublish && formDetails.isMultiState
        && FormsConstant.formPublishStatus.includes(formDetails.helpStatus);

      if (!isValidForm.hasError) {
        if (isMultistateHelpPublish) {
          const message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.MULTISTATE_HELPSHEET_PUBLISH_CONFIRMATION');
          this.openMultiStatePublishPopup(formDetails, message, true);
        } else {
          this.publishForm(formDetails, isSubsequentPublish);
        }
      } else {
        this.formsUtilityService.showAlert(isValidForm.message);
      }
    }
  }

  formAttributes(formId) {
    const href = AppConstants.uiRoutes.formMaintenanceEdit + formId;
    window.open(href, 'formAttributes' + formId, 'left=0,top=0,width=1200,height=1000,toolbar=1,resizable=1');
    return false;
  }

  formJurisdiction(formsList) {
    const href = AppConstants.formJurisdictionURL.replace('formID', formsList.formId).replace('uniformNo', formsList.uniformNo)
      .replace('stCode', this.formsModel.maintainJurisdictions).replace('awebFlag', formsList.awebPublished)
      .replace('wkfsFlag', formsList.wkfsPublished)
      .replace('custFlag', formsList.custPublished);

    const encodedUrl = this.formsUtilityService.getEncodedUrl(href);
    window.open(encodedUrl, FormsConstant.openChildWindow.viewFormJurisdictions + formsList.formId,
      FormsConstant.openChildWindow.openChildWindow); return false;
  }

  lobActions(formsList, i) {
    const lobActionUrl = this.formsService.getLobActionUrl(formsList, this.formsModel.maintainJurisdictions, i);

    const encodedUrl = this.formsUtilityService.getEncodedUrl(lobActionUrl);
    window.open(encodedUrl, FormsConstant.openChildWindow.lobActions + formsList.formId,
      FormsConstant.openChildWindow.openChildWindow); return false;
  }



  fieldDependencyRules(formId, formFile, uniformNo, baseForm) {
    const href = AppConstants.formFieldDependencyRuleReport.replace('formID', formId).replace('filename', formFile)
    .replace('uniformno', uniformNo).replace('baseform', baseForm);

    const encodedUrl = this.formsUtilityService.getEncodedUrl(href);
    window.open(encodedUrl, 'formFieldDependencyRule' + formId, 'left=0,top=0,width=1200,height=1000,toolbar=1,resizable=1'); return false;
  }


  notes(formsList) {
    const href = AppConstants.notesURL.replace('baseform', formsList.baseForm).replace('stCode', this.formsModel.maintainJurisdictions)
      .replace('fromID', formsList.formId).replace('uniformNo', formsList.uniformNo);

    const encodedUrl = this.formsUtilityService.getEncodedUrl(href);
    window.open(encodedUrl, FormsConstant.openChildWindow.notes + formsList.formId, FormsConstant.openChildWindow.openChildWindow);
    return false;
  }
  rules(formsList, i) {
    const href = AppConstants.viewRule.replace('formID', formsList[i].formId).replace('awebFlag', formsList[i].awebPublished)
      .replace('wkfsFlag', formsList[i].wkfsPublished).replace('custFlag', formsList[i].custPublished)
      .replace('stCode', this.formsModel.maintainJurisdictions).replace('formFiles', formsList[i].formFile);

    const encodedUrl = this.formsUtilityService.getEncodedUrl(href);
    window.open(encodedUrl, FormsConstant.openChildWindow.viewRules + formsList[i].formId, FormsConstant.openChildWindow.openChildWindow);
    return false;
  }
  allocationMaintenance(formsList) {
    const hrefUrl = AppConstants.formFieldTextAllocation.replace('formID', formsList.formId).replace('awebFlag', formsList.awebPublished)
      .replace('wkfsFlag', formsList.wkfsPublished).replace('custFlag', formsList.custPublished).replace('uniformNo', formsList.uniformNo)
      .replace('stCode', this.formsModel.maintainJurisdictions).replace('formfile', formsList.formFile);

    const encodedUrl = this.formsUtilityService.getEncodedUrl(hrefUrl);
    window.open(encodedUrl, FormsConstant.openChildWindow.formTextAlocation + formsList.formId,
      FormsConstant.openChildWindow.openChildWindow);
    return false;
  }

  addEditForm(formsList, isNew) {
    if (isNew) {
      formsList.formId = 0;
      formsList.stateCode = this.formsModel.maintainJurisdictions;
      formsList.awebPublished = false;
      formsList.wkfsPublished = false;
      formsList.custPublished = false;
    } else {
      formsList.formId = formsList.formId;
      formsList.stateCode = this.formsModel.maintainJurisdictions;
    }
    const href = AppConstants.addEditForms.replace('stCode', this.formsModel.maintainJurisdictions)
      .replace('formID', formsList.formId).replace('awebFlag', formsList.awebPublished).replace('wkfsFlag', formsList.wkfsPublished)
      .replace('custFlag', formsList.custPublished);

    const encodedUrl = this.formsUtilityService.getEncodedUrl(href);
    window.open(encodedUrl, FormsConstant.openChildWindow.addEditForms + formsList.formId, FormsConstant.openChildWindow.openChildWindow);
    return false;
  }

  changeStatus(formsLists, formType) {
    const modalRef = this.activeModal.open(FormStatusComponent);
    switch (formType) {
      case FormsConstant.filetype.formFile:
        modalRef.componentInstance.allStatus = this.formFileStatus;
        modalRef.componentInstance.previousStatus = formsLists.formStatus;
        break;
      case FormsConstant.filetype.helpFile:
        modalRef.componentInstance.allStatus = this.helpFileStatus;
        modalRef.componentInstance.previousStatus = formsLists.helpStatus;
        break;
    }
    modalRef.componentInstance.formType = formType;
    modalRef.componentInstance.formData = formsLists;
    modalRef.componentInstance.stateCode = this.formsModel.maintainJurisdictions;
    modalRef.componentInstance.stateName = this.formsModel.maintainJurisdictionsName;
    modalRef.result.then((userResponse) => {
      if (userResponse) {
        this.formsListUpdate(userResponse);
      }
    });
  }

  formsListUpdate(userResponse) {
    this.formsList = this.formsUtilityService.formsListUpdate(this.formsList, userResponse);
  }

  refreshPage() {
    this.getByStatesForm();
  }

  publishForm(formDetails, isSubsequentPublish) {
    let message = '';
    const params = {
      formId: formDetails.formId,
      stateCode: this.formsModel.maintainJurisdictions
    };
    const isMultistateHelpPublish = isSubsequentPublish && formDetails.isMultiState
      && FormsConstant.formPublishStatus.includes(formDetails.helpStatus);
    this.formsService.publishForm(params).subscribe(() => {
      message = this.formsUtilityService.getFormPublishSuccessMessage(formDetails, isSubsequentPublish, isMultistateHelpPublish);
      if (isMultistateHelpPublish) {
        this.openMultiStatePublishPopup(formDetails, message, false);
      } else {
        this.formsUtilityService.showSuccessAlert(message);
      }
      this.publishUpdateStatus(formDetails);
    },
      (err: HttpErrorResponse) => {
        if (err.status === 422 || err.status === 500) {
          message = err.error.Message;
        } else {
          message = this.formsUtilityService.getFormPublishFailureMEssage(formDetails, isSubsequentPublish);
        }
        this.spinnerService.stop();
        this.formsUtilityService.showAlert(message);
      });
  }

  publishUpdateStatus(formDetails) {
    const updatedFormStatus = this.formsUtilityService.getUpdatedStatus(formDetails.formStatus);
    const updatedHelpStatus = this.formsUtilityService.getUpdatedStatus(formDetails.helpStatus);

    const returnFormsData = {
      formStatus: updatedFormStatus,
      helpStatus: updatedHelpStatus,
      formId: formDetails.formId,
      formType: FormsConstant.filetype.bothFile
    };
    this.formsListUpdate(returnFormsData);
  }

  openMultiStatePublishPopup(formDetails, message, isConfirmation) {
    const isSubsequentPublish = formDetails.custPublished;
    const modalRef = this.activeModal.open(MultistateHelpsheetPublishComponent);
    const data = {
      message: message,
      formStateList: formDetails.formStates,
      isConfirmation: isConfirmation
    };
    modalRef.componentInstance.data = data;
    modalRef.result.then((userResponse) => {
      if (userResponse) {
        this.publishForm(formDetails, isSubsequentPublish);
      }
    });
  }

  archiveForm(formDetails) {
    let message = '';
    const params = {
      formId: formDetails.formId,
      stateCode: this.formsModel.maintainJurisdictions
    };

    this.formsService.publishForm(params).subscribe(() => {
      message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_ARCHIVE_SUCCESS',
      { uniformNo: formDetails.uniformNo });
      this.formsUtilityService.showSuccessAlert(message);
      const index = this.formsList.findIndex(x => x.formId === formDetails.formId);
      if (index >= 0) {
        this.formsList[index].custPublished = false;
        this.formsList[index].wkfsPublished = false;
        this.formsList[index].awebPublished = false;
      }
    },
      (err: HttpErrorResponse) => {
        if (err.status === 422 || err.status === 500) {
          message = err.error.Message;
        } else {
          message = message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_ARCHIVE_FAIL');
        }
        this.spinnerService.stop();
        this.formsUtilityService.showAlert(message);
      });
  }

  ngOnDestroy() {
    this.storeSubscription.unsubscribe();
  }
}
