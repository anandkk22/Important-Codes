import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { PopupService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';


@Injectable()
export class ViewFormJurisdictionsService {

    constructor(private http: HttpClient,
      private popupService: PopupService,
      private translate: TranslateService) { }

    getFormJurisdictions(formId: any) {
      return this.http.get(`${FormsConstant.webApis.formJurisdictions}`.replace('{formId}', formId));
    }

    updateJurisdictions(data) {
      return this.http.post(`${FormsConstant.webApis.updateJurisdictions}`, data);
    }

    getJurisdictionCheckedData(data: any) {
      let isJurisdictionCheckboxFlag = false;
      for (let i = 0; i < data.length; i++) {
        if (!data[i].isFormState) {
          isJurisdictionCheckboxFlag = true;
          break;
        }
      }
      return isJurisdictionCheckboxFlag;
    }

  validateGridData(jurisdictionData) {
    const collectErrorData = [];
    jurisdictionData.forEach(element => {
      if (element.isFormState) {
        const policyCodesValue = element.policyCodes === null ? 0 : element.policyCodes.trim().length;
        if (!(policyCodesValue > 0 && (element.line.additionalInterest || element.line.commercial ||
          element.line.personal || element.line.workersComp))) {
          collectErrorData.push(element);
        }
      }
    });
    return collectErrorData.length > 0;
  }

  isAllCheckedRow(allData) {
    const collectSelectData = [];
    allData.forEach(element => {
      if (element.isFormState) {
          collectSelectData.push(element);
      }
    });
    return allData.length === collectSelectData.length;
  }

  isAtleastOneChecked(allRowData) {
    const collectSelectData = [];
    allRowData.forEach(element => {
      if (element.isFormState) {
          collectSelectData.push(element);
      }
    });
    return collectSelectData.length < allRowData.length && collectSelectData.length > 0;
  }

  allStateUnChecked(jurisdiction) {
    const unCheckData = [];
    jurisdiction.forEach(element => {
      if (!element.isPublishedState) {
        element.isFormState = element.isPublishedState;
        element.line.additionalInterest = false;
        element.line.commercial = false;
        element.line.personal = false;
        element.line.workersComp = false;
        element.policyCodes = null;
      }
      element.blockCertificateOfMailing = false;
      element.blockMailLogSetting = false;
      unCheckData.push(element);
    });
    return unCheckData;
  }

  allStateChecked(jurisdiction) {
    const checkData = [];
    jurisdiction.forEach(element => {
      element.isFormState = true;
      checkData.push(element);
    });
    return jurisdiction;
  }

  getSelectedStatesOnly(allrowDat) {
    const selectedStates = [];
    allrowDat.forEach(element => {
      if (element.isFormState) {
        delete element.isPublishedState;
        selectedStates.push(element);
      }
    });
    return selectedStates;
  }
  updateLiveJurisdiction(formId) {
    return this.http.put(`${FormsConstant.webApis.updateLiveJurisdiction}`.replace('{formId}', formId), '');
  }
  showAlert(message) {
    this.popupService.showAlert({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }
  showSuccessAlert(message) {
    this.popupService.showSuccess({
        title: '',
        message: message,
        positiveLabel: this.translate.instant('BUTTON.OK'),
        negativeLabel: '',
    });
}
}
