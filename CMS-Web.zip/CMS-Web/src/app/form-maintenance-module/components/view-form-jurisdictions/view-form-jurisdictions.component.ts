import { Component, OnDestroy, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { ViewFormJurisdictionsService } from './view-form-jurisdictions.service';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { take } from 'rxjs/operators';
import { FormsUtilityService } from 'app/form-maintenance-module/services/forms-utility.service';
@Component({
  selector: 'app-view-form-jurisdictions',
  templateUrl: './view-form-jurisdictions.component.html',
  styleUrls: ['./view-form-jurisdictions.component.scss']
})
export class ViewFormJurisdictionsComponent implements OnInit, OnDestroy {

  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  activeSubscription: Subscription;
  activeFormID: string;
  fileName: string;
  formJurisdictionData = [];
  isFormJurisdictionDataAvailable = false;
  updateFormJurisdictionData = [];
  resetJurisdictionData = [];
  commercialLabel = FormsConstant.viewFormJurisdictions.commercialLabel;
  personalLabel = FormsConstant.viewFormJurisdictions.personalLabel;
  workersCompLabel = FormsConstant.viewFormJurisdictions.workersCompLabel;
  additionalInterestLabel = FormsConstant.viewFormJurisdictions.additionalInterestLabel;
  isAtleastOneRowSelected = true;
  uniformno;
  stateCode;
  isAllChecked = false;
  updateLiveConfirmed = false;
  noRecordFound = false;
  isFormPublished: boolean;
  notValidGrid = false;
  constructor(private viewFormJurisdictionService: ViewFormJurisdictionsService,
    private popupService: PopupService,
    private translate: TranslateService,
    private spinnerService: SpinnerService,
    private activatedRoute: ActivatedRoute,
    private formsUtilityService: FormsUtilityService) { }

  ngOnInit(): void {

    this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.params) {
        const paramData = this.formsUtilityService.getDecodedParamData(params.params);
        if (Object.keys(paramData).length !== 0) {
          this.activeFormID = (paramData[FormsConstant.notesUrl.formId]);
          this.uniformno = (paramData[FormsConstant.notesUrl.uniformno]);
          this.stateCode = (paramData[FormsConstant.notesUrl.stateCode]);
          this.isFormPublished = this.formsUtilityService.isFormPublished(paramData[FormsConstant.addEditFormControls.awebPublished],
            paramData[FormsConstant.addEditFormControls.wkfsPublished], paramData[FormsConstant.addEditFormControls.custPublished]);
        }
      }
    });
    this.getFormJurisdictions();
  }

  getFormJurisdictions() {
    this.noRecordFound = false;
    this.activeSubscription = this.viewFormJurisdictionService.getFormJurisdictions(this.activeFormID).subscribe((res: any) => {
      if (res && res.length) {
        this.formJurisdictionData = JSON.parse(JSON.stringify(res));
        this.updateFormJurisdictionData = res;
        this.noRecordFound = this.updateFormJurisdictionData.length === 0;
        this.isFormJurisdictionDataAvailable = true;
        this.isAtleastOneRowSelected = this.viewFormJurisdictionService.isAtleastOneChecked(this.updateFormJurisdictionData);
        this.isAllChecked = this.viewFormJurisdictionService.isAllCheckedRow(this.updateFormJurisdictionData);
      }
    });
  }

  onLinesColumnClick(ev: any, index: any) {
    if (ev.target.value === this.commercialLabel) {
      this.updateFormJurisdictionData[index].line.commercial = ev.target.checked;
    } else if (ev.target.value === this.personalLabel) {
      this.updateFormJurisdictionData[index].line.personal = ev.target.checked;
    } else if (ev.target.value === this.workersCompLabel) {
      this.updateFormJurisdictionData[index].line.workersComp = ev.target.checked;
    } else if (ev.target.value === this.additionalInterestLabel) {
      this.updateFormJurisdictionData[index].line.additionalInterest = ev.target.checked;
    }
    this.onLobandPolicyCodeChange(index);
  }

  onLobandPolicyCodeChange(index: any) {
    if (this.updateFormJurisdictionData[index] != null) {
      if (!this.updateFormJurisdictionData[index].line.commercial &&
        !this.updateFormJurisdictionData[index].line.personal &&
        !this.updateFormJurisdictionData[index].line.workersComp &&
        !this.updateFormJurisdictionData[index].line.additionalInterest  || this.updateFormJurisdictionData[index].policyCodes === null) {
        this.notValidGrid = this.viewFormJurisdictionService.validateGridData(this.updateFormJurisdictionData);
      }
    }
  }

  onBlockMailLogColumnClick(ev: any, index: any) {
    this.updateFormJurisdictionData[index].blockMailLogSetting = ev.target.checked;
  }

  onBlockCertificateColumnClick(ev: any, index: any) {
    this.updateFormJurisdictionData[index].blockCertificateOfMailing = ev.target.checked;
  }

  onPolicyCodeChange(ev: any, index: any) {
    this.updateFormJurisdictionData[index].policyCodes = ev.target.value.trim();
    this.onLobandPolicyCodeChange(index);
  }

  resetData() {
    const oldData = JSON.parse(JSON.stringify(this.formJurisdictionData));
    this.updateFormJurisdictionData = oldData;
    this.isAtleastOneRowSelected = this.viewFormJurisdictionService.isAtleastOneChecked(this.updateFormJurisdictionData);
    this.isAllChecked = this.viewFormJurisdictionService.isAllCheckedRow(this.updateFormJurisdictionData);
  }

  jurisdictionClick(ev: any, index: any) {
    this.updateFormJurisdictionData[index].isFormState = ev.target.checked;
    if (!this.updateFormJurisdictionData[index].isFormState) {
      this.updateFormJurisdictionData[index].blockCertificateOfMailing = false;
      this.updateFormJurisdictionData[index].blockMailLogSetting = false;
      this.updateFormJurisdictionData[index].line.additionalInterest = false;
      this.updateFormJurisdictionData[index].line.commercial = false;
      this.updateFormJurisdictionData[index].line.personal = false;
      this.updateFormJurisdictionData[index].line.workersComp = false;
      this.updateFormJurisdictionData[index].policyCodes = null;
    }
    this.isAtleastOneRowSelected = this.viewFormJurisdictionService.isAtleastOneChecked(this.updateFormJurisdictionData);
    this.isAllChecked = this.viewFormJurisdictionService.isAllCheckedRow(this.updateFormJurisdictionData);
  }

  updateData() {
    this.notValidGrid = this.viewFormJurisdictionService.validateGridData(this.updateFormJurisdictionData);
    if (!this.notValidGrid) {
      const getSelectedStates = {
        formId: this.activeFormID,
        uniformNo: this.uniformno,
        formStates: this.viewFormJurisdictionService.getSelectedStatesOnly(this.updateFormJurisdictionData)
      };
      this.viewFormJurisdictionService.updateJurisdictions(getSelectedStates).subscribe((res: any) => {
        this.getFormJurisdictions();
        if (this.updateLiveConfirmed) {
            this.updateLiveFormJurisdictions();
        } else {
          this.showUpdateMessage();
        }
      });
    } else {
      this.popupService.showAlert({
        title: this.translate.instant('MESSAGES.CONFIRMATION.ALERT'),
        message: this.translate.instant('MAINTAIN_FORMS.FORM_JURISDICTIONS.AT_LEAST_ONE_LINE'),
        positiveLabel: this.translate.instant('BUTTON.OK'),
        negativeLabel: '',
      });
    }
    return true;
  }

  showUpdateMessage() {
    this.popupService.showSuccess({
      title: '',
      message: this.translate.instant('MAINTAIN_FORMS.FORM_JURISDICTIONS.DETAILS_UPDATED') + this.uniformno + this.translate.instant('MAINTAIN_FORMS.FORM_JURISDICTIONS.SUCCESSFULLY'),
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

  checkData() {
    return JSON.stringify(this.updateFormJurisdictionData) === JSON.stringify(this.formJurisdictionData);
  }

  selectAllCheckbox() {
    if (this.isAllChecked) {
      this.updateFormJurisdictionData = this.viewFormJurisdictionService.allStateChecked(this.updateFormJurisdictionData);
    } else {
      this.updateFormJurisdictionData = this.viewFormJurisdictionService.allStateUnChecked(this.updateFormJurisdictionData);
    }
    this.isAtleastOneRowSelected = this.viewFormJurisdictionService.isAtleastOneChecked(this.updateFormJurisdictionData);
    this.isAllChecked = this.viewFormJurisdictionService.isAllCheckedRow(this.updateFormJurisdictionData);
  }

  validateLines(line, isFormState) {
    return isFormState && !line.additionalInterest && !line.commercial && !line.personal && !line.workersComp;
  }

  validatePolicyCodes(policyCodes, isFormState) {
    if (isFormState) {
      return policyCodes === null || policyCodes.length === 0;
    } else {
      return false;
    }
  }
  updateLiveJurisdiction() {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
      message: this.translate.instant('MAINTAIN_FORMS.FORM_JURISDICTIONS.UPDATE_LIVE_CONFIRMATION'),
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: this.translate.instant('BUTTON.CANCEL'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.updateLiveConfirmed = true;
        this.updateData();
      }

    });
  }
  updateLiveFormJurisdictions() {
    this.viewFormJurisdictionService.updateLiveJurisdiction(this.activeFormID).subscribe(() => {
      const alertMessage = this.translate.instant('MAINTAIN_FORMS.FORM_JURISDICTIONS.UPDATE_LIVE_SUCCESS');
      this.viewFormJurisdictionService.showSuccessAlert(alertMessage);
    });
  }

}
