import { environment } from '@env';

export class FormsConstant {
    static webApis = {
        getJurisdictions: environment.apiUrl + 'State',
        getByStates: environment.apiUrl + 'Form/GetByState',
        getForm: environment.apiUrl + 'Form',
        getHelp: environment.apiUrl + 'Help',
        changeFormFileStatus: environment.apiUrl + '{formId}/FormFileStatus/{status}?stateCode={stateCode}',
        changeHelpFileStatus: environment.apiUrl + '{formId}/HelpFileStatus/{status}?stateCode={stateCode}',
        formStatusEmail: environment.apiUrl + 'FormStatusEmail/{status}?type=',
        download: environment.commonApiUrl + 'Download?file=',
        lobExceptCPR: environment.apiUrl + 'LOB/ExceptCPR',
        lobActionMatrix: environment.apiUrl + 'Action',
        formLOBAction: environment.apiUrl + 'FormLOBAction',
        getAllNotes: environment.apiUrl + 'FormNote/{baseForm}/{stateCode}/All',
        addFormNotes: environment.apiUrl + 'FormNote',
        deleteNote: environment.apiUrl + 'FormNote/{noteId}',
        updateNote: environment.apiUrl + 'FormNote',
        getNotes: environment.apiUrl + 'FormNote/All',
        formJurisdictions: environment.apiUrl + 'FormState/{formId}',
        updateJurisdictions: environment.apiUrl + 'FormState',
        uniformNoStatus: environment.apiUrl + 'Form/UniformNoStatus?UniformNo=',
        addEditForm: environment.apiUrl + 'Form',
        deleteFormComponent: environment.apiUrl + 'FormComponent',
        addComponent: environment.apiUrl + 'FormComponent/{formId}',
        formRuleLobs: environment.apiUrl + 'FormRule/lobs',
        formRuleActions: environment.apiUrl + 'FormRule/Actions',
        formRule: environment.apiUrl + 'FormRule?FormId=',
        circumstance: environment.apiUrl + 'Circumstance',
        gotoField: environment.apiUrl + 'FormRule/formId/GotoFields',
        fieldMaster: environment.apiUrl + 'RTFActionField/',
        updateLOBActions: environment.apiUrl + 'FormLOBAction',
        viewFileList: environment.apiUrl + 'File?fileType=',
        copyRulesTo: environment.apiUrl + 'FormRule/CopyToLobs?StateCode=',
        copyRule: environment.apiUrl + 'FormRule/Copy',
        fieldOrdersMaintenance: environment.apiUrl + 'FieldOrder?RTFName=RTFNAME&FormId=formId&Statecode=stateCode',
        manageLabelAction: environment.apiUrl + 'RTFActionField/ActionCode/formId?rtfName=RTFName',
        manageLabelLob: environment.apiUrl + 'RTFActionField/LobAbbrevation/formId?rtfName=RTFName',
        manageLabelCircumstance: environment.apiUrl + 'RTFActionField/Circumstance/formId?rtfName=RTFName',
        universalLabel: environment.apiUrl + 'RTFActionField/UniversalLabel?FieldName=fieldname&RTFName=rtfName&FormId=formId&StateCode=stateCode',
        updateFieldOrder: environment.apiUrl + 'FieldOrder',
        saveFieldMaintenance: environment.apiUrl + 'RTFActionField',
        customizedLabel: environment.apiUrl + 'RTFActionField/CustomizedLabels?StateCode=stCode&FieldName=fieldname&RTFName=rtfName&FormId=formId',
        updateUniversalLabel: environment.apiUrl + 'RTFActionField/UniversalLabel',
        updateCustomizedManageLabel: environment.apiUrl + 'RTFActionField/CustomizedLabel',
        deleteCustomizedLabel: environment.apiUrl + 'RTFActionField/{rtfActionFieldId}?universalLabel={universalLabel}',
        updateLabel: environment.apiUrl + 'RTFActionField/CustomizedLabel',
        copyRulesFrom: environment.apiUrl + 'FormRule/CopyRuleForms?StateCode=',
        copyRules: environment.apiUrl + 'FormRule/CopyRules',
        deleteRule: environment.apiUrl + 'FormRules',
        bulkRuleUpdate: environment.apiUrl + 'FormRule',
        bulkRuleUpdates: environment.apiUrl + 'FormRules',
        validateForm: environment.apiUrl + 'Form/Validate',
        loadForm: environment.apiUrl + 'Form/Load',
        getFormTextAllocation: environment.apiUrl + 'FormFieldTextAllocation/{formId}',
        addUpdateFormTextAllocation: environment.apiUrl + 'FormFieldTextAllocation',
        updateStatusFormTextAllocation: environment.apiUrl + 'FormFieldTextAllocation/Statuses',
        deleteRecord: environment.apiUrl + 'FormFieldTextAllocation/{allocationId}',
        getWizardFieldData: environment.apiUrl + 'FormFieldTextAllocation/WizardFields',
        getFieldNameData: environment.apiUrl + 'FormFieldTextAllocation/FieldNames',
        updateFieldOrderRule: environment.apiUrl + 'RTFActionField/FieldOrderRule',
        syncRTFActionField: environment.apiUrl + 'RTFActionField/Sync',
        updateLiveRule: environment.apiUrl + 'RTFActionField/PublishRules',
        updateLiveComponent: environment.apiUrl + 'FormComponent/{formId}',
        updateLiveFormAttribute: environment.apiUrl + 'Form/UpdateLive',
        updateLiveJurisdiction: environment.apiUrl + 'FormState/{formId}',
        clearExistingRules: environment.apiUrl + 'RTFActionField/ClearExistingRules',
        updateLiveFormTextAllocation: environment.apiUrl + 'FormFieldTextAllocation/{rtfName}',
        publishForm: environment.apiUrl + 'Form/Publish',
        updateDisplayGroup: environment.apiUrl + 'RTFActionField/ManageDisplayGroup',
        getActionStatus: environment.apiUrl + 'RTFActionField/ActionLinkStatus?formId={formId}&stateCode={stateCode}&rtfName={rtfName}',
        formFileExists: environment.apiUrl + 'FormFileExists?filename={filename}',
        helpFileExists: environment.apiUrl + 'HelpFileExists?filename={filename}',
        pdfFileExists: environment.apiUrl + 'PdfFileExists?filename={filename}',
        fileUpload: environment.apiUrl + 'Form/UploadFile'
    };

    static formType = [
        {
            value: 0,
            name: 'All Forms'
        },
        {
            value: 1,
            name: 'In-Process'
        },
        {
            value: 2,
            name: 'Obsolete-Archived'
        }
    ];

    static viewFormJurisdictions = {
        commercialLabel: 'commercial',
        personalLabel: 'personal',
        workersCompLabel: 'workersComp',
        additionalInterestLabel: 'additionalInterest'
    };

    static lines = {
        commercialLines: ' C,',
        personalLines: ' P,',
        workersComp: ' W,',
        miscellaneous: ' A,'
    };

    static empty = '';

    static responseType = {
        blobType: 'blob'
    };

    static downloadPath = {
        authenticityStaging: 'authenticity_staging\\CNRWIP\\'
    };

    static compareString = {
        empty: '',
        na: 'NA',
        undefined: 'undefined'
    };

    static filetype = {
        formFile: 'formFile',
        helpFile: 'helpFile',
        bothFile: 'bothFile'
    };

    static statusHelpForm = {
        pw: 'PW',
        re: 'RE'
    };

    static filestatus = {
        PL: 'PL',
        PAWEB: 'PAWEB',
        PWKFS: 'PWKFS',
        PCUST: 'PCUST',
        LAWEB: 'LAWEB',
        LWKFS: 'LWKFS',
        LCUST: 'LCUST',
        DY: 'DY',
        PW: 'PW',
        AR: 'AR',
        FLP: 'FLP'
    };

    static filestatusFullForm = {
        publishedToCustomerAccounts: 'Published To Customer Accounts',
    };

    static validate = {
        formFileValidation: 'Form file does not exist. Please upload it to continue.',
        helpFileValidation: 'Help file does not exist. Please upload it to continue.'
    };

    static compareValue = {
        textNull: 'null'
    };

    static emailStatus = ['TI', 'TC', 'TN', 'TF', 'TR', 'PC', 'PN', 'PF'];

    static disableStatuses = ['PWKFS', 'PCUST', 'LAWEB', 'LCUST', 'LWKFS'];

    static modelResponse = {
        noReload: 'noReload',
        reload: 'reload',
    };

    static filePath = {
        formWithPwRe: 'CNR4\\webfill\\filtered\\',
        helpWithPwRe: 'CNR4\\',
        formHelpNotPwRe: 'authenticity_staging\\CNRWIP\\'
    };

    static maintainFormValue = {
        formType: 'formType',
        jurisdictions: 'jurisdictions'
    };

    static lobObjectKeys = {
        objectKeys: 'objectKeys'
    };

    static placeholder = 'Search by Wizard Field/ Field Name';

    static moreNotes = {
        lengthOfChar: 380,
        threeDots: '...',
        empty: '',
        zero: 0,
        readMore: 'Read More',
        readLess: 'Read Less'
    };

    static notes = {
        allEditions: 'All Form Editions',
        noteText: 'noteText',
        addNote: 'Add Note',
        editNote: 'Edit Note',
        charactersLeft: ' characters left',
        addedThisNote: 'added this note on',
        modifiedThisNote: 'modified this note on'
    };

    static notesValues = {
        questin: ' ?'
    };

    static notesUrl = {
        stateCode: 'stateCode',
        formId: 'formId',
        uniformno: 'uniformno',
        status: 'status',
        stateQuery: 'stateCode?formFile=formFile',
        baseForm: 'baseForm'
    };
    static formStatusFlags = {
        custPublished: 'custPublished',
        awebPublished: 'awebPublished',
        wkfsPublished: 'wkfsPublished'
    };
    static APIkeys = {
        PDFFile: 'PDFFile',
        HelpFile: 'HelpFile',
        FormFile: 'FormFile',
        formId: 'formId',
        UniformNo: 'UniformNo',
        BaseForm: 'BaseForm',
        DateObsolete: 'DateObsolete',
        EditionMonth: 'EditionMonth',
        EditionYear: 'EditionYear',
        FontSize: 'FontSize',
        CurrentEdition : 'CurrentEdition',
        PaperSize: 'PaperSize',
        FormFileName: 'FormFileName',
        StateCode: 'StateCode',
        HelpFileName: 'HelpFileName',
        Title: 'Title'
    };
    static addEditFormPaperSize = ['Letter', 'Legal'];

    static regExpression = {
        number: /[0-9]/
    };

    static dateFormat = {
        yymmddFormat: 'YYYY-MM-DD',
    };

    static downloadPdf = {
        cnrpdf: 'CNR4\\',
        cnrpdfWip: 'authenticity_staging\\CNRWIP\\'
    };

    static addEditFormControls = {
        currentEdition: 'currentEdition',
        dateObsolete: 'dateObsolete',
        formId: 'formId',
        stateCode: 'stateCode',
        paperSize: 'paperSize',
        editionMonth: 'editionMonth',
        fontSize: 'fontSize',
        letter: 'Letter',
        others: 'Others',
        formStatus: 'formStatus',
        custPublished: 'custPublished',
        awebPublished: 'awebPublished',
        wkfsPublished: 'wkfsPublished',
        formFile: 'formFile'
    };

    static addEditFormCustomComponentTypeControl = [
        { name: 'Insured', code: 'Insured' },
        { name: 'Third Party', code: 'TP' },
        { name: 'Mortgagee', code: 'Mortgagee' },
        { name: 'Certificate Holder', code: 'Certholder' },
        { name: 'Lienholder', code: 'Lienholder' },
        { name: 'Additional Interest', code: 'AddInt' },
        { name: 'WCC', code: 'WCC' }
    ];
    static uploadFile = {
        helpFile: 'helpFile',
        doc: 'doc',
        rh: 'RH',
        pdfFile: 'pdfFile',
        pdf: 'pdf',
        formFile: 'formFile',
        rtf: 'rtf',
        docx: 'docx',
        helpFileData: 'helpFileData',
        pdfFileData: 'pdfFileData',
        formFileData: 'formFileData',
        helpFileNam: 'helpFileName',
        pdfFileName: 'pdfFileName',
        formFileName: 'formFileName',
        pw: 'PW',
        formfile: 'form-file',
        helpfile: 'help-file'
    };
    static addComponentPageType = [{ name: 'Standard', code: 'S' }, { name: 'Non Standard', code: 'N' }];

    static editFormComponentsColNames = ['Component', 'Page Order', 'Standalone?',
        'RTF Section Starts', 'RTF Section Ends', 'PDF Page Starts',
        'PDF Page Ends', 'Copies', 'Page Type', 'Actions'];

    static editFormComponentsGridDataKeys = ['componentType', 'pageOrder', 'standaloneEnabled',
        'rtfSectionStart', 'rtfSectionEnd', 'pdFpageStart',
        'pdFpageEnd', 'copies', 'pageType', 'actions'];

    static openChildWindow = {
        openChildWindow: 'left=0,top=0,width=1200,height=1000,toolbar=1,resizable=1',
        imgTitle: 'Go to Wolters Kluwer Product X home page',
        imgAlt: 'Wolters Kluwer logo',
        lobActions: 'lobActions',
        viewFormJurisdictions: 'viewFormJurisdictions',
        viewRules: 'viewRules',
        notes: 'notes',
        fieldOrderMaintenance: 'fieldOrderMaintenance',
        fieldRuleStep: 'fieldRuleStep',
        addEditForms: 'addEditForms',
        formTextAlocation: 'formTextAlocation'
    };

    static addComponentLabel = 'Add Component(s)';
    static editComponentLabel = 'Edit Component(s)';

    static componentDetails = {
        CertholderName: 'Certificate Holder',
        CertholderCode: 'Certholder',
        AddIntName: 'Additional Interest',
        AddIntCode: 'AddInt',
        TpName: 'Third Party',
        TpCode: 'TP'
    };

    static formRules = {
        stateCode: '&StateCode=',
        actionId: '&ActionId=',
        lobId: '&LobId=',
        checked: 'checked',
        viewformRules: 'formRules',
        xl: 'xl',
        MD: 'md',
        pw: 'PW',
        rtfName: '&RTFName=',
        copyRulesToControl: 'copyRulesToControl',
        goToBottom: 'goToBottom',
        generatlCircumstance: 0,
        actionDuetoConsumerReport: 8
    };

    static viewRuletableHeading = ['ID', 'Field Name', 'Label & Circumstance', 'Field Defined', 'Default', 'Input Reqd?', 'Reg Reqd?', 'Effective Date', 'Actions'];

    static viewFileNameList = [{ id: 0, name: 'View WIP Form Files' }, { id: 1, name: 'View Current Form Files' }, { id: 2, name: 'View WIP PDF Files' }, { id: 3, name: 'View Current PDF Files' }, { id: 4, name: 'View WIP Help Files' }, { id: 5, name: 'View Current Help Files' }];

    static formRulesViewfields = [{ lable: false, name: 'All Fields', }, { lable: true, name: 'Field Defined Only' }];

    static allDisplayControls = ['Textbox', 'Checkbox'];
    static fieldDisplayed = [{ lable: true, name: 'Yes' }, { lable: false, name: 'No' }];

    static fieldMaintenanceControls = {
        textbox: 'Textbox',
        yes: 'Yes',
        displayOrder: 'displayOrder',
        maxLength: 'maxLength',
        displaySize: 'displaySize',
        close: 'close',
        saved: 'saved',
        displayGroup: 'displayGroup',
        displayGroupCodeHundred: 100,
        displayGroupCodeTwoHundred: 200,
        saveSuccesAlert: 'Details saved successfully!',
    };
    static downloadViewFiles = {
        wipFormFile: 'authenticity_staging\\CNRWIP\\',
        currentFormFile: 'CNR4\\webfill\\filtered\\',
        wipPdfFile: 'authenticity_staging\\CNRWIP\\',
        currentPdfFile: 'CNR4\\',
        wipHelpFile: 'authenticity_staging\\CNRWIP\\',
        currentHelpFile: 'CNR4\\',
        hash: '#',
        replaceHash: '%23',
        space: ' ',
        replaceSpace: '%20'

    };
    static formTextAllocation = {
        fieldName: 'fieldName',
        wizardField: 'wizardField',
        fieldLength: 'fieldLength',
        rtfName: 'rtfName',
        recordActive: 'recordActive'
    };

    static addEditComponentRegExpression = {
        number: /^[0-9]\d*$/
    };

    static copyTypes = ['Normal', 'No Copy', 'Copy Only'];
    static mailConstants = {
        mailto: 'mailto:',
        cc: '?cc=',
        subject: '&subject=',
        body: '&body=',
        stateCode: '((StateCode))',
        documentName: '((Document Name))'
    };

    static formPublishStatus = ['PAWEB', 'PWKFS', 'PCUST'];
    static formPublishTypes = {
        customer: 'Customer',
        wkfs: 'WKFS',
        aweb: 'Aweb'
    };
    static helpRH = 'RH';

    static showWarningMessage = {
        warningMsge: {
            isCUSTPublished: 'Removing action(s) will delete the fields and rules associated with the Action - LOB combination(s).\nDo you wish to proceed?',
            isAWEBWKFSPublished: 'Removing action(s) will delete the fields and rules associated with this Action - LOB combination(s).\nDo you wish to proceed?',
            formStatusFormLoad: 'Removing action(s) will delete the fields and rules associated with this Action - LOB combination(s).\nDo you wish to proceed?',
            formStatusNew: 'Removing action(s) will delete the fields and rules associated with this Action - LOB combination(s).\nDo you wish to proceed?'
        },
        noteMessage: {
            isCUSTPublished: 'Note: Form Load process is not required to be run after the action(s) is/(are) removed.\nUser will have to execute the update wizard menuing and/or update live wizard menuing to get these changes reflected to the preview and/or live site as required.',
            isAWEBWKFSPublished: 'Note: Form Load process is not required to be run after action(s) is/(are) removed.\nUser will have to execute the update wizard menuing and/or update live wizard menuing to get these changes reflected to the preview and/or live site as required.',
            formStatusFormLoad: 'Note: Form Load process is not required to be run after the action is removed.',
            formStatusNew: 'Note: Form Load process is not required to be run after the action is removed.'
        }
    };

    static notDisplayGroup = ['PolicyNumber', 'MailingDt', 'TransactionDt', 'PolicyTypeCode', 'Insurerformid'];

    static maxNumbers = {
        maxMonths: 12,
        previousYears: 5,
        nextYears: 21,
    };

    static formListDataKey = {
        formStatus: 'formStatus',
        helpStatus: 'helpStatus',
        formType: 'formType'
    };

    placeholder = 'Search by Wizard Field/ Field Name';
}
