export interface FormRulesAction {
    id?: number;
    code?: string;
    actionDesc?: string;
}
export interface FormRulesLobs {
    id?: number;
    abbr?: string;
    name?: string;
}
export interface FormRule {
    copyGroupId?: number;
    defaultValue?: string;
    boxNumber?: number;
    effectiveDateBegin?: string;
    fieldDefined?: boolean;
    fieldName?: string;
    inputRequired?: boolean;
    label?: string;
    regulatoryRequirement?: boolean;
    rtfactionFieldId?: number;
    whereConditionId?: number;
    boxNo?: number;
}
export interface Circumstance {
    id?: number;
    name?: string;
}
export interface FieldMaintenance {
    displayControl?: string;
    displayGroup?: number;
    displayOrder?: number;
    displaySize?: number;
    fieldDisplayed?: boolean;
    fieldName?: string;
    label?: string;
    maxLength?: number;
    rtfActionFieldID?: number;
}
