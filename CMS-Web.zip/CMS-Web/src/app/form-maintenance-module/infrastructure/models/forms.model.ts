export interface FormTextAllocationData {
    formId?: number;
    fieldName?: string;
    wizardField?: string;
    fieldLength?: number;
    allocationId?: number;
    rtfname?: string;
    recordActive?: boolean;
}

