export interface AddEditForm {
    form: AddEditKeys;
    formComponents?: FormComponents[];
}

export interface AddEditKeys {
    uniformNo?: string;
    baseForm?: string;
    dateObsolete?: string;
    editionMonth?: number;
    editionYear?: string;
    fontSize?: number;
    formSize?: string;
    formStatus?: string;
    currentEdition?: boolean;
    paperSize?: string;
    formFile?: string;
    pdfFile?: string;
    stateCode?: string;
    helpFile?: string;
    title?: string;
    formFileName?: string;
    helpFileName?: string;
    pdfFileName?: string;
    pdfFileData?: string;
    helpFileData?: string;
    formFileData?: string;
}
export interface FormComponents {
    componentType?: string;
    pageOrder?: number;
    standaloneEnabled?: boolean;
    rtfSectionStart?: number;
    rtfSectionEnd?: number;
    pdFpageStart?: number;
    pdFpageEnd?: number;
    copies?: number;
    pageType?: string;
    isSelected?: boolean;
}
