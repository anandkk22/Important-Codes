import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { PopupService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { take } from 'rxjs/operators';

@Injectable()
export class LobActionMarixService {

    constructor(private http: HttpClient,
        private popupService: PopupService,
        private translate: TranslateService) { }

    getLobExceptCPR() {
        return this.http.get(`${FormsConstant.webApis.lobExceptCPR}`);
    }

    getActionMatrix() {
        return this.http.get(`${FormsConstant.webApis.lobActionMatrix}`);
    }

    getFormLOBAction(formId, stateCode) {
        return this.http.get(`${FormsConstant.webApis.formLOBAction}/${formId}/${stateCode}`.replace('{formId}', formId).replace('{stateCode}', stateCode));
    }

    getFormActionItems(formLOBAction, objectKeysnValues) {
        const formLobActionItems = [];
        for (let i = 0; i < formLOBAction.length; i++) {
            for (let j = 0; j < objectKeysnValues.length; j++) {
                if (formLOBAction[i].lobId === objectKeysnValues[j][FormsConstant.lobObjectKeys.objectKeys]) {
                    formLobActionItems.push({
                        lobId: formLOBAction[i].lobId,
                        objectValues: objectKeysnValues[j].objectValues,
                        actionIds: formLOBAction[i].actionIds,
                    });
                }
            }
        }
        return formLobActionItems;
    }

    updateLOBActions(lobDetails) {
        return this.http.post(`${FormsConstant.webApis.updateLOBActions}`, lobDetails);
    }

    showConfirmation(message) {
        return this.popupService.showConfirmation({
            title: this.translate.instant('MESSAGES.CONFIRMATION.CONFIRM'),
            message: message,
            positiveLabel: this.translate.instant('BUTTON.OK'),
            negativeLabel: this.translate.instant('BUTTON.CANCEL'),
        }).pipe(take(1));
    }
}
