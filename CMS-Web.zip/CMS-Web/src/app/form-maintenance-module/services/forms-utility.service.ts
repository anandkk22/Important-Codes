import { Injectable } from '@angular/core';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { saveAs } from 'file-saver';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import { HttpHeaders } from '@angular/common/http';
import { AddEditKeys } from '../infrastructure/models/addEdit.model';

@Injectable()
export class FormsUtilityService {

  constructor(
    private translate: TranslateService,
    private popupService: PopupService
  ) { }


  getLines(commercialLines, personalLines, workersComp, miscellaneous) {
    const commercial = commercialLines ? FormsConstant.lines.commercialLines : FormsConstant.compareString.empty;
    const personal = personalLines ? FormsConstant.lines.personalLines : FormsConstant.compareString.empty;
    const workers = workersComp ? FormsConstant.lines.workersComp : FormsConstant.compareString.empty;
    const mis = miscellaneous ? FormsConstant.lines.miscellaneous : FormsConstant.compareString.empty;
    const combine = commercial + personal + workers + mis;
    return [...combine].slice(0, combine.length - 1).join('');
  }

  loadFile(response: any, filename) {
    saveAs(response.body, filename);
  }

  convertStatus(allStatus) {
    return Object.entries(allStatus).map(([key, value]) => ({ key, value }));
  }

  getStatus(allStatus, status) {
    const extraStatus = {
      key: FormsConstant.filestatus.PW,
      value: FormsConstant.filestatusFullForm.publishedToCustomerAccounts
    };
    allStatus.push(extraStatus);
    let filterValue = FormsConstant.empty;
    status = this.getNAStatus(status);
    filterValue = allStatus.find(i => i.key === status)?.value;
    return filterValue;
  }

  getNAStatus(status) {
    return (status === FormsConstant.compareString.empty || status === FormsConstant.compareString.undefined)
      ? FormsConstant.compareString.na : status;
  }

  getFilePath(status, fileType) {
    if (fileType === FormsConstant.filetype.formFile &&
      (status === FormsConstant.statusHelpForm.pw || status === FormsConstant.statusHelpForm.re)) {
      return FormsConstant.filePath.formWithPwRe;
    } else if (fileType === FormsConstant.filetype.helpFile &&
      (status === FormsConstant.statusHelpForm.pw || status === FormsConstant.statusHelpForm.re)) {
      return FormsConstant.filePath.helpWithPwRe;
    } else {
      return FormsConstant.filePath.formHelpNotPwRe;
    }
  }
  scrollToTop() {
    document.getElementById('main-scroll').scrollIntoView();
  }
  sortAscending(key, array) {
    return array.sort(function (a, b) {
        const x = a[key].toLowerCase(); const y = b[key].toLowerCase();
        return ((x < y) ? -1 : ((x > y) ? 1 : 0));
    });
}

sortDescending(key, array) {
    return array.sort(function (a, b) {
        const x = a[key].toLowerCase(); const y = b[key].toLowerCase();
        return ((x > y) ? -1 : ((x < y) ? 1 : 0));
    });
}
  getSessionData(key) {
    if (sessionStorage.getItem(key)) {
      return (sessionStorage.getItem(key));
    }
  }

  showAlert(message) {
    this.popupService.showAlert({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }

  getModifiedNotes(notes, uniformno) {
    const takeNotes = [];
    notes.forEach(element => {
      if (element.modifiedOn === element.addedOn) {
         element.dispalyDate = element.addedOn;
         element.dispalyText = FormsConstant.notes.addedThisNote;
      } else {
        element.dispalyDate = element.modifiedOn;
        element.dispalyText = FormsConstant.notes.modifiedThisNote;
      }
    });
    notes.sort((a, b) => new Date(b.dispalyDate).getTime() - new Date(a.dispalyDate).getTime());
    notes.forEach(element => {
      if (uniformno !== element.uniformNumber) {
        takeNotes.push(element.uniformNumber);
      }
    });
    takeNotes.unshift(uniformno);
    const uniqueElements = [...new Set(takeNotes)];
    const finalArr = [];
    uniqueElements.forEach(element => {
      const obj = { uniformNo: element, notes: [] };
      finalArr.push(obj);
    });
    finalArr.forEach(element => {
      notes.forEach(elementIn => {
        if (element.uniformNo === elementIn.uniformNumber) {
          element.notes.push(elementIn);
        }
      });
    });
    return finalArr;
  }

  getModifiedNotesHeading(notes, formIdDefault) {
    const drop = [];
    notes.forEach(element => {
      const formIdByDefault = element.notes.length === 0 ? formIdDefault : element.notes[0].formId;
      const objModel = { uniformNumber: element.uniformNo, formId: formIdByDefault };
      drop.push(objModel);
    });
    return drop;
  }
  getFilteredNotes(notes, uniformnos) {
    const filteredNotes = [];
    notes.forEach(element => {
      for (const val of uniformnos) {
        if (element.uniformNo === val) {
          filteredNotes.push(element);
        }
      }
    });
    return filteredNotes;
  }

  addGroupName(data, type) {
    data.forEach(element => {
      element.all = type;
    });
    return data;
  }

  getFormIds(selectedVersins) {
    const formIds = [];
    selectedVersins.forEach(element => {
      formIds.push(element.formId);
    });
    return formIds;
  }

  getUniformNumbers(selectedVersins) {
    const uniformNo = [];
    selectedVersins.forEach(element => {
      uniformNo.push(element.uniformNumber);
    });
    return uniformNo;
  }

  sendData(data) {
    const refactorData = {
      baseForm: data.baseForm,
      currentEdition: data.currentEdition,
      dateObsolete: data.dateObsolete,
      editionMonth: Number(data.editionMonth),
      editionYear: data.editionYear,
      fontSize: Number(data.fontSize),
      formFile: data.formFile,
      paperSize: data.paperSize,
      helpFile: data.helpFile,
      pdfFile: data.pdfFile,
      title: data.title,
      uniformNo: data.uniformNo
    };
    return refactorData;
  }

  getRequestData(records) {
    const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body: records };
    return options;
  }

  getStateName(allState, statusCode) {
    let filterStateName = FormsConstant.empty;
    filterStateName = allState.find(i => i.code === statusCode)?.name;
    return filterStateName;
  }

  isNeedEmail(statusCode) {
    return FormsConstant.emailStatus.includes(statusCode);
  }

  addingClickable(oldStatuses) {
    const newStatuses = [];
    oldStatuses.forEach(element => {
      if (FormsConstant.disableStatuses.includes(element.key)) {
        element.clickable = false;
      } else {
        element.clickable = true;
      }
      newStatuses.push(element);
    });
    return newStatuses;
  }

  getFromStatusName(allStatus, status) {
    let getStateName = FormsConstant.empty;
    if (status === FormsConstant.filestatus.PW) {
      getStateName = FormsConstant.filestatusFullForm.publishedToCustomerAccounts;
    } else {
      getStateName = allStatus.find(i => i.key === status)?.value;
    }
    return getStateName;
  }

  enablePW(addedClickable, previousStatus) {
    switch (previousStatus) {
      case FormsConstant.filestatus.LAWEB:
        const LCUSTStatuses = [];
        addedClickable.forEach(element => {
          if (element.key === FormsConstant.filestatus.PWKFS) {
            element.clickable = true;
          }
          LCUSTStatuses.push(element);
        });
        return LCUSTStatuses;
      case FormsConstant.filestatus.LWKFS:
        const LWKFSStatuses = [];
        addedClickable.forEach(element => {
          if (element.key === FormsConstant.filestatus.PCUST) {
            element.clickable = true;
          }
          LWKFSStatuses.push(element);
        });
        return LWKFSStatuses;
      default:
        return addedClickable;
    }
  }

  formsListUpdate(formsList, userResponse) {
    const formsUpdated = [];
    formsList.forEach(element => {
      if (element.formId === userResponse.formId && userResponse.formType === FormsConstant.filetype.formFile) {
        element.formStatus = userResponse.formStatus;
      } else if (element.formId === userResponse.formId && userResponse.formType === FormsConstant.filetype.helpFile) {
        element.helpStatus = userResponse.formStatus;
      } else if (element.formId === userResponse.formId && userResponse.formType === FormsConstant.filetype.bothFile) {
        element.formStatus = userResponse.formStatus;
        element.helpStatus = userResponse.helpStatus;
      }
      formsUpdated.push(element);
    });
    return formsUpdated;
  }
  showSuccessAlert(message) {
    this.popupService.showSuccess({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }
  isFormPublished(awebPublished, wkfsPublished, custPublished) {
    const formPublishedStatus = (awebPublished || wkfsPublished || custPublished);
    return (formPublishedStatus === FormsConstant.compareString.undefined) ?
      false : JSON.parse(formPublishedStatus);
  }

  // Form publish methods
  validateFormDetails(formDetails, isSubsequentPublish) {
    let hasError = false;
    let message = '';
    const isValidFormStatus = this.validateFormStatusForFirstTimePublish(formDetails);

    if (!formDetails.formFile) {
      message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_FILE_UPLOAD_ERROR');
      hasError = true;
    } else if (!formDetails.helpFile) {
      message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.HELP_FILE_UPLOAD_ERROR');
      hasError = true;
    } else if (!formDetails.formFileFound || !formDetails.pdfFormFound) {
      message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_FILE_MATCH_ERROR');
      hasError = true;
    } else if (!formDetails.helpFileFound) {
      message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.HELP_FILE_MATCH_ERROR');
      hasError = true;
    } else if (!isSubsequentPublish && !this.isValidHelpFileName(formDetails.formFile, formDetails.helpFile)) {
      message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.HELP_FILE_NAME_ERROR');
      hasError = true;
    } else if (!isSubsequentPublish && isValidFormStatus.hasError) {
      message = isValidFormStatus.message;
      hasError = isValidFormStatus.hasError;
    } else if (!isSubsequentPublish) {
      const isFormActivated = this.validateActivatedForm(formDetails);
      if (isFormActivated.hasError) {
        message = isFormActivated.message;
        hasError = isFormActivated.hasError;
      }
    } else if (isSubsequentPublish) {
      if ((formDetails.formStatus !== FormsConstant.filestatus.PCUST && formDetails.helpStatus !== FormsConstant.filestatus.PCUST) &&
          (formDetails.formStatus !== FormsConstant.filestatus.PWKFS && formDetails.helpStatus !== FormsConstant.filestatus.PWKFS) &&
          (formDetails.formStatus !== FormsConstant.filestatus.PAWEB && formDetails.helpStatus !== FormsConstant.filestatus.PAWEB)
         ) {
          hasError = true;
          message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.SUBSEQUENT_PUBLISH_STATUS_ERROR');
      }
    }

    return {
      hasError: hasError,
      message: message
    };
  }

  isValidHelpFileName(formFile, helpFile) {
    const formFileName = formFile.substr(0, formFile.lastIndexOf('.'));
    const helpFileName = helpFile.substr(0, helpFile.lastIndexOf('.'));
    let isValidName = true;

    if ((helpFileName.includes(FormsConstant.helpRH) &&
      formFileName !== helpFileName.substr(0, helpFile.lastIndexOf(FormsConstant.helpRH))) ||
      !helpFileName.includes(FormsConstant.helpRH)) {
      isValidName = false;
    }
    return isValidName;
  }

  validateFormStatusForFirstTimePublish(formDetails) {
    const isValidFormStatus = {
      hasError: false,
      message: null
    };
    let publishType = null;
    if (formDetails.formStatus === FormsConstant.filestatus.PCUST || formDetails.helpStatus === FormsConstant.filestatus.PCUST) {
      if (formDetails.formStatus !== FormsConstant.filestatus.PCUST || formDetails.helpStatus !== FormsConstant.filestatus.PCUST) {
        isValidFormStatus.hasError = true;
        publishType = FormsConstant.formPublishTypes.customer;
      }
    } else if (formDetails.formStatus === FormsConstant.filestatus.PWKFS || formDetails.helpStatus === FormsConstant.filestatus.PWKFS) {
      if (formDetails.formStatus !== FormsConstant.filestatus.PWKFS || formDetails.helpStatus !== FormsConstant.filestatus.PWKFS) {
        isValidFormStatus.hasError = true;
        publishType = FormsConstant.formPublishTypes.wkfs;
      }
    } else if (formDetails.formStatus === FormsConstant.filestatus.PAWEB || formDetails.helpStatus === FormsConstant.filestatus.PAWEB) {
      if (formDetails.formStatus !== FormsConstant.filestatus.PAWEB || formDetails.helpStatus !== FormsConstant.filestatus.PAWEB) {
        isValidFormStatus.hasError = true;
        publishType = FormsConstant.formPublishTypes.aweb;
      }
    } else if ((formDetails.formStatus !== FormsConstant.filestatus.PAWEB && formDetails.helpStatus !== FormsConstant.filestatus.PAWEB) &&
      (formDetails.formStatus !== FormsConstant.filestatus.PWKFS && formDetails.helpStatus !== FormsConstant.filestatus.PWKFS) &&
      (formDetails.formStatus !== FormsConstant.filestatus.PCUST && formDetails.helpStatus !== FormsConstant.filestatus.PCUST)) {
      isValidFormStatus.hasError = true;
      publishType = FormsConstant.formPublishTypes.aweb;
    }
    isValidFormStatus.message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FIRST_TIME_PUBLISH_STATUS_ERROR',
      { publishType: publishType });
    return isValidFormStatus;
  }

  validateActivatedForm(formDetails) {
    const isValidFormStatus = {
      hasError: false,
      message: null
    };
    let activeIn = null;
    if (formDetails.formStatus === FormsConstant.filestatus.PCUST || formDetails.helpStatus === FormsConstant.filestatus.PCUST) {
      if (!formDetails.stgWkfsActivated) {
        isValidFormStatus.hasError = true;
        activeIn = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.LIVE_WKFS');
      }
    } else if (formDetails.formStatus === FormsConstant.filestatus.PWKFS || formDetails.helpStatus === FormsConstant.filestatus.PWKFS) {
      if (!formDetails.stgAwebActivated) {
        isValidFormStatus.hasError = true;
        activeIn = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.LIVE_AWEB');
      }
    } else if (formDetails.formStatus === FormsConstant.filestatus.PAWEB || formDetails.helpStatus === FormsConstant.filestatus.PAWEB) {
      if (!formDetails.stgActivated) {
        isValidFormStatus.hasError = true;
        activeIn = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.LIVE_TEST_WIZARD');
      }
    }

    isValidFormStatus.message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_ACTIVATED_ERROR',
      { activeIn: activeIn });
    return isValidFormStatus;
  }

  getFormPublishSuccessMessage(formDetails, isSubsequentPublish, isMultistateHelpPublish) {
    let message = null;
    let publishType = null;
    let publishFile = null;
    if (!isSubsequentPublish) {
      publishFile = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_AND_HELP');
      publishType = this.getPublishType(formDetails.formStatus);
      message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_PUBLISH_SUCCESS',
      { publishFile: publishFile, publishType: publishType });
    } else {
      const isFormPublish = FormsConstant.formPublishStatus.includes(formDetails.formStatus);
      const isHelpPublish = FormsConstant.formPublishStatus.includes(formDetails.helpStatus);

      if (isFormPublish && isHelpPublish) {
        // Form and Help sheet - different publish
        if (formDetails.formStatus !== formDetails.helpStatus) {
          publishType = this.getPublishType(formDetails.formStatus);
          publishFile = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM');
          message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_PUBLISH_SUCCESS',
          { publishFile: publishFile, publishType: publishType });

          publishFile = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.REG_HELP_SHEET');
          publishType = this.getPublishType(formDetails.helpStatus);
          if (isMultistateHelpPublish) {
            message += '<br/>' + this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.MULTISTATE_HELP_PUBLISH_SUCCESS',
            { publishType: publishType });
          } else {
            message += '<br/>' + this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_PUBLISH_SUCCESS',
            { publishFile: publishFile, publishType: publishType });
          }
        } else {
          // Form and Help sheet - same publish
          if (isMultistateHelpPublish) {
            publishFile = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM');
            publishType = this.getPublishType(formDetails.formStatus);
            message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_PUBLISH_SUCCESS',
            { publishFile: publishFile, publishType: publishType });
            message += '<br/>' + this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.MULTISTATE_HELP_PUBLISH_SUCCESS',
            { publishType: publishType });
          } else {
            publishFile = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_AND_HELP');
            publishType = this.getPublishType(formDetails.formStatus);
            message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_PUBLISH_SUCCESS',
            { publishFile: publishFile, publishType: publishType });
          }
        }
      } else if (isFormPublish) {
        // Only form publish
        publishFile = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM');
        publishType = this.getPublishType(formDetails.formStatus);
        message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_PUBLISH_SUCCESS',
        { publishFile: publishFile, publishType: publishType });
      } else if (isHelpPublish) {
        // Only help sheet publish
        publishFile = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.REG_HELP_SHEET');
        publishType = this.getPublishType(formDetails.helpStatus);
        if (isMultistateHelpPublish) {
          message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.MULTISTATE_HELP_PUBLISH_SUCCESS',
          { publishType: publishType });
        } else {
          message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_PUBLISH_SUCCESS',
          { publishFile: publishFile, publishType: publishType });
        }
      }
    }
    return message;
  }

  getPublishType(status) {
    const publishType = status === FormsConstant.filestatus.PAWEB ? FormsConstant.formPublishTypes.aweb :
          status === FormsConstant.filestatus.PWKFS ? FormsConstant.formPublishTypes.wkfs :
          FormsConstant.formPublishTypes.customer;
    return publishType;
  }

  getFormPublishFailureMEssage(formDetails, isSubsequentPublish) {
    let message = null;
    if (!isSubsequentPublish) {
      message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_HELP_PUBLISH_FAIL');
    } else {
      const isFormPublish = FormsConstant.formPublishStatus.includes(formDetails.formStatus);
      const isHelpPublish = FormsConstant.formPublishStatus.includes(formDetails.helpStatus);
      if (isFormPublish && isHelpPublish) {
        message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_HELP_PUBLISH_FAIL');
      } else if (isFormPublish) {
        message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.FORM_PUBLISH_FAIL');
      } else if (isHelpPublish) {
        message = this.translate.instant('MAINTAIN_FORMS.PUBLISH_FORM.HELP_PUBLISH_FAIL');
      }
    }
    return message;
  }

  getGenerateDisplayGroupName(displayGroupData, displayGroupNumber) {
    let filterName = FormsConstant.empty;
    filterName = displayGroupData.find(i => i.code === displayGroupNumber)?.name;
    return filterName;
  }

  getModifiedDisplayGroupData(displayGroupData, selectedDisplayGroup) {
    const filterGroup = [];
    displayGroupData.forEach(element => {
      if (element.code !== selectedDisplayGroup) {
        filterGroup.push(element);
      }
    });
    return filterGroup;
  }

  fieldOrderDataStatus(fielRes) {
    const filterGroup = [];
    fielRes.forEach(element => {
      if (FormsConstant.notDisplayGroup.includes(element.fieldName)) {
        element.isDisable = true;
      } else {
        element.isDisable = false;
      }
      filterGroup.push(element);
    });
    return filterGroup;
  }

  enableFormStatusForSubsequentPublish(addedClickable) {
    const subsequentPublishStatus = [];
      addedClickable.forEach(element => {
        if (element.key === FormsConstant.filestatus.PWKFS ||
            element.key === FormsConstant.filestatus.PAWEB ||
            element.key === FormsConstant.filestatus.PCUST) {
          element.clickable = true;
        }
        subsequentPublishStatus.push(element);
      });
    return subsequentPublishStatus;
  }

  getValidEditionYear(formsList) {
    formsList.forEach( data => {
      if (data.editionYear && data.editionYear.length > 2) {
        data.editionYear = data.editionYear.substr(data.editionYear.length - 2);
      }
    });
    return formsList;
  }

  convertTwoDigitEditionYear(year) {
    if (year) {
      year = year.toString();
      if (year.length > 2) {
        year = year.substr(year.length - 2);
      }
    }
    return year;
  }

  getUpdatedStatus(status) {
    let updatedStatus = '';
    switch (status) {
      case FormsConstant.filestatus.PAWEB:
        updatedStatus = FormsConstant.filestatus.LAWEB;
        break;
      case FormsConstant.filestatus.PWKFS:
        updatedStatus = FormsConstant.filestatus.LWKFS;
        break;
      case FormsConstant.filestatus.PCUST:
        updatedStatus = FormsConstant.filestatus.PW;
        break;
      default:
        updatedStatus = status;
        break;
    }
    return updatedStatus;
  }

  getFormHelpArchiveStatus (status, selectedStatus, previousStatus, formType) {
    const returnFormsData = status;

    if (selectedStatus === FormsConstant.filestatus.AR) {
      returnFormsData[FormsConstant.formListDataKey.helpStatus] = FormsConstant.filestatus.AR;
      returnFormsData[FormsConstant.formListDataKey.formType] = FormsConstant.filetype.bothFile;
    } else if (previousStatus === FormsConstant.filestatus.AR && selectedStatus !== FormsConstant.filestatus.AR) {
      if (formType === FormsConstant.filetype.formFile) {
        returnFormsData[FormsConstant.formListDataKey.formStatus] = selectedStatus;
        returnFormsData[FormsConstant.formListDataKey.helpStatus] = FormsConstant.filestatus.DY;
        returnFormsData[FormsConstant.formListDataKey.formType] = FormsConstant.filetype.bothFile;
      } else if (formType === FormsConstant.filetype.helpFile) {
        returnFormsData[FormsConstant.formListDataKey.formStatus] = FormsConstant.filestatus.FLP;
        returnFormsData[FormsConstant.formListDataKey.helpStatus] = selectedStatus;
        returnFormsData[FormsConstant.formListDataKey.formType] = FormsConstant.filetype.bothFile;
      }
    }
    return returnFormsData;
  }

  getEncodedUrl(href) {
    let encodedUrl = '';
    const urlValues = href.split('?');
    encodedUrl = `${urlValues[0]}?params=${encodeURIComponent(window.btoa(urlValues[1]))}`;
    return encodedUrl;
  }

  getDecodedParamData(searchData) {
    const decodedData = window.atob(decodeURIComponent(searchData));
    const data = decodedData.split('&');
    const paramData = {};
    data.forEach(i => {
      const obj = i.split('=');
      paramData[obj[0]] = obj[1];
    });
    return paramData;
  }
}
