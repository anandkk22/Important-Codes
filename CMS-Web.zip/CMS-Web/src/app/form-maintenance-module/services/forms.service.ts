import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { FormsUtilityService } from './forms-utility.service';
import { AppConstants } from 'app/app.constants';
import { saveAs } from 'file-saver';
import { SpinnerService } from '@wk/nils-core';

@Injectable()
export class FormsService {

  constructor(private http: HttpClient,
    private spinnerService: SpinnerService,
    private formsUtilityService: FormsUtilityService) { }

  public getJurisdictions() {
    return this.http.get(`${FormsConstant.webApis.getJurisdictions}`);
  }

  public getByStates(data) {
    return this.http.post(`${FormsConstant.webApis.getByStates}`, data);
  }

  public getFormAllStatus() {
    return this.http.get(`${FormsConstant.webApis.getForm}`);
  }

  public getHelpAllStatus() {
    return this.http.get(`${FormsConstant.webApis.getHelp}`);
  }

  public download(filePath, fileName) {
    return this.http.put(FormsConstant.webApis.download + filePath + fileName, '',
      { responseType: FormsConstant.responseType.blobType as 'json', observe: 'response' });
  }

  public getFormAttributesById(formId) {
    return this.http.get(`${FormsConstant.webApis.getForm}` + '/' + formId + '/Attributes-Components');
  }

  public getAllNotes(baseForm, stateCode) {
    return this.http.get(`${FormsConstant.webApis.getAllNotes}`.replace('{baseForm}', baseForm).replace('{stateCode}', stateCode));
  }

  public addFormNotes(data) {
    return this.http.post(`${FormsConstant.webApis.addFormNotes}`, data);
  }

  public deleteNotes(data) {
    return this.http.delete(`${FormsConstant.webApis.deleteNote}`.replace('{noteId}', data));
  }

  public updateNote(updateData) {
    return this.http.put(`${FormsConstant.webApis.updateNote}`, updateData);
  }

  public getNotesSelects(data) {
    return this.http.post(`${FormsConstant.webApis.getNotes}`, data);
  }

  deleteFormComponent(data) {
    const options = this.formsUtilityService.getRequestData(data);
    return this.http.delete(`${FormsConstant.webApis.deleteFormComponent}`, options);
  }

  getLobActionUrl(formsList, stateCode, i) {
    const href = AppConstants.lobAction + formsList[i].formId + '&stateCode=' + stateCode + '&formStatus=' + formsList[i].formStatus
    + '&awebPublished=' + formsList[i].awebPublished + '&wkfsPublished=' + formsList[i].wkfsPublished + '&custPublished='
    + formsList[i].custPublished + '&formFile=' + formsList[i].formFile + '&uniformNo=' + formsList[i].uniformNo;
    return href;
  }

  getFilePath() {
    const filePath = FormsConstant.downloadPdf.cnrpdf;
    return filePath;
  }

  loadFile(response: any, fileName: any) {
    saveAs(response.body, fileName);
}

  getViewRuleUrl(formsList) {
    const href = AppConstants.viewRule + formsList.formId;
    return href;
  }

  validateFormRules(formData) {
    return this.http.post(`${FormsConstant.webApis.validateForm}`, formData, { observe: 'response' });
  }

  public changeFormFileStatus(formId, status, stateCode) {
    return this.http.put(`${FormsConstant.webApis.changeFormFileStatus}`.replace('{formId}', formId).replace('{status}', status).replace('{stateCode}', stateCode), '');
  }

  public changeHelpFileStatus(formId, status, stateCode) {
    return this.http.put(`${FormsConstant.webApis.changeHelpFileStatus}`.replace('{formId}', formId).replace('{status}', status).replace('{stateCode}', stateCode), '');
  }

  public formStatusEmail(status, type) {
    return this.http.get(`${FormsConstant.webApis.formStatusEmail}`.replace('{status}', status) + type);
  }

  getEmailUrl(data, stateCode, fileName) {
    const updatedsubject = data.subject.replace(FormsConstant.mailConstants.stateCode, stateCode)
    .replace(FormsConstant.mailConstants.documentName, fileName);
    return `${FormsConstant.mailConstants.mailto}${data.emailTo}${FormsConstant.mailConstants.cc}${data.emailCC}
    ${FormsConstant.mailConstants.subject}${updatedsubject}`;
  }

  loadFormRules(formData) {
    return this.http.post(`${FormsConstant.webApis.loadForm}`, formData, { observe: 'response' });
  }
  getByStatesForm(formsModel) {
    let formsList = [];
    this.spinnerService.start();
    const formsListRequest = {
      formStatus: Number(formsModel.formStatus),
      stateCodes: [formsModel.stateCodes]
    };
    this.getByStates(formsListRequest).subscribe((res: any) => {
      this.spinnerService.stop();
      if (res) {
         return formsList = res;
      }
    });

  }
  publishForm(formData) {
    return this.http.post(`${FormsConstant.webApis.publishForm}`, formData);
  }

  public getActionStatus(formId, stateCode, fileName) {
    const url = FormsConstant.webApis.getActionStatus.replace('{formId}', formId)
    .replace('{stateCode}', stateCode).replace('{rtfName}', fileName);
    return this.http.get(url);
  }

  public uploadFile(fileData) {
    const request = this.getFormDataForFileUpload(fileData);
    return this.http.post(`${FormsConstant.webApis.fileUpload}`, request);
  }
  getFormDataForFileUpload( data) {
    const formData = new FormData();
    if (data.PDFFile) {
      formData.append(FormsConstant.APIkeys.PDFFile, data.PDFFile);
    } else {
      formData.append(FormsConstant.APIkeys.PDFFile, '');
    }
    if (data.HelpFile) {
      formData.append(FormsConstant.APIkeys.HelpFile, data.HelpFile);
    } else {
      formData.append(FormsConstant.APIkeys.HelpFile, '');
    }
    if (data.FormFile) {
        formData.append(FormsConstant.APIkeys.FormFile, data.FormFile);
      } else {
        formData.append(FormsConstant.APIkeys.FormFile, '');
      }

    return formData;
  }
}
