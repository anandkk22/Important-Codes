import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsConstant } from 'app/form-maintenance-module/infrastructure/forms.constant';
import { PopupService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { FormsUtilityService } from './forms-utility.service';
import { AddEditKeys } from '../infrastructure/models/addEdit.model';

@Injectable()
export class AddEditFormsService {
    constructor(
        private http: HttpClient,
        private popupService: PopupService,
        private translate: TranslateService,
        private formsUtilityService: FormsUtilityService) { }

    getUniformNoStatus(uniformNo) {
        return this.http.get(`${FormsConstant.webApis.uniformNoStatus}${uniformNo}`);
    }

    addForm(data) {
        const formData = this.getFormDataFromAddEditModel(data);
        return this.http.post(`${FormsConstant.webApis.addEditForm}`, formData);
    }

    updateForm(data, formId) {
        const formData = this.getFormDataFromAddEditModel(data, formId);
        return this.http.put(`${FormsConstant.webApis.addEditForm}`, formData);
    }
    getFormDataFromAddEditModel( data: AddEditKeys, formId?) {
        const formData = new FormData();
        if (formId && formId !== 0) {
          formData.append(FormsConstant.APIkeys.formId, formId.toString());
        }
        formData.append(FormsConstant.APIkeys.UniformNo, data.uniformNo);
        formData.append(FormsConstant.APIkeys.BaseForm, data.baseForm);
        formData.append(FormsConstant.APIkeys.DateObsolete, data.dateObsolete);
        formData.append(FormsConstant.APIkeys.EditionMonth, data.editionMonth?.toString());
        formData.append(FormsConstant.APIkeys.EditionYear, data.editionYear);
        formData.append(FormsConstant.APIkeys.FontSize, data.fontSize?.toString());
        formData.append(FormsConstant.APIkeys.CurrentEdition, data.currentEdition.toString());
        formData.append(FormsConstant.APIkeys.PaperSize, data.paperSize);
        formData.append(FormsConstant.APIkeys.FormFileName, data.formFileName ? data.formFileName : '');
        formData.append(FormsConstant.APIkeys.StateCode, data.stateCode);
        if (data.helpFileName) {
            formData.append(FormsConstant.APIkeys.HelpFileName, data.helpFileName);
        }
        formData.append(FormsConstant.APIkeys.Title, data.title);
        return formData;
      }


    getDeleteRecords(formId, records) {
        const deleteRecords = records.reduce(
          function(acc, val) {
            acc.push(val.componentType);
            return acc;
        }, []);

        const deleteParams = {
          formId: formId,
          componentType: deleteRecords
        };
        return deleteParams;
    }

    addComponentData(formId, addComponentDetails) {
        return this.http.post(`${FormsConstant.webApis.addComponent}`.replace('{formId}', formId), addComponentDetails);
    }

    getViewFileList(fileId) {
        return this.http.get(`${FormsConstant.webApis.viewFileList}${fileId}`);
    }
    updateLiveComponent(formId) {
      return this.http.put(`${FormsConstant.webApis.updateLiveComponent}`.replace('{formId}', formId), formId);
    }
    updateLiveFormAttributes(data) {
      return this.http.put(`${FormsConstant.webApis.updateLiveFormAttribute}`, data);
    }

  showAlert(message) {
    this.popupService.showAlert({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.OK'),
      negativeLabel: '',
    });
  }

  getEditionYear() {
    const allEditionYears = [];
    const today = new Date();
    for (let i = (today.getFullYear() - FormsConstant.maxNumbers.previousYears);
      i < (today.getFullYear() + FormsConstant.maxNumbers.nextYears); i++) {
      allEditionYears.push(i);
    }
    return allEditionYears;
  }

  onPaste(key, editionMonthValue, fontSizeValue): boolean {
    const value = (key === FormsConstant.addEditFormControls.editionMonth) ? editionMonthValue.value : fontSizeValue.value;
    if (Number(value)) {
      return true;
    } else {
      if (key === FormsConstant.addEditFormControls.editionMonth) {
        editionMonthValue.setValue('');
      } else {
        fontSizeValue.setValue('');
      }
    }
    return false;
  }
  isFormFileExists(filename) {
    return this.http.get(`${FormsConstant.webApis.formFileExists}`.replace('{filename}', filename));
  }
  isHelpFileExists(filename) {
    return this.http.get(`${FormsConstant.webApis.helpFileExists}`.replace('{filename}', filename));
  }
   isPDFFileExists(filename) {
    return this.http.get(`${FormsConstant.webApis.pdfFileExists}`.replace('{filename}', filename));
  }
}
