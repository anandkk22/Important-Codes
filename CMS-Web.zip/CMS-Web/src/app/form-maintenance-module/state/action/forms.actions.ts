import { Action } from '@ngrx/store';
import { ActionTypes } from '../enum/actionTypes';

export class FormsActions implements Action {
    type = ActionTypes.forms;

    constructor(public payload: any) { }
}
