export enum ActionTypes {
    forms = 'forms',
}
