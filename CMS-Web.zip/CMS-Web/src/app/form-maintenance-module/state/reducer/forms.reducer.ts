import { FormsActions } from '../action/forms.actions';
import { ActionTypes } from '../enum/actionTypes';

const initialState = '';
export function FormsReducer(
  state = initialState,
  action: FormsActions
) {
    switch (action.type) {
        case ActionTypes.forms:
            return action.payload;
        default:
            return state;
    }
}
