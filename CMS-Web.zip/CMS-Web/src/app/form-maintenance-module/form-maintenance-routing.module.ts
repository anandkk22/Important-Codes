import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { EditFormComponent } from './components/edit-form/edit-form.component';
import { FormFieldTextAllocationComponent } from './components/form-field-text-allocation/form-field-text-allocation.component';
import { FormsComponent } from './components/forms/forms.component';
import { MaintainFormsComponent } from './components/maintain-forms/maintain-forms.component';
import { FormFieldDependencyRulesComponent } from './components/form-field-dependency-rules/form-field-dependency-rules.component';
import { LobActionMatrixFormComponent } from './components/lob-action-matrix-form/lob-action-matrix-form.component';
import { NotesComponent } from './components/notes/notes.component';
import { ViewFormJurisdictionsComponent } from './components/view-form-jurisdictions/view-form-jurisdictions.component';
import { AddEditFormComponent } from './components/add-edit-form/add-edit-form.component';
import { ViewRulesComponent } from './components/rules/view-rules.component';
import { FieldOrderMaintenanceComponent } from './components/field-order-maintenance/field-order-maintenance.component';
import { AuthGuardService } from '@global/services/auth-guard.service';
const routes: Routes = [
    {
      path: AppConstants.uiRoutes.empty,
      component: MaintainFormsComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.forms,
      component: FormsComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.formMaintenance,
      component: MaintainFormsComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.editForm,
      component: EditFormComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.formFieldDependencyRules,
      component: FormFieldDependencyRulesComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.formFieldTextAllocation,
      component: FormFieldTextAllocationComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.lobActions,
      component: LobActionMatrixFormComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.notes,
      component: NotesComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.formJurisdiction,
      component: ViewFormJurisdictionsComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.addEditFormUrl,
      component: AddEditFormComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.viewRules,
      component: ViewRulesComponent,
      canActivate: [AuthGuardService]
    },
    {
      path: AppConstants.uiRoutes.fieldOrderMaintenance,
      component: FieldOrderMaintenanceComponent,
      canActivate: [AuthGuardService]
    }

  ];

  @NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
  })
  export class FormMaintenanceRoutingModule { }
