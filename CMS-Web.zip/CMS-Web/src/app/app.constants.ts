import { environment } from '@env';

export class AppConstants {

  static ngxTranslateConfig = {
    supportedBrowserLanguages: ['en'],
    fallbackBrowserLanguage: 'en'
  };

  static uiRoutes = {
    routeSeperator: '/',
    empty: '',
    pathMatch: 'full',
    unauthorized: 'unauthorized',
    welcome: 'welcome',
    xmlFeed: 'xmlfeed',
    daysNoticeReport: 'days-notice-report',
    configurations: 'configurations',
    maintainReasons: 'maintain-reasons',
    maintainDays: 'maintain-days',
    listFormsByJurisdictionAction: 'list-forms-by-jurisdiction-action',
    listFormsByJurisdiction: 'list-forms-by-jurisdiction',
    PermittedReasonWithoutFormRulesComponent: 'permitted-reason-without-form-rules',
    reports: 'reports',
    checkDaysNoticeRules: 'check-days-notice-rules',
    maintainMailType: 'maintain-mail-type',
    checkMailType: 'check-mail-type',
    wizardCriteriaByField: 'wizard-criteria-by-field',
    actionMaintenance: 'action-maintenance',
    wizardCriteriaByForm: 'wizard-criteria-by-form',
    whereConditionMaintenance: 'where-condition-maintenance',
    formMaintenance: 'form-maintenance',
    formMaintenanceEdit: 'form-maintenance/edit-form?formId=',
    reportsMenu: 'reports',
    forms: 'forms',
    lobMaintenance: 'lob-maintenance',
    fieldMasterMaintenance: 'field-master-maintenance',
    fieldDependancyMaintenance: 'field-dependancy-rule',
    fieldRuleSteps: 'field-rule-steps',
    fieldRuleStepsUrl: 'configurations/field-rule-steps?ruleStepId=',
    formsList: 'form-maintenance/forms',
    formsMaintenance: 'form-maintenance/form-maintenance',
    badFieldRuleAssignments: 'bad-field-rule-assignments',
    formsMissingHelpsheet: 'forms-missing-helpsheet',
    editForm: 'edit-form',
    formFieldTextAllocation: 'form-field-text-allocation',
    formFieldDependencyRules: 'form-field-dependency-rules',
    lobActions: 'lob-actions',
    notes: 'notes',
    formJurisdiction: 'form-jurisdictions',
    addEditFormUrl: 'add-edit-form',
    rules: 'rules',
    viewRules: 'view-rules',
    viewRulesUrl: 'view-rules',
    fieldOrderMaintenance: 'view-rules/field-order-maintenance',
    iweLogin: 'iwe/login',
    pdfFormLoad: 'pdf-form-load',
    rulesMarkedRegulatory: 'regulatory-rules',
    compareTools: 'compare-tools',
    formsReferencedByCNRMatrix: 'inactive-aweb-forms',
    nonReferencedFormsInMatrix: 'non-referenced-matrix-forms',
    rulesSummaryReport: 'rules-summary-report',
    userAlert: 'user-alert',
    formsMissingFields: 'form-missing-fields',
    previewAccess : 'preview-access'
  };

  static formFieldDependencyRuleReport = 'form-maintenance/form-field-dependency-rules?formId=formID&fileName=filename&uniformNo=uniformno&baseForm=baseform';
  static formJurisdictionURL = 'form-maintenance/form-jurisdictions?formId=formID&uniformno=uniformNo&stateCode=stCode&awebPublished=awebFlag&wkfsPublished=wkfsFlag&custPublished=custFlag';
  static formFieldTextAllocation =   'form-maintenance/form-field-text-allocation?formId=formID&awebPublished=awebFlag&wkfsPublished=wkfsFlag&custPublished=custFlag&uniformno=uniformNo&stateCode=stCode&formFile=formfile';

  static fieldOrderMaintenanceURL = 'form-maintenance/view-rules/field-order-maintenance?rtfName=RTFNAME&formId=formID&stateCode=stCode';

  static authData = {
    productHomeRoute: environment.productUrl,
    productName: 'cnrcms',
    clientId: 'bc919761-0f94-43eb-a97a-ed825f80a9ef'
  };

  static cnrPath = '/cnr/';

  static webApis = {
    imageUrl: 'assets/Images/WKLogo.png',
  };

  static lobAction = 'form-maintenance/lob-actions?formId=';
  static addEditForms = 'form-maintenance/add-edit-form?stateCode=stCode&formId=formID&awebPublished=awebFlag&wkfsPublished=wkfsFlag&custPublished=custFlag';
  static viewRule = 'form-maintenance/view-rules?formId=formID&awebPublished=awebFlag&wkfsPublished=wkfsFlag&custPublished=custFlag&stateCode=stCode&formFile=formFiles';
  static notesURL = 'form-maintenance/notes?baseForm=baseform&stateCode=stCode&formId=fromID&uniformno=uniformNo';

  static assetPath = 'https://cdn.wolterskluwer.io/wk/fundamentals/1.x.x/logo/assets/';
  static wkLogoImgName = 'medium.svg';

  static cnrpreview = {
    redirectUrl: 'index.aspx',
    method: 'POST',
    innerHtml: '<input name="PreviewHandle" value="CNRPreview">',
    key: 'cnrPreview'
  };

  static pentestRegex = {
    htmlTagsRegex: /<[a-z][\s\S]*>/i,
    specialCharactersRegex: /[@#$^*+\=\[\]{}\\|\/~]/,
    notSpecialCharacter: /[^a-zA-Z0-9.,;:'"?&() ]/g
  };

}
