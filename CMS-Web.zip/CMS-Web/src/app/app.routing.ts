import { NgModule } from '@angular/core';
import { Routes, RouterModule, ExtraOptions } from '@angular/router';
import { PageNotFoundComponent } from 'app/home-module/page-not-found/page-not-found.component';
import { AuthGuardService } from '@global';
import { AppConstants } from 'app/app.constants';
import { UnauthorizeCMSAccessComponent } from './utility-module/unauthorize-cms-access/unauthorize-cms-access.component';
import { PreviewComponent } from './home-module/preview/preview.component';

const routerOptions: ExtraOptions = {
  scrollPositionRestoration: 'enabled',
  anchorScrolling: 'enabled',
  scrollOffset: [0, 64],
  relativeLinkResolution: 'legacy'
};

const appRoutes: Routes = [
  {
    path: AppConstants.uiRoutes.empty,
    redirectTo: AppConstants.uiRoutes.formMaintenance,
    pathMatch: AppConstants.uiRoutes.pathMatch
  },
  {
    path: AppConstants.uiRoutes.configurations,
    loadChildren: () => import('./configurations-module/configurations.module').then(m => m.ConfigurationsModule)
  },
  {
    path: AppConstants.uiRoutes.reports,
    loadChildren: () => import('./reports-module/reports.module').then(m => m.ReportsModule)
  },
  {
    path: AppConstants.uiRoutes.formMaintenance,
    loadChildren: () => import('./form-maintenance-module/form-maintenance.module').then(m => m.FormMaintenanceModule)
  },
  {
    path: AppConstants.uiRoutes.previewAccess,
    component: PreviewComponent
  },
  {
    path: AppConstants.uiRoutes.unauthorized,
    component: UnauthorizeCMSAccessComponent
  },
  {
    path: AppConstants.uiRoutes.compareTools,
    loadChildren: () => import('./compare-tools-module/compare-tools.module').then(m => m.CompareToolsModule)
  },
  {
    path: AppConstants.uiRoutes.userAlert,
    loadChildren: () => import('./user-alert-module/user-alert.module').then(m => m.UserAlertModule)
  },
  {
    path: '**',
    component: PageNotFoundComponent,
    canActivate: [AuthGuardService]
  }

];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes, routerOptions)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
