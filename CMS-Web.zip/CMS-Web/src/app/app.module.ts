import { environment } from '@env';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule, Title } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClient } from '@angular/common/http';
import { ServiceWorkerModule } from '@angular/service-worker';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { Observable } from 'rxjs';
import { CoreModule } from '@core';
import { GlobalModule } from '@global/global.module';
import { AppRoutingModule } from './app.routing';
import { AppComponent } from './app.component';
import { HomeModule } from './home-module/home.module';
import { StoreModule } from '@ngrx/store';
import { UtilityModule } from './utility-module/utility-module.module';
import { FormsReducer } from './form-maintenance-module/state/reducer/forms.reducer';



class TranslateCustomLoader implements TranslateLoader {
  constructor(private http: HttpClient) { }

  getTranslation(lang: string): Observable<any> {
    return new TranslateHttpLoader(
      this.http,
      './assets/i18n/',
      '.json?Date=' + Date.now()
    ).getTranslation(lang);
  }
}

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: false
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useClass: TranslateCustomLoader,
        deps: [HttpClient],
      },
    }),
    CoreModule.forRoot({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      authUrl: environment.authUrl,
      customerCareEmail: environment.customerCareEmail,
      feedbackEmail: environment.feedbackEmail,
      productUrl: environment.productUrl
    }),
    GlobalModule.forRoot(),
    AppRoutingModule,
    HomeModule,
    UtilityModule,
    StoreModule.forRoot({}),
    StoreModule.forRoot({ reducer: FormsReducer })
  ],
  providers: [Title],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  bootstrap: [AppComponent]
})
export class AppModule { }
