export const UserInfoMock = {
  'admin_contacts': [],
  'subscriptions': []
  };
