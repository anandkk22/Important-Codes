import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NilsSharedModule } from '@wk/nils-shared';
import { environment } from '@env';
import { MailLogMenuComponent } from './components/mail-log-menu/mail-log-menu.component';
import { MailLogFormsRoutingModule } from './mail-log-forms-routing.module';
import { MailLogFormService } from './services/mail-log-form-service';
import { NgSelectModule } from '@ng-select/ng-select';
import { MailLogFormUtilityService } from './services/mail-log-form-utility.service';
import { KeytoMailTypesComponent } from './components/keyto-mail-types/keyto-mail-types.component';
@NgModule({
  declarations: [
    MailLogMenuComponent,
    KeytoMailTypesComponent
  ],
  imports: [
    CommonModule,
    MailLogFormsRoutingModule,
    NgSelectModule,
    NilsSharedModule.loadConfig({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      commonApiUrl: '',
      userGroupURL: '',
      feedbackEmail: environment.feedbackEmail,
      customerCareEmail: environment.customerCareEmail,
      productUrl: environment.productUrl
    }),
  ],
  providers: [
    MailLogFormService,
    MailLogFormUtilityService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class MailLogFormsModule { }
