import { Component, OnInit, ViewChild } from '@angular/core';
import { MailLogFormService } from 'app/mail-log-forms/services/mail-log-form-service';
import { NgSelectComponent } from '@ng-select/ng-select';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MailLogFormUtilityService } from 'app/mail-log-forms/services/mail-log-form-utility.service';
import * as moment from 'moment';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { MailLogFormsConstants } from 'app/mail-log-forms/infrastructure/mail-log-forms-constants';
import { KeytoMailTypesComponent } from 'app/mail-log-forms/components/keyto-mail-types/keyto-mail-types.component';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { environment } from '@env';
import { AppConstants } from 'app/app.constants';
import { Constants } from '@global/infrastructure/constants';

@Component({
  selector: 'app-mail-log-menu',
  templateUrl: './mail-log-menu.component.html',
  styleUrls: ['./mail-log-menu.component.scss']
})
export class MailLogMenuComponent implements OnInit {
  @ViewChild('selecter') ngselect: NgSelectComponent;
  viewResults = MailLogFormsConstants.viewResults;
  pdfUrlOpen = MailLogFormsConstants.webApis.userInstuctionsurl;
  serviceCenters = [];
  selectedServiceCenters = [];
  accountInsurers = [];
  selectedAccountInsurers = [];
  selectedInsurersIds = [];
  mailLogData = [];
  dateNow = new Date();
  stopFutureDate;
  isClickedButton = false;
  isFoundFilterData = false;
  mailFromBranch = false;
  producerToMailLog = false;
  gridStatus = MailLogFormsConstants.viewResultsStatus.all;
  viewType = MailLogFormsConstants.viewEditType.view;
  printType = MailLogFormsConstants.viewEditType.print;
  pdfUrl = MailLogFormsConstants.webApis.userInstuctions;
  public mailLogForm: FormGroup = new FormGroup({
    reportDate: new FormControl([Validators.required]),
    serviceCenter: new FormControl(MailLogFormsConstants.formsValue.empty, [Validators.required]),
    insuredJurisdiction: new FormControl(MailLogFormsConstants.formsValue.empty),
    typist: new FormControl(MailLogFormsConstants.formsValue.empty),
    mailType: new FormControl(MailLogFormsConstants.formsValue.s),
    sortBy: new FormControl(MailLogFormsConstants.formsValue.zero),
    mailPostalLogByServiceCenter: new FormControl(false),
    includeProducerNotificationsInMailLog: new FormControl(false)
  });
  isValidDate = false;
  viewForm: FormGroup;
  isViewPrintFormClicked = false;

  constructor(
    private mailLogFormService: MailLogFormService,
    private utilityService: MailLogFormUtilityService,
    private modalService: NgbModal,
    private spinnerService: SpinnerService,
    private popupService: PopupService,
    private translate: TranslateService,
    private fb: FormBuilder
  ) { }

  ngOnInit(): void {
    this.setDate();
    this.getAllServiceCenters();
    this.getAllAccountInsurers();
    this.getDefaultSettings();
    this.createViewForm();
  }

  createViewForm() {
    this.viewForm = this.fb.group({
      view: [MailLogFormsConstants.viewResultsStatus.all]
    });
  }

  setDate() {
    this.stopFutureDate = moment(this.dateNow).format(MailLogFormsConstants.dateFormat.yymmddFormat);
    this.mailLogForm.controls.reportDate.setValue(moment(this.dateNow).format(MailLogFormsConstants.dateFormat.yymmddFormat));
  }

  isDataAvaliable() {
    return this.serviceCenters.length === 0 && this.accountInsurers.length === 0 ? false : true;
  }

  getAllServiceCenters() {
    this.mailLogFormService.getAllServiceCenters().subscribe((res: any) => {
      this.serviceCenters = res.paginationData;
    });
  }

  getAllAccountInsurers() {
    this.mailLogFormService.getAllAccountInsurers().subscribe((res: any) => {
      this.accountInsurers = this.utilityService.addAllProperty(res.paginationData);
    });
  }

  getDefaultSettings() {
    this.mailLogFormService.getDefaultSettings().subscribe((res: any) => {
      this.producerToMailLog = res.producerToMailLog;
      this.mailLogForm.controls.includeProducerNotificationsInMailLog.setValue(this.producerToMailLog);
      this.mailFromBranch = res.mailFromBranch;
      this.mailLogForm.controls.mailPostalLogByServiceCenter.setValue(this.mailFromBranch);
    });
  }

  viewPrintForm(type) {
    this.isClickedButton = true;
    this.isViewPrintFormClicked = true;
    if (this.mailLogForm.valid && this.selectedAccountInsurers.length > 0 && !this.isValidDate) {
      const formdata = {
        reportDate: moment(this.mailLogForm.value.reportDate).format(MailLogFormsConstants.dateFormat.formatMMDDYYYY),
        serviceCenterId: Number(this.mailLogForm.value.serviceCenter),
        insurerIds: this.selectedInsurersIds,
        insuredJurisdiction: this.mailLogForm.value.insuredJurisdiction?.trim(),
        typist: this.mailLogForm.value.typist?.trim(),
        mailType: this.mailLogForm.value.mailType,
        sortBy: Number(this.mailLogForm.value.sortBy),
        mailPostalLogByServiceCenter: this.mailLogForm.value.mailPostalLogByServiceCenter,
        includeProducerNotificationsInMailLog: this.mailLogForm.value.includeProducerNotificationsInMailLog
      };
      this.isClickedButton = false;
      if (type === MailLogFormsConstants.viewEditType.view) {
        this.viewEditMailLogs(formdata);
      } else if (type === MailLogFormsConstants.viewEditType.print) {
        this.viewAndPrintForm(formdata);
      }
    }
  }

  viewEditMailLogs(formdata) {
    this.mailLogData = [];
    this.mailLogFormService.viewEditInsurerMailLog(formdata).subscribe((response: any) => {
      if (response) {
        this.mailLogData = this.utilityService.mailLogDataFilterData(response);
      }
      this.gridStatus = this.isViewPrintFormClicked ? MailLogFormsConstants.viewResultsStatus.all : this.gridStatus;
      this.viewForm.get(MailLogFormsConstants.view).setValue(this.gridStatus);
      this.isViewPrintFormClicked = false;
      this.isFoundFilterData = this.mailLogData.length === 0 ? true : false;
    });
  }

  onDateChange() {
    const date = this.mailLogForm.get('reportDate').value;
    this.isValidDate = !(moment(date, Constants.dateFormat.yymmddFormat, true).isValid()) ? true : false;
    if (this.isValidDate) {
      this.mailLogForm.get('reportDate').reset();
    }
  }

  resetForm() {
    this.setDate();
    this.selectedAccountInsurers = [];
    this.isValidDate = false;
    this.isClickedButton = false;
    this.mailLogForm.patchValue({
      serviceCenter: MailLogFormsConstants.formsValue.empty,
      insuredJurisdiction: MailLogFormsConstants.formsValue.empty,
      typist: MailLogFormsConstants.formsValue.empty,
      mailType: MailLogFormsConstants.formsValue.s,
      sortBy: MailLogFormsConstants.formsValue.zero,
      mailPostalLogByServiceCenter: this.mailFromBranch
    });
  }

  viewAndPrintForm(formdata) {
    this.mailLogFormService.viewAndPrintForm(formdata).subscribe((response: any) => {
      if (response) {
        this.utilityService.loadFile(response, MailLogFormsConstants.downloaFileName.usps3665);
      }
      this.isClickedButton = false;
    }, async (error) => {
      const message = JSON.parse(await error.error.text()).Message;
      this.showAlert(message);
      this.spinnerService.stop();
    });
  }

  getSelectedInsurers() {
    this.selectedInsurersIds = this.utilityService.getSelectedInsurersids(this.selectedAccountInsurers);
  }

  changeCheckbox(row) {
    const recordId = row.id;
    const status = this.utilityService.changeStatus(row.deletedRecord);
    this.mailLogFormService.mailLogDisable(recordId, status).subscribe((res: any) => {
      this.viewPrintForm(MailLogFormsConstants.viewEditType.view);
    });
  }

  changeView(event) {
    this.gridStatus = event.target.value;
  }
  gridChangeData(girdData) {
    return this.utilityService.gridChangeData(girdData, this.gridStatus);
  }
  rowChangeData(recordStatus) {
    return this.utilityService.rowChangeData(recordStatus, this.gridStatus);
  }

  getDown3665File() {
    this.mailLogFormService.getDown3665File().subscribe(response => {
      if (response) {
        this.utilityService.loadFile(response, MailLogFormsConstants.downloaFileName.USPSForm3665);
      }
    }, async (error) => {
      const message = JSON.parse(await error.error.text()).Message;
      this.showAlert(message);
      this.spinnerService.stop();
    });
  }

  getDown3817File() {
    this.mailLogFormService.getDown3817File().subscribe(response => {
      if (response) {
        this.utilityService.loadFile(response, MailLogFormsConstants.downloaFileName.USPSForm3817);
      }
    }, async (error) => {
      const message = JSON.parse(await error.error.text()).Message;
      this.showAlert(message);
      this.spinnerService.stop();
    });
  }

  getOpenPDFFile() {
    this.mailLogFormService.getOpenPDFFile().subscribe((response: any) => {
      if (response) {
        const file = new Blob([response.body], { type: 'application/pdf' });
        const fileURL = URL.createObjectURL(file);
        window.open(fileURL);
      }
    }, async (error) => {
      const message = JSON.parse(await error.error.text()).Message;
      this.showAlert(message);
      this.spinnerService.stop();
    });
  }

  openMailType() {
    const modalRef = this.modalService.open(KeytoMailTypesComponent);
  }

  getInsurerName(tableData) {
    return this.utilityService.getInsurerName(tableData);
  }

  showAlert(message) {
    this.popupService.showAlert({
      title: this.translate.instant('MESSAGES.Confirmation.alertTitle'),
      message: message,
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: '',
    });
  }

  openUserInstructionFile() {
    const url = environment.appUrl + AppConstants.uiRoutes.maillogFileViewer + AppConstants.routeSeperator +
      MailLogFormsConstants.userInstructionFileName;
    window.open(url);
  }
}
