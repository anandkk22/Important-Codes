import { Injectable } from '@angular/core';
import { MailLogFormsConstants } from '../infrastructure/mail-log-forms-constants';
import { saveAs } from 'file-saver';
import moment from 'moment';
@Injectable()
export class MailLogFormUtilityService {

  constructor() { }

  getSelectedInsurersids(insurers) {
    const insurersIds = [];
    insurers.filter(function(e) {
      insurersIds.push(e.insurerId);
    });
    return insurersIds;
  }

  addAllProperty(data) {
    data.forEach(element => {
      element.all = MailLogFormsConstants.insurers.allInsurers;
    });
    return data;
  }

  loadFile(response: any, filename) {
    saveAs(response.body, filename);
  }

  mailLogDataFilterData(data) {
    const mailLogData = [];
    data.forEach(element => {
        if (element.mailLog.length > 0) {
          element.mailLog.forEach(e => {
            e.mailingDate = moment(e.mailingDate).format(MailLogFormsConstants.dateTimeFormat);
          });
          mailLogData.push(element);
        }
    });
    return mailLogData;
  }

  changeStatus(data) {
    if (data) {
      return false;
    }
    return true;
  }

  gridChangeData(girdData, gridStatus) {
    switch (gridStatus) {
      case MailLogFormsConstants.viewResultsStatus.all:
          return true;
      case MailLogFormsConstants.viewResultsStatus.enabled:
          const enabledResult = [];
          girdData.mailLog.forEach(element => {
              if (element.deletedRecord === false) {
                enabledResult.push(element);
              }
          });
          return enabledResult.length > 0 ? true : false;
      case MailLogFormsConstants.viewResultsStatus.disabled:
          const disabledResult = [];
          girdData.mailLog.forEach(element => {
            if (element.deletedRecord === true) {
              disabledResult.push(element);
            }
          });
          return disabledResult.length > 0 ? true : false;
      default:
          break;
    }
  }

  rowChangeData(recordStatus, gridStatus) {
    switch (gridStatus) {
      case MailLogFormsConstants.viewResultsStatus.all:
          return true;
      case MailLogFormsConstants.viewResultsStatus.enabled:
           return recordStatus ? false : true;
      case MailLogFormsConstants.viewResultsStatus.disabled:
         return recordStatus ? true : false;
      default:
          break;
    }
  }

  getInsurerName(tableData) {
    const name = tableData.name === null || tableData.name === '' ? '' : tableData.name + MailLogFormsConstants.address.commaSpace;
    const address1 = tableData.address1 === null || tableData.address1 === '' ? '' :
    tableData.address1 + MailLogFormsConstants.address.commaSpace;
    const address2 = tableData.address2 === null || tableData.address2 === '' ? '' :
    tableData.address2 + MailLogFormsConstants.address.commaSpace;
    const city = tableData.city === null || tableData.city === '' ? '' : tableData.city + MailLogFormsConstants.address.commaSpace;
    const state = tableData.state === null || tableData.state === '' ? '' : tableData.state + MailLogFormsConstants.address.commaSpace;
    const postalCode = tableData.postalCode === null || tableData.postalCode === '' ? '' : tableData.postalCode;
    return name + address1 + address2 + city + state + postalCode;
  }

}
