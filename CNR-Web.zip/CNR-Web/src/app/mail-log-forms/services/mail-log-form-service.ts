import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { MailLogFormsConstants } from 'app/mail-log-forms/infrastructure/mail-log-forms-constants';
import { Observable } from 'rxjs';
@Injectable()
export class MailLogFormService {
    constructor(private http: HttpClient) { }

    public getAllServiceCenters() {
        return this.http.get(`${MailLogFormsConstants.webApis.getAllServiceCenters}`);
    }
    public getAllAccountInsurers() {
        return this.http.get(`${MailLogFormsConstants.webApis.getAllAccountInsurers}`);
    }

    public viewEditInsurerMailLog(formData) {
        return this.http.post(`${MailLogFormsConstants.webApis.viewEditInsurerMailLog}`, formData);
    }

    public viewAndPrintForm(formData) {
        return this.http.post(`${MailLogFormsConstants.webApis.insurerMailLogUspsForm3665}`,
        formData, { responseType: MailLogFormsConstants.responseType.blobType as 'json', observe: 'response' });
    }

    public getDefaultSettings() {
        return this.http.get(`${MailLogFormsConstants.webApis.getDefaultSettings}`);
    }

    public mailLogDisable(recordId, status) {
        return this.http.put(`${MailLogFormsConstants.webApis.mailLogDisable}`.replace('{recordId}', recordId).replace('{status}', status), '');
    }

    public getDown3665File() {
        return this.http.put(MailLogFormsConstants.webApis.UPPSForm3665BlankCopy, '',
        { responseType: MailLogFormsConstants.responseType.blobType as 'json', observe: 'response' });
    }

    public getDown3817File() {
        return this.http.put(MailLogFormsConstants.webApis.UPPSForm3817BlankCopy, '',
        { responseType: MailLogFormsConstants.responseType.blobType as 'json', observe: 'response' });
    }

    public getOpenPDFFile() {
        return this.http.put(MailLogFormsConstants.webApis.userInstuctions, '',
        { responseType: MailLogFormsConstants.responseType.blobType as 'json', observe: 'response' });
    }
}
