import { environment } from '@env';
export class MailLogFormsConstants {

    static webApis = {
        getAllServiceCenters: environment.apiUrl + 'ServiceCenter',
        getAllAccountInsurers: environment.apiUrl + 'AccountInsurer/ByAccountId',
        viewEditInsurerMailLog: environment.apiUrl + 'InsurerMailLog',
        mailLogDisable: environment.apiUrl + 'MailLog/Disable/{recordId}?isDeleted={status}',
        insurerMailLogUspsForm3665: environment.apiUrl + 'InsurerMailLog/UspsForm3665',
        getDefaultSettings: environment.apiUrl + 'AccountCNRDefault/DefaultSetting',
        UPPSForm3665BlankCopy: environment.apiUrl + 'File/Download?file=cnr4\\(E)USPS_Form_3665.doc',
        UPPSForm3817BlankCopy: environment.apiUrl + 'File/Download?file=cnr4\\(E)USPS_Form_3817.doc',
        userInstuctions:  environment.apiUrl + 'File/Download?file=cnr4\\usps3665instructions.pdf',
        userInstuctionsurl: environment.fillingInfoLink + 'getpdf.asp?filename=usps3665instructions.pdf',
    };

    static dateFormat = {
        formatMMDDYYYY: 'MM/DD/YYYY',
        yymmddFormat: 'YYYY-MM-DD',
    };

    static insurers = {
        allInsurers: 'All Insurers'
    };

    static responseType = {
        blobType: 'blob'
    };

    static downloaFileName = {
        usps3665: 'usps3665',
        getDoc: 'getdoc',
        USPSForm3665: 'USPS_Form_3665',
        USPSForm3817: 'USPS Form 3817',
        usps3665instructions: 'usps3665instructions'
    };

    static viewResults = [
        { name: 'All'},
        { name: 'Enabled'},
        { name: 'Disabled'},
    ];

    static viewResultsStatus = {
        all: 'All',
        enabled: 'Enabled',
        disabled: 'Disabled',
    };

    static viewEditType = {
        view: 'view',
        print: 'print'
    };

    static formsValue = {
        s: 'S',
        zero: '0',
        empty: ''
    };

    static address = {
        comma: ',',
        commaSpace: ', ',
        empty: ''
    };

    static userInstructionFileParams = 'file=usps3665instructions.pdf';
    static userInstructionFileName = 'usps3665instructions.pdf';
    static view = 'view';
    static dateTimeFormat = 'MM/DD/YYYY hh:mm:ss A';
}
