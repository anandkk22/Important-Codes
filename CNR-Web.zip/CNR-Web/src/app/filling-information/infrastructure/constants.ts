import { environment } from '@env';
export class Constants {
    static webApis = {
        downloadFile: environment.filingInfoPath + 'CNR4\\StateFilingInfo.doc',
    };

    static responseType = {
        blobType: 'blob'
    };

    static stateFillingInfoFilename = 'StateFilingInfo.doc';

}
