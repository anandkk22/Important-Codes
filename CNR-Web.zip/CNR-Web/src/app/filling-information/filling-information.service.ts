import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { saveAs } from 'file-saver';
import { Constants } from './infrastructure/constants';

@Injectable()
export class FillingInformationService {

    constructor(private http: HttpClient) { }

    public downloadFile() {
        return this.http.put(`${Constants.webApis.downloadFile}`, '',
            { responseType: Constants.responseType.blobType as 'json', observe: 'response' });
    }

    public loadFile(response: any, fileName: any) {
        saveAs(response.body, fileName);
    }
}
