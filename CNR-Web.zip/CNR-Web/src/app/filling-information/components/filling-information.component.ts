import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { FillingInformationService } from '../filling-information.service';
import { Constants } from '../infrastructure/constants';

@Component({
    selector: 'filling-information',
    template: ``
})

export class FillingInformationComponent implements OnInit {

    constructor(
        private fillingInformationService: FillingInformationService,
        private spinnerService: SpinnerService,
        private popupService: PopupService,
        private translate: TranslateService) { }

    ngOnInit() {
        this.fillingInformationService.downloadFile().subscribe(response => {
            if (response) {
                this.fillingInformationService.loadFile(response, Constants.stateFillingInfoFilename);
                setTimeout(() => {
                    window.close();
                }, 500);
            }
        }, async (error) => {
            const message = JSON.parse(await error.error.text()).Message;
            this.showAlert(message);
            this.spinnerService.stop();
        });
    }

    showAlert(message) {
        this.popupService.showAlert({
            title: this.translate.instant('MESSAGES.Confirmation.alertTitle'),
            message: message,
            positiveLabel: this.translate.instant('BUTTON.ok_button'),
            negativeLabel: '',
        });
    }
}
