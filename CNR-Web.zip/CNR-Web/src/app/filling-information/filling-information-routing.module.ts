import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { FillingInformationComponent } from './components/filling-information.component';


const routes: Routes = [
  {
    path: AppConstants.uiRoutes.empty,
    component: FillingInformationComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class FillingInformationRoutingModule { }
