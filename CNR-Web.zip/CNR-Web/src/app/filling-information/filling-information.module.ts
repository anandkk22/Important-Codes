import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NilsSharedModule } from '@wk/nils-shared';
import { environment } from '@env';
import { FillingInformationRoutingModule} from './filling-information-routing.module';
import { FillingInformationComponent } from './components/filling-information.component';
import { FillingInformationService } from './filling-information.service';


@NgModule({
  declarations: [
    FillingInformationComponent
  ],
  imports: [
    CommonModule,
    FillingInformationRoutingModule,
    NilsSharedModule.loadConfig({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      commonApiUrl: '',
      userGroupURL: '',
      feedbackEmail: environment.feedbackEmail,
      customerCareEmail: environment.customerCareEmail,
      productUrl: environment.productUrl
    })
  ],
  providers: [FillingInformationService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class FillingInformationModule { }
