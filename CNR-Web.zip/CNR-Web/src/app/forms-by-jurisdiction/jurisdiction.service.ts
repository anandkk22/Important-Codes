import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Constants } from './infrastructure/constants';
import { saveAs } from 'file-saver';
import { TranslateService } from '@ngx-translate/core';

@Injectable()
export class JurisdictionService {

    constructor(private http: HttpClient,
        private translate: TranslateService) { }

    public getJurisdictionDetails() {
        return this.http.get(`${Constants.webApis.getJurisdictionDetails}`);
    }

    downloadFile(formattedPath) {
        return this.http.put(`${Constants.webApis.downloadFile}`.replace('{fileName}', formattedPath), '',
            { responseType: Constants.responseType.blobType as 'json', observe: 'response' });
    }

    formatResponse(response) {
        response.formsByStates = this.geFormattedCodes(response.formsByStates);
        response.genericIntrestAdditionalForms = this.geFormattedCodes(response.genericIntrestAdditionalForms);
        const groupedByStateName = response.formsByStates.reduce(function (r, a) {
            r[a.stateName] = r[a.stateName] || [];
            r[a.stateName].push(a);
            return r;
        }, Object.create(null));

        groupedByStateName.genericIntrestAdditionalForms = this.getFormattedGenericIntrest(response.genericIntrestAdditionalForms);

        return groupedByStateName;
    }

    getFormattedGenericIntrest(genericIntrestAdditionalForms) {
        genericIntrestAdditionalForms.forEach(element => {
            element.stateCode = this.translate.instant('FORMS_BY_JURISDICTIONS.gen');
        });

        return genericIntrestAdditionalForms;
    }

    geFormattedCodes(response) {
        response.forEach(element => {
            if (element.codes) {
                const splittedCodes = element.codes.split(',');
                delete element.codes;
                element.codes = splittedCodes;
            }
        });
        return response;
    }

    getStateCodes(jurisdictionDetails) {
        const jurisdictions = [];
        Object.keys(jurisdictionDetails).forEach(key => {
            const stateCode = jurisdictionDetails[key] && jurisdictionDetails[key][0] && jurisdictionDetails[key][0].stateCode;
            jurisdictions.push(stateCode);
        });

        return jurisdictions;
    }

    loadFile(response: any, fileName: any) {
        saveAs(response.body, fileName);
    }

}
