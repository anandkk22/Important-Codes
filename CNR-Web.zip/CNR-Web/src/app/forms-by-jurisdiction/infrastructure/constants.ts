import { environment } from '@env';
export class Constants {

    static webApis = {
        getJurisdictionDetails : environment.apiUrl + 'Form/ByState',
        downloadFile: environment.apiUrl + 'File/Download?file={fileName}'
    };

    static responseType = {
        blobType: 'blob'
    };

    static policyCodes = 'CNR4\\policycodes.doc';

    static genericIntrestAdditionalForms = 'genericIntrestAdditionalForms';

    static policyFilename = 'policycodes.doc';

}
