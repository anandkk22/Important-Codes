import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { JurisdictionComponent } from './components/jurisdiction.component';

const routes: Routes = [
  {
    path: AppConstants.uiRoutes.empty,
    component: JurisdictionComponent
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class JurisdictionRoutingModule { }
