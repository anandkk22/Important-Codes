import { Component, OnInit, OnDestroy } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { Subscription } from 'rxjs';
import { Constants } from '../infrastructure/constants';
import { JurisdictionService } from '../jurisdiction.service';

@Component({
    selector: 'forms-by-jurisdiction',
    templateUrl: './jurisdiction.component.html',
    styleUrls: ['./jurisdiction.component.scss']
})

export class JurisdictionComponent implements OnInit, OnDestroy {

    activeSubscription: Subscription;
    isDataAvaliable: Boolean = false;
    jurisdictionDetails = [];
    stateCodes = [];
    policyCodes = Constants.policyCodes;
    hoverIndex = -1;
    stateIndex = -1;

    constructor(
        private jurisdictionService: JurisdictionService,
        private translate: TranslateService,
        private spinnerService: SpinnerService,
        private popupService: PopupService
    ) { }

    ngOnInit() {
        this.getJurisdictionDetails();
    }

    getJurisdictionDetails() {
        this.activeSubscription = this.jurisdictionService.getJurisdictionDetails().subscribe((res: any) => {
            const formattedResponse = this.jurisdictionService.formatResponse(res);
            this.jurisdictionDetails = formattedResponse;
            this.stateCodes = this.jurisdictionService.getStateCodes(formattedResponse);
            this.isDataAvaliable = true;
        });

    }

    scrollToState(state) {
        document.getElementById(state).scrollIntoView({
            behavior: 'smooth'
        });
    }

    downloadForm(filePath, fileName) {
        this.jurisdictionService.downloadFile(filePath).subscribe(response => {
            if (response) {
                this.jurisdictionService.loadFile(response, fileName);
            }
        }, async (error) => {
            const message = JSON.parse(await error.error.text()).Message;
            this.showAlert(message);
            this.spinnerService.stop();
        });
    }

    downloadPolicyCode(filePath) {
        this.jurisdictionService.downloadFile(filePath).subscribe(response => {
            this.jurisdictionService.loadFile(response, Constants.policyFilename);
        }, async (error) => {
            const message = JSON.parse(await error.error.text()).Message;
            this.showAlert(message);
            this.spinnerService.stop();
        });
    }

    getKeyName(key) {
        return key === Constants.genericIntrestAdditionalForms ? this.translate.instant('FORMS_BY_JURISDICTIONS.genericForms') : key;
    }

    ngOnDestroy() {
        this.activeSubscription.unsubscribe();
    }

    showAlert(message) {
        this.popupService.showAlert({
            title: this.translate.instant('MESSAGES.Confirmation.alertTitle'),
            message: message,
            positiveLabel: this.translate.instant('BUTTON.ok_button'),
            negativeLabel: '',
        });
    }

    over(hoverIndex, stateIndex) {
        this.hoverIndex = hoverIndex;
        this.stateIndex = stateIndex;
    }

    out() {
        this.hoverIndex = -1;
        this.stateIndex = -1;
    }
}
