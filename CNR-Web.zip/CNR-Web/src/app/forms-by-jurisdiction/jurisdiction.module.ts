import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NilsSharedModule } from '@wk/nils-shared';
import { environment } from '@env';
import { JurisdictionRoutingModule } from './jurisdiction-routing.module';
import { JurisdictionComponent } from './components/jurisdiction.component';
import { JurisdictionService } from './jurisdiction.service';


@NgModule({
  declarations: [
    JurisdictionComponent
  ],
  imports: [
    CommonModule,
    JurisdictionRoutingModule,
    NilsSharedModule.loadConfig({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      commonApiUrl: '',
      userGroupURL: '',
      feedbackEmail: environment.feedbackEmail,
      customerCareEmail: environment.customerCareEmail,
      productUrl: environment.productUrl
    })
  ],
  providers: [JurisdictionService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class JurisdictionModule { }
