import { TestBed, waitForAsync } from '@angular/core/testing';
import { AppComponent } from './app.component';
describe('AppComponent', () => {
  let component: AppComponent;

  const loggerService = {
    info: (x) => { },
    error: (x) => { }
  };

  const translateService = {
    addLangs: (x) => { },
    setDefaultLang: (x) => { },
    use: (x) => { },
    getBrowserLang: () => {
      return '';
    },

  };

  const sharedService = {
    get _sharedData() {
      return '';
    }
  };

  const routerMock = jasmine.createSpyObj('Router', ['navigate']);
  const authMock = jasmine.createSpyObj('AuthService', ['isUserLoggedIn']);

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  }));

  beforeEach(() => {
    component = new AppComponent(loggerService as any, translateService as any,
      routerMock, sharedService as any);
  });

  it('should create app component instance', () => {
    expect(component).toBeTruthy();
  });
});
