import { Injectable } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { HeaderData } from '@global/infrastructure/authentication.model';
import { Constants } from '@global/infrastructure/constants';
import { AppConstants } from 'app/app.constants';
import { BehaviorSubject } from 'rxjs';
import { SharedDataService } from './shared-data.service';

@Injectable()
export class AccessService {
  isAccess = new BehaviorSubject<boolean>(true); // This is for product repository
  headerDisplay = new BehaviorSubject<HeaderData>({ canDisplayHeader: true, isUserAuthenticated: false });
  userInfo: any;
  activeTabCode: string;


  constructor(private titleService: Title, private _sharedService: SharedDataService) { }

  canViewPage() {
    // check if allowed pages are present in the user selected product
    if (Constants.allowedPages.indexOf(window.location.pathname.toLowerCase()) > -1 &&
        window.location.href.indexOf(AppConstants.uiRoutes.xmlFeed) === -1) {
      // if yes then return true
      this.headerDisplay.next({ canDisplayHeader: true });
      // TODO: 'Is this iacess flag value correct'
      this.isAccess.next(false);
      return true;
    } else {
      // user is not authenticated and does not comes inside allowed pages
      this.isAccess.next(false);
      this._sharedService.redirectToTargetUrl();
      return false;
    }
  }

  isUserAuthorized() {
    this.userInfo = this._sharedService.getUserInfo();
    // Check if userinfo is present if yes it means user is authenticated check for access
    if (this.userInfo.subscriptions.length > 0) {

      // check for access and if access is there or not just return
      this.activeTabCode = this.getActiveTabCode();
      // user is authenticated and user has access
      if (this.userInfo.subscriptions.indexOf(this.activeTabCode) > -1) {
        this.headerDisplay.next({ canDisplayHeader: true, isUserAuthenticated: true });
        return true;
      } else {

        // user is authenticated but user does not have access
        this.headerDisplay.next({ canDisplayHeader: false, isUserAuthenticated: true });
        this.isAccess.next(false);
        return false;
      }

    } else {

      // if user info is not present user is not authenticated.... check for allowed pages
      return this.canViewPage();
    }
  }

  getActiveTabCode() {
    const tabName = this.titleService.getTitle();
    if (Constants.tabTitles.includes(tabName)) {
      return Constants.subscriptionCodes.cnr;
    }
  }
}
