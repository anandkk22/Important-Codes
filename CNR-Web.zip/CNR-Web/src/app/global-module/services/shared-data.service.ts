import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { AuthService, LoggerService, SpinnerService } from '@core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Constants } from '@global/infrastructure/constants';
import { environment } from '@env';
import { UserInfoMock } from 'assets/Infrastructure/user-info-mock';
import { AppConstants } from 'app/app.constants';
import { Observable } from 'rxjs';
import { APITokenModel } from '@global/infrastructure/authentication.model';
@Injectable()
export class SharedDataService {
  private _sharedData = {};

  // todo : should be deleted along with local env block in populateCommonData when portal App is setup on developers machine
  API_TOKEN = '322BD1586FCEC95EC373E9F03B1C855ECB53C15AD10DD5C1A15A83D8D51046BF';
  queryCode;
  constructor(
    private logger: LoggerService,
    private authService: AuthService,
    private httpClient: HttpClient,
    private _spinnerService: SpinnerService,
  ) {
    this.logger.info('SharedDataService : constructor ');
  }

  populateCommonData(): Promise<any> {
    // Condition to mock the userInfo for local development
    if (environment.environmentName === 'Local') {
      this._sharedData = UserInfoMock;
      this.authService.setUserData(this._sharedData);
      this.authService.setAPIToken(this.API_TOKEN);
      this.getAntiforgeryToken().subscribe((token) => {
        // Temporary commented CSRF changes, Do not uncomment
        // this.getCnrAntiforgeryToken().subscribe((cnrToken) => {
          this.getConfigData().subscribe((data) => {
            environment.feedbackEmail = data['feedbackEmail'];
            environment.phoneNumber = data['customerCarePhone'];
            environment.customerCareEmail = data['customerCareEmail'];
          });
        // });
      });

    } else {
      this._spinnerService.start();
      this.logger.info('SharedDataService : populateCommonData ');
      return new Promise<any>((resolve) => {
        this.httpClient.get(`${Constants.webApis.getUserInfo}`)
          .subscribe(
            (successResponse: any) => {
              this._sharedData = successResponse;
              this.logger.info(
                'SharedDataService : populateCommonData : successResponse ' +
                successResponse
              );
              this.getAntiforgeryToken().subscribe((token) => {
                // Temporary commented CSRF changes, Do not uncomment
                // this.getCnrAntiforgeryToken().subscribe((cnrToken) => {
                this.getConfigData().subscribe((data) => {
                  environment.feedbackEmail = data['feedbackEmail'];
                  environment.phoneNumber = data['customerCarePhone'];
                  environment.customerCareEmail = data['customerCareEmail'];
                  this._spinnerService.stop();
                  this.authService.setUserData(this._sharedData);
                  resolve(true);
                });
                // });
              });
            },
            (error) => {
              this._sharedData = UserInfoMock;
              this._spinnerService.stop();
              this.authService.setUserData(this._sharedData);
              resolve(true);

              this.logger.info('SharedDataService : populateCommonData : Failed to get user info -' + error.message);
              throw new Error(error.message);
            });
      });
    }
  }

  getAntiforgeryToken() {
    const result = this.httpClient.get(`${Constants.webApis.antiForgeryToken}`);
    if (result) {
      return result;
    }
    return new Observable();
  }

  redirectToTargetUrl() {
    const reqParams = {
      RedirectUri: `${window.location.href}`,
      ClientId: environment.cnrPreview ? AppConstants.authData.cnrPreviewClientId : AppConstants.authData.cnrClientId
    };
    this.getTargetUrl(reqParams).subscribe((result: any) => {
      if (result && result.target) {
        window.location.replace(`${environment.portalUrl}${result.target}`);
      }
    });
  }

  getTargetUrl(reqParams) {
    const result = this.httpClient.post(`${Constants.webApis.targetRedirect}`, reqParams);
    if (result) {
      return result;
    }
    return new Observable();

  }

  getUserInfo() {
    return this._sharedData;
  }

  setUserInfo(data) {
    this._sharedData = data;
  }

  handleError(errorResponse: any) {
    this.logger.info(
      '****** SharedDataService : populateCommonData : server returned error'
    );
    this.logger.info('errorResponse : ' + errorResponse);
  }

  getConfigData() {
    const result = this.httpClient.get(`${Constants.webApis.getConfigData}`);
    if (result) {
      return result;
    }
    return new Observable();
  }

  getCnrAntiforgeryToken() {
    const result = this.httpClient.get(`${Constants.webApis.cnrAntiForgeryToken}`);
    if (result) {
      return result;
    }
    return new Observable();
  }
}
