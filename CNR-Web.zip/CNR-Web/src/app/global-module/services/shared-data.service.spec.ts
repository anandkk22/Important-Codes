
import { SharedDataService } from './shared-data.service';

describe('SharedData Service ', () => {
    let sharedDataService: SharedDataService;

    const loggerService = {
        info: (x) => {
        }
    };

    const authService = {
        isUserLoggedIn: (value: boolean = true) => {
            return value;
        },
        setUserData: (x: any) => {
            return x;
        }
    };

    const utilityService = {
        reload: () => {
            return {};
        }
    };

    const apiService = {
        get: (x) => {
            return {
                subscribe: (y) => { y(); },
            };

        }
    };

    beforeEach(() => {
        sharedDataService = new SharedDataService(loggerService as any, authService as any, utilityService as any, apiService as any);
    });

    it('should create shared-data service instance', () => {
        expect(sharedDataService).toBeTruthy();
    });
});



