import { environment } from './../../../environments/environment';
import { Injectable } from '@angular/core';
import {
  CanActivate,
  Router,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  ResolveEnd
} from '@angular/router';

import {
  LoggerService,
  AuthService
} from '@core';
import { AppConstants } from 'app/app.constants';
import { AccessService } from './access.service';
import { SharedDataService } from './shared-data.service';
@Injectable()
export class AuthGuardService implements CanActivate {
  userInfo: any;
  isUserLoggedIn: boolean;

  constructor(
    private _router: Router,
    private _logger: LoggerService,
    private _authService: AuthService,
    private accessService: AccessService,
    private _sharedService: SharedDataService) {
    this._logger.info('AuthGuard : constructor ');
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    this.isUserLoggedIn = this._authService.isUserLoggedIn();
    const userInfo: any = this._sharedService.getUserInfo();
    if (this.accessService.isUserAuthorized()) {

      this._router.events.subscribe((routerData) => {
        if (routerData instanceof ResolveEnd) {
          if (routerData.url.includes('Hub')) {
            window.location.href = environment.portalUrl + routerData.url.substring(1);
          }
        }
      });

      if (window.location.href.includes(AppConstants.adminMenu)) {
        if (!userInfo.is_cnr_administrator) {
          this._router.navigate([AppConstants.uiRoutes.unauthorizedAdmin]);
          return false;
        }
      }

      return true;
    } else {
      return false;
    }
  }
}
