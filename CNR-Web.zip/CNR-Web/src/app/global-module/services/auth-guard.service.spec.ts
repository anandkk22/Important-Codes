import { AuthGuardService } from './auth-guard.service';

describe('AuthGuard Service', () => {
    let authGuard: AuthGuardService;
    const routerMock = jasmine.createSpyObj('Router', ['navigate']);
    const authMock = jasmine.createSpyObj('AuthService', ['isUserLoggedIn']);

    const loggerService = {
        info: (x) => { }
    };

    const token = { roleId: 2 };

    const user: any = {
        sessionId: 'sasass',
        userName: 'username',
        userId: 1,
        firstName: 'aaas',
        lastName: 'ssaas',
        entityName: 'wqqw',
        entityId: 1,
        role: 1,
        token
    };
    const sharedService = {
        get _sharedData() {
            return user;
        }
    };
    const authService = {
        isUserLoggedIn: (value: boolean = true) => {
            return value;
        }
    };
    beforeEach(() => {
        authGuard = new AuthGuardService(routerMock, loggerService as any, authMock, sharedService as any);
    });

    it('should create auth-guard service instance', () => {
        expect(authGuard).toBeTruthy();
    });
});
