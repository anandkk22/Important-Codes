export class HeaderData {
  canDisplayHeader?: boolean;
  isUserAuthenticated?: boolean;
}

export class APITokenModel {
  access_token: string;
  expires_in: any;
  token_type: string;
  scope: string;
}
