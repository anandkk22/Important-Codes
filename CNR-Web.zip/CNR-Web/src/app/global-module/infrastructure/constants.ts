import { environment } from '../../../environments/environment';


export class Constants {

  static uiRoutes = {
    login: 'login',
    shop: 'shop',
    cart: 'cart'
  };

  static cnrPath = '/cnr/';

  static targetKey = {
    insource: 'insource',
    caseLaw: 'caseLaw'
  };

  static businessExceptions = {
    SessionExpired: 'SessionExpired',
    SessionKilled: 'SessionKilled',
    ErrorCode: 'ErrorCode',
    MessageCode: 'MessageCode'
  };

  static webApis = {
    getUserInfo: environment.portalUrl + 'Webservices/API/ICSAuth/connect/SessionUserInfo',
    targetRedirect: environment.portalUrl + 'Webservices/API/ICSAuth/connect/TargetRedirect',
    redirectAPI: environment.portalUrl + 'index.aspx?Target=',
    getTokenForAPI: environment.portalUrl + 'Webservices/API/ICSAuth/connect/token',
    getConfigData: environment.commonApiUrl + 'FrontendConfig',
    imageUrl: 'assets/Images/WKLogo.png',
    antiForgeryToken: environment.apiUrl + 'AntiForgery/Token',
    getStaticFilePath: environment.portalUrl + 'cnr/assets/files/',
    cnrAntiForgeryToken: environment.wkApiUrl + 'antiForgery/token'
  };

  static fileTypes = {
    msexcel: 'application/ms-excel',
    excelExtension: '.xls',
  };

  static excelFile = {
    downloadExcel: 'download-excel'
  };

  static keepLeadingZero = {
    start: '=\"',
    end: '\"\t',
    empty: ''
  };

  static queryString = {
    SessionExpired: 'SessionExpired=true'
  };

  static localStorageKeys = {
    sessionId: 'sessionId'
  };

  static cookies =
    {
      sessionId: 'SessionId',
      apiContext: 'apiContext'
    };

  static allowedPages = ['/insource/bookmark', '/insource/insource.asp', '/insource/showdoc.asp', '/insource/citedisplay.asp', '/insource/jurisdictions-value-added-table', '/', '/insource', '/insource/'];

  static subscriptionCodes = {
    cnr: 'CNRV4'
  };

  static productNameWithCode = {
    cnr: 'CNR'
  };

  static pendoData = {
    'Email': '',
    'NilsPlatformRole': 'User',
    'CNRRole': 'None',
    'AccountID': 'WKFS',
    'AccountName': 'Wolters Kluwer Financial Services',
    'AccountType': 'Internal Account',
    'SoldToID': undefined,
    'SoldToName': undefined
  };

  static headerOptions = [
    {
      key: 'criteriaSelection',
      canviewInNewTab: false,
      title: 'Criteria Selection',
      isActive: false,
      url: 'notice-generation/criteria-selection',
      class: 'wk-nav-item',
      tab_title: 'Cancellation and Nonrenewal- Fill Form'
    },
    {
      key: 'filingInformation',
      canviewInNewTab: true,
      title: 'Filing Information',
      isActive: false,
      url: 'filling-information',
      class: 'wk-nav-item'
    },
    {
      key: 'mailLogForm',
      canviewInNewTab: true,
      title: 'Mail Log/Forms',
      url: 'mail-log-forms',
      isActive: false,
      class: 'wk-nav-item',
      tab_title: 'Cancellation and Nonrenewal- Mail Log/Forms'
    },
    {
      key: 'administratorMenu',
      canviewInNewTab: true,
      title: 'Administrator Menu',
      isActive: false,
      url: 'admin-menu',
      class: 'wk-nav-item',
      tab_title: 'Cancellation and Nonrenewal- Administrator Menu',
      subUrls: [
        'admin-menu/additional-interests',
        'admin-menu/lienholders',
        'admin-menu/certificate-holders',
        'admin-menu/mortgagees',
        'admin-menu/insurers',
        'admin-menu/producers',
        'admin-menu/service-centers',
        'admin-menu/records-report',
        'admin-menu/purge-parameters',
        'admin-menu/days-notice-requirements',
        'admin-menu/signature-files',
        'admin-menu/default-settings',
        'admin-menu/editions-by-jurisdiction',
        'admin-menu/custom-lob',
        'admin-menu/signature-mappings',
        'admin-menu/signature-lists',
        'admin-menu/maintain-reasons',
        'admin-menu/purge-mail-logs',
        'admin-menu/upload-producers'
      ]
    },
    {
      key: 'formsByJuridiction',
      canviewInNewTab: true,
      title: 'Forms by Jurisdiction',
      isActive: false,
      url: 'forms-by-jurisdiction',
      class: 'wk-nav-item',
      tab_title: 'Cancellation and Nonrenewal- Forms By Jurisdiction'
    },
    {
      key: 'signupForTraining',
      canviewInNewTab: true,
      title: 'Sign up for Training',
      class: 'wk-nav-item',
      isActive: false,
      url: 'https://attendee.gototraining.com/rt/907261329511685121'
    }
  ];

  static adminMenus = [
    {
      addIntCertHoldLineHoldMorgMaxCharacters: {
        name: 96,
        address1: 50,
        address2: 50,
        city: 50,
        jurisdiction: 2,
        postalCode: 10,
        code: 50,
      }
    },
    {
      serviceCenterMaxCharacters: {
        name: 50,
        address1: 50,
        address2: 50,
        city: 50,
        jurisdiction: 2,
        postalCode: 10,
        code: 50,
      }
    },
    {
      insurerMaxCharacters: {
        name: 255,
        address1: 50,
        address2: 50,
        city: 255,
        jurisdiction: 2,
        postalCode: 50,
        code: 10,
      }
    },
    {
      producerMaxCharacters: {
        name: 96,
        address1: 50,
        address2: 50,
        city: 50,
        jurisdiction: 2,
        postalCode: 50,
        code: 20,
      }
    }
  ];

  static recordsReportLength = {
    recordReportLength: 4000,
  };

  static dateFormat = {
    format: 'MM/dd/yyyy',
    yymmddFormat: 'YYYY-MM-DD',
    excelDateFormat: 'MM-dd-yyyy',
  };

  static pageSizes = [500, 1000, 1500];
  static cnrApi = 'CNRV4.API';
  static rowColor: any;

  static xlFileExtensions = {
    xls: 'xls',
    xlsx: 'xlsx',
  };

  static sizeTwoHundred = [200, 400, 600];

  static cnrPreviewPath = '/preview/cnr/';

  static paginationBar = '#pagination-bar-dynamic .wk-field-select';

  static responseError = {
    fourTwoTwo: 422
  };

  static pagination = {
    pageNo: 1,
    pageSize: 200
  };

  static paginationOptions = {
    currentPage: 1,
    pageSize: 200,
    totalItems: 100,
  };

  static tabTitles = ['CNR - Welcome', 'Cancellation and Nonrenewal- Fill Form',
      'Cancellation and Nonrenewal- Mail Log/Forms', 'Cancellation and Nonrenewal- Administrator Menu',
      'Cancellation and Nonrenewal- Forms By Jurisdiction',
      'Cancellation and Nonrenewal- Maintain Additional Interests',
      'Cancellation and Nonrenewal- Maintain Certificate Holders',
      'Cancellation and Nonrenewal- Maintain Insurers',
      'Cancellation and Nonrenewal- Maintain Lienholders',
      'Cancellation and Nonrenewal- Maintain Mortgagees',
      'Cancellation and Nonrenewal- Maintain Producers',
      'Cancellation and Nonrenewal- Maintain Service Centers',
      'Cancellation and Nonrenewal- Maintain API Tokens',
      'Cancellation and Nonrenewal- Maintain Custom Footers',
      'Cancellation and Nonrenewal- Maintain Customized Lines of Business',
      'Cancellation and Nonrenewal- Maintain Days Notice Requirements',
      'Cancellation and Nonrenewal- Maintain Default Settings',
      'Cancellation and Nonrenewal- Maintain Form Editions by Jurisdiction',
      'Cancellation and Nonrenewal- Records Report',
      'Cancellation and Nonrenewal- User Maintenance Table',
      'Cancellation and Nonrenewal- Maintain Signature Files',
      'Cancellation and Nonrenewal- Maintain Signature Mappings',
      'Cancellation and Nonrenewal- Configure Purge Parameters',
      'Cancellation and Nonrenewal- Prepare to Purge All Mail Log Records',
      'Cancellation and Nonrenewal- Maintain Reasons',
      'Cancellation and Nonrenewal- Circumstance Definitions'
    ];

    static maintainReasonsPageSizes = [5000, 10000, 15000];

    static somethingWentWrongOldMsg = 'Sorry. Looks like something went wrong on our end. Please try again.';

    static somethingWentWrongNewMsg  = 'It appears there is a problem loading this page. Please click the back arrow or log out and try again.' +
    ' If you continue to encounter this issue, please contact ${customerCare}. \n We apologize for the inconvenience.';
}
