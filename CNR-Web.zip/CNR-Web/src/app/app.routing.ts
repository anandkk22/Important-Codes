import { NgModule } from '@angular/core';
import { Routes, RouterModule, ExtraOptions } from '@angular/router';
import { PageNotFoundComponent } from 'app/home/page-not-found/page-not-found.component';
import { AuthGuardService } from '@global';
import { UnauthorizeComponent } from 'app/home/unauthorize/unauthorize.component';
import { AppConstants } from 'app/app.constants';
import { HomeComponent } from './home/home.component';
import { UnauthorizeAdminAccessComponent } from './admin/components/unauthorize-admin-access/unauthorize-admin-access.component';
import { FileViewerComponent } from './home/file-viewer/file-viewer.component';

const routerOptions: ExtraOptions = {
  scrollPositionRestoration: 'enabled',
  anchorScrolling: 'enabled',
  scrollOffset: [0, 64],
  relativeLinkResolution: 'legacy'
};

const appRoutes: Routes = [
  {
    path: AppConstants.uiRoutes.empty,
    redirectTo: AppConstants.uiRoutes.noticeGeneration,
    pathMatch: AppConstants.uiRoutes.pathMatch
  },
  {
    path: AppConstants.uiRoutes.cnr,
    redirectTo: AppConstants.uiRoutes.noticeGeneration,
    pathMatch: AppConstants.uiRoutes.pathMatch
  },
  {
    path: AppConstants.uiRoutes.CNR,
    redirectTo: AppConstants.uiRoutes.noticeGeneration,
    pathMatch: AppConstants.uiRoutes.pathMatch
  },
  {
    path: AppConstants.uiRoutes.cnrCNR,
    redirectTo: AppConstants.uiRoutes.noticeGeneration,
    pathMatch: AppConstants.uiRoutes.pathMatch
  },
  {
    path: AppConstants.uiRoutes.noticeGeneration,
    loadChildren: () => import('./notice-generation/notice-generation.module').then(m => m.NoticeGenerationModule)
  },
  {
    path: AppConstants.uiRoutes.mailLogForms,
    loadChildren: () => import('./mail-log-forms/mail-log-forms.module').then(m => m.MailLogFormsModule)
  },
  {
    path: AppConstants.uiRoutes.adminMenu,
    loadChildren: () => import('./admin/admin.module').then(m => m.AdminModule)
  },
  {
    path: AppConstants.uiRoutes.formsByJurisdiction,
    loadChildren: () => import('./forms-by-jurisdiction/jurisdiction.module').then(m => m.JurisdictionModule)
  },
  {
    path: AppConstants.uiRoutes.fillingInformation,
    loadChildren: () => import('./filling-information/filling-information.module').then(m => m.FillingInformationModule)
  },
  {
    path: AppConstants.uiRoutes.welcome,
    component: HomeComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.fileViewer,
    component: FileViewerComponent,
    children: [
      { path: '**', component: FileViewerComponent }
    ]
  },
  // {
  //   path: AppConstants.uiRoutes.welcome,
  //   component: HomeComponent,
  //   canActivate: [AuthGuardService]
  // },
  {
    path: AppConstants.uiRoutes.unauthorized,
    component: UnauthorizeComponent
  },
  {
    path: AppConstants.uiRoutes.unauthorizedAdmin,
    component: UnauthorizeAdminAccessComponent
  },
  {
    path: '**',
    component: PageNotFoundComponent,
    // canActivate: [AuthGuardService]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes, routerOptions)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
