import { environment } from '@env';

export class AppConstants {

  static ngxTranslateConfig = {
    supportedBrowserLanguages : [ 'en' ],
    fallbackBrowserLanguage : 'en'
  };

  static uiRoutes = {
    empty: '',
    pathMatch: 'full',
    unauthorized: 'unauthorized',
    unauthorizedAdmin: 'admin-menu/unauthorized',
    welcome: 'welcome',
    xmlFeed: 'xmlfeed',
    fillForm: 'fill-form',
    noticeGeneration: 'notice-generation',
    criteriaSelection: 'criteria-selection',
    adminMenu: 'admin-menu',
    circumDefinitions: 'circumstance-definitions',
    additionalInterests: 'additional-interests',
    insurers: 'insurers',
    circumstancesDefinitions: 'circumstance-definitions',
    lienHolders: 'lienholders',
    certificateholders: 'certificate-holders',
    serviceCenters: 'service-centers',
    producers: 'producers',
    mortgagees: 'mortgagees',
    premiumAdjustment: 'premium-adjustment',
    recordsReport: 'records-report',
    purgeParameters: 'purge-parameters',
    signatureFiles: 'signature-files',
    daysNoticeRequirements: 'days-notice-requirements',
    defaultSettings: 'default-settings',
    editionsByJurisdiction: 'editions-by-jurisdiction',
    formsByJurisdiction: 'forms-by-jurisdiction',
    addEditForm: 'add-edit-form',
    supplementalDynamicForm: 'supplemental-dynamic-form',
    mailLogForms: 'mail-log-forms',
    customizedLOB: 'custom-lob',
    signatureMappings: 'signature-mappings',
    signatureLists: 'signature-lists',
    customFooters: 'custom-footers',
    maintainReasons: 'maintain-reasons',
    purgeMailLog: 'purge-mail-logs',
    lookupDate: 'look-up',
    uploadProducers: 'upload-producers',
    cnr: 'cnr',
    CNR: 'CNR',
    cnrCNR: 'cnr/CNR',
    fillingInformation: 'filling-information',
    fileViewer: 'display-file',
    maillogFileViewer: 'display-file/user-instruction',
    recordsReportGrid: 'record-reports-results',
    documentLink: 'display-file/document-link',
    downloadPurgeMailLog: 'download-purge-mail-log',
  };

  static authData = {
    productHomeRoute: environment.productUrl,
    productName: 'cnr',
    cnrClientId: '9957BBA5-1D0D-4D55-BD34-3E57F909CE52',
    cnrPreviewClientId : '9957BBA5-1D0D-4D55-BD34-3E57F909CE52' // To DO - Need client id for cnr-preview app from wk team
  };

  static wkApiUrl = {
    url: environment.portalUrl + '/webservices/api/cnr/v1/'
  };

  static maintainApiToken = environment.portalUrl + 'ManageTokens.aspx';

  static circumstanceDefUrl = 'notice-generation/circumstance-definitions';

  static wkLogoImgName = 'medium.svg';

  static assetPath = 'https://cdn.wolterskluwer.io/wk/fundamentals/1.x.x/logo/assets/';

  static adminMenu =  'admin-menu';

  static userMaintenancePageLink = environment.portalUrl + 'UserAdmin.aspx';

  static downloadFile = 'Display file';

  static routeSeperator = '/';

  static querySeperator = '?';

  static recordReportsURL = 'admin-menu/record-reports-results';

  static downloadPurgeMailLogURL = 'admin-menu/download-purge-mail-log';

  static mailLogDownload = {
    oneExcelFileLimit: 20000,
    apiRequestLimit: 20000,
    downloadExcelLimit: 100000,
    start: 'start',
    end: 'end',
    threeDots: ' ...',
    slash: '/',
    accountNo: '?accountNo=',
    startDate: '&startDate=',
    endDate: '&endDate=',
    totalcount: '&totalcount=',
    windowSize: 'left=0,top=0,width=700,height=400,toolbar=1,resizable=1',
    purge: 'purge',
    of: ' of ',
    minTime: 200,
    maxTime: 70000
  };

  static zero = 0;

}
