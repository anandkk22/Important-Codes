import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { NoticeGenerationRoutingModule } from './notice-generation-routing.module';
import { CriteriaSelectionComponent } from './components/criteria-selection/criteria-selection.component';
import { CriteriaSelectionService } from './service/criteria-selection.service';
import { FormlyModule } from '@ngx-formly/core';
import { FormlyBootstrapModule } from '@ngx-formly/bootstrap';
import { DropdownComponent } from './custom-template-components/field-types/dropdown/dropdown.component';
import { NilsSharedModule } from '@wk/nils-shared';
import { environment } from '@env';
import { CircumstanceDefinitionComponent } from './components/circumstance-definition/circumstance-definition.component';
import { DynamicFormValidationService } from 'app/notice-generation/service/dynamic-form-validation.service';
import { validationDetails } from './model/dynamic-form.model';
import { ReasonTextModalComponent } from './components/reason-text/reason-text-modal.component';
import { DynamicFormHttpService } from './service/dynamic-form-http.service';
import { DynamicFormService } from './service/dynamic-form.service';
import { PremiumAdjustmentSectionFormComponent } from './components/premium-adjustment-section-form/premium-adjustment-section-form.component';
import { DynamicFormsPlaceholderComponent } from './components/dynamic-forms-placeholder/dynamic-forms-placeholder.component';
import { DynamicFormsComponent } from './components/dynamic-forms/dynamic-forms.component';
import { PolicySectionFormComponent } from './components/policy-section-form/policy-section-form.component';
import { RenderDynamicContentDirective } from './directives/render-dynamic-content.directive';
import { LookupDatepickerComponent } from './custom-template-components/field-types/lookup-datepicker/lookup-datepicker.component';
import { LabelWrapperComponent } from './custom-template-components/field-wrapper/label-wrapper.component';
import { NumericComponent } from './custom-template-components/field-types/numeric/numeric.component';
import { CheckboxComponent } from './custom-template-components/field-types/checkbox/checkbox.component';
import { TextareaComponent } from './custom-template-components/field-types/textarea/textarea.component';
import { RadioComponent } from './custom-template-components/field-types/radio/radio.component';
import { InputComponent } from './custom-template-components/field-types/input/input.component';
import { CustomDatepickerComponent } from './custom-template-components/field-types/datepicker/datepicker.component';
import { InsurerSectionFormComponent } from './components/insurer-section-form/insurer-section-form.component';
import { FormSectionComponent } from './components/form-section/form-section.component';
import { AddEditFormComponent } from './components/add-edit-form/add-edit-form.component';
import { InsuredSectionFormComponent } from './components/insured-section-form/insured-section-form.component';
import { LienholderSectionFormComponent } from './components/lienholder-section-form/lienholder-section-form.component';
import { MortgageSectionFormComponent } from './components/mortgage-section-form/mortgage-section-form.component';
import { AdditionalInterestSectionFormComponent } from './components/additional-interest-section-form/additional-interest-section-form.component';
import { CertificateHolderSectionFormComponent } from './components/certificate-holder-section-form/certificate-holder-section-form.component';
import { ProducerSectionFormComponent } from './components/producer-section-form/producer-section-form.component';
import { MailTypeComponent } from './custom-template-components/field-types/mail-type/mail-type.component';
import { LookupTableComponent } from './custom-template-components/field-types/lookup-table/lookup-table.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { NgSelectModule } from '@ng-select/ng-select';
import { ReasonsDropdownComponent } from './custom-template-components/field-types/reasons-dropdown/reasons-dropdown.component';

@NgModule({
  declarations: [
    CriteriaSelectionComponent,
    DynamicFormsPlaceholderComponent,
    DynamicFormsComponent,
    PolicySectionFormComponent,
    RenderDynamicContentDirective,
    InputComponent,
    DropdownComponent,
    TextareaComponent,
    RadioComponent,
    CheckboxComponent,
    NumericComponent,
    CustomDatepickerComponent,
    LabelWrapperComponent,
    LookupDatepickerComponent,
    CircumstanceDefinitionComponent,
    ReasonTextModalComponent,
    InsurerSectionFormComponent,
    PremiumAdjustmentSectionFormComponent,
    AddEditFormComponent,
    FormSectionComponent,
    InsuredSectionFormComponent,
    LienholderSectionFormComponent,
    MortgageSectionFormComponent,
    CertificateHolderSectionFormComponent,
    AdditionalInterestSectionFormComponent,
    MailTypeComponent,
    ProducerSectionFormComponent,
    LookupTableComponent,
    ReasonsDropdownComponent
  ],
  imports: [
    NoticeGenerationRoutingModule,
    NgSelectModule,
    NgMultiSelectDropDownModule.forRoot(),
    FormlyModule.forChild(validationDetails),
    FormlyBootstrapModule,
    NilsSharedModule.loadConfig({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      commonApiUrl: '',
      userGroupURL: '',
      feedbackEmail: environment.feedbackEmail,
      customerCareEmail: environment.customerCareEmail,
      productUrl: environment.productUrl
    }),
  ],
  providers: [
    CriteriaSelectionService,
    DynamicFormValidationService,
    DynamicFormHttpService,
    DynamicFormService,
    PolicySectionFormComponent,
    DynamicFormsComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class NoticeGenerationModule { }
