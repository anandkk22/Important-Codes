import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FieldType } from '@ngx-formly/core';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { take } from 'rxjs/operators';

@Component({
  selector: 'app-mail-type',
  templateUrl: './mail-type.component.html',
  styleUrls: ['./mail-type.component.scss']
})
export class MailTypeComponent extends FieldType implements OnInit {
  radioOptions: any;
  isMailType: boolean;
  selectedMailType: any;
  defaultMailType: any;
  sectionFormData: any;
  certified: string;
  registered: string;
  standard: string;
  none: string;
  MailtypeValue: any;
  constructor(
    private modalService: NgbModal,
    private popupService: PopupService,
    private translate: TranslateService) {
    super();
  }


  ngOnInit() {

    this.radioOptions = this.field?.templateOptions?.options;
    this.isMailType = this.getFieldname(this.field?.key);
    this.standard = NoticeGenerationConstants.MailTypeValidation.standard;
    this.certified = NoticeGenerationConstants.MailTypeValidation.certified;
    this.registered = NoticeGenerationConstants.MailTypeValidation.registered;
    this.none = NoticeGenerationConstants.MailTypeValidation.none;
    this.setMailtype();

  }

  setMailtype() {
    this.defaultMailType = this.field?.defaultValue;
    const MailtypeData = [];
    this.sectionFormData = JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.MailTypeValidation.notice_data));
    if (this.sectionFormData) {
      this.sectionFormData[0].components.forEach(element => {
        element.fields.forEach(ele => {
          if (ele.name.includes('MailType')) {
            MailtypeData.push({name: ele.name, value: ele.value});
          }
        });
      });
    }
    if (MailtypeData) {
      this.MailtypeValue = this.getMailtypeUpdatedValue(MailtypeData);
      if (this.MailtypeValue && this.MailtypeValue !== this.defaultMailType) {
        this.selectedMailType = this.MailtypeValue;
      }
      else {
        this.selectedMailType = this.defaultMailType;
      }
    }
    else {
      this.selectedMailType = this.defaultMailType;
    }

  }

  getMailtypeUpdatedValue(MailtypeData: any) {
    for (let i = 0; i < MailtypeData.length; i++) {
      if (this.field?.key === MailtypeData[i].name) {
        return MailtypeData[i].value;
      }
    }
  }

  getFieldname(elementName) {
    return ((elementName === NoticeGenerationConstants.insuredForm.insuredMailType ||
      elementName === NoticeGenerationConstants.producerMailType) ? true : false);
  }
  showCheckMailType(content) {
    this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title',
      size: 'xl',
      windowClass: 'myCustomModalClass'
    }).result.then((result) => { });
  }
  showMailtypeAlert(changedValue) {

  this.popupService.showConfirmation({
    title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
    message: this.translate.instant('NOTICE_GEN_TAB.MAILTYPE_VALIDATION.message'),
    positiveLabel: this.translate.instant('BUTTON.ok_button'),
    negativeLabel: this.translate.instant('BUTTON.cancel_button')
  })
    .pipe(take(1)).subscribe(res => {
      if (res) {
        this.selectedMailType = this.defaultMailType;
      }
      else {
        this.setMailTypeValues(changedValue);
      }
    });
  }

  validateMailType(changedValue) {
    if (this.field?.key === NoticeGenerationConstants.insuredForm.insuredMailType) {
      if (this.field?.templateOptions?.nonComplianceWarnings) {
        if (this.defaultMailType === this.certified) {
          if (changedValue === this.standard) {
            this.showMailtypeAlert(changedValue);
          }
          else {
            this.setMailTypeValues(changedValue);
          }
        }
        else if (this.defaultMailType === this.registered) {
          if (changedValue === this.standard ||
          changedValue === this.certified) {
            this.showMailtypeAlert(changedValue);
          }
          else {
            this.setMailTypeValues(changedValue);
          }
        }
        else if (this.defaultMailType === this.none) {
          if (changedValue === this.standard ||
          changedValue === this.certified ||
          changedValue === this.registered) {
            this.showMailtypeAlert(changedValue);
          }
        }
        else {
          this.setMailTypeValues(changedValue);
        }
      }
    }
  }

  setMailTypeValues(changedValue) {
    this.selectedMailType = changedValue;
    this.defaultMailType = changedValue;
  }
}
