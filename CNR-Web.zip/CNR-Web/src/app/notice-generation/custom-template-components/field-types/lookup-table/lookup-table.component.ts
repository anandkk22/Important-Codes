import { Component, OnInit } from '@angular/core';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { AppConstants } from 'app/app.constants';

@Component({
  selector: 'app-lookup-table',
  templateUrl: './lookup-table.component.html',
  styleUrls: ['./lookup-table.component.scss']
})
export class LookupTableComponent implements OnInit {
  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  lookupData = [];
  userSelectedKey = '';
  selectedDate: Date;
  formModel;
  actionName: string;
  jurisdiction: string;
  optionsUrl;
  circumstanceIdSelected: any;
  lobIdSelected: any;
  isDataAvailable = false;
  stateMandate = [];
  isCustomized = false;
  keyCodeError = [116, 82, 65];
  isLoading = false;
  constructor(private dynamicFormService: DynamicFormService) {
    document.addEventListener('contextmenu', event => event.preventDefault());
    window.addEventListener('keyup', disableF5);
    window.addEventListener('keydown', disableF5);
    function disableF5(e) {
      if (e && (e.which.includes(this.keyCodeError) || (e.keyCode.includes(this.keyCodeError)))) { e.preventDefault(); }
    }
    }

  ngOnInit(): void {
    this.isLoading = true;
    this.showLookupNotice();
  }

  showLookupNotice() {
    this.getData();
    this.userSelectedKey = this.dynamicFormService.getLookUpKey();
    this.optionsUrl = this.dynamicFormService.getLookUpUrl();
    this.lookupData = this.getLookUp();
    if (this.lookupData && this.lookupData.length) {
      this.isLoading = false;
      this.isDataAvailable = true;
    }  else {
      /*  Show only blue if both blue and yelow are available for give criteria.
          Show yellow if no blue record found for given criteria */
      this.lookupData = JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.childWindowLookupTable));
      this.setLookUp(this.lookupData);
      this.isDataAvailable = (this.lookupData && this.lookupData.length) ? true : false;
    }
  }
  getData() {
    if (this.dynamicFormService.getStoredData(NoticeGenerationConstants.criteriaSelectionData)) {
      this.formModel = JSON.parse(this.dynamicFormService.getStoredData(NoticeGenerationConstants.criteriaSelectionData));
      this.actionName = this.formModel.actionName;
      this.jurisdiction = this.formModel.jurisdiction;
      this.lobIdSelected = this.formModel.lob;
      this.circumstanceIdSelected = this.formModel.circumstance;
    }
  }

  selectDate(index) {
    this.selectedDate = new Date(this.lookupData[index].minDate);
    this.selectedDate = new Date(this.selectedDate.getTime() + this.selectedDate.getTimezoneOffset() * 60000);
    this.dynamicFormService.sendDataToParent(this.selectedDate);

  }
  setLookUp(result) {
    this.lookupData = result;
  }
  getLookUp() {
    return this.lookupData;
  }

  getRowColor(row) {
    if (row.circumstanceId === this.circumstanceIdSelected) {
      for (let i = 0; i < this.lobIdSelected.length; i++) {
        if (row.lobId === this.lobIdSelected[i]) {
          return this.dynamicFormService.getAllRowColors(row);
        }
      }
    } else {
      return;
    }
  }

  sendDataToParent(data: any) {
    this.dynamicFormService.sendDataToParent(data);
   }
  sortAscending(header: any) {
    this.lookupData = this.dynamicFormService.sortAscending(header, this.lookupData);
    }
  sortDescending(header: any) {
      this.lookupData = this.dynamicFormService.sortDescending(header, this.lookupData);
  }
  setMaxDaysValue(max: any) {
   return this.dynamicFormService.setMaxDays(max);
  }

  manipulateDate(date: any) {
    return this.dynamicFormService.manipulateDate(date);
  }

}


