import { Component, OnInit } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
@Component({
  selector: 'app-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.scss']
})

export class CustomDatepickerComponent extends FieldType implements OnInit {

  selectedDateDP: Date;

  constructor() {
   super();
  }

  ngOnInit(): void {
    this.selectedDateDP = this.field?.defaultValue;
  }
}
