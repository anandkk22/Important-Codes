import { Component, OnInit } from '@angular/core';
import { FieldType } from '@ngx-formly/core';

@Component({
  selector: 'app-reasons-dropdown',
  templateUrl: './reasons-dropdown.component.html',
  styleUrls: ['./reasons-dropdown.component.scss']
})
export class ReasonsDropdownComponent extends FieldType implements OnInit {

  constructor() {
    super();
  }

  ngOnInit() {
  }
}
