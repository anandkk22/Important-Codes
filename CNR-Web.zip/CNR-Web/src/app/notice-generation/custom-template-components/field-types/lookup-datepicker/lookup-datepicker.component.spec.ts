import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LookupDatepickerComponent } from './lookup-datepicker.component';

describe('LookupDatepickerComponent', () => {
  let component: LookupDatepickerComponent;
  let fixture: ComponentFixture<LookupDatepickerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LookupDatepickerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LookupDatepickerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
