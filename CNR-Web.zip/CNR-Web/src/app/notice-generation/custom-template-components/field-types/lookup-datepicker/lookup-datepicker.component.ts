import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FieldWrapper } from '@ngx-formly/core';
import { SpinnerService } from '@wk/nils-core';
import { AppConstants } from 'app/app.constants';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormHttpService } from 'app/notice-generation/service/dynamic-form-http.service';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';

@Component({
  selector: 'app-lookup-datepicker',
  templateUrl: './lookup-datepicker.component.html',
  styleUrls: ['./lookup-datepicker.component.scss']
})
export class LookupDatepickerComponent extends FieldWrapper implements OnInit {
  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  lookupData = [];
  userSelectedKey = '';
  selectedDate: Date;
  formModel;
  actionName: string;
  jurisdiction: string;
  optionsUrl;
  circumstanceIdSelected: any;
  lobIdSelected: any;
  isReinstatement = false;

  constructor(private modalService: NgbModal,
     private dynamicFormService: DynamicFormService,
     private dynamicFormHttpService: DynamicFormHttpService) {
    super();
  }

  ngOnInit(): void {
    this.getData();
  }

  showLookupNotice(optionsUrl, key, content) {
    this.userSelectedKey = key;
    this.lookupData = JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.childWindowLookupTable));
    this.modalService.open(content, {
      ariaLabelledBy: 'modal-basic-title',
      size: 'xl',
      windowClass: 'myCustomModalClass'
    }).result.then((result) => { });
  }

  selectDate(index) {
    this.selectedDate = new Date(this.lookupData[index].minDate);
    this.selectedDate = new Date(this.selectedDate.getTime() + this.selectedDate.getTimezoneOffset() * 60000);
    this.modalService.dismissAll();
    this.dynamicFormService.emitDate.next({key: this.userSelectedKey, value: this.selectedDate});
  }

 getData() {
    if (this.dynamicFormService.getStoredData(NoticeGenerationConstants.criteriaSelectionData)) {
      this.formModel = JSON.parse(this.dynamicFormService.getStoredData(NoticeGenerationConstants.criteriaSelectionData));
      this.actionName = this.formModel.actionName;
      this.jurisdiction = this.formModel.jurisdiction;
      this.lobIdSelected = this.formModel.lob;
      this.circumstanceIdSelected = this.formModel.circumstance;
      if (this.actionName === NoticeGenerationConstants.LookUpDateDetails.reinstatement) {
        this.isReinstatement = true;
      }
    }
  }

  getRowColor(row) {
    if (row) {
      if (row.circumstanceId === this.circumstanceIdSelected) {
        for (let i = 0; i < this.lobIdSelected.length; i++) {
          if (row.lobId === this.lobIdSelected[i]) {
            return this.dynamicFormService.getAllRowColors(row);
          }
        }
      } else {
        return;
      }
    }
  }

  sortAscending(header: any) {
    this.lookupData = this.dynamicFormService.sortAscending(header, this.lookupData);
    }
  sortDescending(header: any) {
      this.lookupData = this.dynamicFormService.sortDescending(header, this.lookupData);
  }
  setMaxDaysValue(max: any) {
   return this.dynamicFormService.setMaxDays(max);
  }

  manipulateDate(date: any) {
    return this.dynamicFormService.manipulateDate(date);
  }
}
