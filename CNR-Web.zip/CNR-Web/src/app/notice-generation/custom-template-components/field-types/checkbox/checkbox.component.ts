import { Component, OnInit } from '@angular/core';
import { FieldType } from '@ngx-formly/core';
@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss']
})
export class CheckboxComponent extends FieldType implements OnInit {
  acceptTerms: any;

  ngOnInit() {
    this.acceptTerms = this.field.templateOptions.options;
  }
}
