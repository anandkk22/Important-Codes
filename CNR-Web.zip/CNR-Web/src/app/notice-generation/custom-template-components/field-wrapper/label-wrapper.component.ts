import { Component, OnInit } from '@angular/core';
import { FieldWrapper } from '@ngx-formly/core';
import { AppConstants } from 'app/app.constants';
import { PolicySectionFormComponent } from 'app/notice-generation/components/policy-section-form/policy-section-form.component';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';

@Component({
  selector: 'label-wrapper-panel',
  templateUrl: './label-wrapper.component.html',
  styleUrls: ['./label-wrapper.component.scss']
})

export class LabelWrapperComponent extends FieldWrapper implements OnInit {

  sectionName: string;
  isChildWindow = false;
  constructor(
    private policySection: PolicySectionFormComponent,
    private _dynamicFormService: DynamicFormService) {
    super();
  }

  ngOnInit() {
    this.sectionName = this._dynamicFormService.sectionName;
    if (window.location.href.indexOf(AppConstants.uiRoutes.addEditForm) > -1) {
      this.isChildWindow  = true;
    }
  }

  showReasonText(to) {
    this.policySection.showReasonText(to);
  }

  getClass(to) {
    let styleClass = '';
    if (this.isChildWindow) {
      if (to.label.includes(NoticeGenerationConstants.copies)) {
        styleClass = 'col-md-8 col-lg-10 pl_0'; //
      } else {
        styleClass = 'col-md-4 col-lg-5 pl_0';
      }
    } else {
      if (to.label.includes(NoticeGenerationConstants.copies) && !to.name?.includes(NoticeGenerationConstants.insurerText)) {
        styleClass = 'col-lg-8'; // producer n insured   ..for copie
      } else if (this.sectionName === 'PremiumAdjustment') {
        styleClass = 'col-lg-5';
      }
     else {
        styleClass = 'col-lg-4'; // insurer ..other than copies
      }
    }
    return styleClass;
  }

  isPolicySection() {
    return this.sectionName && this.sectionName.includes(NoticeGenerationConstants.policyText) ? true : false;
  }

  skipAsterisk(to: any) {
    return this._dynamicFormService.skipAsterisk(to);
  }

  // method to get class for field inline messages
  geErrorMssageClass() {
    let styleClass = '';
    if (this.isChildWindow) { // child window form
      styleClass = 'col-md-4 col-lg-5';
    } else {
      if (this.sectionName === NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment) { // premium adj
        styleClass = 'col-lg-5';
      } else { // other
        styleClass = 'col-lg-4';
      }
    }
    return styleClass;
  }
}
