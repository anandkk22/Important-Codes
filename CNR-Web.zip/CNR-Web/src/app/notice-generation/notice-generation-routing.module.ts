import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '@global';
import { AppConstants } from 'app/app.constants';
import { AddEditFormComponent } from './components/add-edit-form/add-edit-form.component';
import { CircumstanceDefinitionComponent } from './components/circumstance-definition/circumstance-definition.component';
import { CriteriaSelectionComponent } from './components/criteria-selection/criteria-selection.component';
import { DynamicFormsComponent } from './components/dynamic-forms/dynamic-forms.component';
import { LookupTableComponent } from './custom-template-components/field-types/lookup-table/lookup-table.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: AppConstants.uiRoutes.criteriaSelection,
    pathMatch: 'full'
  },
  {
    path: AppConstants.uiRoutes.criteriaSelection,
    component: CriteriaSelectionComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.fillForm,
    component: DynamicFormsComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.circumstancesDefinitions,
    component: CircumstanceDefinitionComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.addEditForm,
    component: AddEditFormComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.supplementalDynamicForm,
    component: DynamicFormsComponent,
  },
  {
    path: AppConstants.uiRoutes.lookupDate,
    component: LookupTableComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NoticeGenerationRoutingModule { }
