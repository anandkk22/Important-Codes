export interface IFieldRuleEvent {
    eventType: string;
    value: boolean;
    field: string;
}
