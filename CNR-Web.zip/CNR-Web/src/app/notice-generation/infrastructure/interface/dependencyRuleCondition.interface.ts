export interface IDependencyRuleCondition {
    conditionOperator: string;
    conditionType: string;
    conditionValue: any;
    field: string;
}
