export interface IFormSectionIsRequired {
    isRequired: string;
    index: number;
}
