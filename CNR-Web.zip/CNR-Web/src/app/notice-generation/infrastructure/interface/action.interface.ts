export interface Action {
    id: number;
    code: string;
    name: string;
    codeName: string;
}
