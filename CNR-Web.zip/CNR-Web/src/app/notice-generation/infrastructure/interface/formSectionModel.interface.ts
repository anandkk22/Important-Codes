import { IField } from './field.interface';
import { IFieldDependencyRules } from './fieldDependencyRules.interface';

export interface IFormSectionModel {
    name: string;
    dataType: string;
    displayName: string;
    displayOrder: number;
    isRequired: boolean;
    fields: IField[];
    fieldDependencyRules: IFieldDependencyRules;
    optionsUrl: string;
    settings: any;
    }
