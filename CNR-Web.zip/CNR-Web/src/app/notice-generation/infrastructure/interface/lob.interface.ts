export interface LOB {
    id: number;
    name: string;
}
