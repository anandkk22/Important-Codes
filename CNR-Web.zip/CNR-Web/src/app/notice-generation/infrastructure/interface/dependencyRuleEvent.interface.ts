
export interface IDependencyRuleEvent {
    eventType: string;
    field: string;
    value: any;
}
