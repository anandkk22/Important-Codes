export interface Jurisdiction {
    code: string;
    name: string;
}
