export interface CircumstanceDefinitions {
    id: number;
    definition: string;
    description: string;
}
