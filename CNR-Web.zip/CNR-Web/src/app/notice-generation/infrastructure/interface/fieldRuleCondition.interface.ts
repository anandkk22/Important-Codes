export interface IFieldRuleCondition {
    conditionOperator: string;
    conditionType: string;
    conditionValue: string;
    field: string;
}
