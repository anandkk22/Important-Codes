export interface IField {
    name: string;
    displayName: string;
    dataType: string;
    displayControlType: string;
    isRequired: boolean;
    min: number;
    max: number;
    isRegulatoryRequirement: boolean;
    defaultValue: any;
    optionsUrl: string;
    format: string;
    minLength: number;
    maxLength: number;
    dependencyRules: any[];
    isOptionRequired: boolean;
    fields: any[];
}
