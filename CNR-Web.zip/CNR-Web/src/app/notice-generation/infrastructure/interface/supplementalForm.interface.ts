export interface ISupplementalForm  {
    name: string;
    index: number;
    isSupplemental?: boolean;
    pdfUrl: string;
    formCode: string;
  }

