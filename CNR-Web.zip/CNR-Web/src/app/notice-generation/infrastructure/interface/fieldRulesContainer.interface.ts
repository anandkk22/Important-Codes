import { IFieldRuleCondition } from './fieldRuleCondition.interface';
import { IFieldRuleEvent } from './fieldRuleEvent.interface';

export interface IFieldRulesContainer {
    conditions: IFieldRuleCondition[];
    events: IFieldRuleEvent[];
}
