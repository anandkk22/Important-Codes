export interface InsurerDetails {
    id: number;
    name: string;
    code: string;
    address1: string;
    address2: string;
    city: string;
    stateProvidence: string;
    postalCode: string;
}
