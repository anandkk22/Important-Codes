export interface IFormSectionNames {
    displayName: string;
    name: string;
    index: number;
}
