export interface PolicyType {
    code: string;
    name: string;
}
