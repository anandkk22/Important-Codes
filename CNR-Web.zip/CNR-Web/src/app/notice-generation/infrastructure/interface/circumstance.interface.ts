export interface Circumstance {
    id: number;
    name: string;
}
