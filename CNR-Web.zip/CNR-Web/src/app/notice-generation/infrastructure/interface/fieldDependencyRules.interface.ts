import { IFieldRulesContainer } from './fieldRulesContainer.interface';

export interface IFieldDependencyRules {
    rules: IFieldRulesContainer;
}
