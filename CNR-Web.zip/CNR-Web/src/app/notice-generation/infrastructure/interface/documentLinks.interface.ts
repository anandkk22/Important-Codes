export interface IDocumentLinks {
    name: string;
    index: number;
    isSupplemental?: boolean;
    pdfUrl: string;
    docUrl: string;
    regHelpDocUrl: string;
    helpFormName?: string;
  }
