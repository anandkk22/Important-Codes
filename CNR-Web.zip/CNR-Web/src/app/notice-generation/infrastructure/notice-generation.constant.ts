import { environment } from '@env';
import { AppConstants } from 'app/app.constants';

// Uncomment for running apis on local
// environment.apiUrl = 'https://dev.onesumxnils.com/';

export class NoticeGenerationConstants {

  static webApis = {
    policyTypes: environment.apiUrl + 'PolicyType',
    jurisdictions: environment.wkApiUrl + 'v1/Jurisdictions',
    actions: environment.wkApiUrl + 'v1/Actions?policyType={policyType}&jurisdiction={jurisdictionCode}',
    circumstances: environment.wkApiUrl +
      'v1/Circumstances?policyType={policyType}&jurisdiction={jurisdictionCode}&action={actionCode}',
    lob: environment.wkApiUrl + 'v1/Lobs?policyType={policyType}&jurisdiction={jurisdictionCode}&action={actionCode}&circumstance={circumstanceCode}',
    circumstanceDefinition: environment.apiUrl + 'Circumstance/Definition',
    serviceCenter: environment.wkApiUrl + 'v1/ServiceCenters',
    getFormTitle: environment.apiUrl + 'RTFActionField/FormTitle?RTFName={rtfName}&Jurisdiction={jurisdictionCode}&ActionId={actionCode}&CircumstanceId={circumstanceCode}&{lobCode}',
    getForms: environment.wkApiUrl + 'v1/Forms/prefill?policyType={policyType}&jurisdiction={jurisdictionCode}&action={actionCode}&circumstance={circumstanceCode}&lobs={lobCode}',
    producerCode: environment.apiUrl + 'Producer?PageNo=0&PageSize=0',
    maintainParties: environment.apiUrl + 'MaintainParties',
    getAddendumForm: environment.commonApiUrl + 'Download?file=CNR4\\AddendumForAdditionalReasons.doc',
    getHelpForm: environment.commonApiUrl + 'Download?file=CNR4\\{helpForm}.doc',
    getGenerateNotice: environment.portalUrl + 'webservices/api/cnr/v1/notices/inline',
    getNoticeDataByPolicy: environment.wkApiUrl +
    'v1/Notices/RegenerationLookup?policyType={policyType}&jurisdiction={jurisdictionCode}&action={actionCode}&circumstance={circumstanceCode}&lobs={lobCode}&policynumber={policyNumber}&docName={docName}',
    noticeFile : environment.wkApiUrl + 'v1/Notices/File',
    getProducerCount: environment.apiUrl + 'Producer/Count',
    maintainPartiesBulkInsert: environment.apiUrl + 'MaintainParties/Bulk',
    getStateCodes:  environment.wkApiUrl + 'v1/StateProvidences',
    getLOBsAbb: environment.apiUrl + 'LOB/LobAbbrivations',
    mapCriteriaSelectionOptions: environment.apiUrl + 'Form/MapSelectionCriteria',
  };

  static urlGenerate = {
    lobIds: 'lobIds=',
    andSymbol: '&',
    querySymbol: '?',
    equalSymbol: '='
  };
  static validationMessages = {
    is_required: 'is required.',
    date: 'Date ',
    value_should_be_in: 'Value should be in',
    format: 'format',
    characters: 'characters',
    value_cannot_be_less_than: 'Value cannot be less than',
    value_cannot_be_more_than: 'Value cannot be more than',
    should_have_atleast: 'Should have atleast',
    should_be_today_or_greater: 'should be Today or greater.',
    this_value_should_be_less_than: 'This value should be less than',
    please_enter_amount_in_format: 'Please enter amount in the format 99.99',
    postal_code_in_valid_format: 'Postal code should be in valid format.',
    phone_number_in_valid_format: 'Phone number should be in valid format.',
    date_valid_format: 'Please enter the date as m/d/yyyy or mm/dd/yyyy.'
  };
  static policyText = 'Policy';
  static premiumText = 'Premium';
  static policyChange = 'Policy Change';
  static change = '/Change';
  static insurerText = 'Insurer';
  static producerText = 'Producer';
  static supplementalDynamicForm = 'supplemental-dynamic-form';
  static supplementalForm = 'supplementalForm';
  static isSupplementalform = 'isSupplementalform';
  static sectionsAvailable = 'sectionsAvailable';
  static supplementalFormCode = 'supplementalFormCode';
  static noticeData = 'noticeData';
  static supplementalNoticeData = 'supplementalNoticeData';
  static producerStateProv = 'ProducerStateProv';
  static policyNumber = 'PolicyNumber';
  static policyTypeCodeText = 'PolicyTypeCode';
  static cRDueAmt = 'CRDueAmt';
  static lobText = 'LOB';
  static lobAbbText = '_LOBs';
  static transactionDateText = 'TransactionDt';
  static packagePolicy = 'Package Policy';
  static code = 'Code';
  static transactionTime = 'TransactionTime';
  static insurer = 'Insurer';
  static routeSeparator = '/';
  static stateProvPlaceholder = 'Select Jurisdiction/Province';
  static copies = 'Copies';
  static stateProv = 'StateProv';
  static mailType = 'MailType';
  static producerMailType = 'ProducerMailType';
  static doubleFormat_regex = /^[0-9]+(\.[0-9]{0,2})?$/g;
  static doubleFormatWithSpecialRegex = /^\$?-?[0-9]*(\.[0-9]{0,2})?$/g;
  static alphanumeric_regex = /[a-zA-Z0-9]/;
  static postalCodeUSRegex = /(^\d{5})$|(^\d{5}-\d{4}$)/g;
  static postalCodeCARegex = /^[a-zA-Z]\d{1}[a-zA-Z]\s?\d{1}[a-zA-Z]\d{1}/g;
  static city = 'City';
  static postalCode = 'PostalCode';
  static fieldName = 'Name';
  static addr1 = 'Addr1';
  static addr2 = 'Addr2';
  static hoursArray = [
    {
      'name': '12:01 AM',
      'code': '12:01 AM'
    },
    {
      'name': '12:00 PM',
      'code': '12:00 PM'
    }
  ];
  static fill3817 = 'Fill3817';
  static criteriaSelectionData = 'criteriaSelectionData';
  static sectionId = 'sectionId';
  static previousVisitedSections = 'previousVisitedSections';
  static supplemntalPreviousVisitedSections = 'supplemntalPreviousVisitedSections';
  static typistData = 'typistData';
  static nA = 'N/A';
  static reasonsAPIurl = 'webservices/api/cnr/v1/Reasons';
  static daysNoticeAPIurl = 'DaysOfNotice';
  static certholder = 'Certholder';
  static certificateHolder = 'Certificate Holder';
  static addInt = 'AddInt';
  static additionalInterest = 'Additional Interest';
  static tp = 'TP';
  static thirdParty = 'Third Party';
  static fieldNameOnPolicy = 'Termination/Cancellation/NonRenewal/ConditionalRenewal/Declination indicated';
  static saveButtonId = 'save_button';
  static cancelButtonId = 'cancel_button';
  static premiumAdjutsmentForm = {
    premiumAdjustment: 'PremiumAdjustment',
    premium_adjustment: 'Premium Adjustment',
    unearnedPRAmt_label: 'Unearned premium amount refunded (99.99)',
    unearnedPRAmt: 'UnearnedPRAmt',
    unearnedPRInd: 'UnearnedPRInd',
    otherPremAdjInd: 'OtherPremAdjInd',
    otherDesc: 'OtherDesc',
    otherDesc_label: 'Premium adjustment reason, explanation and/or description'
  };
  static dropDownOptions = [
    {
      'code': 'AL',
      'name': 'Alabama'
    },
    {
      'code': 'AK',
      'name': 'Alaska'
    },
    {
      'code': 'AB',
      'name': 'Alberta (Canada)'
    },
    {
      'code': 'AZ',
      'name': 'Arizona'
    },
    {
      'code': 'AR',
      'name': 'Arkansas'
    },
    {
      'code': 'BC',
      'name': 'British Columbia (Canada)'
    },
  ];

  static copiesNumberDropDownValues = [
    {
      'id': 1,
      'name': 1
    },
    {
      'id': 2,
      'name': 2
    },
    {
      'id': 3,
      'name': 3
    },
  ];

  static radioOptions = [
    {
      'code': 'S',
      'name': 'Standard'
    },
    {
      'code': 'C',
      'name': 'Certified'
    },
    {
      'code': 'R',
      'name': 'Registered'
    },
    {
      'code': 'N',
      'name': 'None'
    }
  ];
  static insuredForm = {
    insured: 'Insured',
    applicant: '/Applicant',
    insuredName: 'InsuredName',
    insuredAddr1: 'InsuredAddr1',
    insuredAddr2: 'InsuredAddr2',
    insuredCity: 'InsuredCity',
    insuredStateProv: 'InsuredStateProv',
    insuredPostalCode: 'InsuredPostalCode',
    insuredCopies: 'InsuredCopies',
    insuredMailType: 'InsuredMailType',
    fill3817Insured: 'Fill3817Insured'
  };
  static insurerForm = {
    insurerId: 'InsurerId',
    insurerName: 'InsurerName',
    insurerAddr1: 'InsurerAddr1',
    insurerAddr2: 'InsurerAddr2',
    insurerCity: 'InsurerCity',
    insurerStateProv: 'InsurerStateProv',
    insurerPostalCode: 'InsurerPostalCode',
    insurerCopies: 'InsurerCopies',
    insurerFormData: 'InsurerFormData',
    serviceCenterData: 'serviceCenterData',
    useServiceCenterAddress: 'UseServiceCenterAddress',
    selectedServiceCenter: 'selectedServiceCenter',
    policyChange: 'PolicyChange',
  };

  static resetInsurer = {
    id: null,
    name: null,
    code: null,
    address1: null,
    address2: null,
    city: null,
    stateProvidence: null,
    postalCode: null
  };

  static NoticeGenerate = {
    noticeExists: 'NoticeExists',
    unableToFindFile: 'UnableToFindFormFile',
    mainFormIsRequired: 'MainFormIsRequired'
  };
  static producerForm = {
    pPostalCode: 'PPostalCode',
    producerAddr1: 'ProducerAddr1',
    producerAddr2: 'ProducerAddr2',
    producerCity: 'ProducerCity',
    producerCode: 'ProducerCode',
    producerCopies: 'ProducerCopies',
    producerName: 'ProducerName',
    producerId: 'ProducerId',
    producerStateProv: 'ProducerStateProv',
    fill3817Producer: 'Fill3817Producer',
    noMatch: '-- No Matching Producer --',
    producerMailType: 'ProducerMailType',
    minimumTermLength: 1,
    debounceTime: 350
  };

  static allowPastDateField = {
    transactionDt: 'TransactionDt',
    mailingDt: 'MailingDt',
    policyEffectiveDt: 'PolicyEffectiveDt',
    premDueDt: 'PremDueDt',
    premDueDt1: 'PremDueDt1'
  };

  static producerSearchBy = {
    producerCode: 'ProducerCode',
    producerId: 'ProducerId',
    producerName: 'ProducerName',
    name: 'Name',
    code: 'Code',
    searchProducerBy: 'searchProducerBy',
    producerSearchTerm: 'producerSearchTerm'
  };
  static fieldNames = {
    mortgagee: {
      id: 'MortgageeId',
      name: 'MortgageeName',
      addr1: 'MortgageeAddr1',
      addr2: 'MortgageeAddr2',
      city: 'MortgageeCity',
      state: 'MStateProv',
      postalCode: 'MPostalCode',
      copies: 'MortgageeCopies',
      mailType: 'MortgageeMailType',
      fill3817Mortgagee: 'Fill3817Mortgagee',
      physicalAddr: 'CNNRCRDeclAddr1',
      propertyDescription: 'CNNRCRDeclDesc1',
      effectiveDate: 'CNNRCRDeclEffectDt',
      effectiveTime: 'CNNRCRDeclTime'
    },
    lienholder: {
      id: 'LienholderId',
      name: 'LienholderName',
      addr1: 'LienholderAddr1',
      addr2: 'LienholderAddr2',
      city: 'LienholderCity',
      postalCode: 'LPostalCode',
      state: 'LStateProv',
      mailType: 'LienholderMailType',
      copies: 'LienholderCopies',
      fill3817Lienholder: 'Fill3817Lienholder'
    },
    certifholder: {
      id: 'CertholderId',
      name: 'CertholderName',
      addr1: 'CertholderAddr1',
      addr2: 'CertholderAddr2',
      city: 'CertholderCity',
      postalCode: 'ChPostalCode',
      state: 'ChStateProv',
      mailType: 'CertholderMailType',
      copies: 'CertholderCopies',
      fill3817Certholder: 'Fill3817Certholder'
    },
    addInt: {
      id: 'AddIntId',
      name: 'AddIntName',
      addr1: 'AddIntAddr1',
      addr2: 'AddIntAddr2',
      city: 'AddIntCity',
      postalCode: 'APostalCode',
      state: 'AStateProv',
      mailType: 'AddIntMailType',
      copies: 'AddIntCopies',
      fill3817AddInt: 'Fill3817AddInt'
    },
    tp: {
      id: 'TPId',
      name: 'TPName',
      addr1: 'TPAddr1',
      addr2: 'TPAddr2',
      city: 'TPCity',
      postalCode: 'TPPostalCode',
      state: 'TPStateProv',
      mailType: 'TPMailType',
      copies: 'TPCopies',
      fill3817TP: 'Fill3817TP'
    },
    wcc: {
      id: '',
      name: 'WCCName',
      addr1: 'WCCAddr1',
      addr2: 'WCCAddr2',
      city: 'WCCCity',
      postalCode: 'WCCPostalCode',
      state: 'WCCStateProv',
      mailType: 'WCCMailType',
      copies: 'WCCCopies',
      fill3817WCC: 'Fill3817WCC'
    }
  };

  static sectionNames = {
    mortgagee: 'Mortgagee',
    lienholder: 'Lienholder',
    certholder: 'Certholder',
    addInt: 'AddInt',
    tp: 'TP',
    wcc: 'WCC'

  };

  static sectionMailTypes = [
    'LienholderMailType',
    'MortgageeMailType',
    'CertholderMailType',
    'AddIntMailType',
    'TPMailType',
    'WCCMailType'
  ];

  static sectionStateFields = [
    'LStateProv',
    'MStateProv',
    'ChStateProv',
    'AStateProv',
    'TPStateProv',
    'WCCStateProv'
  ];

  static addEditFormWinConfig = 'left=0,top=0,width=1200,height=700,toolbar=1,resizable';
  static windowName = 'scriptWindow';
  static winFormDataKey = 'windowFormData';
  static winMessageKey = 'message';

  static customCopiesFieldSections = [
    'Producer',
    'Insured',
    'Mortgagee',
    'Lienholder',
    'Certholder',
    'AddInt',
    'TP',
    'WCC'
  ];

  static refreshConfirmationPopup = {
    confirm_title: 'Confirm',
    back_on_criteria_Selection: 'Information entered will be discarded. Are you sure you wish to continue?',
    confirm_button: 'Confirm',
    ok_button: 'OK',
    cancel_button: 'Cancel'
  };

  static WCCDisplayName = 'Workers Compensation Commission';

  static LookUpDateDetails = {
    lookUp_key: 'lookUpkey',
    lookUp_Url: 'lookUpOptionsUrl',
    lookupData: 'lookupData',
    reinstatement: 'Reinstatement'
  };

  static dateFormat = 'MM/DD/YYYY';

  static reasonForActionCustom = 'Custom Reason(s)/Other Information will be entered below:';

  static MailTypeValidation = {
    notice_data: 'noticeData',
    standard: 'S',
    certified: 'C',
    registered: 'R',
    none: 'N'
  };

  static isoDateFormat = 'YYYY-MM-DD';
  static fieldGroupClassName = 'row';
  static ignoredDataText = 'ignoredData';
  static ignoredDataTextSupplemental = 'ignoredDataSupplemental';
  static mailingDate = 'MailingDt';
  static transactionDate = 'TransactionDt';
  static policyTransactionTime = 'TransactionTime';
  static cnrCRDeclEffectDt = 'CNNRCRDeclEffectDt';
  static ignoredKey = 'isIgnored';
  static mortgageeText = 'Mortgagee';
  static ignoredPreAdjustDataText = 'ignoredData_PreAdjustment';
  static ignoredPreAdjustDataTextSupplemental = 'ignoredData_PreAdjustmentSupplemental';
  static transactionDateKey = 'transactionDate';
  static transactionTimeKey = 'transactionTime';
  static mailingDateKey = 'mailingDate';
  static effectiveTime = {
    beforeTwelveKey: '00:01:00',
    beforeTwelveValue: '12:01 AM',
    afterTwelveKey: '12:00:00',
    afterTwelveValue: '12:00 PM',
  };

  static twelveNoon = '12:00 Noon';

  static responseType = {
    blobType: 'blob'
  };

  static addendum = 'Addendum to Provide Additional Reasons';

  static ignoreNonComplianceWarnings = ['InvalidCurrentDate', 'InvalidDaysNotice'];

  static nonComplianceProp = {
    inValidCurrentDate: 'inValidCurrentDate',
    inValidDaysNotice: 'inValidDaysNotice'
  };

  static sectionIdFields = [
    'MortgageeId',
    'LienholderId',
    'CertholderId',
    'AddIntId',
    'TPId',
    'ProducerId'
  ];

  static effectiveDateKey = 'noticeEffectiveDate';
  static supplimentalEffectDateKey = 'supplemental_EffectiveDate';
  static ignoredWarningKeys = ['isIgnored', 'inValidCurrentAndDayNoticeDate', 'invalidCurrentDate'];
  static childWindowLookupTable = 'childWindowLookupTable';
  static fileName = 'filename=';
  static noticeFileConfig = 'height=800,width=1000,status=yes,toolbar=no,menubar=no,location=no';
  static labelWrapperPanel = 'label-wrapper-panel';
  static formlyFieldCheckbox = 'formly-field-checkbox';
  static labelText = 'label';
  static noneText = 'none';
  static starText = '*';
  static checkBoxText = 'checkbox';
  static keyText = 'key';
  static sectionsWithJurisdiction = ['Insurer', 'Producer', 'Mortgagee', 'Lienholder', 'Certholder', 'AddInt', 'TP'];
  static invalidJurisdictionProvinceOption = 'InvalidJurisdictionProvinceOption';
  static noSublines =  'There are no sublines available for this combination.';
  static stateProvidences = 'StateProvidences';
  static allStateCodes = 'allStateCodes';
  static formCodeText = '&formCode=';
  static reinstatementDisplayName = 'Reinstatement';
  static policyReinstatement = 'PolicyReinstatement';
  static mortgageeSupplementalEffectiveDate = 'mortgageeIgnoreSupEffectiveDate';
  static mortgageeEffectiveDate = 'mortgageeIgnoreEffectiveDate';
  static timeZoneDiff = 60000;
  static formCode = 'formCode';
  static insurerSelectedValues = 'insurerSelectedValues';
  static formSizeWarning = 'FormSizeWarning';

  static eventType = {
    updateFieldValue: 'UpdateFieldValue',
    requiredField: 'RequiredField'
  };

  static insurerUseLookupValuesFields = [
    'InsurerAddr1',
    'InsurerAddr2',
    'InsurerCity',
    'InsurerStateProv',
    'InsurerPostalCode',
  ];

  static localStorageKeys = {
    formData: 'formData',
    isSupplementalFirstLoad: 'isSupplementalFirstLoad',
    selectedLOB: 'selectedLOB'
  };

  static unearnedMailedDt = 'UnearnedMailedDt';

  static daysNoticeWarningLogData = {
    serverDate: '',
    clientDate: '',
    effectiveDate: null,
    mailingDate: null,
    minDays: null,
    minDate: ''
  };

  static excludedFields = ['serviceCenterData', 'LOB'];
  static filenameKey = 'filename';
}

