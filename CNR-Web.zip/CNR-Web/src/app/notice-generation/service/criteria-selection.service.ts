import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { NoticeGenerationConstants } from '../infrastructure/notice-generation.constant';

@Injectable()
export class CriteriaSelectionService {

  constructor(private http: HttpClient) { }

  getPolicies() {
    return this.http.get(NoticeGenerationConstants.webApis.policyTypes);
  }

  getJurisdiction() {
    return this.http.get(NoticeGenerationConstants.webApis.jurisdictions);
  }

  getActions(policyType: string, jurisdictionCode: string) {
    return this.http.get(NoticeGenerationConstants.webApis.actions
      .replace('{policyType}', policyType)
      .replace('{jurisdictionCode}', jurisdictionCode));
  }

  getCircumstances(policyType: string, jurisdictionCode: string, actionCode: number) {
    return this.http.get(NoticeGenerationConstants.webApis.circumstances
      .replace('{policyType}', policyType)
      .replace('{jurisdictionCode}', jurisdictionCode)
      .replace('{actionCode}', String(actionCode)));
  }

  getLobs(policyType: string, jurisdictionCode: string, actionCode: number, circumstanceCode: number) {
    return this.http.get(NoticeGenerationConstants.webApis.lob
      .replace('{policyType}', policyType)
      .replace('{jurisdictionCode}', jurisdictionCode)
      .replace('{actionCode}', String(actionCode))
      .replace('{circumstanceCode}', String(circumstanceCode)));
  }

  compare(property: string, sortOder: number = 1) {
    return function (a, b) {
      const result = (a[property] < b[property]) ? -1 : (a[property] > b[property]) ? 1 : 0;
      return result * sortOder;
    };
  }

  getCircumstanceDefinitions() {
    return this.http.get(NoticeGenerationConstants.webApis.circumstanceDefinition);
  }

  mapCriteriaSelectionOptions() {
    return this.http.put(NoticeGenerationConstants.webApis.mapCriteriaSelectionOptions, '');
  }
}
