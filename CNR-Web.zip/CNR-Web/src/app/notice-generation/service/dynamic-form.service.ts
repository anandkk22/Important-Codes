import { EventEmitter, Injectable, Output } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of, Observable, Subject } from 'rxjs';
import 'rxjs/add/operator/map';
import { FormlyFieldConfig } from '@ngx-formly/core';
import { IField } from '../infrastructure/interface/field.interface';
import { IFormSectionModel } from '../infrastructure/interface/formSectionModel.interface';
import { NoticeGenerationConstants } from '../infrastructure/notice-generation.constant';
import moment from 'moment';
import { IFieldDependencyRules } from '../infrastructure/interface/fieldDependencyRules.interface';
import { IDependencyRuleCondition } from '../infrastructure/interface/dependencyRuleCondition.interface';
import { IDocumentLinks } from '../infrastructure/interface/documentLinks.interface';
import { ISupplementalForm } from '../infrastructure/interface/supplementalForm.interface';
import { IFormSectionNames } from '../infrastructure/interface/formSectionNames.interface';
import { IDependencyRuleEvent } from '../infrastructure/interface/dependencyRuleEvent.interface';
import { ConditionOperatorType } from '../state/enum/conditionOperatorType';
import { EventType } from '../state/enum/eventTypes';
import { environment } from '@env';
import { AppConstants } from 'app/app.constants';
import { DynamicFormHttpService } from './dynamic-form-http.service';
import { maintainPartyEnums } from '../state/enum/maintainPartyEnums';
import { IFormSectionIsRequired } from '../infrastructure/interface/sectionIsRequired.interface';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { Constants } from 'app/admin/infrastructure/constants';
import { debounceTime, distinctUntilChanged, take, windowCount } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { DynamicFormValidationService } from './dynamic-form-validation.service';
@Injectable({
  providedIn: 'root',
})
export class DynamicFormService {
  isSupplementalForm: boolean;
  criteriaData: any;
  currentRtfName: string;
  LObAbb: string;
  daysNoticeData: any[];
  lookupData: any;
  serviceCenters = [];
  constructor(
    private _http: HttpClient,
    private popupService: PopupService,
    private translate: TranslateService,
    private spinnerService: SpinnerService,
    private route: ActivatedRoute,
    private dynamicFormHttpService: DynamicFormHttpService) {
    this.route.queryParams.subscribe(params => {
      this.isSupplementalForm = Boolean(params['supplementalForm']);
    });
  }
  sectionIsRequired: any[];
  @Output() backButtonClickedEvent = new EventEmitter<object>();
  @Output() sectionClickedEvent = new EventEmitter<number>();
  formSectionModel: IFormSectionModel[];
  formSectionNames: IFormSectionNames[];
  fieldDetails: IField[] = [];
  formFields: FormlyFieldConfig[] = [{}];
  emitDate = new Subject<{ key: string; value: any }>();
  emitUpdatedModel = new Subject<any>();
  formData;
  formModel: any = {};
  triggerSubmitManually = new Subject<number>();
  regularatoryProducts = [];
  requiredFields = [];
  regulatoryRequiredFields = [];
  premAdjustRegulatoryFields = [];
  producerSearchCode: string;
  private sectionNames;
  private sectionisRequired;
  sectionName: string;
  private api: string;
  private premiumSection: boolean;
  private useServiceCenterAddressChange: () => void;
  private saveFormData: () => void;
  fill3817FieldDetails;
  noticeGenerate: boolean;
  private componentMethodCallSource = new Subject<any>();
  componentMethodCalled$ = this.componentMethodCallSource.asObservable();
  lastFormIndex = 0;
  reasonForActionOptions = [];
  lookupTableData = [];
  lookupDaysValidationData;
  private showLookupDaysNoticeWarning: () => void;
  private showMortgageeEffectiveDtWarning: (ref) => void;
  showLookupWarningPopup = true;
  showDoubleWarningPoup = false;
  private getPolicyInfo: () => void;
  previousPolicyNumber: string = null;
  previousMailingDate = null;
  isNoticeRegenerated = false;
  insurerUseServiceCenterAddressDefaultValue = false;
  currentFormCode;
  amtFields = new Set();
  dateFields = new Set();
  settingDetails;
  showNavigationPrefillWarning = true;
  navPrefillNext = false;
  isLookupselected = false;
  isProducerFormValid = false;
  isSupplementalFirstLoad = false;
  allStateCodes = [];
  avoidPreAdjustNavigation = false;
  isPreAdjustmentFormValid = false;
  isNavigationPrefilledClicked = false;
  navigationSectionIndex = null;
  mortgegeeIgnoreArray = [];
  standardDateFields = [NoticeGenerationConstants.allowPastDateField.transactionDt,
      NoticeGenerationConstants.allowPastDateField.mailingDt,
      NoticeGenerationConstants.allowPastDateField.policyEffectiveDt,
      NoticeGenerationConstants.allowPastDateField.premDueDt,
      NoticeGenerationConstants.allowPastDateField.premDueDt1
    ];
  dependencyArray = [];
  insurerSelectedValues = null;
  isNoticeRegeneratedExactMatch = false;

  // Day's notice warning log data
  daysNoticeWarningLogData = NoticeGenerationConstants.daysNoticeWarningLogData;

  public getSectionsfromAPI(formData: IFormSectionNames, index) {
    this.formData = formData;
    this.formSectionNames = [];
    this.formSectionModel = formData[index].components;
    this.lastFormIndex = this.formSectionModel.length - 1;
    if (this.formSectionModel) {
      this.formSectionModel.forEach((val, elIndex, element) => {
        this.formSectionNames.push({
          displayName:
            element[elIndex].displayName ===
              NoticeGenerationConstants.WCCDisplayName
              ? element[elIndex].name
              : element[elIndex].displayName,
          name: element[elIndex].name,
          index: element[elIndex].displayOrder,
        });
      });
      function compare(a, b) {
        if (a.index > b.index) {
          return 1;
        }
        if (b.index > a.index) {
          return -1;
        }

        return 0;
      }
      this.formSectionNames.sort(compare);
      this.setSections(this.formSectionNames);

      return this.formSectionNames;
    }
  }

  public getIsRequiredfromAPI(formData: IFormSectionIsRequired, index) {
    this.formData = formData;
    this.sectionIsRequired = [];
    this.formSectionModel = formData[index].components;
    if (this.formSectionModel) {
      this.formSectionModel.forEach((val, elIndex, element) => {
        this.sectionIsRequired.push({
          isRequired: element[elIndex].isRequired,
          index: element[elIndex].displayOrder,
        });
      });
      function compare(a, b) {
        if (a.index > b.index) {
          return 1;
        }
        if (b.index > a.index) {
          return -1;
        }

        return 0;
      }
      this.sectionIsRequired.sort(compare);
      this.setSectionsIsRequired(this.sectionIsRequired);
      return this.sectionIsRequired;
    }
  }

  public setSections(sectionNames) {
    this.sectionNames = sectionNames;
    const sectionsAvailable = [];
    this.sectionNames.forEach(element => {
      sectionsAvailable.push(element.name);
    });
    this.setCurrentSection(sectionsAvailable);
  }

  setCurrentSection(sectionNames) {
    const formName = this.getCurrentFormName();
    const data = { 'name': formName, 'sectionsPresent': sectionNames };
    let dataTemp = sessionStorage.sectionsAvailable ? JSON.parse(sessionStorage.sectionsAvailable) : [data];
    let iterator = 0;
    if (dataTemp && dataTemp.length) {
      for (const i of dataTemp) {
        if (i && i.name === formName) {
          dataTemp[iterator] = data;
          break;
        }
        iterator++;
      }
      if (iterator === dataTemp.length) {
        dataTemp = [...dataTemp, data];
      }
    } else {
      dataTemp = [...dataTemp, data];
    }
    sessionStorage.setItem(NoticeGenerationConstants.sectionsAvailable, JSON.stringify(dataTemp));
  }

  addSection(sectionName) {
    const formName = this.getCurrentFormName();
    const presentSections = this.getSectionsForCurrentForm(formName);
    if (!presentSections.includes(sectionName)) {
      presentSections.push(sectionName);
      this.setCurrentSection(presentSections);
    }
  }

  getAllStateCodes() {
    this._http.get(NoticeGenerationConstants.webApis.getStateCodes).subscribe((res: any[]) => {
      const allStateCodes = res.map(state => state.code);
      sessionStorage.setItem(NoticeGenerationConstants.allStateCodes, JSON.stringify(allStateCodes));
    });
  }

  removeSection(sectionName) {
    const formName = this.getCurrentFormName();
    const presentSections = this.getSectionsForCurrentForm(formName);
    const updatedSections = presentSections.filter(el => el !== sectionName);
    this.setCurrentSection(updatedSections);
  }

  removeSectionData(sectionName) {
    const formName = this.getCurrentFormName();
    const updatedData = [];
    let formData = [];
    const noticeData = (sessionStorage.noticeData && JSON.parse(sessionStorage.noticeData)) ? JSON.parse(sessionStorage.noticeData) : [];

    if (noticeData && noticeData.length) {
      for (const i of noticeData) {
        if (i && i.name === formName) {
          formData = i.formData;
          formData.forEach(element => {
            if (element.sectionName !== sectionName) {
              formData.push(element);
            }
          });
          const data = i.components;
          data.forEach(element => {
            if (element.name !== sectionName) {
              updatedData.push(element);
            }
          });
          break;
        }
      }
    }
    this.pushDataToNoticeData(updatedData, formData);
  }

  getSectionsForCurrentForm(formName) {
    let data = [];
    const dataTemp = JSON.parse(sessionStorage.sectionsAvailable);
    if (dataTemp && dataTemp.length) {
      for (const i of dataTemp) {
        if (i && i.name === formName) {
          data = i.sectionsPresent;
          break;
        }
      }
    }
    return data;
  }

  getCurrentFormName() {
    let isSupplementalForm;
    let currentSupplementalForm = '';
    const formData = this.getPrefill();
    const formCode = sessionStorage.MainFormName ? sessionStorage.MainFormName : formData[0].name;
    const supplementalFormCode =  this.currentFormCode;
    this.route.queryParams.subscribe(params => {
      isSupplementalForm = Boolean(params['supplementalForm']);
      currentSupplementalForm = params[NoticeGenerationConstants.formCode];
    });
    if (!isSupplementalForm) {
     sessionStorage.setItem('CurrentFormName', this.isSupplementalForm ? supplementalFormCode : formCode);
    }
    return (isSupplementalForm ? currentSupplementalForm : formCode);
  }

  public getSections() {
    return this.sectionNames;
  }

  public setSectionsIsRequired(isRequired) {
    this.sectionisRequired = isRequired;
  }

  public getSectionsIsRequired() {
    return this.sectionisRequired;
  }

  public setPrefill(formData) {
    const formCode = formData ? formData[0].name : '';
    sessionStorage.setItem('MainFormName', formCode);
    this.formData = formData;
  }

  public getPrefill() {
    return this.formData;
  }

  public getSupplementalForms(formData: ISupplementalForm[]) {
    const formNames: ISupplementalForm[] = [];
    formData.forEach((value, index, element) => {
      if (element[index].isSupplemental) {
        formNames.push({
          name: element[index].name.slice(0, -4),
          index: index,
          pdfUrl: element[index].pdfUrl,
          formCode: element[index].name,
        });
      }
    });
    return formNames;
  }

  public getDocumentLinks(formData: IDocumentLinks[], index) {
    const documentLinks = [];
    if (formData) {
      const linkData = this.getdocumentLinksName(formData, index);
      documentLinks.push({
        name: linkData.formFileName,
        pdfUrl: formData[index].pdfUrl,
        docUrl: formData[index].docUrl,
        regHelpDocUrl: formData[index].regHelpDocUrl,
        helpFormName: linkData.helpFileName
      });
    }
    return documentLinks;
  }

  getdocumentLinksName(formData, index) {
    let helpFileName = '';
    let formFileName = '';
    const url = new URL(formData[index]?.regHelpDocUrl);
    const queryParam = new URLSearchParams(url.search);
    helpFileName = queryParam?.get(NoticeGenerationConstants.filenameKey);

    helpFileName = helpFileName?.slice(0, helpFileName?.indexOf('.'));
    formFileName = formData[index]?.name?.slice(0, formData[index]?.name?.indexOf('.'));

    return {
      helpFileName,
      formFileName
    };
  }

  public setProducerCode(code) {
    this.producerSearchCode = code;
  }

  public getProducerCode() {
    return this.producerSearchCode;
  }

  public getLastFormIndex() {
    return this.lastFormIndex;
  }

  public getFormFields(formSectionDetails: IFormSectionModel) {
    this.premiumSection =
      formSectionDetails.name ===
        NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment
        ? true
        : false;
    this.fieldDetails = [];
    this.formFields = [{}];
    this.regularatoryProducts = [];
    this.regulatoryRequiredFields = [];
    this.requiredFields = [];
    this.fieldDetails = formSectionDetails.fields;
    this.sectionName = formSectionDetails.name;
    this.settingDetails = formSectionDetails.settings;

    if (
      NoticeGenerationConstants.customCopiesFieldSections.includes(
        formSectionDetails.name
      )
    ) {
      formSectionDetails.fields.forEach((field) => {
        if (field.name.includes(NoticeGenerationConstants.fill3817)) {
          this.fill3817FieldDetails = field;
        }
      });
    }

    if (this.sectionName === NoticeGenerationConstants.producerText) {
      this.settingDetails.ProducerCodeLookup ? this.setProducerCode(NoticeGenerationConstants.producerSearchBy.producerCode) :
        this.setProducerCode(NoticeGenerationConstants.producerSearchBy.producerName);
    }

    if (this.fieldDetails) {
      this.fieldDetails.forEach((val, index, element) => {

        // special regulatory condition
        if (
          element[index].isRequired &&
          element[index].isRegulatoryRequirement
        ) {
          this.regularatoryProducts.push(element[index].name);
          this.regulatoryRequiredFields.push({
            key: element[index].name,
            value: element[index].displayName,
          });
        }

        if (
          !element[index].isRequired &&
          element[index].isRegulatoryRequirement
        ) {
          this.regulatoryRequiredFields.push({
            key: element[index].name,
            value: element[index].displayName,
          });
        }

        if (
          element[index].isRequired &&
          !element[index].isRegulatoryRequirement &&
          element[index].name !==
          NoticeGenerationConstants.producerSearchBy.producerCode
        ) {
          this.requiredFields.push({
            key: element[index].name,
            value: element[index].displayName,
          });
        }

        if (
          element[index].displayControlType === 'checkbox' &&
          element[index].name ===
          NoticeGenerationConstants.insurerForm.useServiceCenterAddress
        ) {
          this.insurerUseServiceCenterAddressDefaultValue =
            element[index].defaultValue;
        }

        if (
          element[index].displayControlType === 'text' &&
          element[index].format == null &&
          !element[index].optionsUrl &&
          element[index].name !==
          NoticeGenerationConstants.producerSearchBy.producerCode
        ) {
          this.pushNullFormatField(element, index);
        }

        if (
          element[index].displayControlType === 'text' &&
          element[index].format === 'Double' &&
          !element[index].optionsUrl
        ) {
          this.pushDoubleFormatField(element, index);
        }

        if (
          element[index].displayControlType === 'text' &&
          element[index].format == null &&
          element[index].optionsUrl &&
          !element[index].optionsUrl.includes(
            NoticeGenerationConstants.reasonsAPIurl
          )
        ) {
          this.pushNullFormatFieldWhenOptionUrl(element, index);
        }

        if (
          element[index].displayControlType === 'text' &&
          element[index].format == null &&
          element[index].optionsUrl &&
          element[index].optionsUrl.includes(
            NoticeGenerationConstants.reasonsAPIurl
          )
        ) {
          this.pushReasonForActionField(element, index);
        }

        if (
          element[index].displayControlType === 'number' &&
          element[index].name.includes(NoticeGenerationConstants.copies) &&
          !NoticeGenerationConstants.customCopiesFieldSections.includes(
            formSectionDetails.name
          )
        ) {
          this.pushCopyNumberFormatField(element, index);
        }

        if (
          element[index].displayControlType === 'number' &&
          element[index].name.includes(NoticeGenerationConstants.copies) &&
          NoticeGenerationConstants.customCopiesFieldSections.includes(
            formSectionDetails.name
          )
        ) {
          this.pushCopyNumberFormatCheckboxField(element, index);
        }

        if (
          element[index].displayControlType === 'number' &&
          !element[index].name.includes(NoticeGenerationConstants.copies)
        ) {
          this.pushNumberFormatField(element, index);
        }

        if (
          element[index].displayControlType === 'checkbox' &&
          !element[index].name.includes(NoticeGenerationConstants.fill3817) &&
          element[index].name !==
          NoticeGenerationConstants.insurerForm.useServiceCenterAddress
        ) {
          this.pushCheckBoxFormatField(element, index);
        }
        if (element[index].name.includes(NoticeGenerationConstants.mailType)) {
          this.pushMailTypeField(element, index);
        }
        if (
          element[index].displayControlType === 'radio' &&
          !element[index].name.includes(NoticeGenerationConstants.mailType)
        ) {
          this.pushRadioFormatField(element, index);
        }
        if (
          element[index].displayControlType === 'text' &&
          element[index].format === 'Date' &&
          !element[index].isOptionRequired
        ) {
          this.pushDateFormatField(element, index);
        }

        if (
          element[index].displayControlType === 'text' &&
          element[index].isOptionRequired &&
          element[index].format === 'Date'
        ) {
          this.pushDateFormatFieldWhenOptionRequired(element, index);
        }
        if (
          (element[index].displayControlType === 'text' &&
            element[index].isOptionRequired &&
            element[index].format === 'Time') ||
          (element[index].displayControlType === 'text' &&
            !element[index].isOptionRequired &&
            element[index].format === 'Time' &&
            element[index].name ===
            NoticeGenerationConstants.fieldNames.mortgagee.effectiveTime)
        ) {
          this.pushTimeFormatField(element, index);
        }
        if (
          element[index].displayControlType === 'text' &&
          !element[index].isOptionRequired &&
          element[index].format === 'Time' &&
          element[index].name !==
          NoticeGenerationConstants.fieldNames.mortgagee.effectiveTime
        ) {
          this.pushTimeFormatTextField(element, index);
        }
      });
      this.pushDependencyRules(formSectionDetails.fieldDependencyRules);
    }

    this.formFields.map((f) => {
      if (f.templateOptions && f.templateOptions.changeExpr) {
        f.templateOptions.change = Function(
          'field',
          '$event',
          f.templateOptions.changeExpr
        ).bind(this);
      }
    });

    // added new field LOB in dynamic form at start of fieldarray for policy change
    if (
      formSectionDetails.name.includes(NoticeGenerationConstants.policyText)
    ) {
      this.formFields.unshift({
        key: 'LOB',
        wrappers: ['labelWrapper'],
        type: 'input',
        className: 'text-class',
        templateOptions: {
          type: 'text',
          label: 'Sublines of Business',
          readonly: true,
        },
      });
    }
    return this.formFields;
  }

  pushNullFormatField(element: any, index: any) {
    this.formFields.push({
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'input',
      defaultValue: this.getDefaultValue(
        element[index].defaultValue,
        this.premiumSection
      ),
      className: this.getPushNullFormatFieldClass(element[index].name, this.premiumSection),
      templateOptions: {
        type: 'text',
        label: element[index].displayName,
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        isRegulatoryRequirement: element[index].isRegulatoryRequirement,
        minLength: element[index].minLength,
        maxLength: element[index].maxLength,
        dependencyRules: element[index].dependencyRules,
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        displaySize: element[index].displaySize
          ? element[index].displaySize
          : null,
        name: element[index].name,
        change: (field, $event) => {
          this.fieldRuleValidator(field, $event);
        }
      },
      validators: {
        validation: ['noSpace', 'postalCode', 'phoneNumber'],
      },
      modelOptions: {
        updateOn: element[index].name === NoticeGenerationConstants.policyNumber ? 'blur' : 'change',
      },
      hooks: {
        onInit: (field: FormlyFieldConfig) => {
          if (field.key === NoticeGenerationConstants.policyNumber) {
            this.clearPolicyDetailsOnInitialLoad(field);
            field.form
              .get(NoticeGenerationConstants.policyNumber)
              .valueChanges.subscribe((result) => {
                this.emitUpdatedModel.next();
              });
          }
        },
        onChanges: (field: FormlyFieldConfig) => {
          if (field.key === NoticeGenerationConstants.policyNumber) {
            this.clearPolicyDetailsOnInitialLoad(field);
            field.form
              .get(NoticeGenerationConstants.policyNumber)
              .valueChanges.pipe(debounceTime(100), distinctUntilChanged())
              .subscribe((result) => {
                const policyNumber = field.form.get(
                  NoticeGenerationConstants.policyNumber
                ).value;
                let isSupplementalForm;
                this.route.queryParams.subscribe(params => {
                  isSupplementalForm = Boolean(params['supplementalForm']);
                });
                if (
                  policyNumber &&
                  policyNumber !== null &&
                  policyNumber !== '' &&
                  policyNumber !== this.previousPolicyNumber &&
                  !isSupplementalForm
                ) {
                  this.previousPolicyNumber = policyNumber;
                  this.getPolicyInfo();
                }
              });
          }
        },
        Validators: {
          validation: ['noSpace', 'postalCode'],
        },
      },
    });
  }

  pushDoubleFormatField(element: any, index: any) {
    this.formFields.push({
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'input',
      defaultValue: element[index].defaultValue
        ? parseFloat(
          this.getDefaultValue(
            element[index].defaultValue,
            this.premiumSection
          )
        ).toFixed(2)
        : '',
      className: this.getDoubleFormatClass(element[index].name, this.premiumSection),
      templateOptions: {
        type: 'input',
        label: element[index].displayName,
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        isRegulatoryRequirement: element[index].isRegulatoryRequirement,
        min: element[index].minLength
          ? element[index].minLength
          : element[index].min,
        max: element[index].maxLength
          ? element[index].maxLength
          : element[index].max,
        dependencyRules: element[index].dependencyRules,
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        keypress: (field, event) => {
          this.validateNumber(event);
          this.showDoubleWarningPoup = true;
        },
        change: (field, event) => {
          this.showDoubleWarningPoup = true;
          this.fieldRuleValidator(field, event);
        },
      },
      modelOptions: {
        updateOn: 'blur'
      },
      hooks: {
        onChanges: (field: FormlyFieldConfig) => {
          if (field.key === element[index].name) {
            field.form
              .get(element[index].name)
              .valueChanges.pipe(debounceTime(100), distinctUntilChanged())
              .subscribe((result) => {
                this.fieldRuleValidator(field, null);
                const fieldValue = field.form.get(element[index].name).value;
                if (fieldValue && fieldValue !== null && fieldValue !== '') {
                  this.showDoubleFormatWarning(field, element[index].name, fieldValue);
                }
              });
          }
        },
      }
    });
  }

  pushNullFormatFieldWhenOptionUrl(element: any, index: any) {
    const stateFieldObj = {
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'select',
      defaultValue: element[index].defaultValue,
      templateOptions: {
        label: element[index].displayName,
        placeholder: this.getStateFieldPlaceholder(element[index].name),
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        isRegulatoryRequirement: element[index].isRegulatoryRequirement,
        minLength: element[index].minLength,
        maxLength: element[index].maxLength,
        valueProp: 'code',
        options: null,
        labelProp: 'name',
        dependencyRules: element[index].dependencyRules,
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        change: (field, $event) => {
          this.fieldRuleValidator(field, $event);
        }
      },
    };
    if (
      !NoticeGenerationConstants.sectionStateFields.includes(
        element[index].name
      )
    ) {
      stateFieldObj.templateOptions.options = this.getdropdownOptions(
        element[index].optionsUrl,
        element[index].name
      );
      this.formFields.push(stateFieldObj);
    } else {
      this.getdropdownOptions(
        element[index].optionsUrl,
        element[index].name
      ).subscribe((data: any) => {
        stateFieldObj.templateOptions.options = data;
        this.formFields.push(stateFieldObj);
      });
    }
  }

  pushNumberFormatField(element: any, index: any) {
    this.formFields.push({
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'input',
      defaultValue: this.getDefaultValue(
        element[index].defaultValue,
        this.premiumSection
      ),
      templateOptions: {
        label: element[index].displayName,
        type: this.shouldHideField(element[index].name) ? 'hidden' : 'number',
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        min: element[index].min,
        max: element[index].max,
        isRegulatoryRequirement: element[index].isRegulatoryRequirement,
        dependencyRules: element[index].dependencyRules,
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        change: (field, $event) => {
          this.fieldRuleValidator(field, $event);
        }
      },
    });
  }

  pushCopyNumberFormatField(element: any, index: any) {
    this.getdropdownOptions(
      element[index].optionsUrl,
      element[index].name
    ).subscribe((data: any) => {
      this.formFields.push({
        key: element[index].name,
        wrappers: ['labelWrapper'],
        type: 'select',
        className: this.getCopyNumberFormatFieldClass(element[index].name),
        defaultValue: this.getDefaultValue(
          element[index].defaultValue,
          this.premiumSection
        ),
        templateOptions: {
          label: element[index].displayName,
          name: element[index].name,
          required:
            element[index].isRequired && element[index].isRegulatoryRequirement
              ? false
              : element[index].isRequired,
          isRegulatoryRequirement: element[index].isRegulatoryRequirement,
          minLength: element[index].minLength,
          maxLength: element[index].maxLength,
          options: data,
          valueProp: 'id',
          labelProp: 'name',
          dependencyRules: element[index].dependencyRules,
          isregularatoryProduct: this.isregularatoryProducts(
            element[index].name
          ),
          change: (field, $event) => {
            this.fieldRuleValidator(field, $event);
          }
        },
      });
    });
  }

  pushCheckBoxFormatField(element: any, index: any) {
    this.formFields.push({
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'checkbox',
      defaultValue: this.getDefaultValue(
        element[index].defaultValue,
        this.premiumSection
      ),
      className: 'checkbox-class',
      templateOptions: {
        type: 'checkbox',
        label: '',
        name: this.getName(element[index].displayName),
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        isRegulatoryRequirement: element[index].isRegulatoryRequirement,
        indeterminate: false,
        dependencyRules: element[index].dependencyRules,
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        change: (field, $event) => {
          this.fieldRuleValidator(field, $event);
        }
      },
      hooks: {
        onChanges: (field: FormlyFieldConfig) => {
          if (
            element[index].name ===
            NoticeGenerationConstants.insurerForm.useServiceCenterAddress
          ) {
            field.form
              .get(
                NoticeGenerationConstants.insurerForm.useServiceCenterAddress
              )
              .valueChanges.subscribe((result) => {
                this.useServiceCenterAddressChange();
              });
          }
        },
      },
    });
  }

  fieldRuleValidator(field, event) {
    const currentRule = this.dependencyArray.find(obj => {
      return obj.name === field?.key;
    });

    if (currentRule) {
      currentRule.dependencyRules.forEach(rule => {
        rule.events.forEach(e => {
          switch (e.eventType) {
            case NoticeGenerationConstants.eventType.updateFieldValue:
              /* tslint:disable */
              if (eval(rule.expression) && e.field !== field?.key) {
               /* tslint:enable */
                field?.form?.controls[e.field].setValue(e.value);
              }
              break;
            case NoticeGenerationConstants.eventType.requiredField:
              const formlyField = this.formFields.find(f => {
                return f.key === e.field;
              });
              /* tslint:disable */
              if (eval(rule.expression)) {
              /* tslint:enable */
                formlyField.templateOptions.required = true;
              } else {
                formlyField.templateOptions.required = false;
              }
              break;
          }
        });
      });
    }
  }


  fieldRuleValidatorForAllFields() {
    let currentRule;
    this.formFields.forEach(field => {
      if (field && field.templateOptions && field.templateOptions['dependencyRules']) {
        currentRule = this.dependencyArray.find(obj => {
          return obj.name === field.key;
        });
        if (currentRule) {
          currentRule.dependencyRules.forEach(rule => {
            rule.events.forEach(e => {
              switch (e.eventType) {
                case NoticeGenerationConstants.eventType.updateFieldValue:
                  if (field && field.form) {
                    /* tslint:disable */
                    if (eval(rule.expression) && e.field !== field.key) {
                      /* tslint:enable */
                      field?.form?.controls[e.field].setValue(e.value);
                    }
                  }
                  break;
                case NoticeGenerationConstants.eventType.requiredField:
                  const formlyField = this.formFields.find(f => {
                    return f.key === e.field;
                  });
                  /* tslint:disable */
                    if (eval(rule.expression)) {
                      /* tslint:enable */
                      formlyField.templateOptions.required = true;
                    } else {
                      formlyField.templateOptions.required = false;
                    }
                  break;
              }
            });
          });
        }
      }
    });
  }

  getName(displayName) {
    if (displayName === NoticeGenerationConstants.fieldNameOnPolicy) {
      if (displayName.includes('/')) {
        displayName = displayName.replaceAll('/', '/ ');
      }
    }
    return displayName;
  }
  pushDateFormatField(element: any, index: any) {
    this.formFields.push({
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'datepicker',
      className: 'date-class',
      defaultValue: this.getDefaultValue(
        element[index].defaultValue,
        this.premiumSection,
        element[index].name
      ),
      templateOptions: {
        type: 'date',
        label: element[index].displayName,
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        isRegulatoryRequirement:
          element[index].name ===
            NoticeGenerationConstants.fieldNames.mortgagee.effectiveDate
            ? false
            : element[index].isRegulatoryRequirement,
        dependencyRules: element[index].dependencyRules,
        showLookupNotice: element[index].isOptionRequired,
        optionsUrl: element[index].optionsUrl,
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        change: (field, $event) => {
          this.fieldRuleValidator(field, $event);
        }
      },
      validators: {
        validation: ['dateInvalid'],
      },
      modelOptions: {
        updateOn: 'blur',
      },
      hooks: {
        onChanges: (field: FormlyFieldConfig) => {
          if (element[index].name === NoticeGenerationConstants.fieldNames.mortgagee.effectiveDate) {
            field.form.get(NoticeGenerationConstants.fieldNames.mortgagee.effectiveDate).valueChanges
            .pipe(debounceTime(100), distinctUntilChanged())
            .subscribe((result) => {
              const effectiveDtValue = field.form.get(element[index].name).value;
              this.showMortgageeEffectiveDtWarning(effectiveDtValue);
            });
          }
          if (element[index].name === NoticeGenerationConstants.mailingDate) {
            field.form.get(NoticeGenerationConstants.mailingDate)
              .valueChanges.pipe(debounceTime(100), distinctUntilChanged())
              .subscribe((result) => {
              const MailingDateValue = field.form.get(element[index].name).value; // Getting Mailing Date Value
              if (MailingDateValue) {
              this.updateLookupDate(field, MailingDateValue);
              }
              else {
                this.setLookupTableDataToLocalS(this.lookupData);
                this.previousMailingDate = null;
              }
              setTimeout(() => {
                this.saveFormData();
              }, 100);
              this.showLookupDaysNoticeWarning();
            });
          }
        },
      },
    });
  }
  pushRadioFormatField(element: any, index: any) {
    this.getOptionsData(element[index].optionsUrl).subscribe((data: any) => {
      this.formFields.push({
        key: element[index].name,
        wrappers: ['labelWrapper'],
        type: 'radio',
        defaultValue: this.getDefaultValue(
          element[index].defaultValue,
          this.premiumSection
        ),
        templateOptions: {
          label: element[index].displayName,
          required:
            element[index].isRequired && element[index].isRegulatoryRequirement
              ? false
              : element[index].isRequired,
          isRegulatoryRequirement: element[index].isRegulatoryRequirement,
          options: data,
          valueProp: 'code',
          labelProp: 'name',
          dependencyRules: element[index].dependencyRules,
          isregularatoryProduct: this.isregularatoryProducts(
            element[index].name
          ),
          change: (field, $event) => {
            this.fieldRuleValidator(field, $event);
          }
        },
      });
    });
  }

  pushMailTypeField(element: any, index: any) {
    const mailtypeObj = {
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'mailType',
      defaultValue: this.getDefaultValue(
        element[index].defaultValue,
        this.premiumSection
      ),
      className: this.getPushMailTypeFormatFieldClass(element[index].name),
      templateOptions: {
        type: 'radio',
        label: element[index].displayName,
        key: element[index].name,
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        isRegulatoryRequirement: element[index].isRegulatoryRequirement,
        options: null,
        valueProp: 'code',
        labelProp: 'name',
        dependencyRules: element[index].dependencyRules,
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        nonComplianceWarnings: element[index].nonComplianceWarnings,
        change: (field, $event) => {
          this.fieldRuleValidator(field, $event);
        }
      },
    };
    if (
      !NoticeGenerationConstants.sectionMailTypes.includes(
        element[index].name
      ) &&
      element[index].name.indexOf(NoticeGenerationConstants.mailType) > -1
    ) {
      mailtypeObj.templateOptions.options = this.getOptionsData(
        element[index].optionsUrl
      );
      this.formFields.push(mailtypeObj);
    } else {
      this.getOptionsData(element[index].optionsUrl).subscribe((data: any) => {
        mailtypeObj.templateOptions.options = data;
        this.formFields.push(mailtypeObj);
      });
    }
  }
  pushDateFormatFieldWhenOptionRequired(element: any, index: any) {
    this.formFields.push({
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'lookup',
      defaultValue: this.getDefaultValue(
        element[index].defaultValue,
        this.premiumSection
      ),
      templateOptions: {
        type: 'date',
        placeholder: 'mm/dd/yyyy',
        key: element[index].name,
        label: element[index].displayName,
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        isRegulatoryRequirement: element[index].isRegulatoryRequirement,
        dependencyRules: element[index].dependencyRules,
        showLookupNotice: element[index].isOptionRequired,
        optionsUrl: element[index].optionsUrl,
        changeExpr: 'this.getData($event, field)',
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        change: (field, $event) => {
          this.fieldRuleValidator(field, $event);
        }
      },
      validators: {
        validation: ['dateInvalid'],
      },
      modelOptions: {
        updateOn: 'blur',
      },
      hooks: {
        onChanges: (field: FormlyFieldConfig) => {
          if (element[index].name === NoticeGenerationConstants.transactionDate) {
            field.form.get(NoticeGenerationConstants.transactionDate).valueChanges.subscribe((result) => {
              setTimeout(() => {
                this.saveFormData();
              }, 100);
              this.showLookupDaysNoticeWarning();
            });
          }
        },
      },
    });
  }

  pushTimeFormatField(element: any, index: any) {
    const timeDropdownObj = {
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'select',
      defaultValue:
        this.getDefaultValue(
          element[index].defaultValue,
          this.premiumSection
        ) === '00:01:00'
          ? '12:01 AM'
          : element[index].defaultValue,
      className: 'select-class',
      templateOptions: {
        label: element[index].displayName,
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        isRegulatoryRequirement: element[index].isRegulatoryRequirement,
        minLength: element[index].minLength,
        maxLength: element[index].maxLength,
        options: null,
        optionsUrl: element[index].optionsUrl,
        valueProp: 'code',
        labelProp: 'name',
        dependencyRules: element[index].dependencyRules,
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        change: (field, $event) => {
          this.fieldRuleValidator(field, $event);
        }
      },
    };

    if (
      element[index].name !==
      NoticeGenerationConstants.fieldNames.mortgagee.effectiveTime
    ) {
      timeDropdownObj.templateOptions.options = this.getdropdownOptions(
        element[index].optionsUrl,
        element[index].name
      );
      this.formFields.push(timeDropdownObj);
    } else {
      this.getdropdownOptions(
        element[index].optionsUrl,
        element[index].name
      ).subscribe((data: any) => {
        timeDropdownObj.templateOptions.options = data;
        this.formFields.push(timeDropdownObj);
      });
    }
  }

  pushTimeFormatTextField(element: any, index: any) {
    this.formFields.push({
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'input',
      defaultValue:
        this.getDefaultValue(
          element[index].defaultValue,
          this.premiumSection
        ) === '00:01:00'
          ? '12:01 AM'
          : element[index].defaultValue,
      templateOptions: {
        type: 'text',
        label: element[index].displayName,
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        isRegulatoryRequirement: element[index].isRegulatoryRequirement,
        minLength: element[index].minLength,
        maxLength: element[index].maxLength,
        dependencyRules: element[index].dependencyRules,
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        displaySize: element[index].displaySize
          ? element[index].displaySize
          : null,
        name: element[index].name,
        change: (field, $event) => {
          this.fieldRuleValidator(field, $event);
        }
      },
    });
  }

  pushCopyNumberFormatCheckboxField(element: any, index: any) {
    this.getdropdownOptions(
      element[index].optionsUrl,
      element[index].name
    ).subscribe((data: any) => {
      this.formFields.push({
        fieldGroupClassName: 'row',
        fieldGroup: [
          {
            key: element[index].name,
            wrappers: ['labelWrapper'],
            type: 'select',
            className:
              'col-md-6 ' +
              this.getCopyNumberFormatFieldClass(element[index].name),
            defaultValue: this.getDefaultValue(
              element[index].defaultValue,
              this.premiumSection
            ),
            templateOptions: {
              label: element[index].displayName,
              name: element[index].name,
              required:
                element[index].isRequired &&
                  element[index].isRegulatoryRequirement
                  ? false
                  : element[index].isRequired,
              isRegulatoryRequirement: element[index].isRegulatoryRequirement,
              minLength: element[index].minLength,
              maxLength: element[index].maxLength,
              options: data,
              valueProp: 'id',
              labelProp: 'name',
              dependencyRules: element[index].dependencyRules,
              isregularatoryProduct: this.isregularatoryProducts(
                element[index].name
              ),
              change: (field, $event) => {
                this.fieldRuleValidator(field, $event);
              }
            },
          },
          {
            key: this.fill3817FieldDetails.name,
            type: 'checkbox',
            defaultValue: this.getDefaultValue(
              this.fill3817FieldDetails.defaultValue,
              this.premiumSection
            ),
            className: 'checkbox-class-1',
            templateOptions: {
              type: 'checkbox',
              label: this.fill3817FieldDetails.displayName,
              name: this.fill3817FieldDetails.displayName,
              required:
                this.fill3817FieldDetails.isRequired &&
                  this.fill3817FieldDetails.isRegulatoryRequirement
                  ? false
                  : this.fill3817FieldDetails.isRequired,
              isRegulatoryRequirement:
                this.fill3817FieldDetails.isRegulatoryRequirement,
              indeterminate: false,
              dependencyRules: this.fill3817FieldDetails.dependencyRules,
              isregularatoryProduct: this.isregularatoryProducts(
                this.fill3817FieldDetails.name
              ),
              change: (field, $event) => {
                this.fieldRuleValidator(field, $event);
              }
            },
          },
        ],
      });
    });
  }

  pushReasonForActionField(element: any, index: any) {
    if (this.reasonForActionOptions && this.reasonForActionOptions.length > 0) {
      this.formFields.push({
        key: element[index].name + '_dropdown',
        wrappers: ['labelWrapper'],
        type: 'reasonsDropdown',
        className: 'select-class-500px reason-drop-down',
        defaultValue: null,
        templateOptions: {
          label: '',
          placeholder: 'Please select',
          minLength: element[index].minLength,
          maxLength: element[index].maxLength,
          options: this.getdropdownOptions(
            element[index].optionsUrl,
            element[index].name
          ),
          valueProp: 'value',
          labelProp: 'description',
          dependencyRules: [],
          change: ($event) => {
            const textboxField = this.formFields.find(f => {
              return f.key === element[index].name;
            });
            this.fieldRuleValidator(textboxField, $event);
          }
        },
        hooks: {
          onChanges: (field: FormlyFieldConfig) => {
            this.fieldRuleValidator(field.form.get(element[index].name), null);
            field.form
              .get(element[index].name + '_dropdown')
              .valueChanges.subscribe((result) => {
                field.form.get(element[index].name).setValue(result);
              });
          },
        },
      });
    }

    this.formFields.push({
      key: element[index].name,
      wrappers: ['labelWrapper'],
      type: 'input',
      defaultValue: this.getDefaultValue(
        element[index].defaultValue,
        this.premiumSection
      ),
      className: this.getPushNullFormatFieldClass(element[index].name, this.premiumSection),
      templateOptions: {
        type: 'text',
        label: element[index].displayName,
        required:
          element[index].isRequired && element[index].isRegulatoryRequirement
            ? false
            : element[index].isRequired,
        isRegulatoryRequirement: element[index].isRegulatoryRequirement,
        minLength: element[index].minLength,
        maxLength: element[index].maxLength,
        dependencyRules: element[index].dependencyRules,
        isregularatoryProduct: this.isregularatoryProducts(element[index].name),
        displaySize: element[index].displaySize
          ? element[index].displaySize
          : null,
        name: element[index].name,
        change: (field, $event) => {
          this.fieldRuleValidator(field, $event);
        }
      },
    });
  }

  pushDependencyRules(fieldDependencyRules: IFieldDependencyRules) {
    let modelExpression: string;
    let condition: IDependencyRuleCondition[];
    let event: IDependencyRuleEvent[];
    this.dependencyArray = [];
    this.formFields.forEach((element) => {

      if (
        element &&
        element.templateOptions &&
        element.templateOptions['dependencyRules'].length !== 0
      ) {
        const dependecyObject = {
          name: element.key,
          dependencyRules: []
        };
        for (
          let i = 0;
          i < element.templateOptions['dependencyRules'].length;
          i++
        ) {

          condition =
            fieldDependencyRules[element.templateOptions['dependencyRules'][i]]
              .conditions;
          event =
            fieldDependencyRules[element.templateOptions['dependencyRules'][i]]
              .events;

          modelExpression = '';
          let updateModelExpression = '';
            const eventValue = '';
              for (let cindex = 0; cindex < condition.length; cindex++) {

                const operator =
                  condition[cindex].conditionOperator ===
                    ConditionOperatorType.equals
                    ? '==='
                    : '!==';

                const conditionValue = condition[cindex].conditionValue === '' ? '\'\'' : condition[cindex].conditionValue;
                modelExpression = 'field?.form?.controls["' + condition[cindex].field + '"].value ' + operator + ' ' + conditionValue;

                if (conditionValue === '\'\'') {
                  const combiner = condition[cindex].conditionOperator ===
                    ConditionOperatorType.equals
                    ? ' || '
                    : ' && ';
                  modelExpression += `${combiner} field?.form?.controls["${condition[cindex].field}"].value ${operator} null`;
                }

                if (condition[cindex].conditionType === 'And') {
                  modelExpression = ' && ' + modelExpression;
                } else if (condition[cindex].conditionType === 'Or') {
                  modelExpression = ' || ' + modelExpression;
                }

                updateModelExpression += modelExpression;
              }


              dependecyObject.dependencyRules.push({
                expression: updateModelExpression,
                events: event,
              });

        }
        this.dependencyArray.push(dependecyObject);
      }
    });
  }

  getData(event, field) { }

  getDefaultValue(defaultValue, premiumSection, fieldName = '') {
    if (premiumSection) {
      return null;
    } else if (fieldName === NoticeGenerationConstants.mailingDate) {
      return moment().format(NoticeGenerationConstants.isoDateFormat);
    } else {
      return defaultValue;
    }
  }

  getLongTextFieldClass(elementName) {
    return elementName.includes(NoticeGenerationConstants.fieldName) ||
      elementName.includes(NoticeGenerationConstants.addr1) ||
      elementName.includes(NoticeGenerationConstants.addr2) ||
      elementName ===
      NoticeGenerationConstants.fieldNames.mortgagee.propertyDescription
      ? true
      : false;
  }
  getDoubleFormatClass(elementName, premiumSection) {
    if (premiumSection) {
      return 'premium-input-field';
    }
    else {
      return 'text-class';
    }


  }

  getPushNullFormatFieldClass(elementName, premiumSection) {
    if (premiumSection) {
      return 'premium-input-field';
    }
    if (elementName === 'ExtRptCovAddr1') {

      return 'text-class';

    }
    if (this.getLongTextFieldClass(elementName)) {
      return 'width-408px';
    }
    if (
      elementName.includes(NoticeGenerationConstants.city) ||
      elementName.includes(NoticeGenerationConstants.postalCode)
    ) {
      return 'width-212px';
    }
    return 'text-class';
  }

  getOptionsData(apiURL: string): Observable<any[]> {
    if (apiURL) {
      return this._http.get(apiURL).map((result: any[]) => {
        if (result && result.length) {
          return result;
        }
      });
    } else {
      const radioOptions: any[] = NoticeGenerationConstants.radioOptions;
      if (this.sectionName !== NoticeGenerationConstants.producerText) {
        radioOptions.pop();
      }
      return of(radioOptions);
    }
  }

  getdropdownOptions(apiURL: string, fieldName: string): Observable<any[]> {
    if (apiURL) {
      const hoursArray = [];
      return this._http.get(apiURL).map((result: any[]) => {
        if (result && result.length) {
          switch (fieldName) {
            case 'TransactionTime':
              result.forEach((item) => {
                if (item === '00:01:00') {
                  item = '12:01 AM';
                } else if (item === '12:00:00') {
                  item = '12:00 PM';
                }
                hoursArray.push({ name: item, code: item });
              });
              return hoursArray;
              break;

            default:
              if (
                apiURL.includes(NoticeGenerationConstants.reasonsAPIurl) &&
                result.length > 0
              ) {
                const data = [];
                result.forEach((value) => {
                  data.push({ description: value, value: value });
                });
                data.push({
                  description: NoticeGenerationConstants.reasonForActionCustom,
                  value: null,
                });
                return data;
              }

              return result;
          }
        }
      });
    } else {
      if (fieldName.includes(NoticeGenerationConstants.copies)) {
        const dropdownOptions: any[] =
          NoticeGenerationConstants.copiesNumberDropDownValues;
        return of(dropdownOptions);
      } else if (
        fieldName === NoticeGenerationConstants.transactionTime ||
        fieldName ===
        NoticeGenerationConstants.fieldNames.mortgagee.effectiveTime
      ) {
        const dropdownOptions: any[] = NoticeGenerationConstants.hoursArray;
        return of(dropdownOptions);
      } else {
        const dropdownOptions: any[] =
          NoticeGenerationConstants.dropDownOptions;
        return of(dropdownOptions);
      }
    }
  }

  isregularatoryProducts(element) {
    if (this.regularatoryProducts.includes(element)) {
      return true;
    } else {
      return false;
    }
  }

  getSectionTypes(sectionType: any) {
    if (sectionType.includes(NoticeGenerationConstants.policyText)) {
      return NoticeGenerationConstants.policyText;
    } else {
      return sectionType;
    }
  }

  isDateValid(data) {
    const today = moment(new Date()).format(NoticeGenerationConstants.isoDateFormat);
    if (data && data !== '' && data < today && data !== today) {
      return true;
    } else {
      return false;
    }
  }
  getSelectedLobUrl(lobIds) {
    const lobArray = lobIds;
    let url = '';
    lobArray.forEach((element, index) => {
      url =
        index === lobArray.length - 1
          ? url + NoticeGenerationConstants.urlGenerate.lobIds + element
          : url +
          NoticeGenerationConstants.urlGenerate.lobIds +
          element +
          NoticeGenerationConstants.urlGenerate.andSymbol;
    });
    url.trim();
    return url;
  }

  onUseServiceCenterChange(fn: () => void) {
    this.useServiceCenterAddressChange = fn;
  }

  shouldHideField(fieldName) {
    if (fieldName) {
      switch (fieldName) {
        case NoticeGenerationConstants.insurerForm.insurerId:
        case NoticeGenerationConstants.fieldNames.mortgagee.id:
        case NoticeGenerationConstants.fieldNames.lienholder.id:
        case NoticeGenerationConstants.fieldNames.certifholder.id:
        case NoticeGenerationConstants.fieldNames.addInt.id:
        case NoticeGenerationConstants.producerForm.producerId:
        case NoticeGenerationConstants.fieldNames.tp.id:
        case NoticeGenerationConstants.fieldNames.wcc.id:
          return true;

        default:
          return false;
      }
    }
  }

  getTypeAndFields(sectionName) {
    let maintainPartiesEnum = null;
    let fieldNames = null;
    switch (sectionName) {
      case NoticeGenerationConstants.sectionNames.mortgagee:
        maintainPartiesEnum = maintainPartyEnums[3];
        fieldNames = NoticeGenerationConstants.fieldNames.mortgagee;
        break;

      case NoticeGenerationConstants.sectionNames.lienholder:
        maintainPartiesEnum = maintainPartyEnums[2];
        fieldNames = NoticeGenerationConstants.fieldNames.lienholder;
        break;

      case NoticeGenerationConstants.sectionNames.certholder:
        maintainPartiesEnum = maintainPartyEnums[1];
        fieldNames = NoticeGenerationConstants.fieldNames.certifholder;
        break;

      case NoticeGenerationConstants.sectionNames.addInt:
        maintainPartiesEnum = maintainPartyEnums[0];
        fieldNames = NoticeGenerationConstants.fieldNames.addInt;
        break;

      case NoticeGenerationConstants.sectionNames.tp:
        maintainPartiesEnum = maintainPartyEnums[4];
        fieldNames = NoticeGenerationConstants.fieldNames.tp;
        break;

      case NoticeGenerationConstants.sectionNames.wcc:
        maintainPartiesEnum = maintainPartyEnums[5];
        fieldNames = NoticeGenerationConstants.fieldNames.wcc;
        break;
    }

    return {
      type: maintainPartiesEnum,
      fieldNames: fieldNames,
    };
  }

  getIdFieldKey(sectionName) {
    switch (sectionName) {
      case NoticeGenerationConstants.sectionNames.mortgagee:
        return NoticeGenerationConstants.fieldNames.mortgagee.id;

      case NoticeGenerationConstants.sectionNames.lienholder:
        return NoticeGenerationConstants.fieldNames.lienholder.id;

      case NoticeGenerationConstants.sectionNames.certholder:
        return NoticeGenerationConstants.fieldNames.certifholder.id;

      case NoticeGenerationConstants.sectionNames.addInt:
        return NoticeGenerationConstants.fieldNames.addInt.id;

      case NoticeGenerationConstants.sectionNames.tp:
        return NoticeGenerationConstants.fieldNames.tp.id;

      case NoticeGenerationConstants.sectionNames.wcc:
        return NoticeGenerationConstants.fieldNames.wcc.id;
    }
  }

  getStateFieldPlaceholder(fieldName) {
    return fieldName.includes(NoticeGenerationConstants.stateProv)
      ? NoticeGenerationConstants.stateProvPlaceholder
      : '';
  }
  getCopyNumberFormatFieldClass(elementName) {
    return elementName.includes(NoticeGenerationConstants.copies)
      ? 'width-52px'
      : '';
  }

  getPushMailTypeFormatFieldClass(elementName) {
    return elementName.includes(NoticeGenerationConstants.mailType)
      ? 'radio-class'
      : '';
  }

  public formatProducerResult(value, addProducerId) {
    if (value === NoticeGenerationConstants.producerForm.noMatch) {
      return NoticeGenerationConstants.producerForm.noMatch;
    }
    if (
      sessionStorage.getItem(
        NoticeGenerationConstants.producerSearchBy.searchProducerBy
      ) === NoticeGenerationConstants.producerSearchBy.producerName
    ) {
      return (
        value.name.trim() +
        (value.code.trim() !== '' ? ', ' : '') +
        (addProducerId ? value.code.trim() : '') +
        (value.address1 ? ', ' : '') +
        value.address1 +
        (value.address2 ? ', ' : '') +
        value.address2 +
        (value.city ? ', ' : '') +
        value.city +
        (value.stateProvince.trim() !== '' ? ', ' : '') +
        value.stateProvince +
        (value.postalCode ? ', ' : '') +
        value.postalCode
      );
    } else {
      return (
        value.code.trim() +
        ' - ' +
        value.name.trim() +
        (value.address1 ? ', ' : '') +
        value.address1 +
        (value.address2 ? ', ' : '') +
        value.address2 +
        (value.city ? ', ' : '') +
        value.city +
        (value.stateProvince.trim() !== '' ? ', ' : '') +
        value.stateProvince +
        (value.postalCode ? ', ' : '') +
        value.postalCode
      );
    }
  }

  public formatProducerInput(value) {
    if (value === NoticeGenerationConstants.producerForm.noMatch) {
      return NoticeGenerationConstants.producerForm.noMatch;
    }
    if (
      sessionStorage.getItem(
        NoticeGenerationConstants.producerSearchBy.searchProducerBy
      ) === NoticeGenerationConstants.producerSearchBy.producerName
    ) {
      return value.name.trim();
    } else {
      return value.code.trim();
    }
  }

  clearFormData() {
    if (
      sessionStorage.getItem(NoticeGenerationConstants.winFormDataKey) !== null
    ) {
      sessionStorage.removeItem(NoticeGenerationConstants.winFormDataKey);
    }
  }

  sendDataToParent(data: any) {
    if (data) {
      const formData = { isDataSent: true, formData: data };
      parent.postMessage(formData, location.origin);
    }
    window.close();
  }
  getLookUpKey() {
    return JSON.parse(
      sessionStorage.getItem(
        NoticeGenerationConstants.LookUpDateDetails.lookUp_key
      )
    );
  }

  getLookUpUrl() {
    return JSON.parse(
      sessionStorage.getItem(
        NoticeGenerationConstants.LookUpDateDetails.lookUp_Url
      )
    );
  }

  setLookUpDetails(key, optionsUrl) {
    sessionStorage.setItem(
      NoticeGenerationConstants.LookUpDateDetails.lookUp_key,
      JSON.stringify(key)
    );
    sessionStorage.setItem(
      NoticeGenerationConstants.LookUpDateDetails.lookUp_Url,
      JSON.stringify(optionsUrl)
    );
  }

  getChildWindowRef() {
    const url =
      environment.appUrl +
      AppConstants.uiRoutes.noticeGeneration +
      NoticeGenerationConstants.routeSeparator +
      AppConstants.uiRoutes.addEditForm;
    return window.open(
      url,
      NoticeGenerationConstants.windowName,
      NoticeGenerationConstants.addEditFormWinConfig
    );
  }

  isduplicateRecord(sectionName, allRecords, checkRecord) {
    const fieldNames = this.getTypeAndFields(sectionName).fieldNames;
    let isDuplicate = false;

    allRecords.forEach((element) => {
      if (element[fieldNames.id] && checkRecord[fieldNames.id]) {
        if (element[fieldNames.id] === checkRecord[fieldNames.id]) {
          isDuplicate = true;
        }
      } else if (
        element[fieldNames.name] === checkRecord[fieldNames.name] &&
        element[fieldNames.addr1] === checkRecord[fieldNames.addr1] &&
        element[fieldNames.city] === checkRecord[fieldNames.city]
      ) {
        isDuplicate = true;
      }
    });
    return isDuplicate;
  }

  extractDataFromParent() {
    if (
      sessionStorage.getItem(NoticeGenerationConstants.winFormDataKey) !== null
    ) {
      const data = JSON.parse(
        sessionStorage.getItem(NoticeGenerationConstants.winFormDataKey)
      );
      return data;
    }
  }

  storeFormData(data: any) {
    sessionStorage.setItem(
      NoticeGenerationConstants.winFormDataKey,
      JSON.stringify(data)
    );
  }

  prefillFormData(form, data) {
    for (const key in data) {
      if (
        data.hasOwnProperty(key) &&
        key !== NoticeGenerationConstants.insurerForm.useServiceCenterAddress
      ) {
        form.get(key)?.setValue(data[key]);
      }
    }
  }

  setMaxDays(max: any) {
    if (max === null) {
      return NoticeGenerationConstants.nA;
    } else {
      return max;
    }
  }

  sortAscending(element: any, data: any) {
    data.sort((a, b) => (a[element] > b[element] ? 1 : -1));
    return data;
  }

  sortDescending(element: any, data: any) {
    data.sort((a, b) => ((a[element] < b[element]) ? 1 : -1));
    return data;
  }
  saveSectionFormData(sectionName, data) {
    let formData = [], component = []; let iterator = 0;
    const formName = this.getCurrentFormName();
    const presentSections = this.getSectionsForCurrentForm(formName);
    if (presentSections.includes(sectionName)) {
      const sectionData = sessionStorage.noticeData ? JSON.parse(sessionStorage.noticeData) : [];
      if (sectionData && sectionData.length) {
        sectionData.filter(ele => {
          if (ele && ele.name === formName) {
            component = ele.components ? ele.components : [];
            if (ele.formData && ele.formData.length) {
              formData = ele.formData;
              if (formData && formData.length) {
                for (const i of formData) {
                  if (i && i.sectionName === sectionName) {
                    if (!Object.values(data).every(obj => obj === null)) {
                      i.formValue = data;
                    } else if (Object.values(NoticeGenerationConstants.sectionNames).includes(sectionName) ||
                      (sectionName === NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment)) {
                      i.formValue = data;
                    }
                    break;
                  }
                  iterator++;
                }
                if (iterator === formData.length) {
                  const form = { 'sectionName': sectionName, 'formValue': this.getRefreshData(sectionName, data) };
                  formData = [...formData, form];
                }
              }
              else {
                const form = { 'sectionName': sectionName, 'formValue': this.getRefreshData(sectionName, data) };
                formData = [...formData, form];
              }
            } else {
              const form = { 'sectionName': sectionName, 'formValue': this.getRefreshData(sectionName, data) };
              formData = [...formData, form];
            }
          }
        });
      } else {
        formData = [{ 'sectionName': sectionName, 'formValue': this.getRefreshData(sectionName, data) }];
      }
      this.pushDataToNoticeData(component, formData);
    }
  }

  getRefreshData(sectionName, data) {
    let formValue;
    if (!Object.values(data).every(obj => obj === null)) {
      formValue = data;
    } else if (Object.values(NoticeGenerationConstants.sectionNames).includes(sectionName) ||
      (sectionName === NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment)) {
      formValue = data;
    }
    return formValue;
  }

  setNoticeStatus(noticeGenerate) {
    this.noticeGenerate = noticeGenerate;
  }

  getNoticeStatus() {
    return this.noticeGenerate;
  }

  getSectionFormData(sectionName) {
    const formName = this.getCurrentFormName();
    const presentSections = this.getSectionsForCurrentForm(formName);
    let data, formData = [];
    const sectionData = sessionStorage.noticeData ? JSON.parse(sessionStorage.noticeData) : [];
    if (presentSections.includes(sectionName)) {
      if (sectionData && sectionData.length) {
        for (const i of sectionData) {
          if (i && i.name === formName) {
            formData = i.formData;
            if (formData && formData.length) {
              for (const item of formData) {
                if (item.sectionName === sectionName) {
                  data = item.formValue;
                  break;
                }
              }
            }
          }
        }
      }
    }
    return data;
    // return JSON.parse(sessionStorage.getItem(sectionName + '_Data'));
  }
  removeStoredData(key) {
    sessionStorage.removeItem(key);
  }

  setToLocal(key, data) {
    sessionStorage.setItem(key, data);
  }

  saveSectionId(sectionId) {
    sessionStorage.setItem(this.getCurrentFormSectionIdKey(), sectionId);
  }

  setStoreData(key, data) {
    sessionStorage.setItem(key, JSON.stringify(data));
  }

  getStoredData(key) {
    return sessionStorage.getItem(key);
  }

  backButtonClicked(msg: object) {
    if (this.sectionName.includes(NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment)) {
      if (this.isPreAdjustmentFormValid) {
        this.isPreAdjustmentFormValid = false;
        this.backButtonClickedEvent.emit(msg);
      }
    } else {
      this.backButtonClickedEvent.emit(msg);
    }

  }

  SectionClicked(id: number) {
    if (this.sectionName.includes(NoticeGenerationConstants.policyText)) {
      if (this.navPrefillNext) {
        this.navPrefillNext = false;
        this.sectionClickedEvent.emit(id);
      }
    } else if (this.sectionName.includes(NoticeGenerationConstants.producerText)) {
      // case - Producer optional section with invalid values
        if (this.isProducerFormValid) {
          this.isProducerFormValid = false;
          this.sectionClickedEvent.emit(id);
        }
    } else if (this.sectionName.includes(NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment)) {
      if (this.isPreAdjustmentFormValid) {
        this.isPreAdjustmentFormValid = false;
        this.sectionClickedEvent.emit(id);
      }
    }
    else {
      this.sectionClickedEvent.emit(id);
    }
  }

  callComponentMethod(data: any) {
    this.componentMethodCallSource.next(data);
  }

  noticeFieldData(sectionName, form) {
    let isSupplementalForm;
    const formName = this.getCurrentFormName();
    const presentSections = this.getSectionsForCurrentForm(formName);
    this.route.queryParams.subscribe(params => {
      isSupplementalForm = Boolean(params['supplementalForm']);
    });

    if (presentSections.includes(sectionName)) {
      if (isSupplementalForm) {
        this.supplementalNoticeData(sectionName, form);
      } else {
        let x = 0;
        let noticeData = (sessionStorage.noticeData &&
          JSON.parse(sessionStorage.noticeData) && JSON.parse(sessionStorage.noticeData)[0].components) ?
          JSON.parse(sessionStorage.noticeData)[0].components : [];
        const formData = (sessionStorage.noticeData &&
          JSON.parse(sessionStorage.noticeData) && JSON.parse(sessionStorage.noticeData)[0].formData) ?
          JSON.parse(sessionStorage.noticeData)[0].formData : [];
        if (form.value && form.value.LOB) {
          delete form.value.LOB;
        }
        if (form.value && form.value.serviceCenterData) {
          delete form.value.serviceCenterData;
        }

        if (noticeData.length > 0) {
          for (const i of noticeData) {
            if (i.name === sectionName && !sectionName.includes(NoticeGenerationConstants.sectionNames)) {
              const index = noticeData.indexOf(i);
              noticeData[index].fields = [];
              if (sectionName === NoticeGenerationConstants.producerText) {
                form.value = { ...form.value };
              }
              if (sectionName === NoticeGenerationConstants.insurerText) {
                form.value = { ...form.value, UseServiceCenterAddress: null };
              }
              noticeData[index].fields = this.createObj(form.value ? form.value : form);

              if (noticeData[index].fields.length === 0) {
                noticeData.splice(index, 1);
              }
              break;
            }
            x++;
          }
          if (x === noticeData.length) {  // 1st time add data
            if (sectionName === NoticeGenerationConstants.producerText) {
              form.value = { ...form.value };
            }
            if (sectionName === NoticeGenerationConstants.insurerText) {
              form.value = { ...form.value, UseServiceCenterAddress: null };
            }
            if (this.createObj(form.value ? form.value : form).length !== 0) {
              noticeData.push({ name: sectionName, fields: this.createObj(form.value ? form.value : form) });
            }
          }
        } else {

          if (sectionName === NoticeGenerationConstants.producerText) {
            form.value = { ...form.value };
          }
          if (sectionName === NoticeGenerationConstants.insurerText) {
            form.value = { ...form.value, UseServiceCenterAddress: null };
          }
          if (this.createObj(form.value ? form.value : form).length !== 0) {
            noticeData.push({ name: sectionName, fields: this.createObj(form.value ? form.value : form) });
          }
        }

        // Ignored-NoticeData
        noticeData = this.ignoreNoticeData(noticeData, true);
        noticeData = this.ignoreNoticeData(noticeData, false);
        noticeData = this.setMortgageeIgnoreData(noticeData);
        const data = [{ 'name': formName, 'components': noticeData, 'formData': formData }];
        const localNoticeData = (sessionStorage.noticeData && JSON.parse(sessionStorage.noticeData))
          ? JSON.parse(sessionStorage.noticeData) : [];
        if (localNoticeData && localNoticeData.length > 0) {
          const index = localNoticeData.findIndex(ele => ele.name === formName);
          localNoticeData[index] = data[0];
          sessionStorage.setItem(NoticeGenerationConstants.noticeData, JSON.stringify(localNoticeData));
        }
        else {
          sessionStorage.setItem(NoticeGenerationConstants.noticeData, JSON.stringify(data));
        }
        return noticeData;

      }
    }
  }

  supplementalNoticeData(sectionName, form) {
    let x = 0;
    let supplementalNoticeData = [], formData = [];
    const formName = this.getCurrentFormName();
    const data = (sessionStorage.noticeData && JSON.parse(sessionStorage.noticeData)) ? JSON.parse(sessionStorage.noticeData) : [];
    if (data && data.length > 0) {
      data.filter(ele => {
        if (ele.name === formName) {
          supplementalNoticeData = ele.components;
          formData = ele.formData;
        }
      });
    }

    if (form.value && form.value.LOB) {
      delete form.value.LOB;
    }
    if (form.value && form.value.serviceCenterData) {
      delete form.value.serviceCenterData;
    }
    if (supplementalNoticeData.length > 0) {
      for (const i of supplementalNoticeData) {
        if (i.name === sectionName && !sectionName.includes(NoticeGenerationConstants.sectionNames)) {
          const index = supplementalNoticeData.indexOf(i);
          supplementalNoticeData[index].fields = [];
          if (sectionName === NoticeGenerationConstants.producerText) {
            form.value = { ...form.value };
          }
          if (sectionName === NoticeGenerationConstants.insurerText) {
            form.value = { ...form.value, UseServiceCenterAddress: null };
          }
          supplementalNoticeData[index].fields = this.createObj(form.value ? form.value : form);

          if (supplementalNoticeData[index].fields.length === 0) {
            supplementalNoticeData.splice(index, 1);
          }
          break;
        }
        x++;
      }
      if (x === supplementalNoticeData.length) {  // 1st time add data for given section
        if (sectionName === NoticeGenerationConstants.producerText) {
          form.value = { ...form.value };
        }
        if (sectionName === NoticeGenerationConstants.insurerText) {
          form.value = { ...form.value, UseServiceCenterAddress: null };
        }
        if (this.createObj(form.value ? form.value : form).length !== 0) {
          supplementalNoticeData.push({
            name: sectionName,
            fields: this.createObj(form.value ? form.value : form),
          });
        }
      }
    } else {
      if (sectionName === NoticeGenerationConstants.producerText) {
        form.value = { ...form.value };
      }
      if (sectionName === NoticeGenerationConstants.insurerText) {
        form.value = { ...form.value, UseServiceCenterAddress: null };
      }
      if (this.createObj(form.value ? form.value : form).length !== 0) {
        supplementalNoticeData.push({ name: sectionName, fields: this.createObj(form.value ? form.value : form) });
      }
    }
    // }

    // Ignored-NoticeData
    supplementalNoticeData = this.ignoreNoticeData(supplementalNoticeData, true);
    supplementalNoticeData = this.ignoreNoticeData(supplementalNoticeData, false);
    supplementalNoticeData = this.setMortgageeIgnoreData(supplementalNoticeData);
    this.pushDataToNoticeData(supplementalNoticeData, formData);
    // sessionStorage.setItem(NoticeGenerationConstants.supplementalNoticeData, JSON.stringify(supplementalNoticeData));
    return supplementalNoticeData;
  }

  supplementalNoticeDataCommonComp(sectionName, form) {
    let x = 0,
      isSectionPresent = false;
    const spliceArray = [];
    let supplementalNoticeData = [];
    let formData = [];
    // const supplementalNoticeData = sessionStorage.supplementalNoticeData ? JSON.parse(sessionStorage.supplementalNoticeData) : [];
    const formName = this.getCurrentFormName();
    const presentSections = this.getSectionsForCurrentForm(formName);
    const data = (sessionStorage.noticeData && JSON.parse(sessionStorage.noticeData)) ? JSON.parse(sessionStorage.noticeData) : [];
    if (data && data.length > 0) {
      data.filter(ele => {
        if (ele.name === formName) {
          supplementalNoticeData = ele.components;
          formData = ele.formData;
        }
      });
    }
    if (form.length && presentSections.includes(sectionName)) {
      if (supplementalNoticeData.length > 0) {
        supplementalNoticeData.forEach((element, index) => {
          if (element.name === sectionName) {
            isSectionPresent = true;
            spliceArray.push(index);
          }
          x++;
        });
        if (isSectionPresent) {
          supplementalNoticeData.splice(spliceArray[0], spliceArray.length);
        }
        x++;
      }

      if (isSectionPresent) {
        supplementalNoticeData.splice(spliceArray[0], spliceArray.length);
      }
      if (supplementalNoticeData.length && form.length) {
        if (this.createObj(form).length !== 0) {
          if (form.length > 0) {
            form.forEach((element) => {
              supplementalNoticeData.push({
                name: sectionName,
                fields: this.createObj(element),
              });
            });
          }
        }
      }

      // Ignored-NoticeData
      supplementalNoticeData = this.ignoreNoticeData(supplementalNoticeData, true);
      supplementalNoticeData = this.ignoreNoticeData(supplementalNoticeData, false);
      supplementalNoticeData = this.setMortgageeIgnoreData(supplementalNoticeData);
      this.pushDataToNoticeData(supplementalNoticeData, formData);

    } else {
      let is_SectionPresent = false;
      const splice_Array = [];
      if (supplementalNoticeData.length > 0) {
        supplementalNoticeData.forEach((element, index) => {
          if (element.name === sectionName) {
            is_SectionPresent = true;
            splice_Array.push(index);
          }
        });
        if (is_SectionPresent) {
          supplementalNoticeData.splice(splice_Array[0], splice_Array.length);
        }

        // Ignored-NoticeData
        supplementalNoticeData = this.ignoreNoticeData(supplementalNoticeData, true);
        supplementalNoticeData = this.ignoreNoticeData(supplementalNoticeData, false);
        supplementalNoticeData = this.setMortgageeIgnoreData(supplementalNoticeData);
        this.pushDataToNoticeData(supplementalNoticeData, formData);

        const updatedSections = presentSections.filter(el => el !== sectionName);
        this.setCurrentSection(updatedSections);
      }
    }

    // sessionStorage.setItem(NoticeGenerationConstants.supplementalNoticeData, JSON.stringify(supplementalNoticeData));
    return supplementalNoticeData;
  }

  noticeFieldDataCommonComp(sectionName, form) {
    let isSupplementalForm;
    const formName = this.getCurrentFormName();
    const presentSections = this.getSectionsForCurrentForm(formName);
    let noticeData = (sessionStorage.noticeData && JSON.parse(sessionStorage.noticeData)[0].components) ?
      JSON.parse(sessionStorage.noticeData)[0].components : [];
    const formData = (sessionStorage.noticeData && JSON.parse(sessionStorage.noticeData)[0].formData) ?
      JSON.parse(sessionStorage.noticeData)[0].formData : [];

    this.route.queryParams.subscribe(params => {
      isSupplementalForm = Boolean(params['supplementalForm']);
    });
    if (isSupplementalForm) {
      this.supplementalNoticeDataCommonComp(sectionName, form);
    } else {
      if (form.length && presentSections.includes(sectionName)) {
        let x = 0, isSectionPresent = false;
        const spliceArray = [];

        if (noticeData.length) {
          noticeData.forEach((element, index) => {
            if (element.name === sectionName) {
              isSectionPresent = true;
              spliceArray.push(index);
            }
            x++;
          });
          if (isSectionPresent) {
            noticeData.splice(spliceArray[0], spliceArray.length);
          }
          if (noticeData.length && form.length) {
            if (this.createObj(form).length !== 0) {
              if (form.length > 0) {
                form.forEach(element => {
                  noticeData.push({ name: sectionName, fields: this.createObj(element) });
                });
              }
            }
          }
        } else {
          if (this.createObj(form).length !== 0) {
            if (form.length > 0) {
              form.forEach((element) => {
                noticeData.push({
                  name: sectionName,
                  fields: this.createObj(element),
                });
              });
            }
          }
        }
        // Ignored-NoticeData
        noticeData = this.ignoreNoticeData(noticeData, true);
        noticeData = this.ignoreNoticeData(noticeData, false);
        noticeData = this.setMortgageeIgnoreData(noticeData);
        this.pushDataToNoticeData(noticeData, formData);
      } else {
        let x = 0, isSectionPresent = false;
        const spliceArray = [];
        if (noticeData.length > 0) {
          noticeData.forEach((element, index) => {
            if (element.name === sectionName) {
              isSectionPresent = true;
              spliceArray.push(index);
            }
            x++;
          });
          if (isSectionPresent) {
            noticeData.splice(spliceArray[0], spliceArray.length);
          }

          // Ignored-NoticeData
          noticeData = this.ignoreNoticeData(noticeData, true);
          noticeData = this.ignoreNoticeData(noticeData, false);
          noticeData = this.setMortgageeIgnoreData(noticeData);
          this.pushDataToNoticeData(noticeData, formData);

          const updatedSections = presentSections.filter(el => el !== sectionName);
          this.setCurrentSection(updatedSections);
        }
      }
    }
    return noticeData;
  }

  pushDataToNoticeData(noticeData, formData?) {
    const formName = this.getCurrentFormName();
    formData?.forEach(element => {
      if (element !== null && typeof (element) !== 'undefined' &&
        element?.sectionName === NoticeGenerationConstants.insurerText) {
      }
    });
    const data = { 'name': formName, 'components': noticeData, 'formData': formData };
    let dataTemp = sessionStorage.noticeData ? JSON.parse(sessionStorage.noticeData) : [data];
    let iterator = 0;
    if (dataTemp && dataTemp.length) {
      for (const i of dataTemp) {
        if (i && i.name === formName) {
          dataTemp[iterator] = data;
          break;
        }
        iterator++;
      }
      if (iterator === dataTemp.length) {
        dataTemp = [...dataTemp, data];
      }
    } else {
      dataTemp = [...dataTemp, data];
    }
    sessionStorage.setItem(NoticeGenerationConstants.noticeData, JSON.stringify(dataTemp));
  }

  generateNoticeData(sectionName, form) {
    let noticeDataRequest, supplementalNoticeRequest, isSupplementalForm, request;
    this.setNoticeStatus(true);
    this.route.queryParams.subscribe(params => {
      isSupplementalForm = Boolean(params['supplementalForm']);
    });
    if (isSupplementalForm) {
      supplementalNoticeRequest = form.value ?
        this.supplementalNoticeData(sectionName, form) : this.supplementalNoticeDataCommonComp(sectionName, form);
      if (supplementalNoticeRequest !== null && typeof supplementalNoticeRequest !== 'undefined') {
        request = this.generateNotice(supplementalNoticeRequest);
      }
    } else {
      if (form.value) {
        const noticeFieldData = this.noticeFieldData(sectionName, form);
        if (noticeFieldData !== null && typeof noticeFieldData !== 'undefined') {
          noticeDataRequest = noticeFieldData;
        }
      } else {
        const noticeFieldDataCommonComp = this.noticeFieldDataCommonComp(sectionName, form);
        if (noticeFieldDataCommonComp !== null && typeof noticeFieldDataCommonComp !== 'undefined') {
          noticeDataRequest = noticeFieldDataCommonComp;
        }
      }

      const noticeDataLocalStorage  = JSON.parse(sessionStorage.noticeData);
      const formIndex = this.isSupplementalForm ? 1 : 0;
      if (noticeDataRequest !== null && typeof noticeDataRequest !== 'undefined') {
        noticeDataLocalStorage[formIndex]['components'] = noticeDataRequest;
        sessionStorage.setItem(NoticeGenerationConstants.noticeData, JSON.stringify(noticeDataLocalStorage));
        request = this.generateNotice(noticeDataRequest);
      }
    }
    const allStateCodes = JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.allStateCodes));
    const insurerSelectedValues = this.insurerSelectedValues;
    if (request) {
      request.forms?.forEach(f => {
        f.components?.forEach(n => {

          const excludedFields: any = NoticeGenerationConstants.excludedFields;
              const includedFields = [];
              n.fields.forEach(field => {
                if (!excludedFields.includes(field.name)) {
                  includedFields.push(field);
                }
              });

          n.fields = [...includedFields];
          if (NoticeGenerationConstants.sectionsWithJurisdiction.includes(n.name)) {
            if (n.fields) {
              const index = n.fields.findIndex(element => element.name.includes(NoticeGenerationConstants.stateProv));
              const stateCode = n.fields[index].value;
              n.fields.forEach(field => {
                if (field.value === NoticeGenerationConstants.effectiveTime.beforeTwelveValue) {
                  field.value = NoticeGenerationConstants.effectiveTime.beforeTwelveKey;
                } else if (field.value === NoticeGenerationConstants.effectiveTime.afterTwelveValue) {
                  field.value = NoticeGenerationConstants.effectiveTime.afterTwelveKey;
                }
              });
              if (!allStateCodes.includes(stateCode)) {
                const obj = {
                  ...n.fields[index],
                  'ignoreNonComplianceWarnings': [NoticeGenerationConstants.invalidJurisdictionProvinceOption]
                };
                n.fields[index] = obj;
              }
            }
          }
          // Note: Insurer section - UseLookupValues flag changes
          if (n.name === NoticeGenerationConstants.insurerText) {
            if (n.fields) {
              for (let index = 0; index < n.fields.length; index++) {
                if (NoticeGenerationConstants.insurerUseLookupValuesFields.includes(n.fields[index].name)) {
                  let isUseLookupValue = true;
                  if (insurerSelectedValues === null) {
                    isUseLookupValue = false;
                  } else if ((n.fields[index].name === NoticeGenerationConstants.insurerForm.insurerAddr1 &&
                    n.fields[index].value !== insurerSelectedValues.address1) ||
                    (n.fields[index].name === NoticeGenerationConstants.insurerForm.insurerAddr2 &&
                      n.fields[index].value !== insurerSelectedValues.address2) ||
                    (n.fields[index].name === NoticeGenerationConstants.insurerForm.insurerCity &&
                      n.fields[index].value !== insurerSelectedValues.city) ||
                    (n.fields[index].name === NoticeGenerationConstants.insurerForm.insurerStateProv &&
                      n.fields[index].value !== insurerSelectedValues.stateProvidence) ||
                    (n.fields[index].name === NoticeGenerationConstants.insurerForm.insurerPostalCode &&
                      n.fields[index].value !== insurerSelectedValues.postalCode)) {
                        isUseLookupValue = false;
                  }
                  const obj = {
                    ...n.fields[index],
                    'useLookupValue': isUseLookupValue
                  };
                  n.fields[index] = obj;
                }
              }
            }
          }
        });
      });
    }

    this.dynamicFormHttpService.generateNoticeAPI(request).subscribe(response => {
      let pdfUrl = null;
      if (this.isSupplementalForm) {
        pdfUrl = response && response.forms && response.forms[1].pdfUrl ? response.forms[1].pdfUrl : null;
      } else {
        pdfUrl = response && response.forms && response.forms[0].pdfUrl ? response.forms[0].pdfUrl : null;
      }

      if (response && response.forms && pdfUrl) {
        if (environment.environmentName === 'Local') {
          pdfUrl = this.changeLocalPDFUrl(pdfUrl);
          this.dynamicFormHttpService.getNoticePdf(pdfUrl).subscribe((res: any) => {
            if (res) {
              this.loadFile(res);
            }
          }, async (error) => {
            const message = JSON.parse(await error.error.text()).message;
            this.showAlert(message);
            this.spinnerService.stop();
          });
        } else {
          const formName = this.getFormName(response);
          this.viewPdfFile(pdfUrl, formName);
        }
      }
    },
      error => {
        if (error.status === 500) {
          this.showAlert(error.error.message);
        }
        this.spinnerService.stop();
        /* Do not remove this comments. It is temporary comment to check behavior of RefId implementation
        if (error.error && error.error.errors.length > 0) {
          if (error.error.errors[0].type === NoticeGenerationConstants.NoticeGenerate.noticeExists) {
            const message = this.translate.instant('NOTICE_GEN_TAB.Notice_Generate.notice_exists_message');
            this.showSectionAlert(message);
          }
          else if (error.error.errors[0].type === NoticeGenerationConstants.NoticeGenerate.unableToFindFile) {
            const message = this.translate.instant('NOTICE_GEN_TAB.Notice_Generate.unable_to_find_file_message');
            this.showSectionAlert(message);
          }
          else if (error.error.errors[0].type === NoticeGenerationConstants.NoticeGenerate.mainFormIsRequired) {
            const message = this.translate.instant('NOTICE_GEN_TAB.Notice_Generate.the_main_form') + '  ' +
              error.error.errors[0].instance + ' ' + this.translate.instant('NOTICE_GEN_TAB.Notice_Generate.is_required');
            this.showSectionAlert(message);
          }
          if (error.error.forms[0].componentErrors.length > 0) {
            error.error.forms[0].componentErrors.forEach(ele => {
              if (ele) {
                this.showSectionAlert(ele.message);
              }
            });
          }
        } */
      });
  }

  loadFile(response: any) {
    const file = new Blob([response], { type: 'application/pdf' });
    const fileURL = URL.createObjectURL(file);
    window.open(fileURL, null, NoticeGenerationConstants.noticeFileConfig);
  }

  showSectionAlert(message) {
    this.spinnerService.stop();
    this.popupService
      .showAlert({
        title: '',
        message: message,
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: '',
      })
      .subscribe((res) => {
        if (res) {
          this.spinnerService.stop();
        }
      });
  }

  generateNotice(noticeData, supplementalNoticeData?) {
    let request;
    const formModel = JSON.parse(
      sessionStorage.getItem(NoticeGenerationConstants.criteriaSelectionData)
    );
    const formData = this.getPrefill();
    const formCode = formData[0].name;
    let isSupplementalForm;
    let supplementalFormCode;
    supplementalFormCode = this.currentFormCode;
    noticeData = sessionStorage.noticeData ? JSON.parse(sessionStorage.noticeData) : noticeData;
    const mainFormIndex = noticeData.findIndex(x => x.name === formCode);
    this.route.queryParams.subscribe(params => {
      isSupplementalForm = Boolean(params['supplementalForm']);
    });
    this.currentFormCode = isSupplementalForm ? supplementalFormCode : formCode;
    if (this.currentFormCode === formCode) {
      request = {
        'policyType': formModel.policy,
        'jurisdiction': formModel.jurisdiction,
        'actionId': formModel.action,
        'circumstanceId': formModel.circumstance,
        'typist': sessionStorage.typistData ? JSON.parse(sessionStorage.typistData) : '',
        'serviceCenterId': sessionStorage.serviceCenterData ? JSON.parse(JSON.parse(sessionStorage.serviceCenterData)) : (
          sessionStorage.selectedServiceCenter ? JSON.parse(sessionStorage.selectedServiceCenter).id : ''),
        'lobs': formModel.lob,
        'forms': [{
          'name': formCode,
          'components': noticeData[mainFormIndex].components
        }]
      };
    } else {
      noticeData.forEach(element => {
        if (element.name === this.currentFormCode) {
          request = {
            'policyType': formModel.policy,
            'jurisdiction': formModel.jurisdiction,
            'actionId': formModel.action,
            'circumstanceId': formModel.circumstance,
            'typist': sessionStorage.typistData ? JSON.parse(sessionStorage.typistData) : '',
            'serviceCenterId': sessionStorage.serviceCenterData ? JSON.parse(JSON.parse(sessionStorage.serviceCenterData)) : (
              sessionStorage.selectedServiceCenter ? JSON.parse(sessionStorage.selectedServiceCenter).id : ''),
            'lobs': formModel.lob,
            'forms': [{
              'name': formCode,
              'components': noticeData[mainFormIndex].components
            },
            {
              'name': supplementalFormCode,
              'components': element.components
            }]
          };
        }
      });
    }
    if (request) {
      return request;
    } else {
      throw new Error('return value is null');
    }
  }

  updatePolicySectionForm(fn: () => void) {
    this.saveFormData = fn;
  }

  sortDropdownData(key) {
    return function (element1, element2) {
      const result =
        element1[key].toLocaleLowerCase() < element2[key].toLocaleLowerCase()
          ? -1
          : element1[key].toLocaleLowerCase() >
            element2[key].toLocaleLowerCase()
            ? 1
            : 0;
      return result;
    };
  }

  createObj(valueObj) {
    const temparr = [];
    valueObj = valueObj[0] ? valueObj[0] : valueObj;
    for (const i in valueObj) {
      if (!NoticeGenerationConstants.ignoredWarningKeys.includes(i)) {
        if (!this.isAdditionalField(i)) {
          if (`${valueObj[i]}` !== 'undefined' && `${valueObj[i]}` !== 'null' && valueObj[i] !== '') {
            if (i.includes('Copies')) {
              const value = JSON.parse(`${valueObj[i]}`);
              temparr.push({ name: i, value: value });
            } else if (i.includes('Id')) {
              let value = JSON.parse(`${valueObj[i]}`);
              if (NoticeGenerationConstants.sectionIdFields.includes(i)) {
                value = null;
              }
              temparr.push({ name: i, value: value });
            } else if (i.includes('StateProv')) {
              const value = valueObj[i].trim() === '' ? null : valueObj[i].trim();
              temparr.push({ name: i, value: value });
            } else if (i.includes('UseServiceCenterAddress')) {
              temparr.push({ name: i, value: null });
            } else if (
              this.amtFields.has(i)
            ) {
              temparr.push({ name: i, value: valueObj[i] });
            } else if (`${valueObj[i]}` === 'true') {
              temparr.push({ name: i, value: true });
            } else if (`${valueObj[i]}` === 'false') {
              temparr.push({ name: i, value: false });
            } else if (`${valueObj[i]}` === '12:01 AM') {
              temparr.push({ name: i, value: '00:01:00' });
            } else if (`${valueObj[i]}` === '12:00 PM') {
              temparr.push({ name: i, value: '12:00:00' });
            } else if (i === NoticeGenerationConstants.cnrCRDeclEffectDt) {
              temparr.push({
                name: i,
                value: `${valueObj[i]}`,
                ignoreNonComplianceWarnings: this.getIgnoreWarningArray(valueObj)
              });
            } else {
              temparr.push({ name: i, value: `${valueObj[i]}` });
            }
          } else {
            if (i === NoticeGenerationConstants.cnrCRDeclEffectDt) {
              temparr.push({
                name: i,
                value: `${valueObj[i]}`,
                ignoreNonComplianceWarnings: this.getIgnoreWarningArray(valueObj)
              });
            } else {
              temparr.push({ name: i, value: null });
            }
          }
        }
      }
    }
    return temparr;
  }

  isAdditionalField(key) {
    if (key.includes('_dropdown')) {
      return true;
    } else {
      return false;
    }
  }

  getDistinctRecords(data) {
    return data.filter(
      (v, i, a) =>
        a.findIndex((t) => JSON.stringify(t) === JSON.stringify(v)) === i
    );
  }

  showAlert(message) {
    this.popupService.showAlert({
      title: this.translate.instant('MESSAGES.Confirmation.alertTitle'),
      message: message,
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: '',
    });
  }

  manipulateDate(date: any) {
    return date
      ? moment(date).format(NoticeGenerationConstants.dateFormat)
      : '';
  }

  reOrderFieldSequence(data: any, formIndexValue: any) {
    let orderedData = [];
    let field: any;
    let apiData: any;
    let currentSupplementalForm: any;
    let distinctData: any;

    if (data) {
      distinctData = this.getDistinctRecords(data.fields);
      if (this.isSupplementalForm) {
        this.route.queryParams.subscribe(params => {
          currentSupplementalForm = params[NoticeGenerationConstants.formCode];
        });
        const supplementalData = data.formDataObject?.filter(
          (x) => x.name === currentSupplementalForm);
          apiData = supplementalData[0]?.components[data.sectionId];
      }
      else {
      apiData = data.formDataObject[formIndexValue].components[data.sectionId];
      }
    }
    if (distinctData && apiData && apiData.fields) {
      apiData.fields.forEach((item: any) => {
        if (item.name && item.name.includes(NoticeGenerationConstants.copies)) {
          field = distinctData.filter(
            (x) =>
              x.fieldGroupClassName ===
              NoticeGenerationConstants.fieldGroupClassName
          )[0];
          orderedData.push(field);
        } else if (
          item.name &&
          !item.name.includes(NoticeGenerationConstants.fill3817)
        ) {
          field = distinctData.filter((x) => x.key === item.name)[0];
          orderedData.push(field);
        }
      });
    } else {
      orderedData = [];
    }
    return orderedData.length > 0 ? orderedData : [];
  }

  skipAsterisk(to: any) {
    let showAsterisk = false;
    if (to && to.hasOwnProperty('name')) {
      const value = (to.name && to.name.includes(NoticeGenerationConstants.mailType)) ||
        (to.name && to.name.includes(NoticeGenerationConstants.copies));
      showAsterisk = value ? false : true;
    } else if (to && to.hasOwnProperty('key')) {
      const value = (to.key && to.key.includes(NoticeGenerationConstants.mailType)) ||
        (to.key && to.key.includes(NoticeGenerationConstants.copies));
      showAsterisk = value ? false : true;
    } else {
      showAsterisk = true;
    }
    return showAsterisk;
  }
  getAllRowColors(row) {
    if (!row.isCompanyDaysNotice) {
      return Constants.rowColor.yellowOpa;
    } else {
      return Constants.rowColor.blueOpa;
    }
  }

  getChildWindowLookupData(filterData, whiteData) {
    const customizedData = [];
    const stateMandate = [];
    let isCustomized = false;
    filterData.filter(item => {
      if (item.isCompanyDaysNotice) {
        customizedData.push(item);   // blue records
        isCustomized = true;
      } else {
        stateMandate.push(item); // yellow records
      }
    });
    this.lookupData = [];
    this.lookupData = isCustomized ? customizedData.concat(whiteData) : stateMandate.concat(whiteData);
    this.setLookupTableDataToLocalS(this.lookupData);
  }

  onLookupDaysNoticeDateChange(fn: () => void) {
    this.showLookupDaysNoticeWarning = fn;
  }

  onEffectiveDateChange (fn: () => void) {
    this.showMortgageeEffectiveDtWarning = fn;
  }

  getLookupDaysDateDiff(transactionDt: any, mailingDt: any) {
    const today = new Date(mailingDt);
    const val = new Date(transactionDt);
    const datediff = -Math.floor(
      (today.getTime() - val.getTime()) / (1000 * 3600 * 24)
    );
    return datediff;
  }

  // notice regenerate functionality
  getValue(value) {
    switch (value) {
      case '00:01:00':
        return '12:01 AM';
      case '12:00:00':
        return '12:00 PM';
      case 'false':
        return false;
      case 'true':
        return true;
      default:
        return value;
    }
  }

  getSectionName(name) {
    if (name === NoticeGenerationConstants.certholder) {
      return NoticeGenerationConstants.certificateHolder;
    } else if (name === NoticeGenerationConstants.addInt) {
      return NoticeGenerationConstants.additionalInterest;
    } else if (name.includes(NoticeGenerationConstants.policyText)) {
      name = name.slice(
        name.indexOf(NoticeGenerationConstants.policyText) + 6,
        name.length
      );
      name = NoticeGenerationConstants.policyText + '/' + name;
      return name;
    } else if (name === NoticeGenerationConstants.tp) {
      return NoticeGenerationConstants.thirdParty;
    } else {
      return name;
    }
  }

  onPolicyNumberChange(fn: () => void) {
    this.getPolicyInfo = fn;
  }

  setIgnoredData(localstorageKey: any, ignoredData: any) {
    if (ignoredData) {
      sessionStorage.setItem(localstorageKey, JSON.stringify(ignoredData)
      );
    }
  }

  setDefaultValues(form, fields) {
    const data = fields.reduce(
      (obj, item) => Object.assign(obj, { [item.key]: item.defaultValue }), {});
    this.prefillFormData(form, data);
  }

  setPreAdjustmentIgnoredData(ignoredData: any) {
    if (ignoredData) {
      this.setToLocal(
        NoticeGenerationConstants.ignoredPreAdjustDataText,
        JSON.stringify(ignoredData)
      );
    }
  }

  getPolicyDetails() {
    let returnData: any;
    const formName = this.getCurrentFormName();
    if (sessionStorage.noticeData !== null && sessionStorage.noticeData !== undefined) {
      const data = JSON.parse(sessionStorage.noticeData);
    if (data && data.length) {
      for (const ele of data) {
        if (ele && ele.name === formName) {
          const formData = ele.components;
          if (formData && formData.length) {
            for (const i of formData) {
              if (i && i.name.includes(NoticeGenerationConstants.policyText)) {
                const fields = i.fields;
                const transactionDate = fields.filter(x => x.name === NoticeGenerationConstants.transactionDate);
                const transactionTime = fields.filter(x => x.name === NoticeGenerationConstants.policyTransactionTime);
                const mailingDate = fields.filter(x => x.name === NoticeGenerationConstants.mailingDate);
                if (transactionDate && transactionTime) {
                  returnData = {
                    transactionDate: transactionDate,
                    transactionTime: transactionTime,
                    mailingDate: mailingDate
                  };
                }
                break;
              }
            }
          }
        }
      }
    }
  }
    return returnData;
  }

  getTansactionTime(value: any) {
    let item = '';
    if (value === NoticeGenerationConstants.effectiveTime.beforeTwelveKey) {
      item = NoticeGenerationConstants.effectiveTime.beforeTwelveValue;
    } else if (value === NoticeGenerationConstants.effectiveTime.afterTwelveKey) {
      item = NoticeGenerationConstants.effectiveTime.afterTwelveValue;
    }
    return item;
  }

  getNumberOnlyValue(value) {
    const arr = value.split('');
    const index = arr.findIndex(item => (item !== '$' && item !== '-'));
    return value.substr(index);
  }

  showDoubleFormatWarning(field: FormlyFieldConfig, AmtFieldName: any, fieldValue: any) {
    const doubleFieldValue = this.getNumberOnlyValue(fieldValue);
    const isDecimalValue =
      DynamicFormValidationService.decimalValidator(doubleFieldValue);
    if (isDecimalValue && this.showDoubleWarningPoup) {
      const message =
        NoticeGenerationConstants.validationMessages
          .please_enter_amount_in_format;
      this.popupService.showAlert({
        title: '',
        message: message,
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: '',
      }).pipe(take(1)).subscribe(res => {
        if (res) {
            const isNumberic = /^\d+(\.\d+)?$/g.test(doubleFieldValue);
            if (!isNumberic) {
              field.form.get(AmtFieldName).setValue(null);
            }
        }
      });
    }
    this.showDoubleWarningPoup = false;
  }

  isGenerateNoticeButtonEnable(isFormValid) {
    if (isFormValid && this.getNoticeStatus()) {
      return false;
    } else if (isFormValid && this.isNoticeRegenerated) {
      return false;
    } else if (isFormValid && this.isSupplementalForm) {
      return false;
    } else if (this.sectionName.includes(NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment) &&
      (this.getNoticeStatus() || this.isNoticeRegenerated || this.isSupplementalForm)) {
      return false;
    }
    return true;
  }

  validateNumber(event) {
    const allowedRegex = NoticeGenerationConstants.doubleFormatWithSpecialRegex;
    const inputValue = event.target.value;
    const inputValues = inputValue.split('');
    inputValues.splice(event.target.selectionStart, 0, event.key);
    const userInput = inputValues.join('');
    if (!userInput.match(allowedRegex)) {
      event.preventDefault();
    }
  }

  ignoreNoticeData(noticeData: any, isPolicyCheck: boolean) {
    const sessionStorageKey = isPolicyCheck ?
      (this.isSupplementalForm ? NoticeGenerationConstants.ignoredDataTextSupplemental : NoticeGenerationConstants.ignoredDataText) :
      (this.isSupplementalForm ? NoticeGenerationConstants.ignoredPreAdjustDataTextSupplemental :
        NoticeGenerationConstants.ignoredPreAdjustDataText);
    this.handleReinstatementsIgnoreData(sessionStorageKey, isPolicyCheck);
    const ignoredData = JSON.parse(sessionStorage.getItem(sessionStorageKey));
    if (ignoredData !== null) {
      noticeData.forEach((element: any) => {
        const name = isPolicyCheck ? NoticeGenerationConstants.policyText :
          NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment;
        const isNameExists = element.name.includes(name);
        if (isNameExists) {
          ignoredData.forEach((item: any) => {
            if (item && item.isIgnored) {
              const filteredData = element.fields.find(z => z.name === item.key);
              if (filteredData && typeof (filteredData) !== 'undefined' && filteredData !== undefined) {
                if ((item.key === NoticeGenerationConstants.transactionDate ||
                  item.key.includes(NoticeGenerationConstants.transactionDate)) ||
                  (item.key === NoticeGenerationConstants.mailingDate ||
                    item.key.includes(NoticeGenerationConstants.mailingDate)) ||
                  (this.dateFields.has(item.key) &&
                    (item.hasOwnProperty(NoticeGenerationConstants.nonComplianceProp.inValidCurrentDate) ||
                    item.hasOwnProperty(NoticeGenerationConstants.nonComplianceProp.inValidDaysNotice)))
                ) {
                  const ignoreWarningArray = [];
                  if (item.hasOwnProperty(NoticeGenerationConstants.nonComplianceProp.inValidCurrentDate) && item.inValidCurrentDate) {
                    ignoreWarningArray.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[0]);
                  }
                  if (item.hasOwnProperty(NoticeGenerationConstants.nonComplianceProp.inValidDaysNotice) && item.inValidDaysNotice) {
                    ignoreWarningArray.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[1]);
                  }
                  /* Do not remove: May require in future for sending value for null case
                  if (element.fields.find(z => z.name === item.key) && element.fields.find(z => z.name === item.key).value === null) {
                    element.fields.find(z => z.name === item.key).value = this.getCurrentDate();
                  } */
                  element.fields.find(z => z.name === item.key).ignoreNonComplianceWarnings = ignoreWarningArray;
                } else {
                  element.fields.find(z => z.name === item.key).ignoreRegulatoryRequirement = true;
                  element.fields.find(y => y.name === item.key).ignoreRequirement = true;
                }
              }
            }
          });
        }
      });
    }
    return noticeData;
  }

  getCurrentDate() {
    const currentDate = new Date();
    return currentDate.getFullYear() + '-' + currentDate.getMonth() + '-' + currentDate.getDate();
  }

  getFormName(response: any) {
    let formName = '';
    if (this.isSupplementalForm) {
      formName = response.forms[1]?.name;
    } else {
      formName = response.forms[0]?.name;
    }
    return formName;
  }

  viewPdfFile(pdfUrl: any, formName: any) {
    if (pdfUrl && pdfUrl.includes('?') && pdfUrl !== undefined) {
      const queryParams = pdfUrl.split('?');
      const form = formName?.split('.')?.slice(0, -1)?.join('.');
      if (queryParams.length > 0 && queryParams[1]) {
        const url = environment.appUrl + AppConstants.uiRoutes.fileViewer +
          AppConstants.routeSeperator + form + AppConstants.querySeperator + queryParams[1];
        window.open(url, null, NoticeGenerationConstants.noticeFileConfig);
      }
    }
  }

  getIgnoreWarningArray(valueObj: any) {
    let ignoredWarnings = [];
    if (valueObj) {
      if (valueObj.inValidCurrentAndDayNoticeDate) {
        ignoredWarnings = NoticeGenerationConstants.ignoreNonComplianceWarnings;
      } else if ((valueObj.invalidCurrentDate) ||
        (this.isDateValid(valueObj.CNNRCRDeclEffectDt))) {
        ignoredWarnings.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[0]);
      } else {
        const sessionStorageKey = this.isSupplementalForm ? NoticeGenerationConstants.supplimentalEffectDateKey :
          NoticeGenerationConstants.effectiveDateKey;
        const data = JSON.parse(this.getStoredData(sessionStorageKey));
        if (data && data !== undefined && data.minDays) {
          ignoredWarnings.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[1]);
        }
      }
    }
    const formModel = JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.criteriaSelectionData));
    if (formModel && formModel?.actionName.includes(NoticeGenerationConstants.LookUpDateDetails.reinstatement)) {
      if (ignoredWarnings.length > 0) {
        if (!ignoredWarnings.includes(NoticeGenerationConstants.nonComplianceProp.inValidDaysNotice)) {
          ignoredWarnings.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[1]);
        }
      } else {
          ignoredWarnings.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[1]);
      }
   }
    return ignoredWarnings;
  }

  scrollToTop() {
    document.getElementById('main-scroll').scrollIntoView();
  }

  clickHiddenElement() {
    document.getElementById('hiddenEle')?.click();
  }
  setSessionData(key, data) {
    sessionStorage.setItem(key, data);
  }
  manipulateSessionServiceCenter(serviceCenterData: any) {
    let serviceCenterValue = false;
    if (serviceCenterData) {
      const serviceCenterIds = serviceCenterData.map(x => x.id);
      if (serviceCenterIds.length > 0) {
        const serviceCenterId = JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.insurerForm.serviceCenterData));
        if (serviceCenterId && (!serviceCenterIds.includes(Number(serviceCenterId)))) {
          sessionStorage.removeItem(NoticeGenerationConstants.insurerForm.serviceCenterData);
          sessionStorage.removeItem(NoticeGenerationConstants.insurerForm.selectedServiceCenter);
          serviceCenterValue = true;
        }
      }
    }
    return serviceCenterValue;
  }

  changeLocalPDFUrl(pdfUrl: any) {
    if (pdfUrl && pdfUrl.includes('?') && pdfUrl !== undefined) {
      const queryParams = pdfUrl.split('?');
      if (queryParams.length > 0 && queryParams[1]) {
        pdfUrl = NoticeGenerationConstants.webApis.noticeFile + AppConstants.querySeperator + queryParams[1];
      }
    }
    return pdfUrl;
  }

  getMinDaysDetails(formModel: any, effectiveDate: any) {
    let showDayNoticePopup = false;
    const policyData = this.getPolicyDetails();
    if (policyData && policyData.hasOwnProperty(NoticeGenerationConstants.transactionDateKey)
      && policyData.hasOwnProperty(NoticeGenerationConstants.mailingDateKey)) {
      const datediff = this.getLookupDaysDateDiff(effectiveDate, policyData.mailingDate[0].value);
      const minDays = this.getPolicyEffectiveDateDetails().minDays;
      if (formModel.actionName === NoticeGenerationConstants.LookUpDateDetails.reinstatement) {
        showDayNoticePopup = false;
      } else {
        if (minDays === 0) {
          showDayNoticePopup = false;
        } else {
          if (datediff < minDays) {
            showDayNoticePopup = true;
          }
        }
      }
    }
    return showDayNoticePopup;
  }

  getPolicyEffectiveDateDetails() {
    const sessionStorageKey = this.isSupplementalForm ? NoticeGenerationConstants.supplimentalEffectDateKey :
      NoticeGenerationConstants.effectiveDateKey;
     return JSON.parse(this.getStoredData(sessionStorageKey));
  }

  getAmtFieldNames(formData) {
    this.amtFields = new Set();
    this.dateFields = new Set();
    formData.forEach(element => {
      element.components.forEach(ele => {
        if (ele.name.includes(NoticeGenerationConstants.policyText) ||
        ele.name.includes(NoticeGenerationConstants.premiumText) ) {
          ele.fields.forEach(f => {
            if (f.format === 'Double') {
              this.amtFields.add(f.name);
            }
            else if (f.format === 'Date' && !this.standardDateFields.includes(f.name)) {
              this.dateFields.add(f.name);
            }
          });
        }
      });
    });
  }

  openDocumentFile(pdfUrl: any) {
    let url = '';
    if (pdfUrl && pdfUrl.includes('?') && pdfUrl !== undefined) {
      const queryParams = pdfUrl.split('?');
      if (queryParams && queryParams[1]) {
        const fileParams = queryParams[1].split(NoticeGenerationConstants.fileName);
        if (fileParams && fileParams[1]) {
            url = environment.appUrl + AppConstants.uiRoutes.documentLink + AppConstants.routeSeperator +
            fileParams[1];
        }
      }
    }
    return url;
  }

  setRegeneratePremiumAdjIgnoreValues(noticeFieldValues) {
    const premiumAdjIgnoreData = [];
    noticeFieldValues.forEach(ignData => {
      if (!ignData.value) {
        ignData['ignoreRegulatoryRequirement'] = true;
        ignData['ignoreRequirement'] = true;
        const saveIgnData = {
          'key': ignData.name,
          'isIgnored': true,
          'message': this.translate.instant('NOTICE_GEN_TAB.PREMIUM_ADJUSTMENT.missing_value_for') +
           ignData.name + this.translate.instant('NOTICE_GEN_TAB.PREMIUM_ADJUSTMENT.post')
        };
        premiumAdjIgnoreData.push(saveIgnData);
      }
    });
    if (premiumAdjIgnoreData.length > 0) {
      this.setPreAdjustmentIgnoredData(
        premiumAdjIgnoreData
      );
    }
  }

  hideExtraAsterisk() {
    const labelPanel = document.getElementsByTagName(NoticeGenerationConstants.labelWrapperPanel);
    if (labelPanel && labelPanel.length > 0) {
      for (let i = 0; i < labelPanel.length; i++) {
        const formlyFieldCheckBox = labelPanel[i]?.getElementsByTagName(NoticeGenerationConstants.formlyFieldCheckbox);
        if (formlyFieldCheckBox && formlyFieldCheckBox.length > 0) {
          const firstChild: any = formlyFieldCheckBox[0]?.firstElementChild;
          const label: any = firstChild?.getElementsByTagName(NoticeGenerationConstants.labelText);
          const innerTxt = label[0]?.firstElementChild?.innerText;
          if (innerTxt === NoticeGenerationConstants.starText) {
            const hideProp = label[0]?.firstElementChild;
            if ((hideProp !== null) && (hideProp !== undefined)) {
              hideProp.style.display = NoticeGenerationConstants.noneText;
            }
          }
        }
      }
    }
  }

  getCurrentFormSectionIdKey() {
    const currentFormName = this.getCurrentFormName();
    const currentFormCode = currentFormName?.slice(0, -4);
    return currentFormCode + '_' + NoticeGenerationConstants.sectionId;
  }

  checkRequiredSectionDataAvailable(data) {
    const formName = this.getCurrentFormName();
    let requiredFields = [];
    let noticeDataAvailble = [];
    data.formDataObject.forEach(form => {
      if (formName === form.name) {
        requiredFields = form.components.reduce(
          function(acc, val) {
            if (val.isRequired) {
              acc.push(val.name);
            }
          return acc;
        }, []);
      }
    });

    const storedNoticeData = sessionStorage.noticeData ? JSON.parse(sessionStorage.noticeData) : null;
    if (storedNoticeData) {
      storedNoticeData.forEach(noticeDataForm => {
        if (formName === noticeDataForm.name) {
          noticeDataAvailble = noticeDataForm.components.reduce(
            function(acc, val) {
              acc.push(val.name);
              return acc;
          }, []);
        }
      });
    }

    let isContainAllRequired = true;
    const missingSectionsList = [];
    requiredFields.forEach(section => {
      if (!noticeDataAvailble.includes(section)) {
        isContainAllRequired = false;
        missingSectionsList.push(section);
      }
    });
    if (!isContainAllRequired) {
      const alertMessage = this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.required_section_missing_message_pre') +
                      missingSectionsList.toString().replace(',', ', ') +
                      this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.required_section_missing_message_post');
      this.showAlert(alertMessage);
    }
    return isContainAllRequired;
  }

  getLOBData() {
    this.criteriaData = JSON.parse(
      sessionStorage.getItem(NoticeGenerationConstants.criteriaSelectionData)
    );
    this.getCurrentFormName();
    this.currentRtfName = this.getCurrentFormName();
    const LOBData = {
      'stateCode': this.criteriaData.jurisdiction,
      'actionID': this.criteriaData.action,
      'circumstanceID': this.criteriaData.circumstance,
      'lobIds': this.criteriaData.lob,
      'rtfName': this.currentRtfName
    };
    return LOBData;
  }

  getLOBsAbbreviations(res) {
    const lobArray = [];
    res.forEach(ele => {
      if (ele.rtfName === this.currentRtfName) {
        lobArray.push(ele.lobAbbr);
      }
    });
    this.LObAbb = lobArray.toString();
    this.LObAbb = (this.LObAbb.split(',').join(', ')).trim();
    sessionStorage.setItem(this.currentRtfName + NoticeGenerationConstants.lobAbbText, this.LObAbb);
  }

  setPremiumAdjDefaultValues(form, fields) {
    const fieldDetails = [];
    fields.forEach(item => {
      if (item.hasOwnProperty('fieldGroupClassName')) {
        item.fieldGroup.forEach(fieldData => {
          fieldDetails.push({key: fieldData.key, defaultValue: fieldData.defaultValue});
        });
      } else {
        fieldDetails.push({key: item.key, defaultValue: item.defaultValue});
      }
    });
    const data = fieldDetails.reduce(
      (obj, item) => Object.assign(obj, { [item.key]: item.defaultValue }), {});
    this.prefillFormData(form, data);
  }

  clearPolicyDetailsOnInitialLoad(field: any) {
    if (!this.isSupplementalForm) {
    const policyData = this.getPolicyDetails();
    if (policyData === undefined || policyData === null) {
      field.form.get(NoticeGenerationConstants.transactionDateText).setValue(null);
      field.form.get(NoticeGenerationConstants.policyNumber).setValue(null);
     }
   }
 }
 changeInDateAFormat(anyDate: any, change: number) {
    anyDate = new Date(anyDate);
    anyDate =  new Date(anyDate.getTime() + anyDate.getTimezoneOffset() * NoticeGenerationConstants.timeZoneDiff);
    anyDate.setDate(anyDate.getDate() + change);
    anyDate = moment(anyDate).format(NoticeGenerationConstants.isoDateFormat);
    return anyDate;
 }

 updateLookupDate(field: FormlyFieldConfig, fieldValue: any) {
    let dateDiff = null;
  const today = moment(new Date()).format(NoticeGenerationConstants.isoDateFormat);
  if (fieldValue && fieldValue !== null && this.previousMailingDate !== null
    && fieldValue !== this.previousMailingDate) {
    const mailingDateChange = this.getLookupDaysDateDiff(fieldValue, this.previousMailingDate); // No of days changed in Mailing date
    this.setEffectiveLookupData(mailingDateChange);
    dateDiff = mailingDateChange;
  }
  else if (fieldValue && this.previousMailingDate === null) {
    const mailingDateChange = this.getLookupDaysDateDiff(fieldValue, today);
    this.setEffectiveLookupData(mailingDateChange);
    dateDiff = mailingDateChange;
  }
  this.previousMailingDate = fieldValue;

  // Day's notice warning log data
  if (this.daysNoticeWarningLogData.minDate && dateDiff) {
    this.daysNoticeWarningLogData.minDate = this.changeInDateAFormat(this.daysNoticeWarningLogData.minDate, dateDiff);
  }
 }

 setEffectiveLookupData(mailingDateChange: number) {
  const formModel = JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.criteriaSelectionData));
  this.daysNoticeData = JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.childWindowLookupTable));
  if (this.daysNoticeData) {
    this.daysNoticeData.forEach(data => {
      if (Array.isArray(formModel.lob)) {
        for (let i = 0; i < formModel.lob.length; i++) {
          if (
            data.circumstanceId === formModel.circumstance &&
            data.lobId === formModel.lob[i]
          ) {
            data.minDate = this.changeInDateAFormat(data.minDate, mailingDateChange);
          }
        }
      }
    });
    this.setLookupTableDataToLocalS(this.daysNoticeData);
  }
 }

 setLookupTableDataToLocalS(lookupTData: any) {
  sessionStorage.setItem(NoticeGenerationConstants.childWindowLookupTable, JSON.stringify(lookupTData));
 }

 lookupDateValidation(filterData1: any, isCompanyDaysNoticeData: any) {
   if (filterData1) {
    if (
      filterData1.findIndex((item: any) => item.isCompanyDaysNotice === true) >=
      0
    ) {
      isCompanyDaysNoticeData = true;
      this.lookupDaysValidationData =
        filterData1[
        filterData1.findIndex(
          (item: any) => item.isCompanyDaysNotice === true
        )
        ];
    }
    if (!isCompanyDaysNoticeData && filterData1.length > 0) {
      this.lookupDaysValidationData = filterData1[0];
    } else if (!isCompanyDaysNoticeData && filterData1.length === 0) {
      this.lookupDaysValidationData = this.lookupTableData[0];
    }
   }

   // Day's notice warning log data
   if (this.lookupDaysValidationData) {
    this.daysNoticeWarningLogData.minDays = this.lookupDaysValidationData?.minDays;
    this.daysNoticeWarningLogData.minDate = this.lookupDaysValidationData?.minDate;
   }
  }

 isDaysLookupDateValid(effectiveDate: any, noticeData: any) {
  let mailingDate = '';
  let isDaysLookupDateValid = false;
  const policyData = noticeData?.find(x => x.name.includes(NoticeGenerationConstants.policyText));
  if (policyData && policyData !== undefined) {
    mailingDate = policyData?.fields?.find(x => x.name === NoticeGenerationConstants.mailingDate)?.value;
  } else {
    mailingDate = this.getCurrentDate();
  }
  const datediff = this.getLookupDaysDateDiff(effectiveDate, mailingDate);
  const minDays = this.getPolicyEffectiveDateDetails()?.minDays;
  if (minDays === 0) {
    isDaysLookupDateValid = false;
  } else {
    isDaysLookupDateValid = datediff < minDays ? false : true;
  }
  return isDaysLookupDateValid;
 }

 setRegenerateMortgageeValues(noticeFieldValues: any, noticeData: any) {
   let mortgageeData: any;
  noticeFieldValues.forEach((item: any, index: any) => {
    if (item && item.name && item.name.includes(NoticeGenerationConstants.fieldNames.mortgagee.effectiveDate)) {
        const inValidCurrentDate = this.isDateValid(item.value);
        const storageKey = this.isSupplementalForm ? NoticeGenerationConstants.mortgageeSupplementalEffectiveDate :
        NoticeGenerationConstants.mortgageeEffectiveDate;
        mortgageeData = { name : item.name, inValidCurrentDate :  inValidCurrentDate,
          invalidDaysLookupDate : this.isDaysLookupDateValid(item.value, noticeData), index: index };

        if (this.formModel.actionName === NoticeGenerationConstants.LookUpDateDetails.reinstatement) {
          mortgageeData.inValidCurrentDate = true;
          mortgageeData.invalidDaysLookupDate = true;
        }

        this.mortgegeeIgnoreArray.push(mortgageeData);
        this.setToLocal(storageKey, JSON.stringify(this.mortgegeeIgnoreArray));
    }
  });
  return mortgageeData;
}

setMortgageeIgnoreData(data: any) {
  const storageKey = this.isSupplementalForm ? NoticeGenerationConstants.mortgageeSupplementalEffectiveDate :
        NoticeGenerationConstants.mortgageeEffectiveDate;
  const mortgageeIgnoredData = JSON.parse(sessionStorage.getItem(storageKey));
  let mortgageeCount = 0;
 if (data && data.length > 0 && mortgageeIgnoredData !== null) {
  data.forEach((element: any) => {
    const isSectionNameExists = element.name.includes(NoticeGenerationConstants.mortgageeText);
    if (isSectionNameExists) {
      const ignoreWarningArray = [];
       mortgageeCount++;
      if (mortgageeIgnoredData[mortgageeCount - 1]?.inValidCurrentDate && mortgageeIgnoredData[mortgageeCount - 1]?.invalidDaysLookupDate) {
        ignoreWarningArray.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[0]);
        ignoreWarningArray.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[1]);
      } else if (mortgageeIgnoredData[mortgageeCount - 1]?.inValidCurrentDate) {
        ignoreWarningArray.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[0]);
      } else if (mortgageeIgnoredData[mortgageeCount - 1]?.invalidDaysLookupDate) {
        ignoreWarningArray.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[1]);
      }
      if (element.fields.find(z => z.name.includes(NoticeGenerationConstants.fieldNames.mortgagee.effectiveDate))) {
        element.fields.find(z => z.name.includes(NoticeGenerationConstants.fieldNames.mortgagee.effectiveDate))
        .ignoreNonComplianceWarnings = ignoreWarningArray;
      }
    }
  });
 }
  return data;
 }

 getMortgageeIgnoreArray(mortgageeData: any) {
  const ignoreWarningArray = [];
  if (mortgageeData?.inValidCurrentDate && mortgageeData?.invalidDaysLookupDate) {
    ignoreWarningArray.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[0]);
    ignoreWarningArray.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[1]);
  } else if (mortgageeData?.inValidCurrentDate) {
    ignoreWarningArray.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[0]);
  } else if (mortgageeData?.invalidDaysLookupDate) {
    ignoreWarningArray.push(NoticeGenerationConstants.ignoreNonComplianceWarnings[1]);
  }
  return ignoreWarningArray;
 }

 clearMortgageeIgnoreData() {
  const storageKey = this.isSupplementalForm ? NoticeGenerationConstants.mortgageeSupplementalEffectiveDate :
      NoticeGenerationConstants.mortgageeEffectiveDate;
  this.removeStoredData(storageKey);
}

 handleReinstatementsIgnoreData(storageKey: any, isPolicyCheck: any) {
  let data: any;
  const ignoredData: any = JSON.parse(sessionStorage.getItem(storageKey));
  const formModel = JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.criteriaSelectionData));
   if (isPolicyCheck && formModel && formModel.actionName.includes(NoticeGenerationConstants.LookUpDateDetails.reinstatement)) {
        if (ignoredData === null) {
          data = [{ key: NoticeGenerationConstants.transactionDate, isIgnored: true, message: '', inValidDaysNotice: true }];
          this.setToLocal(storageKey, JSON.stringify(data));
        } else {
          ignoredData.forEach((item: any) => {
           if (item.key.includes(NoticeGenerationConstants.transactionDate)) {
              if (!item.inValidDaysNotice) {
                item.inValidDaysNotice = true;
            }
          }
        });
        this.setToLocal(storageKey, JSON.stringify(ignoredData));
      }
    }
 }
}
