import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UrlResolver } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { NoticeGenerationConstants } from '../infrastructure/notice-generation.constant';

@Injectable({
  providedIn: 'root'
})
export class DynamicFormHttpService {

  constructor(private _http: HttpClient) { }
  public getFormData(policyType: string, jurisdictionCode: string, actionCode: number,
    circumstanceCode: number, lobs: number): Observable<any> {
    return this._http.get(NoticeGenerationConstants.webApis.getForms
      .replace('{policyType}', policyType)
      .replace('{jurisdictionCode}', jurisdictionCode)
      .replace('{actionCode}', String(actionCode))
      .replace('{circumstanceCode}', String(circumstanceCode))
      .replace('{lobCode}', String(lobs)));
  }

  public getLookupTableData(optionsUrl): Observable<any> {
    return this._http.get(optionsUrl);
  }
  public getServiceCenterDetails() {
    return this._http.get(NoticeGenerationConstants.webApis.serviceCenter);
  }

  public getFormTitle(rtfName: string, jurisdictionCode: string, actionCode: number,
    circumstanceCode: number, lobs: any): Observable<any> {
    return this._http.get(NoticeGenerationConstants.webApis.getFormTitle
      .replace('{rtfName}', rtfName)
      .replace('{jurisdictionCode}', jurisdictionCode)
      .replace('{actionCode}', String(actionCode))
      .replace('{circumstanceCode}', String(circumstanceCode))
      .replace('{lobCode}', (lobs)));
  }

  public getSectionFieldOptions(apiUrl: string): Observable<any> {
    return this._http.get(apiUrl);
  }

  public getAddendumForm(): Observable<any> {
    return this._http.put(NoticeGenerationConstants.webApis.getAddendumForm, '',
    { responseType: NoticeGenerationConstants.responseType.blobType as 'json', observe: 'response' });
  }

  public getHelpForm(helpForm): Observable<any> {
    return this._http.put(NoticeGenerationConstants.webApis.getHelpForm.replace('{helpForm}', helpForm), '',
    { responseType: NoticeGenerationConstants.responseType.blobType as 'json', observe: 'response' });
  }

  public getAPIsAddToMasterFile(element) {
    return this._http.post(
      NoticeGenerationConstants.webApis.maintainParties, element);
  }
  public generateNoticeAPI(formData): Observable<any> {
    return this._http.post(NoticeGenerationConstants.webApis.getGenerateNotice, formData);
  }
  getNoticePdf(url) {
    let headers = new HttpHeaders();
    headers = headers.set('Accept', 'application/pdf');
    return this._http.get(url, { headers: headers, responseType: 'blob' as 'json' });
  }

  public getPolicyInfo(params): Observable<any> {
    return this._http.get(NoticeGenerationConstants.webApis.getNoticeDataByPolicy
      .replace('{policyType}', params.policyType)
      .replace('{jurisdictionCode}', params.jurisdiction)
      .replace('{actionCode}', String(params.action))
      .replace('{circumstanceCode}', String(params.circumstance))
      .replace('{lobCode}', String(params.lobs))
      .replace('{policyNumber}', params.policynumber)
      .replace('{docName}', params.docName));
  }

  public getStateCodes() {
    return this._http.get(NoticeGenerationConstants.webApis.getStateCodes);
  }

  getProducerCount() {
    return this._http.get(NoticeGenerationConstants.webApis.getProducerCount);
  }

  addAdditionalPartiesRecords(records) {
    return this._http.post(NoticeGenerationConstants.webApis.maintainPartiesBulkInsert, records);
  }
  getLOBsAbbreviations(formData) {
    return this._http.post(NoticeGenerationConstants.webApis.getLOBsAbb, formData);
  }
}
