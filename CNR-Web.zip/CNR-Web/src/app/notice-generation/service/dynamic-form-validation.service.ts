import { Injectable } from '@angular/core';
import { NoticeGenerationConstants } from '../infrastructure/notice-generation.constant';
import * as moment from 'moment';

@Injectable({
  providedIn: 'root'
})
export class DynamicFormValidationService {

  isServiceCenterValid = false;
  constructor() { }
  static requiredValidationMessage(err, field) {
    if (field?.templateOptions?.type === 'date') {
      return NoticeGenerationConstants.validationMessages.date + NoticeGenerationConstants.validationMessages.is_required;
    }
    else {
      if (field && field?.templateOptions?.type === NoticeGenerationConstants.checkBoxText &&
        (!field?.templateOptions?.hasOwnProperty(NoticeGenerationConstants.labelText) || field?.templateOptions?.label === '')) {
        return `${field?.templateOptions?.name} ` + NoticeGenerationConstants.validationMessages.is_required;
      } else {
        return `${field?.templateOptions?.label} ` + NoticeGenerationConstants.validationMessages.is_required;
      }
    }
  }

  static minNumberValidationMessage(err, field) {
    return NoticeGenerationConstants.validationMessages.value_cannot_be_less_than + ` ${field.templateOptions.min}`;
  }

  static maxNumberValidationMessage(err, field) {
    return NoticeGenerationConstants.validationMessages.value_cannot_be_more_than + ` ${field.templateOptions.max}`;
  }

  static minlengthValidationMessage(err, field) {
    return NoticeGenerationConstants.validationMessages.should_have_atleast +
      ` ${field.templateOptions.minLength} ` +
      NoticeGenerationConstants.validationMessages.characters;
  }

  static maxlengthValidationMessage(err, field) {
    return NoticeGenerationConstants.validationMessages.this_value_should_be_less_than +
      ` ${field.templateOptions.maxLength} ` + NoticeGenerationConstants.validationMessages.characters;
  }
  static alphanumericValidationMessage(err, field) {
    return NoticeGenerationConstants.validationMessages.value_should_be_in +
      ` ${field.templateOptions.pattern} ` +
      NoticeGenerationConstants.validationMessages.format;
  }
  static alphanumericValidator(control) {
    return !control.value || (NoticeGenerationConstants.alphanumeric_regex.test(control.value)) ? null as any : { alphanumeric: true };
  }
  static dateValidator(control) {
    const today = moment(new Date()).format('YYYY-MM-DD');
    if (control.value && control.value < today && control.value !== today) {
       return { date: true };
     } else {
       return null as any;
     }
  }
  static dateFormatValidator(control) {
    if (control.value && control.value.length > 10) {
      return { dateInvalid: true };
    }
  }
  static dateValidationMessage(err, field) {
    return NoticeGenerationConstants.validationMessages.date + NoticeGenerationConstants.validationMessages.should_be_today_or_greater;
  }
  static dateFormatMessage() {
    return NoticeGenerationConstants.validationMessages.date_valid_format;
   }

  static decimalValidator(control) {
    let decimal: any;
    const isTwoDecimal = /^[0-9]+(\.[0-9]{2})$/g.test(control);
    if (isTwoDecimal) {
      decimal = null;
    }
    else {
      decimal = true;
    }
    return decimal;
  }

  static decimalValidationMessage(err, field) {
    return NoticeGenerationConstants.validationMessages.please_enter_amount_in_format;
  }
  static noSpaceValidatorMessage(err, field) {
    return `${field.templateOptions.label} ` + NoticeGenerationConstants.validationMessages.is_required;
  }
  static noSpaceValidator(control) {
    if (control && control.value) {
      const isArray = Array.isArray(control.value);
      return isArray ? !control.value[0] || (control && control.value[0].trim()) ? null as any : { noSpace: true } :
        !control.value || (control && control.value.trim()) ? null as any : { noSpace: true };

    } else {
      return null as any;
    }
  }
  static postalCodeValidator(control) {
    if (control._fields[0].key.includes(NoticeGenerationConstants.postalCode) && control.value) {
      const isUSCodeValid = /(^\d{5})$|(^\d{5}-\d{4}$)/g.test(control.value);
      const isCACodeValid = /^[a-zA-Z]\d{1}[a-zA-Z]\s?\d{1}[a-zA-Z]\d{1}/g.test(control.value);
      if (isUSCodeValid || isCACodeValid) {
          return null as any;
      } else {
        return { postalCode: true };
      }
    } else {
      return null as any;
    }
  }
  static postalCodeValidationMessage(err, field) {
    return NoticeGenerationConstants.validationMessages.postal_code_in_valid_format;
  }
  static phoneNumberValidator(control) {
    if (control._fields[0].key.includes('PhNum') && control.value) {
      const isPhoneValid = /^[(]{0,1}[0-9]{1,3}[)]{0,1}[-\s\./0-9]*$/g.test(control.value);
      if (isPhoneValid) {
          return null as any;
      } else {
        return { phoneNumber: true };
      }
    } else {
      return null as any;
    }
  }
  static phoneNumberValidationMessage(err, field) {
    return NoticeGenerationConstants.validationMessages.phone_number_in_valid_format;
  }
}
