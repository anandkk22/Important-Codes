import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[renderContent]',
})
export class RenderDynamicContentDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}
