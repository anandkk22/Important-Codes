import { Component, OnInit, OnDestroy } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Constants } from '@global/infrastructure/constants';
import { SpinnerService } from '@wk/nils-core';
import { AppConstants } from 'app/app.constants';
import { CircumstanceDefinitions } from 'app/notice-generation/infrastructure/interface/circumstanceDefinitions.interface';
import { CriteriaSelectionService } from 'app/notice-generation/service/criteria-selection.service';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { Subscription } from 'rxjs';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-circumstance-definition',
  templateUrl: './circumstance-definition.component.html',
  styleUrls: ['./circumstance-definition.component.scss'],
})
export class CircumstanceDefinitionComponent implements OnInit, OnDestroy {

  isDataAvailable = false;
  circumstanceDefinitions: CircumstanceDefinitions[] = [];
  selectedCircumstance = null;
  activeSubscription: Subscription;
  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  selectedCircumstanceId = null;
  circumstances = [];
  isLoading = false;

  constructor(private criteriaSelectionService: CriteriaSelectionService,
    private dynamicFormService: DynamicFormService,
    private spinnerService: SpinnerService,
    private titleService: Title,
    public activeModal: NgbActiveModal
    ) {
      this.titleService.setTitle(Constants.tabTitles[25]);
    }

  ngOnInit(): void {
    this.isLoading = true;
    this.getCircumstanceDefinitions();
  }

  getCircumstanceDefinitions() {
    this.activeSubscription = this.criteriaSelectionService.getCircumstanceDefinitions().subscribe((res: CircumstanceDefinitions[]) => {
      if (res) {
        this.circumstanceDefinitions = res;
        if (this.circumstanceDefinitions.length > 0) {
          this.circumstances = this.circumstanceDefinitions;
          this.selectedCircumstance = this.circumstanceDefinitions[0];
        }
        this.isLoading = false;
        this.isDataAvailable = true;
      }
    }, error => {
      if (error.status === 500) {
        this.dynamicFormService.showAlert(error.error.message);
      }
      this.spinnerService.stop();
    });
  }


  customSearchFn(event) {
    const data = this.circumstanceDefinitions.filter(x => x.description.toLowerCase().startsWith(event.term.toLowerCase()));
    this.circumstances = event.term ? data : this.circumstanceDefinitions;
  }

  setdropdownData() {
    this.circumstances = this.circumstanceDefinitions;
    this.selectedCircumstance = this.circumstanceDefinitions[0];
    this.selectedCircumstanceId = null;
  }

  scrollToDefinition(definition: any) {
    document.getElementById(definition.id).scrollIntoView({
      behavior: 'smooth'
    });
    this.selectedCircumstanceId = definition.id;
  }

  isSelected(id) {
    return (id === this.selectedCircumstanceId) ? true : false;
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

  onClose() {
    this.activeModal.dismiss();
  }
}
