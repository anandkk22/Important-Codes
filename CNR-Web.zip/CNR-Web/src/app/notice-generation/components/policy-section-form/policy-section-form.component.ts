import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { AppConstants } from 'app/app.constants';
import { take } from 'rxjs/operators';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormsComponent } from '../dynamic-forms/dynamic-forms.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ReasonTextModalComponent } from '../reason-text/reason-text-modal.component';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { IFormSectionNames } from 'app/notice-generation/infrastructure/interface/formSectionNames.interface';
import { DynamicFormHttpService } from 'app/notice-generation/service/dynamic-form-http.service';
import { FormlyFormOptions } from '@ngx-formly/core';
import { environment } from '@env';
import moment from 'moment';
@Component({
  selector: 'app-policy-section-form',
  templateUrl: './policy-section-form.component.html',
  styleUrls: ['./policy-section-form.component.scss']
})
export class PolicySectionFormComponent implements OnInit, AfterViewInit {

  @Input() data;
  @Output() sectionIdEventEmitter = new EventEmitter<number>();
  displayPopup = false;
  popupData: any = {};
  requiredIndex = 0;
  regulatoryIndex = 0;
  displayAlert: boolean;
  requiredMessageArray = [];
  regulatoryMessageArray = [];
  formIndex = 0;
  formData;
  formSectionNames: IFormSectionNames[] = [];
  sectionName: string;
  formIndexValue = 0;
  sectionForm = new FormGroup({});
  sectionFormData;
  lastFormIndex = 0;
  isNoticeGenerated = true;
  currentSectionId: string;
  previousLookupDate: string = null;
  isContinueClicked = false;
  isNavigationPrefillClicked = false;
  formModel;
  previousPolicyNumber: string = null;
  isGenerateNoticeClicked = false;
  ignoreRegulatoryRequirementArray = [];
  isEffectiveDateValid = false;
  checkboxData: any[] = [];
  options: FormlyFormOptions = {};
  isRegulatoryWarningPresent: Boolean = false;
  isRequiredWarningPresent: Boolean = false;
  nonSupplementalSection = ['PremiumAdjustment', 'Mortgagee', 'Lienholder', 'Certholder', 'AddInt', 'WCC', 'TP'];
  serviceCenterExistAfterRegen = true;

  isSupplementalForm;
  formCode;
  supplementalFormCode;
  isVisitedFirst = false;
  currentFormName: string;
  performSupplementalLookup = false;
  warningCount: number;

  constructor(private _dynamicFormService: DynamicFormService,
    private popupService: PopupService,
    private translate: TranslateService,
    private router: Router,
    private route: ActivatedRoute,
    private dynamicFormsComponent: DynamicFormsComponent,
    private modalService: NgbModal,
    private spinnerService: SpinnerService,
    private dynamicFormHttpService: DynamicFormHttpService) {
    this._dynamicFormService.componentMethodCalled$.subscribe(
      (res: any) => {
        if (Number(res.requested) === Number(this.data?.sectionId) || Number(res.current) === Number(this.data?.sectionId)) {
          if (Number(res.requested) === Number(this.data.sectionId) && !this.isVisitedFirst) {
            if (this.data && this.data?.form) {
              this.data?.form?.resetAll();
            }
            this.isVisitedFirst = true;
          }
          this.onClickPrefillValidateForm();
        }
      }
    );
  }

  ngOnInit(): void {
    this.formModel = JSON.parse(this._dynamicFormService.getStoredData(NoticeGenerationConstants.criteriaSelectionData));
    this._dynamicFormService.updatePolicySectionForm(this.saveFormData.bind(this));
    this._dynamicFormService.onLookupDaysNoticeDateChange(this.showLookupDaysNoticeWarning.bind(this));
    this.route.queryParams.subscribe(params => {
      this.isSupplementalForm = Boolean(params['supplementalForm']);
    });
    if (!this.isSupplementalForm) {
      this._dynamicFormService.onPolicyNumberChange(this.getPolicyInfo.bind(this));
    }
    this._dynamicFormService.saveSectionId(this.data.sectionId);
    this.sectionName = this.data.sectionName;
    this.data.form = this.sectionForm;
    this.data.options = this.options;
    this._dynamicFormService.triggerSubmitManually.subscribe((res) => {
      this.validateAllFormFields(this.data.form);
      this.onSubmit(this.data.form, res);
    });

    this._dynamicFormService.isSupplementalFirstLoad =
    JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.localStorageKeys.isSupplementalFirstLoad));
    sessionStorage.removeItem(NoticeGenerationConstants.localStorageKeys.isSupplementalFirstLoad);
    this.sectionFormData = this._dynamicFormService.getSectionFormData(this.sectionName);
    if (this.isSupplementalForm && this._dynamicFormService.isSupplementalFirstLoad) {
      this._dynamicFormService.showLookupWarningPopup = false;
      const formName = this._dynamicFormService.getCurrentFormName();
      const presentSections = this._dynamicFormService.getSectionsForCurrentForm(formName);
      let components = [];
      let formData = [];
      const visitedSections = [];

      presentSections.forEach((element, index) => {
        this.dynamicFormsComponent.isvisitedSection[index] = true;
        if (sessionStorage.previousVisitedSections.includes(element) && !this.nonSupplementalSection.includes(element)) {
          visitedSections.push(element);
        }
      });

      const updatedData = [{ 'name': formName, 'visitedSections': visitedSections }];
      this.dynamicFormsComponent.supplemntalPreviousSection = visitedSections;
      this._dynamicFormService.setStoreData(NoticeGenerationConstants.supplemntalPreviousVisitedSections, updatedData);

      formData = this.prefillSupplemental(formName);
      const resData = [];
      formData.forEach(ele => {
        resData.push({ 'name': ele.sectionName, 'fields': this._dynamicFormService.createObj(ele.formValue) });
      });
      components = resData;
      this._dynamicFormService.pushDataToNoticeData(components, formData);
      this._dynamicFormService.isSupplementalFirstLoad = false;
      this.performSupplementalLookup = true;
    } else if (this.isSupplementalForm && !this._dynamicFormService.isSupplementalFirstLoad) {
      this._dynamicFormService.showLookupWarningPopup = false;
      const getAllSections = JSON.parse(sessionStorage.noticeData);
      const sectionNames = [];
      getAllSections.forEach(element => {
        if (element.name === this._dynamicFormService.currentFormCode) {
          element.formData.forEach(sections => {
            sectionNames.push(sections.sectionName);
          });
        }
      });
      const formName = this._dynamicFormService.getCurrentFormName();
      const presentSections = this._dynamicFormService.getSectionsForCurrentForm(formName);
      presentSections.forEach((element, index) => {
        if (sectionNames.includes(element)) {
          this.dynamicFormsComponent.isvisitedSection[index] = true;
        }
      });
      const updatedData = [{ 'name': this._dynamicFormService.currentFormCode, 'visitedSections': sectionNames }];
      this.dynamicFormsComponent.supplemntalPreviousSection = sectionNames;
      this._dynamicFormService.setStoreData(NoticeGenerationConstants.supplemntalPreviousVisitedSections, updatedData);
      this.performSupplementalLookup = false;
    }
    this.lastFormIndex = this._dynamicFormService.getLastFormIndex();
    this.sectionFormData = this._dynamicFormService.getSectionFormData(this.sectionName);
    this.isNoticeGenerated = this._dynamicFormService.getNoticeStatus();
    this.currentSectionId = this._dynamicFormService.getStoredData(this._dynamicFormService.getCurrentFormSectionIdKey());
  }
  prefillSupplemental(formName) {
    const dataTemp = this.data.formDataObject;
    const sectionArray = [];
    if (dataTemp && dataTemp.length) {
      for (const i of dataTemp) {
        if (i && i.name === formName) {
          // add logic
          i.components.forEach(element => {
            if (!this.nonSupplementalSection.includes(element.name)) {
              const data = this.getMainFormSection(element.name);
              if (data) {
                if (element.name === data.sectionName) {
                  const fields = element.fields.reduce(
                    (obj, item) => Object.assign(obj, {
                      [item.name]:
                        this.getData(item.name, data, item.defaultValue)
                    }), {}
                  );
                  sectionArray.push({ 'sectionName': element.name, 'formValue': fields });
                }
              }
            }
          });
          break;
        }
      }
    }
    return sectionArray;
  }
  getData(key, data, defaultValue) {
    let res = null;
    if (data.formValue.hasOwnProperty(key)) {
      for (const [item, value] of Object.entries(data.formValue)) {
        if (key === item) {
          res = `${data.formValue[item]}` ? `${data.formValue[item]}` : defaultValue;
          res = res === (null || 'null') ? '' : res;
          break;
        }
      }
    } else {
      res = defaultValue;
    }

    if (key.includes('Copies') && res) {
      res = JSON.parse(res);
    }
    else if (this._dynamicFormService.amtFields.has(key) && res) {
      res = parseFloat(res);
    }
    return this._dynamicFormService.getValue(res);
  }
  getMainFormSection(sectionName) {
    let response;
    const mainFormData = JSON.parse(sessionStorage.noticeData)[0].formData;
    for (const item of mainFormData) {
      if (item && item.sectionName === sectionName) {
        response = item;
        break;
      }
    }
    return response;
  }
  ngAfterViewInit() {
    this.getAllCheckboxes(this.data.fields);
    if (this.sectionFormData) {
      this._dynamicFormService.prefillFormData(this.data.form, this.sectionFormData);
    }
    // Need to verify whether this.setCheckboxDefaultValues is required or not.

    // case - regeneration lookup for supplemental first time form load
    if (this.isSupplementalForm && this.performSupplementalLookup) {
      this.getPolicyInfo();
    }

    setTimeout(() => {
      this._dynamicFormService.showLookupWarningPopup = true;
      this._dynamicFormService.showNavigationPrefillWarning = true;
    }, 100);
    this._dynamicFormService.scrollToTop();
    this.hideExtraAsterisk();
    this._dynamicFormService.fieldRuleValidatorForAllFields();
  }

  getAllCheckboxes(fields) {
    fields.forEach(element => {
      if (element.templateOptions.type === 'checkbox') {
        this.checkboxData.push({ 'name': element.key, 'defaultValue': element.defaultValue });
      }
    });
  }

  setCheckboxDefaultValues() {
    this.checkboxData.forEach(check => {
      this.data.form.get(check.name).setValue(check.defaultValue);
    });
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  onSubmit(form: FormGroup, sectionId = 0) {
    this.setExplicityDefaultValues();
    this.isGenerateNoticeClicked = false;
    this.ignoreRegulatoryRequirementArray = [];
    this._dynamicFormService.fieldRuleValidatorForAllFields();
    this.validateAllFormFields(this.data.form);
    this.dynamicFormsComponent.isvisitedSection[this.currentSectionId] = true;

    const serviceCenterData = sessionStorage.selectedServiceCenter ? sessionStorage.selectedServiceCenter :
      (sessionStorage.serviceCenterData ? sessionStorage.serviceCenterData : null);
    if (JSON.parse(serviceCenterData) && serviceCenterData.length > 0) {
      this._dynamicFormService.noticeFieldData(this.sectionName, form);
      this.showRandWarningAlerts(form, sectionId, JSON.parse(serviceCenterData));
    }
    else {
      this.dynamicFormsComponent.isServiceCenterValid = false;
    }
  }
  generateNotice(form: FormGroup) {
    this.saveFormData();
    this.setEffectiveDatePopupDetails();
    this._dynamicFormService.generateNoticeData(this.data.sectionName, form);
    this.isGenerateNoticeClicked = false;
  }
  moveToCriteriaSelection(form: FormGroup) {
    this.popupService.showConfirmation({
      title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
      message: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.back_on_criteria_Selection'),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button')
    })
      .pipe(take(1)).subscribe(res => {
        if (res) {
          form.reset();
          this._dynamicFormService.removeStoredData('formData');
          this._dynamicFormService.removeStoredData(NoticeGenerationConstants.insurerForm.serviceCenterData);
          this.dynamicFormsComponent.noticeData = [];
          this._dynamicFormService.previousPolicyNumber = null;
          this._dynamicFormService.isNoticeRegenerated = false;
          this. isVisitedFirst = false;
          this.router.navigate([AppConstants.uiRoutes.noticeGeneration +
            NoticeGenerationConstants.routeSeparator +
            AppConstants.uiRoutes.criteriaSelection]);
        } else {
          window.scrollTo(0, 0);
        }
      });
  }

  dateValidator(data) {
    return this._dynamicFormService.isDateValid(data);
  }

  showRandWarningAlerts(form: FormGroup, sectionId, serviceCenterData) {
    this.requiredIndex = 0;
    this.regulatoryIndex = 0;
    const submitForm = true;
    const showWarning = true;
    const showRequiredWarning = false;
    const regulatoryRequiredWarning = false;
    this.previousLookupDate = null;
    this.isContinueClicked = true;
    this.ignoreRegulatoryRequirementArray = [];
    const sessionStorageKey = this.isSupplementalForm ? NoticeGenerationConstants.ignoredDataTextSupplemental
      : NoticeGenerationConstants.ignoredDataText;
    this._dynamicFormService.removeStoredData(sessionStorageKey);
    this.setEffectiveDatePopupDetails();
    if (form.valid) {
      console.log('showRandWarningAlerts->Transaction Dt: ', this.data.form.controls.TransactionDt.value);
      console.log('showRandWarningAlerts->Mailing Dt', this.data.form.controls.MailingDt.value);
      console.log('showRandWarningAlerts->Client Dt and Time', new Date().toLocaleString());
      const dataArray = [...this._dynamicFormService.requiredFields, ...this._dynamicFormService.regulatoryRequiredFields];
      this.regulatoryMessageArray = this.getAlertMessagesArray(form, dataArray);
        if (this.regulatoryMessageArray.length > 0) {
          this.rerenderRegulatoryRequirements(form, showWarning, regulatoryRequiredWarning, submitForm, sectionId, serviceCenterData);
        } else {
          this.isGenerateNoticeClicked ? this.generateNotice(form) : this.nextFormSection(form, submitForm, sectionId, serviceCenterData);
        }
        this.isContinueClicked = false;
    }
  }

  rerenderRegulatoryRequirements(form, showWarning, regulatoryRequiredWarning, submitForm, sectionId, serviceCenterData) {
    this.setEffectiveDatePopupDetails();
    if (this.regulatoryIndex <= this.regulatoryMessageArray.length) {
      this.popupService.showConfirmation({
        title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
        message: this.translate.instant(this.regulatoryMessageArray[this.regulatoryIndex].message),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: this.translate.instant('BUTTON.cancel_button')
      })
        .pipe(take(1)).subscribe(res => {
          if (!res && showWarning) {

            // maintained ignore Regulatory Requirement
            if (this.ignoreRegulatoryRequirementArray.length > 0 && this.ignoreRegulatoryRequirementArray[this.regulatoryIndex]) {
              let index = 0;
              index = this.warningCount !== 0 ? this.regulatoryIndex + this.warningCount : this.regulatoryIndex;
              index = this.isEffectiveDateValid ? index + 1 : index;
              if (this.ignoreRegulatoryRequirementArray[index]?.hasOwnProperty(NoticeGenerationConstants.ignoredKey)) {
                this.ignoreRegulatoryRequirementArray[index].isIgnored = true;
              }
              if (this.ignoreRegulatoryRequirementArray[index]?.key.
                includes(NoticeGenerationConstants.transactionDate)) {
                this.ignoreRegulatoryRequirementArray[index].inValidDaysNotice = true;
                if (this.dateValidator(this.data.form.controls.TransactionDt.value)) {
                  this.ignoreRegulatoryRequirementArray[index].inValidCurrentDate = true;
                }
              }
              if (this.ignoreRegulatoryRequirementArray[index]?.key.
                includes(NoticeGenerationConstants.mailingDate)) {
                if (this.dateValidator(this.data.form.controls.MailingDt.value)) {
                  this.ignoreRegulatoryRequirementArray[index].inValidCurrentDate = true;
                }
              }
              if (this._dynamicFormService.dateFields.has(this.ignoreRegulatoryRequirementArray[index]?.key)) {
                const dateKey = this.ignoreRegulatoryRequirementArray[index].key;
                if (this.dateValidator(this.data.form.controls[dateKey].value)) {
                  this.ignoreRegulatoryRequirementArray[index].inValidCurrentDate = true;
                }
              }
            }

            // warning popup
            regulatoryRequiredWarning = true;
            if (this.regulatoryIndex === this.regulatoryMessageArray.length - 1) {
              if (this.isRegulatoryWarningPresent) {
                this.popupService.showConfirmation({
                  title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
                  message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.override_regulatory_req'),
                  positiveLabel: this.translate.instant('BUTTON.ok_button'),
                  negativeLabel: this.translate.instant('BUTTON.cancel_button')
                })
                  .pipe(take(1)).subscribe(response => {
                    if (response) {
                      submitForm = false;
                      showWarning = false;
                      this._dynamicFormService.showNavigationPrefillWarning = true;
                      this.setIgnoredData(null);
                    } else {
                      if (this.isRequiredWarningPresent) {
                        this.popupService.showConfirmation({
                          title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
                          message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.override_company_req'),
                          positiveLabel: this.translate.instant('BUTTON.ok_button'),
                          negativeLabel: this.translate.instant('BUTTON.cancel_button')
                        })
                          .pipe(take(1)).subscribe(result => {
                            if (result) {
                              submitForm = false;
                              showWarning = false;
                              this._dynamicFormService.showNavigationPrefillWarning = true;
                              this.setIgnoredData(null);
                            } else {
                              this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
                              this.isGenerateNoticeClicked ?
                                this.generateNotice(form) : this.nextFormSection(form, submitForm, sectionId, serviceCenterData);
                            }
                          });
                      } else {
                        this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
                        this.isGenerateNoticeClicked ?
                          this.generateNotice(form) : this.nextFormSection(form, submitForm, sectionId, serviceCenterData);
                      }
                    }
                  });
              } else if (this.isRequiredWarningPresent) {
                this.popupService.showConfirmation({
                  title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
                  message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.override_company_req'),
                  positiveLabel: this.translate.instant('BUTTON.ok_button'),
                  negativeLabel: this.translate.instant('BUTTON.cancel_button')
                })
                  .pipe(take(1)).subscribe(response => {
                    if (response) {
                      submitForm = false;
                      showWarning = false;
                      this._dynamicFormService.showNavigationPrefillWarning = true;
                      this.setIgnoredData(null);
                    } else {
                      this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
                      this.isGenerateNoticeClicked ?
                        this.generateNotice(form) : this.nextFormSection(form, submitForm, sectionId, serviceCenterData);
                    }
                  });
              } else {
                this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
                this.isGenerateNoticeClicked ?
                  this.generateNotice(form) : this.nextFormSection(form, submitForm, sectionId, serviceCenterData);
              }
            }
            if (this.regulatoryIndex !== this.regulatoryMessageArray.length - 1) {
              this.regulatoryIndex++;
              this.rerenderRegulatoryRequirements(
                form, showWarning, regulatoryRequiredWarning, submitForm, sectionId, serviceCenterData);
            }
          } else {
            submitForm = false;
            showWarning = false;
            this._dynamicFormService.showNavigationPrefillWarning = true;
            this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
          }
        });
    }
  }

  getAlertMessagesArray(form, dataArray) {
    this.warningCount = 0;
    const msgArray = [];
    let isInvalidCurrentDate = null;
    this.isRegulatoryWarningPresent = false;
    this.isRequiredWarningPresent = false;
    const transactionDt = form.get(NoticeGenerationConstants.transactionDate)?.value;
    const mailingDt = form.get(NoticeGenerationConstants.mailingDate)?.value;
    if (this.dateValidator(mailingDt)) {
      isInvalidCurrentDate = NoticeGenerationConstants.mailingDate;
    }
    else if (this.dateValidator(transactionDt)) {
      isInvalidCurrentDate = NoticeGenerationConstants.transactionDate;
    }
    // Checking for any other Date field other than TranctDt & MailingDt
    if (this._dynamicFormService.hasOwnProperty('dateFields')) {
      this._dynamicFormService.dateFields?.forEach(dt => {
        const dateValue = form.get(dt)?.value;
        if (dateValue && this.dateValidator(dateValue)) {
          if (isInvalidCurrentDate === null) {
           isInvalidCurrentDate = dt;
          }
          else {
            const data = {
              key: dt,
              isIgnored: true,
              message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.non_compliance_warning'),
              inValidCurrentDate: true
            };
            this.ignoreRegulatoryRequirementArray.push(data);
            this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
            this.warningCount++;
          }
        }
      });
    }

    if (isInvalidCurrentDate !== null) {
      for (let i = 0; i < 3; i++) {
        msgArray.push({key: isInvalidCurrentDate, message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.non_compliance_warning')});
      }
    }

    console.log('getAlertMessagesArray->msgArray', msgArray);

    const isLookupDateValidData = this.showLookupDaysNoticeWarning();
    if ((msgArray[msgArray.length - 1]?.message !== isLookupDateValidData.message &&
      msgArray[msgArray.length - 1]?.key === NoticeGenerationConstants.transactionDate) ||
      (msgArray[msgArray.length - 1]?.message !== isLookupDateValidData.message &&
      msgArray[msgArray.length - 1]?.key === NoticeGenerationConstants.mailingDate) ||
      msgArray.length === 0) {
      if (!isLookupDateValidData.isValidLookupDate && isLookupDateValidData.message !== '') {
        for (let i = 0; i < 3; i++) {
          msgArray.push({key: NoticeGenerationConstants.transactionDate, message: isLookupDateValidData.message});
        }
      }
      if (!isLookupDateValidData.isValidLookupDate && isLookupDateValidData.message === '') {
        isLookupDateValidData.isValidLookupDate = true;
      }
    }

    if ((this.dateValidator(transactionDt) && isLookupDateValidData.isValidLookupDate) ||
    (this.dateValidator(transactionDt) && !isLookupDateValidData.isValidLookupDate &&
    this._dynamicFormService.lookupDaysValidationData?.minDays === 0)) {
      const data = {
        key: NoticeGenerationConstants.transactionDate,
        isIgnored: true,
        inValidDaysNotice: true,
        inValidCurrentDate: true,
        message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.non_compliance_warning')
      };
      this.ignoreRegulatoryRequirementArray.push(data);
      this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
      this.isEffectiveDateValid = true;
    }

    dataArray.forEach((item, index) => {
      if (form.get(item.key).value === '' || form.get(item.key).value === false || form.get(item.key).value === null) { // * field
        if (this._dynamicFormService.requiredFields.map(a => a.key).includes(item.key)) {
          const message = this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.company_req_pre') +
            item.value +
            this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.company_req_post');
          msgArray.push({key: item.key, message: message});
          this.isRequiredWarningPresent = true;
        } else if (this._dynamicFormService.regulatoryRequiredFields.map(a => a.key).includes(item.key)) {
          const message = this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.regulatory_req_pre') +
            item.value +
            this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.regulatory_req_post');
          msgArray.push({key: item.key, message: message});
          this.isRegulatoryWarningPresent = true;
        }
      }
    });
    msgArray.forEach(element => {
      const data = { key: element.key, isIgnored: false, message: element.message };
      this.ignoreRegulatoryRequirementArray.push(data);
    });
    return msgArray;
  }

  showReasonText(to) {
    const modalRef = this.modalService.open(ReasonTextModalComponent);
    const data = {
      defaultValue: this.data.form.get(to.name).value,
      fieldData: to
    };
    modalRef.componentInstance.data = data;
    modalRef.result.then((userResponse) => {
      this.data.form.get(to.name).setValue(userResponse);
    });
  }

  saveFormData() {
    this.hideExtraAsterisk();
    this._dynamicFormService.saveSectionFormData(this.sectionName, this.data.form.value);
  }

  reset() {
    this._dynamicFormService.showLookupWarningPopup = false;
    this.data.options.resetModel();
    this._dynamicFormService.setDefaultValues(this.data.form, this.data.fields);
    this._dynamicFormService.previousPolicyNumber = null;
    this._dynamicFormService.isNoticeRegenerated = false;
    this._dynamicFormService.isNoticeRegeneratedExactMatch = false;
    this.setCheckboxDefaultValues();
    this._dynamicFormService.fieldRuleValidatorForAllFields();
    this.saveFormData();
  }
  onClickPrefillValidateForm() {
    this.validateAllFormFields(this.data.form);
    const serviceCenterData = this._dynamicFormService.getStoredData(NoticeGenerationConstants.insurerForm.serviceCenterData)
      ? this._dynamicFormService.getStoredData(NoticeGenerationConstants.insurerForm.serviceCenterData) : '';
    if (serviceCenterData && serviceCenterData !== '') {
      this.data.form.addControl('serviceCenterData', new FormControl(serviceCenterData));
        if (this.data.form.valid) {
          this.dynamicFormsComponent.isvisitedSection[this.currentSectionId] = true;
          this.dynamicFormsComponent.isPageValid = true;
          this.dynamicFormsComponent.isSectionValid = true;
          this.dynamicFormsComponent.currentSection.push(1);
          this._dynamicFormService.noticeFieldData(this.sectionName, this.data.form);
          this.data.form.addControl('serviceCenterData', new FormControl(serviceCenterData));
          if (JSON.parse(this.currentSectionId) === 0 && this._dynamicFormService.showNavigationPrefillWarning) {
            if (this.dynamicFormsComponent.isAllRequiredVisited(this._dynamicFormService.navigationSectionIndex)) {
              this.isNavigationPrefillClicked = true;
              this.showRandWarningAlerts(this.data.form, JSON.parse(this.currentSectionId), serviceCenterData);
              this._dynamicFormService.showNavigationPrefillWarning = false;
            }
          }
          this.saveFormData();
        }
        else {
          this.dynamicFormsComponent.isSectionValid = false;
        }
    }
    else {
      this.dynamicFormsComponent.isServiceCenterValid = false;
    }
  }

  nextFormSection(form, submitForm, sectionId, serviceCenterData) {
    if (form.valid && submitForm) {
      this.dynamicFormsComponent.isPageValid = true;
      this.dynamicFormsComponent.isSectionValid = true;
      this.dynamicFormsComponent.currentSection.push(1);
      form.addControl('serviceCenterData', new FormControl(serviceCenterData));
      this.saveFormData();
      this._dynamicFormService.noticeFieldData(this.sectionName, form);
      this._dynamicFormService.showLookupWarningPopup = false;
      this._dynamicFormService.showDoubleWarningPoup = false;
      this._dynamicFormService.showNavigationPrefillWarning = false;
      if (!this.isNavigationPrefillClicked) {
        this.sectionIdEventEmitter.emit(sectionId);
      } else {
        this.isNavigationPrefillClicked = false;
        this._dynamicFormService.navPrefillNext = true;
        this.dynamicFormsComponent.onclickPrefillSec(this._dynamicFormService.navigationSectionIndex);
      }
    }
  }

  showDateValidationWarning(form, showWarning, submitForm, sectionId, serviceCenterData) {
    const message = this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.non_compliance_warning');
    this.popupService.showConfirmation({
      title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
      message: this.translate.instant(message),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button')
    })
      .pipe(take(1)).subscribe(res => {
        if (res) {
          submitForm = false;
          showWarning = false;
        } else {
          const data = { key: NoticeGenerationConstants.mailingDate, isIgnored: true, message: message };
          this.ignoreRegulatoryRequirementArray.push(data);
          this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
          this.isGenerateNoticeClicked ? this.generateNotice(form) : this.nextFormSection(form, submitForm, sectionId, serviceCenterData);
        }
      });
  }

  showLookupDaysNoticeWarning() {
    this.setEffectiveDatePopupDetails();
    console.log('showLookupDaysNoticeWarning->Transaction Dt: ', this.data.form.controls.TransactionDt.value);
    console.log('showLookupDaysNoticeWarning->Mailing Dt', this.data.form.controls.MailingDt.value);
    console.log('showLookupDaysNoticeWarning->Client Dt and Time', new Date().toLocaleString());
    if (this.data.form.controls.TransactionDt.valid &&
      this.data.form.controls.TransactionDt.value !== null) {
        // Day's notice warning log data
        this._dynamicFormService.daysNoticeWarningLogData.clientDate = moment(new Date()).format(NoticeGenerationConstants.isoDateFormat);
        this._dynamicFormService.daysNoticeWarningLogData.effectiveDate = this.data.form.controls.TransactionDt.value;
        this._dynamicFormService.daysNoticeWarningLogData.mailingDate = this.data.form.controls.MailingDt.value;

      const datediff = this._dynamicFormService.getLookupDaysDateDiff
        (this.data.form.controls.TransactionDt.value, this.data.form.controls.MailingDt.value);
      this.previousLookupDate = this.data.form.controls.TransactionDt.value;
      if ((this._dynamicFormService.lookupDaysValidationData &&
        datediff < this._dynamicFormService.lookupDaysValidationData.minDays &&
        this._dynamicFormService.lookupDaysValidationData.minDays !== (undefined || null)) ||
        (this.formModel.actionName === NoticeGenerationConstants.LookUpDateDetails.reinstatement &&
        datediff < 0)) {

        let message = '';
        if (this.formModel.actionName === NoticeGenerationConstants.LookUpDateDetails.reinstatement) {
          if (datediff < 0 && this.dateValidator(this.data.form.controls.TransactionDt.value)) {
            message = this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.non_compliance_warning');
          } else if (datediff < 0 && !this.dateValidator(this.data.form.controls.TransactionDt.value)) {
            const data = {
              key: NoticeGenerationConstants.transactionDate,
              isIgnored: true,
              message: message,
              inValidCurrentDate: false,
              inValidDaysNotice: true
            };
            this.ignoreRegulatoryRequirementArray.push(data);
            this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
          }
        } else {
          if (this._dynamicFormService.lookupDaysValidationData.minDays === 0 &&
             this.dateValidator(this.data.form.controls.TransactionDt.value)) {
            message = this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.non_compliance_warning');
          } else if (this._dynamicFormService.lookupDaysValidationData.minDays === 0 &&
            !this.dateValidator(this.data.form.controls.TransactionDt.value)) {
              const data = {
                key: NoticeGenerationConstants.transactionDate,
                isIgnored: true,
                message: message,
                inValidCurrentDate: false,
                inValidDaysNotice: true
              };
              this.ignoreRegulatoryRequirementArray.push(data);
              this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
          } else if (this._dynamicFormService.lookupDaysValidationData.minDays > 0) {
            message = this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.lookup_days_warning_pre') +
            this._dynamicFormService.lookupDaysValidationData.minDays +
            this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.lookup_days_warning_post');

            // Day's notice warning log data
            if (this._dynamicFormService.daysNoticeWarningLogData) {
              if (environment.environmentName !== '') {
                message += '<br><br>Server date: ' + this._dynamicFormService.daysNoticeWarningLogData?.serverDate +
                  ' | Client date: ' + this._dynamicFormService.daysNoticeWarningLogData?.clientDate +
                  ' | Effective date: ' + this._dynamicFormService.daysNoticeWarningLogData?.effectiveDate +
                  ' | Mailing date: ' + this._dynamicFormService.daysNoticeWarningLogData?.mailingDate +
                  ' | Min days: ' + this._dynamicFormService.daysNoticeWarningLogData?.minDays +
                  ' | Min date: ' + this._dynamicFormService.daysNoticeWarningLogData?.minDate;
              }
            }
          }
        }

        if (!this.isContinueClicked && this._dynamicFormService.showLookupWarningPopup) {
          setTimeout(() => {
            this.popupService.showConfirmation({
              title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
              message: this.translate.instant(message),
              positiveLabel: this.translate.instant('BUTTON.ok_button'),
              negativeLabel: this.translate.instant('BUTTON.cancel_button')
            }).pipe(take(1)).subscribe((response: any) => {
              if (!response) {
                const data = {
                  key: NoticeGenerationConstants.transactionDate,
                  isIgnored: true,
                  message: message,
                  inValidCurrentDate: false,
                  inValidDaysNotice: true
                };
                if (this.dateValidator(this.data.form.controls.TransactionDt.value)) {
                  data.inValidCurrentDate = true;
                }
                this.ignoreRegulatoryRequirementArray.push(data);
                this.setIgnoredData(this.ignoreRegulatoryRequirementArray);
              } else {
                const presentIgnoredData: any = JSON.parse
                  (this._dynamicFormService.getStoredData(NoticeGenerationConstants.ignoredDataText));
                if (presentIgnoredData !== null && presentIgnoredData.length > 0) {
                  const skipTransDtData = presentIgnoredData.filter
                    (x => x.key !== NoticeGenerationConstants.transactionDate);
                  this.setIgnoredData(skipTransDtData);
                }
              }
            });
          }, 200);
        }
        return {
          isValidLookupDate: false,
          message: message
        };
      } else {
        return {
          isValidLookupDate: true,
          message: null
        };
      }
    } else {
      return {
        isValidLookupDate: true,
        message: null
      };
    }
  }

  getPolicyInfo() {
    this._dynamicFormService.clearMortgageeIgnoreData();
    this._dynamicFormService.mortgegeeIgnoreArray = [];
    const formName = this._dynamicFormService.getCurrentFormName();
    const params = {
      policyType: this.formModel.policy,
      jurisdiction: this.formModel.jurisdiction,
      action: this.formModel.action,
      circumstance: this.formModel.circumstance,
      lobs: this.formModel.lob,
      policynumber: (this.data.form.get(NoticeGenerationConstants.policyNumber).value).trim(),
      docName: formName
    };
    this.saveFormData();
    this.dynamicFormHttpService.getPolicyInfo(params).subscribe(res => {
      if (res && res.forms && res.forms.length > 0) {
        this._dynamicFormService.showLookupWarningPopup = false;
        const sectionNames = [];
        const sectionDetails = [];
        const noticeData = [];
        const formIndex = res.forms.findIndex(x => x.name === formName);
        if ((this.isSupplementalForm &&
          res.forms[formIndex].components.findIndex(x => (x.name).includes(NoticeGenerationConstants.policyText)) >= 0)
          || !this.isSupplementalForm) {
          this.dynamicFormsComponent.typistValue = res.typist;
          if ((this.isSupplementalForm && res.serviceCenterId && res.serviceCenterId !== 0) || !this.isSupplementalForm) {
            this.dynamicFormsComponent.serviceCenterValue = res.serviceCenterId;
          }
        }
        this._dynamicFormService.setStoreData(NoticeGenerationConstants.typistData, this.dynamicFormsComponent.typistValue);
        this._dynamicFormService.setStoreData(NoticeGenerationConstants.insurerForm.serviceCenterData,
           this.dynamicFormsComponent.serviceCenterValue);
        this._dynamicFormService.setSessionData(NoticeGenerationConstants.insurerForm.serviceCenterData,
        this.dynamicFormsComponent.serviceCenterValue);
        this.serviceCenterExistAfterRegen =
        this.dynamicFormsComponent.checkIfServiceCenterExist(this.dynamicFormsComponent.serviceCenterValue);
        this.dynamicFormsComponent.serviceCenterData.forEach(element => {
          if (Number(this.dynamicFormsComponent.serviceCenterValue) === element.id) {
            this.dynamicFormsComponent.selectedServiceCenter = element;
            this._dynamicFormService.setStoreData(NoticeGenerationConstants.insurerForm.selectedServiceCenter, element);
            this.dynamicFormsComponent.isServiceCenterValid = true;
          }
        });

        if (res.forms[formIndex].name === formName && res.forms.length) {
          res.forms[formIndex].components.forEach(element => {
            const fields = element.fields.reduce(
              (obj, item) => Object.assign(obj, { [item.name]: this._dynamicFormService.getValue(item.value) }), {});

            if (sectionDetails.length > 0) {
              if (Object.values(NoticeGenerationConstants.sectionNames).includes(element.name)) {
                if (sectionDetails.findIndex((ele) => ele.name === element.name) >= 0) {
                  const index = sectionDetails.findIndex((ele) => ele.name === element.name);
                  sectionDetails[index].value = [...sectionDetails[index].value, fields];
                } else {
                  sectionDetails.push({ name: element.name, value: [fields] });
                }
              } else {
                sectionDetails.push({ name: element.name, value: fields });
              }
            } else {
              sectionDetails.push({ name: element.name, value: fields });
            }

            let noticeFieldValues = [];

            element.fields.forEach(field => {
              if (sessionStorage.sectionsAvailable && sessionStorage.sectionsAvailable.includes(element.name)) {
                if (field.value === NoticeGenerationConstants.effectiveTime.afterTwelveValue ||
                  field.value === NoticeGenerationConstants.twelveNoon) {
                  field.value = NoticeGenerationConstants.effectiveTime.afterTwelveKey;
                }
                noticeFieldValues.push({ name: field.name, value: field.value });
              }
            });

            // avoid invalid premiumAdj and produce data
            let containsValue = false;
            noticeFieldValues.forEach(ele => {
              if (ele.value !== null) {
                containsValue = true;
              }
            });

            if (containsValue) {
              // case - policy information has ignored notice data
              if (element.name.includes(NoticeGenerationConstants.policyText)) {
                noticeFieldValues = this.setRegenerationPolicyIgnoreValues(noticeFieldValues, formName);
              }

              // case - Premium adjustment has ignored notice data
              if (element.name === NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment) {
                this._dynamicFormService.setRegeneratePremiumAdjIgnoreValues(noticeFieldValues);
              }

              // case - Setting mortgagee ignore data
              if (element.name.includes(NoticeGenerationConstants.mortgageeText)) {
                const mortgageeData = this._dynamicFormService.setRegenerateMortgageeValues(noticeFieldValues, noticeData);
                if (mortgageeData) {
                  noticeFieldValues[mortgageeData.index].ignoreNonComplianceWarnings = this._dynamicFormService.
                  getMortgageeIgnoreArray(mortgageeData);
                }
              }
              noticeData.push({ name: element.name, fields: noticeFieldValues });
            }
          });

          const sectionsAvailable = [];
          const dataTemp = [];
          sectionDetails.forEach(element => {
            // avoid invalid premiumAdj and produce data
            let containsValue = false;
            for (const key in element.value) {
              if (element.value.hasOwnProperty(key) && element.value[key] !== null) {
                containsValue = true;
              }
            }

            if (containsValue) {
              if (element.value === NoticeGenerationConstants.effectiveTime.afterTwelveValue ||
                element.value === NoticeGenerationConstants.twelveNoon) {
                element.value = NoticeGenerationConstants.effectiveTime.afterTwelveKey;
              }
              dataTemp.push({ 'sectionName': element.name, 'formValue': element.value });
              sectionNames.push(element.name);
              sectionsAvailable.push(element.name);
            }
          });
          if (this.formModel.actionName === NoticeGenerationConstants.reinstatementDisplayName &&
             !sectionsAvailable.includes(NoticeGenerationConstants.policyReinstatement)) {
            sectionsAvailable.unshift(NoticeGenerationConstants.policyReinstatement);
          } else if (!sectionsAvailable.includes(this.data.sectionName)) {
            sectionsAvailable.unshift(this.data.sectionName);
          }
          this._dynamicFormService.setCurrentSection(sectionsAvailable);

          const data =
            [{ 'name': formName, 'components': noticeData, 'formData': dataTemp }];

            if (!this.isSupplementalForm) {
              const localNoticeData = (sessionStorage.noticeData && JSON.parse(sessionStorage.noticeData)) ?
                JSON.parse(sessionStorage.noticeData) : [];
              if (localNoticeData && localNoticeData.length > 0) {
                const index = localNoticeData.findIndex(x => x.name === formName);
                localNoticeData[index] = data[0];
                sessionStorage.setItem(NoticeGenerationConstants.noticeData, JSON.stringify(localNoticeData));
              } else {
                sessionStorage.setItem(NoticeGenerationConstants.noticeData, JSON.stringify(data));
              }
              this._dynamicFormService.isNoticeRegenerated = true;
              if (data[0].formData.findIndex(x => (x.sectionName).includes(NoticeGenerationConstants.policyText)) >= 0) {
                this._dynamicFormService.isNoticeRegeneratedExactMatch = true;
              }
            } else if (this.isSupplementalForm &&
               data[0].formData.findIndex(x => (x.sectionName).includes(NoticeGenerationConstants.policyText)) >= 0) {
              /* Scenario - supplemental form
               1. policy lookup => This will return parties or No data for PolicyInformation => Populate main form data
               2. policy lookup => PolicyInformation => Load data from the response */
              const localNoticeData = (sessionStorage.noticeData && JSON.parse(sessionStorage.noticeData)) ?
                JSON.parse(sessionStorage.noticeData) : [];
              if (localNoticeData && localNoticeData.length > 0) {
                const index = localNoticeData.findIndex(x => x.name === formName);
                localNoticeData[index] = data[0];
                sessionStorage.setItem(NoticeGenerationConstants.noticeData, JSON.stringify(localNoticeData));

                this.dynamicFormsComponent.supplemntalPreviousSection = sectionNames;
                this._dynamicFormService.setStoreData(NoticeGenerationConstants.supplemntalPreviousVisitedSections,
                  this.dynamicFormsComponent.supplemntalPreviousSection);
              }
            }

          this.sectionFormData = this._dynamicFormService.getSectionFormData(this.sectionName);
          this._dynamicFormService.prefillFormData(this.data.form, this.sectionFormData);
          if (!this.isSupplementalForm) {
            this.dynamicFormsComponent.previousSection = sectionNames;
            this._dynamicFormService.setStoreData(NoticeGenerationConstants.previousVisitedSections,
              this.dynamicFormsComponent.previousSection);

            this._dynamicFormService.formSectionNames.forEach((section, index) => {
              if (this.dynamicFormsComponent.previousSection.includes(section.displayName)) {
                this.dynamicFormsComponent.isvisitedSection[index] = true;
              }
              else if (this.dynamicFormsComponent.previousSection.includes(section.name)) {
                this.dynamicFormsComponent.isvisitedSection[index] = true;
              }
            });
          }
        }
        setTimeout(() => {
          this._dynamicFormService.showLookupWarningPopup = true;
        }, 100);
      } else if (!res && this._dynamicFormService.isNoticeRegenerated && !this.isSupplementalForm) {
        const policyValue = this.data.form.get(NoticeGenerationConstants.policyNumber).value;
        this._dynamicFormService.isNoticeRegenerated = false;
        this._dynamicFormService.isNoticeRegeneratedExactMatch = false;
        this._dynamicFormService.setNoticeStatus(false);
        this.dynamicFormsComponent.isvisitedSection.fill(false);
        this.reset();
        this.data.form.get(NoticeGenerationConstants.policyNumber).setValue(policyValue);

        this._dynamicFormService.formSectionNames.forEach((section, index) => {
          sessionStorage.removeItem(section.name + '_Data');
        });
        this.dynamicFormsComponent.typistValue = '';
        this._dynamicFormService.setStoreData(NoticeGenerationConstants.typistData, this.dynamicFormsComponent.typistValue);
        this.dynamicFormsComponent.previousSection = [];
        this._dynamicFormService.setStoreData(NoticeGenerationConstants.previousVisitedSections,
          this.dynamicFormsComponent.previousSection);
        const temp = [];
        if (sessionStorage.noticeData) {
          JSON.parse(sessionStorage.noticeData).forEach(ele => {
            if (ele && ele.name !== formName) {
              temp.push(ele);
            }
          });
        }
        (temp && temp.length > 0) ? sessionStorage.setItem(NoticeGenerationConstants.noticeData, JSON.stringify(temp)) :
          sessionStorage.removeItem(NoticeGenerationConstants.noticeData);
      }
      this._dynamicFormService.fieldRuleValidatorForAllFields();
    }, error => {
      if (error.status === 500) {
        this._dynamicFormService.showAlert(error.error.message);
      }
      this.spinnerService.stop();
    });
  }

  isGenerateNoticeButtonEnable() {
    if (!this.dynamicFormsComponent.serviceCenterValue) {
      return true;
    } else {
      return this._dynamicFormService.isGenerateNoticeButtonEnable(this.data.form.valid);
    }
  }

  onGererateNoticeClick(form: FormGroup, sectionId = 0) {
    this._dynamicFormService.fieldRuleValidatorForAllFields();
    this._dynamicFormService.noticeFieldData(this.sectionName, form);
    if (this._dynamicFormService.checkRequiredSectionDataAvailable(this.data)) {
      this.isGenerateNoticeClicked = true;
      this.validateAllFormFields(this.data.form);
      this.dynamicFormsComponent.isvisitedSection[this.currentSectionId] = true;
      const serviceCenterData = sessionStorage.serviceCenterData ? JSON.parse(JSON.parse(sessionStorage.serviceCenterData)) : (
        sessionStorage.selectedServiceCenter ? JSON.parse(sessionStorage.selectedServiceCenter).id : '');
      this.setEffectiveDatePopupDetails();
      if (serviceCenterData && serviceCenterData !== '') {
        this.showRandWarningAlerts(form, sectionId, serviceCenterData);
      } else {
        this.dynamicFormsComponent.isServiceCenterValid = false;
      }
    }
  }

  prepareIgnoredData(message: any) {
    let data: any;
    data = { key: NoticeGenerationConstants.transactionDate, isIgnored: true, message: message };
    data.inValidCurrentDate = this._dynamicFormService.lookupDaysValidationData.minDays === 0 ? true : false;
    data.inValidDaysNotice = this._dynamicFormService.lookupDaysValidationData.minDays === 0 ? false : true;
    return data;
  }

  setIgnoredData(data: any) {
    const sessionStorageKey = this.isSupplementalForm ? NoticeGenerationConstants.ignoredDataTextSupplemental :
      NoticeGenerationConstants.ignoredDataText;
    const distinctRecords = this._dynamicFormService.getDistinctRecords(data);
    this._dynamicFormService.setIgnoredData(sessionStorageKey, distinctRecords);
  }

  setEffectiveDatePopupDetails() {
    const sessionStorageKey = this.isSupplementalForm ? NoticeGenerationConstants.supplimentalEffectDateKey :
      NoticeGenerationConstants.effectiveDateKey;
    this._dynamicFormService.removeStoredData(sessionStorageKey);
    const data = { minDays: this._dynamicFormService.lookupDaysValidationData?.minDays };
    this._dynamicFormService.setIgnoredData(sessionStorageKey, data);
  }

  removeEffectiveDatePopupDetails() {
    const sessionStorageKey = this.isSupplementalForm ? NoticeGenerationConstants.supplimentalEffectDateKey :
    NoticeGenerationConstants.effectiveDateKey;
    this._dynamicFormService.removeStoredData(sessionStorageKey);
  }

  hideExtraAsterisk() {
    this._dynamicFormService.hideExtraAsterisk();
  }

  setExplicityDefaultValues() {
    this.data?.fields?.forEach((item: any) => {
      if (item && item.hasOwnProperty(NoticeGenerationConstants.keyText)) {
        const isRequired = item?.templateOptions?.required;
        const currentValue = this.data.form.get(item?.key)?.value;
        if (item?.templateOptions?.type === NoticeGenerationConstants.checkBoxText && isRequired && (!currentValue)) {
          this.data.form.get(item?.key).setValue(null);
        }
      }
    });
  }

  setRegenerationPolicyIgnoreValues(noticeFieldValues, formName) {
    const ignoreFields = [];
    const ignoreFieldDetails = [];
    if (this.data) {
      const formIndex = this.data.formDataObject.findIndex(x => x.name === formName);
      this.data?.formDataObject[formIndex]?.components[0]?.fields?.forEach(ele => {
        if (ele?.isRegulatoryRequirement || ele?.isRequired) {
          ignoreFields.push(ele.name);
        }
      });
    }

    noticeFieldValues?.forEach(field => {
      if (ignoreFields.includes(field.name) && (field.value === null || field.value === '' || field.value === false)) {
        field['ignoreRegulatoryRequirement'] = true;
        field['ignoreRequirement'] = true;
        ignoreFieldDetails.push({
          'key': field.name,
          'isIgnored': true,
          'message': ''
        });
      } else if ((field.name === NoticeGenerationConstants.mailingDate || this._dynamicFormService.dateFields.has(field.name))
        && this._dynamicFormService.isDateValid(field.value)) {
        field['ignoreNonComplianceWarnings'] = [NoticeGenerationConstants.ignoreNonComplianceWarnings[0]];
        ignoreFieldDetails.push({
          'key': field.name,
          'isIgnored': true,
          'message': this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.non_compliance_warning'),
          'inValidCurrentDate': true
        });
      } else if (field.name === NoticeGenerationConstants.transactionDate) {
        let isDaysLookupDateValid = false;
        const mailingDate = noticeFieldValues ?
          noticeFieldValues?.find(x => x.name === NoticeGenerationConstants.mailingDate)?.value : this._dynamicFormService.getCurrentDate();
        const datediff = this._dynamicFormService.getLookupDaysDateDiff(field.value, mailingDate);
        const minDays = this._dynamicFormService.getPolicyEffectiveDateDetails()?.minDays;
        let invalidCurrentDate = this._dynamicFormService.isDateValid(field.value);

        if (Number(datediff) < Number(minDays)) {
          isDaysLookupDateValid = true;
        } else if (Number(minDays) === 0) {
          isDaysLookupDateValid = false;
        }

        if (this.formModel.actionName === NoticeGenerationConstants.LookUpDateDetails.reinstatement) {
          invalidCurrentDate = true;
          isDaysLookupDateValid = true;
        }

        const data = { name : field.name, inValidCurrentDate :  invalidCurrentDate,
          invalidDaysLookupDate : isDaysLookupDateValid};

        field['ignoreNonComplianceWarnings'] = this._dynamicFormService.getMortgageeIgnoreArray(data);

        ignoreFieldDetails.push({
          'key': field.name,
          'isIgnored': true,
          'message': this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.non_compliance_warning'),
          'inValidDaysNotice': isDaysLookupDateValid,
          'inValidCurrentDate': invalidCurrentDate
        });
      }
    });
    this.setIgnoredData(ignoreFieldDetails);
    return noticeFieldValues;
  }
}
