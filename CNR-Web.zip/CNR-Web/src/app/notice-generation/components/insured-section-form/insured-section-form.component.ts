import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { FormlyFormOptions } from '@ngx-formly/core';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import { AppConstants } from 'app/app.constants';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { take } from 'rxjs/operators';
import { DynamicFormsComponent } from '../dynamic-forms/dynamic-forms.component';

@Component({
  selector: 'app-insured-section-form',
  templateUrl: './insured-section-form.component.html',
  styleUrls: ['./insured-section-form.component.scss']
})
export class InsuredSectionFormComponent implements OnInit, AfterViewInit {
  @Input() data;
  @Output() sectionIdEventEmitter = new EventEmitter<number>();
  formModel = {};
  insuredCopy: number;
  insuredMailType: string;
  uspsValue: boolean;
  sectionName: string;
  formIndexValue = 0;
  sectionForm = new FormGroup({});
  sectionFormData;
  lastFormIndex = 0;
  currentSectionId: string;
  isVisitedFirst = false;
  options: FormlyFormOptions = {};

  constructor(
    private popupService: PopupService,
    private translate: TranslateService,
    private router: Router,
    private dynamicFormsComponent: DynamicFormsComponent,
    private _dynamicFormService: DynamicFormService
  ) {
    this._dynamicFormService.componentMethodCalled$.subscribe(
      (res: any) => {
        if (Number(res.requested) === Number(this.data.sectionId) || Number(res.current) === Number(this.data.sectionId)) {
          if (Number(res.requested) === Number(this.data.sectionId) && !this.isVisitedFirst) {
            if (this.data && this.data?.form) {
              this.data?.form?.resetAll();
            }
            this.isVisitedFirst = true;
          }
          this.onClickPrefillValidateForm();
        }
      }
    );
  }

  ngOnInit(): void {
    this._dynamicFormService.saveSectionId(this.data.sectionId);
    this.sectionName = this.data.sectionName;
    this.data.form = this.sectionForm;
    this.data.options = this.options;
    this.sectionFormData = this._dynamicFormService.getSectionFormData(this.sectionName);
    this.lastFormIndex = this._dynamicFormService.getLastFormIndex();
    this.currentSectionId = this._dynamicFormService.getStoredData(this._dynamicFormService.getCurrentFormSectionIdKey());
  }
  ngAfterViewInit() {
    this.insuredCopy = this.data.form.get(NoticeGenerationConstants.insuredForm.insuredCopies).value
      ? this.data.form.get(NoticeGenerationConstants.insuredForm.insuredCopies).value : '';
    this.insuredMailType = this.data.form.get(NoticeGenerationConstants.insuredForm.insuredMailType).value
      ? this.data.form.get(NoticeGenerationConstants.insuredForm.insuredMailType).value : '';
    this.uspsValue = this.data.form.get(NoticeGenerationConstants.insuredForm.fill3817Insured).value
      ? this.data.form.get(NoticeGenerationConstants.insuredForm.fill3817Insured).value : false;
    this.data.options.resetModel();
    this.data.form.get(NoticeGenerationConstants.insuredForm.insuredCopies).setValue(this.insuredCopy);
    this.data.form.get(NoticeGenerationConstants.insuredForm.insuredMailType).setValue(this.insuredMailType);
    this.data.form.get(NoticeGenerationConstants.insuredForm.fill3817Insured).setValue(this.uspsValue);

    if (this.sectionFormData) {
      this._dynamicFormService.prefillFormData(this.data.form, this.sectionFormData);
    }

    this._dynamicFormService.fieldRuleValidatorForAllFields();
    this._dynamicFormService.scrollToTop();
  }

  reset() {
    this.data.form.reset();
    this.data.form.get(NoticeGenerationConstants.insuredForm.insuredCopies).setValue(this.insuredCopy);
    this.data.form.get(NoticeGenerationConstants.insuredForm.insuredMailType).setValue(this.insuredMailType);
    this.data.form.get(NoticeGenerationConstants.insuredForm.fill3817Insured).setValue(this.uspsValue);
    this.removeGreenTick(this.sectionName);
    this._dynamicFormService.fieldRuleValidatorForAllFields();
    this.saveFormData();
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  generateNotice(form: FormGroup) {
    this._dynamicFormService.noticeFieldData(this.sectionName, form);
    this.saveFormData();
    if (this._dynamicFormService.checkRequiredSectionDataAvailable(this.data)) {
      this._dynamicFormService.setNoticeStatus(true);
      this._dynamicFormService.generateNoticeData(this.sectionName, form);
    }
  }
  onSubmit(form) {
    this.validateAllFormFields(form);
    this.dynamicFormsComponent.isvisitedSection[this.currentSectionId] = true;
    if (this.data.form.valid) {
      this.dynamicFormsComponent.isPageValid = true;
      this.dynamicFormsComponent.isSectionValid = true;
      this._dynamicFormService.noticeFieldData(this.sectionName, form);
      this.saveFormData();
      this.sectionIdEventEmitter.emit(this.data.sectionId);
    }
  }
  addGreenTick(sectionName) {
    if (this._dynamicFormService.isSupplementalForm) {
      if (!this.dynamicFormsComponent.supplemntalPreviousSection.includes(sectionName)) {
        this.dynamicFormsComponent.supplemntalPreviousSection.push(sectionName);
        this._dynamicFormService.setStoreData(NoticeGenerationConstants.supplemntalPreviousVisitedSections,
          this.dynamicFormsComponent.supplemntalPreviousSection);
      }
    } else {
      if (!this.dynamicFormsComponent.previousSection.includes(sectionName)) {
        this.dynamicFormsComponent.previousSection.push(sectionName);
        this._dynamicFormService.setStoreData(NoticeGenerationConstants.previousVisitedSections,
          this.dynamicFormsComponent.previousSection);
      }
    }

  }
  removeGreenTick(sectionName) {
    if (this._dynamicFormService.isSupplementalForm) {
      if (this.dynamicFormsComponent.supplemntalPreviousSection.includes(sectionName)) {
        this.dynamicFormsComponent.supplemntalPreviousSection =
          this.dynamicFormsComponent.supplemntalPreviousSection.filter(item => (item !== sectionName));
        this._dynamicFormService.setStoreData(NoticeGenerationConstants.supplemntalPreviousVisitedSections,
          this.dynamicFormsComponent.supplemntalPreviousSection);
      }
    } else {
      if (this.dynamicFormsComponent.previousSection.includes(sectionName)) {
        this.dynamicFormsComponent.previousSection.push(sectionName);
        this.dynamicFormsComponent.previousSection =
        this.dynamicFormsComponent.previousSection.filter(item => (item !== sectionName));
          this._dynamicFormService.setStoreData(NoticeGenerationConstants.previousVisitedSections,
          this.dynamicFormsComponent.previousSection);
      }
    }
  }
  moveToCriteriaSelection(form: FormGroup) {

    this.popupService.showConfirmation({
      title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
      message: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.back_on_criteria_Selection'),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button')
    })
      .pipe(take(1)).subscribe(res => {
        if (res) {
          form.reset();
          this._dynamicFormService.setNoticeStatus(false);
          this._dynamicFormService.removeStoredData(NoticeGenerationConstants.insurerForm.serviceCenterData);
          this.dynamicFormsComponent.noticeData = [];
          this._dynamicFormService.previousPolicyNumber = null;
          this._dynamicFormService.isNoticeRegenerated = false;
          this.isVisitedFirst = false;
          this.router.navigate([AppConstants.uiRoutes.noticeGeneration +
            NoticeGenerationConstants.routeSeparator +
            AppConstants.uiRoutes.criteriaSelection]);
        } else {
          window.scrollTo(0, 0);
        }
      });
  }

  saveFormData() {
    if (this.data.form.valid) {
      this.addGreenTick(this.sectionName);
    }
    this._dynamicFormService.saveSectionFormData(this.sectionName, this.data.form.value);
  }
  onClickPrefillValidateForm() {
      this.validateAllFormFields(this.data.form);
      if (this.data.form.valid) {
        this._dynamicFormService.noticeFieldData(this.sectionName, this.data.form);
        this.saveFormData();
        this.dynamicFormsComponent.isSectionValid = true;
        this.dynamicFormsComponent.isPageValid = true;
      }
      else {
        this.dynamicFormsComponent.isSectionValid = false;
      }
    }
}
