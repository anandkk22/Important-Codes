import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { take } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';

@Component({
  selector: 'reason-text-modal',
  templateUrl: './reason-text-modal.component.html',
  styleUrls: ['./reason-text-modal.component.scss']
})
export class ReasonTextModalComponent implements OnInit {
  @Input() data: any;
  textData: string;
  isSaved = true;
  savedValue: string;
  maxLengthParam = {
    maxLength: 0
  };

  constructor(
    public activeModal: NgbActiveModal,
    private popupService: PopupService,
    private translate: TranslateService,
  ) {}

  ngOnInit() {
    this.textData = this.data.defaultValue;
    this.savedValue = this.data.defaultValue;
    this.maxLengthParam.maxLength = this.data.fieldData.maxLength;
  }

  onSave() {
    this.isSaved = true;
    this.savedValue = this.textData;
    this.activeModal.close(this.savedValue);
  }

  onReset() {
    this.textData = this.data.defaultValue;
    this.savedValue = this.data.defaultValue;
    this.isSaved = true;
  }

  onTextChange(event) {
    this.textData = this.textData.trim();
    this.isSaved = false;
  }

  onKeyPress(event) {
    this.isSaved = false;
    if (event.keyCode === 13  || event.keyCode === 0) {
      this.popupService.showAlert({
        title: this.translate.instant('MESSAGES.Confirmation.alertTitle'),
        message: this.translate.instant('NOTICE_GEN_TAB.MAGNIFYING_GLASS_MODAL.invalid_key_alert'),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: ''
      });
      return false;
    }
  }

  onCancel() {
    if (this.isSaved) {
      this.activeModal.close(this.savedValue);
    } else {
      this.popupService.showConfirmation({
        title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
        message: this.translate.instant('NOTICE_GEN_TAB.MAGNIFYING_GLASS_MODAL.save_alert'),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: this.translate.instant('BUTTON.cancel_button')
      })
        .pipe(take(1)).subscribe( res => {
          if (res) {
            this.activeModal.close(this.savedValue);
          }
        });
    }
  }

  disableSaveResetButton() {
    let isBtnDisable = false;
    isBtnDisable = this.textData === this.data.defaultValue ? true : false;
    return isBtnDisable;
  }
}
