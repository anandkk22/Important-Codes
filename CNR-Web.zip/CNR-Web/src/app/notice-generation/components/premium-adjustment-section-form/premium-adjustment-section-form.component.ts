import { Component, OnInit, EventEmitter, Output, Input, AfterViewInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import { AppConstants } from 'app/app.constants';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { of } from 'rxjs';
import { take } from 'rxjs/operators';
import { DynamicFormsComponent } from '../dynamic-forms/dynamic-forms.component';
import { FormlyFormOptions } from '@ngx-formly/core';
@Component({
  selector: 'app-premium-adjustment-section-form',
  templateUrl: './premium-adjustment-section-form.component.html',
  styleUrls: ['./premium-adjustment-section-form.component.scss'],
})

export class PremiumAdjustmentSectionFormComponent
  implements OnInit, AfterViewInit {
  @Input() data;
  @Output() sectionIdEventEmitter = new EventEmitter<number>();
  formModel: any = {};
  requiredIndex = 0;
  regulatoryIndex = 0;
  displayAlert: boolean;
  requiredMessageArray = [];
  regulatoryMessageArray = [];
  sectionName: string;
  formIndexValue = 0;
  sectionForm = new FormGroup({});
  sectionFormData;
  isNoticeGenerated: boolean;
  lastFormIndex = 0;
  currentSectionId: any;
  ignoreRegulatoryRequirementArray = [];
  isSupplementalForm: boolean;
  options: FormlyFormOptions = {};
  isVisitedFirst = false;
  isContinueClicked = false;
  isGenerateNoticeClicked = false;

  constructor(
    private popupService: PopupService,
    private translate: TranslateService,
    private router: Router,
    private route: ActivatedRoute,
    private _dynamicFormService: DynamicFormService,
    private dynamicFormsComponent: DynamicFormsComponent
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      this.isSupplementalForm = Boolean(params['supplementalForm']);
    });
    this._dynamicFormService.saveSectionId(this.data.sectionId);
    this.dynamicFormsComponent.isPageValid = false;
    this.sectionName = this.data.sectionName;
    this.data.form = this.sectionForm;
    this.data.options = this.options;
    this._dynamicFormService.triggerSubmitManually.subscribe((res) => {
      this.validateAllFormFields(this.data.form);
      this.onSubmit(this.data.form);
    });
    this.sectionFormData = this._dynamicFormService.getSectionFormData(
      this.sectionName
    );
    this.isNoticeGenerated = this._dynamicFormService.getNoticeStatus();
    this.lastFormIndex = this._dynamicFormService.getLastFormIndex();
    this.currentSectionId = this._dynamicFormService.getStoredData(
      this._dynamicFormService.getCurrentFormSectionIdKey()
    );
    this._dynamicFormService.componentMethodCalled$.subscribe((res: any) => {
      if (
        Number(res.requested) === Number(this.data.sectionId) ||
        Number(res.current) === Number(this.data.sectionId)
      ) {
        if (Number(res.requested) === Number(this.data.sectionId) && !this.isVisitedFirst) {
          if (this.data && this.data?.form) {
            this.data?.form?.resetAll();
            this.isVisitedFirst = true;
          }
        }
        if (!this._dynamicFormService.avoidPreAdjustNavigation) {
          this.onClickPrefillValidateForm();
        }
      }
    });
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  ngAfterViewInit() {
    this.data.form.reset();
    if (this.sectionFormData) {
      this._dynamicFormService.prefillFormData(
        this.data.form,
        this.sectionFormData
      );
    }
    this.requiredMessageArray = [];
    this._dynamicFormService.scrollToTop();
    this.hideExtraAsterisk();
    this._dynamicFormService.fieldRuleValidatorForAllFields();
    setTimeout(() => {
      this._dynamicFormService.avoidPreAdjustNavigation = false;
    }, 100);
  }

  generateNotice(form: FormGroup) {
    if (this._dynamicFormService.checkRequiredSectionDataAvailable(this.data)) {
      this.isContinueClicked = false;
      this.isGenerateNoticeClicked = true;
      this._dynamicFormService.isNavigationPrefilledClicked = false;
      this.addPremiumAdjustmentFormData(form);
    }
  }

  onSubmit(form: FormGroup) {
    this._dynamicFormService.fieldRuleValidatorForAllFields();
    this.setExplicityDefaultValues();
    this.isContinueClicked = true;
    this._dynamicFormService.isNavigationPrefilledClicked = false;
    setTimeout(() => {
      this.addPremiumAdjustmentFormData(form);
    }, 800);
  }

  addPremiumAdjustmentFormData(form) {
    this.ignoreRegulatoryRequirementArray = [];
    let submitForm = true;
    const fieldArr = [];
    this.dynamicFormsComponent.isPageValid = false;
    this.dynamicFormsComponent.isvisitedSection[this.currentSectionId] = true;
    const formName = this._dynamicFormService.getCurrentFormName();
    const presentSections = this._dynamicFormService.getSectionsForCurrentForm(formName);

    if (!presentSections.includes(this.sectionName)) {
      this._dynamicFormService.addSection(this.sectionName);
    }

    this.data.fields.forEach(ele => {
      if (ele && ele.key) {
        for (const i in this.data.model) {
          if (ele.key === i) {
            fieldArr.push({ name: i, value: `${this.data.model[i]}` });
            const temp = `${this.data.model[i]}`;
            const isRequired = ele?.templateOptions?.required;
            const containsRegulatory = this._dynamicFormService.regulatoryRequiredFields.map(a => a.key).includes(ele.key);
            if ((isRequired && temp === 'null') || (temp !== 'null' && temp && temp !== 'false') || (containsRegulatory)) {
              this.dynamicFormsComponent.isPageValid = true;
              this.dynamicFormsComponent.isSectionValid = true;
              break;
            }
          }
        }
      }
    });

    if (this.dynamicFormsComponent.isPageValid) {
      this.showRandWarningAlerts(form).subscribe(
        (value) => {
          submitForm = value;
          if (submitForm) {
            this._dynamicFormService.noticeFieldData(this.sectionName, form);
            this.saveFormData();
            if (this.requiredMessageArray.length === 0 && this.isContinueClicked) {
              this.sectionIdEventEmitter.emit(this.data.sectionId);
            }
          }

        });
    } else {
      // this.removeSection();
      this._dynamicFormService.isPreAdjustmentFormValid = true;
      const updatedData = [];
      let formData = [];
      let iterator = 0;
      const noticeData = (sessionStorage.noticeData && JSON.parse(sessionStorage.noticeData)) ? JSON.parse(sessionStorage.noticeData) : [];

      if (noticeData && noticeData.length) {
        for (const i of noticeData) {
          if (i && i.name === formName) {
            formData = i.formData;
            const data = i.components;
            data.forEach(element => {
              if (element.name !== this.sectionName) {
                updatedData.push(element);
              }
            });
            break;
          }
          iterator++;
        }
      }
      this._dynamicFormService.pushDataToNoticeData(updatedData, formData);
      this.saveFormData();
      if (this.isGenerateNoticeClicked) {
        this._dynamicFormService.generateNoticeData(this.sectionName, form);
        this.isGenerateNoticeClicked = false;
      } else {
        this.sectionIdEventEmitter.emit(this.data.sectionId);
      }
    }
  }

  reset() {
    this.data.form.reset();
    this._dynamicFormService.fieldRuleValidatorForAllFields();
    this.saveFormData();
    this.dynamicFormsComponent.isPageValid = false;
  }

  showRandWarningAlerts(form: FormGroup) {
    this.ignoreRegulatoryRequirementArray = [];
    this.requiredIndex = 0;
    this.regulatoryIndex = 0;
    let submitForm = true;
    let showWarning = true;
    let showRequiredWarning = false;
    this.requiredMessageArray = [];
    this.regulatoryMessageArray = [];
    this._dynamicFormService.premAdjustRegulatoryFields = [];
    this._dynamicFormService.requiredFields = [];
    const sessionStorageKey = this.isSupplementalForm ? NoticeGenerationConstants.ignoredPreAdjustDataTextSupplemental
      : NoticeGenerationConstants.ignoredPreAdjustDataText;
    this._dynamicFormService.removeStoredData(sessionStorageKey);

    if (this.data?.form?.controls) {
    for (const value of Object.keys(this.data?.form?.controls)) {
      const isFieldRegulatory = this._dynamicFormService.regulatoryRequiredFields.map(a => a.key).includes(value);
      const currentFieldValue = this.data?.form?.get(value)?.value;
      if (this.data?.form?.controls?.hasOwnProperty(value)) {
        if (this.data?.form?.get(value)?.errors && this.data?.form?.get(value)?.errors?.required) {
          this._dynamicFormService.requiredFields.push({
            key: value,
            value: this.getFieldLabel(value)
          });
        } else if ((currentFieldValue === 'null' || currentFieldValue === null) && isFieldRegulatory) {
          this._dynamicFormService.premAdjustRegulatoryFields.push({
            key: value,
            value: this.getFieldLabel(value)
          });

        }
      }
    }
  }

    this.requiredMessageArray = this.getAlertMessagesArray(this.data.form, this._dynamicFormService.requiredFields, true, false);
    this.regulatoryMessageArray = this.getAlertMessagesArray
    (this.data.form, this._dynamicFormService.premAdjustRegulatoryFields, false, true);

    this.requiredMessageArray = [...new Set(this.requiredMessageArray), ... new Set(this.regulatoryMessageArray)];
    if (this.requiredMessageArray.length > 0) {
      this.rerenderRequiredfunction(form, showWarning, showRequiredWarning, submitForm
      ).subscribe((res) => {
        showWarning = res.showWarning;
        showRequiredWarning = res.showRequiredWarning;
        submitForm = res.submitForm;
      });
    }
    else {
      if (this.isGenerateNoticeClicked) {
        this._dynamicFormService.generateNoticeData(this.sectionName, form);
        this.isGenerateNoticeClicked = false;
      } else {
        this.sectionIdEventEmitter.emit(this.data.sectionId);
      }
      this._dynamicFormService.isPreAdjustmentFormValid = true;
      this._dynamicFormService.avoidPreAdjustNavigation = true;
      this._dynamicFormService.isNavigationPrefilledClicked = false;
    }
    return of(submitForm);
  }

  rerenderRequiredfunction(form, showWarning, showRequiredWarning, submitForm) {
    if (this.requiredIndex <= this.requiredMessageArray.length) {
      this.ignoreRegulatoryRequirementArray = [
        ...new Set(this.ignoreRegulatoryRequirementArray),
      ];
      this.popupService
        .showConfirmation({
          title: this.translate.instant(
            'NOTICE_GEN_TAB.CONFIRMATION.confirm_title'
          ),
          message: this.translate.instant(
            this.requiredMessageArray[this.requiredIndex]
          ),
          positiveLabel: this.translate.instant('BUTTON.ok_button'),
          negativeLabel: this.translate.instant('BUTTON.cancel_button'),
        })
        .pipe(take(1))
        .subscribe((res) => {
          if (!res && showWarning) {
            showRequiredWarning = true;
            if (this.ignoreRegulatoryRequirementArray.length > 0 && this.ignoreRegulatoryRequirementArray[this.requiredIndex]) {
              this.ignoreRegulatoryRequirementArray[this.requiredIndex].isIgnored = true;
            }
            if (this.requiredIndex === (this.requiredMessageArray.length - 1)) {
              this.popupService.showConfirmation({
                title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
                message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.override_company_req'),
                positiveLabel: this.translate.instant('BUTTON.ok_button'),
                negativeLabel: this.translate.instant('BUTTON.cancel_button')
              })
                .pipe(take(1)).subscribe(response => {
                  if (response) {
                    submitForm = false;
                    showWarning = false;
                    this._dynamicFormService.setPreAdjustmentIgnoredData(null);
                  } else {
                    this._dynamicFormService.setPreAdjustmentIgnoredData(this.ignoreRegulatoryRequirementArray);
                    if (this._dynamicFormService.isNavigationPrefilledClicked) {
                      this._dynamicFormService.isPreAdjustmentFormValid = true;
                      this._dynamicFormService.avoidPreAdjustNavigation = true;
                      this._dynamicFormService.isNavigationPrefilledClicked = false;
                      this.dynamicFormsComponent.onclickPrefillSec(this._dynamicFormService.navigationSectionIndex);
                    } else if (this.isContinueClicked) {
                      this.sectionIdEventEmitter.emit(this.data.sectionId);
                    } else if (this.isGenerateNoticeClicked) {
                      this._dynamicFormService.generateNoticeData(this.sectionName, form);
                      this.isGenerateNoticeClicked = false;
                    } else if (!this.isContinueClicked && (!this._dynamicFormService.isNavigationPrefilledClicked)) {
                      this._dynamicFormService.isPreAdjustmentFormValid = true;
                      this._dynamicFormService.avoidPreAdjustNavigation = true;
                      this.dynamicFormsComponent.onClickBack();
                    }
                  }
                });
            }
            if (this.requiredIndex !== this.requiredMessageArray.length - 1) {
              this.requiredIndex++;
              this.rerenderRequiredfunction(
                form,
                showWarning,
                showRequiredWarning,
                submitForm
              );
            }
          } else {
            submitForm = false;
            showWarning = false;
            const ignoredCountArray =
              this.ignoreRegulatoryRequirementArray.filter(
                (x) => x.isIgnored === true
              );
            if (ignoredCountArray.length > 0) {
              this._dynamicFormService.setPreAdjustmentIgnoredData(
                this.ignoreRegulatoryRequirementArray
              );
            }
          }
        });
    }

    return of({
      showWarning,
      showRequiredWarning,
      submitForm,
    });
  }


  getAlertMessagesArray(form, dataArray, isRequired, isRegulatory) {
    const msgArray = [];
    dataArray.forEach((item, index) => {
      if (
        form.get(item.key)?.value === '' ||
        form.get(item.key)?.value === false ||
        form.get(item.key)?.value === null
      ) {
        // * field
        if (isRequired) {
          const message =
            this.translate.instant(
              'NOTICE_GEN_TAB.PREMIUM_ADJUSTMENT.missing_value_for'
            ) +
            item.value +
            this.translate.instant('NOTICE_GEN_TAB.PREMIUM_ADJUSTMENT.post');
          msgArray.push(message);
          const data = { key: item.key, isIgnored: false, message: message };
          const alreadyExistsData = this.ignoreRegulatoryRequirementArray.filter(x => x.key === data.key);
          if (alreadyExistsData.length <= 0) {
            this.ignoreRegulatoryRequirementArray.push(data);
          }
        } else if (isRegulatory) {
          const message = this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.company_req_pre') + item.value + this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.company_req_post');
          msgArray.push(message);
          const data = { key: item.key, isIgnored: false, message: message };
          const alreadyExistsData = this.ignoreRegulatoryRequirementArray.filter(x => x.key === data.key);
          if (alreadyExistsData.length <= 0) {
            this.ignoreRegulatoryRequirementArray.push(data);
          }
        }
      }
    });
    this.ignoreRegulatoryRequirementArray = [
      ...new Set(this.ignoreRegulatoryRequirementArray),
    ];
    return msgArray;
  }

  moveToCriteriaSelection(form: FormGroup) {
    this.popupService
      .showConfirmation({
        title: this.translate.instant(
          'NOTICE_GEN_TAB.CONFIRMATION.confirm_title'
        ),
        message: this.translate.instant(
          'NOTICE_GEN_TAB.CONFIRMATION.back_on_criteria_Selection'
        ),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: this.translate.instant('BUTTON.cancel_button'),
      })
      .pipe(take(1))
      .subscribe((res) => {
        if (res) {
          this._dynamicFormService.removeStoredData('formData');
          this._dynamicFormService.removeStoredData(
            NoticeGenerationConstants.insurerForm.serviceCenterData
          );
          this.dynamicFormsComponent.noticeData = [];
          this._dynamicFormService.previousPolicyNumber = null;
          this._dynamicFormService.isNoticeRegenerated = false;
          this.isVisitedFirst = false;
          this.router.navigate([
            AppConstants.uiRoutes.noticeGeneration +
            NoticeGenerationConstants.routeSeparator +
            AppConstants.uiRoutes.criteriaSelection,
          ]);
        } else {
          window.scrollTo(0, 0);
        }
      });
  }

  saveFormData() {
    this.setExplicityDefaultValues();
    this._dynamicFormService.saveSectionFormData(
      this.sectionName,
      this.data.form.value
    );
  }

  onClickPrefillValidateForm() {
    let submitForm = true;
    let isAllRequiredVisited = true;
    this.setExplicityDefaultValues();
    this.validateAllFormFields(this.data.form);
    this.dynamicFormsComponent.isPageValid = false;
    this.data.fields.forEach((ele) => {
      if (ele?.key) {
        for (const i in this.data.model) {
          if (ele?.key === i) {
            const temp = `${this.data.model[i]}`;
            const isRequired = ele?.templateOptions?.required;
            if ((isRequired && temp === 'null') || (temp !== 'null' && temp && temp !== 'false')) {
              this.dynamicFormsComponent.isPageValid = true;
              this.dynamicFormsComponent.isSectionValid = true;
              break;
            }
          }
        }
      }
    });
    const formName = this._dynamicFormService.getCurrentFormName();
    const presentSections = this._dynamicFormService.getSectionsForCurrentForm(formName);
    if (this.dynamicFormsComponent.isPageValid) {
      if (!presentSections.includes(this.sectionName)) {
        this._dynamicFormService.addSection(this.sectionName);
      }

      if (this._dynamicFormService.isNavigationPrefilledClicked) {
        isAllRequiredVisited = this.dynamicFormsComponent.isAllRequiredVisited(this._dynamicFormService.navigationSectionIndex);
      }

      if (!this._dynamicFormService.avoidPreAdjustNavigation && isAllRequiredVisited) {
        this.showRandWarningAlerts(this.data.form).subscribe(
          (value) => {
            submitForm = value;
            if (submitForm) {
              this._dynamicFormService.noticeFieldData(this.sectionName, this.data.form);
            }
          });
      }
      this.saveFormData();
    } else {
      if (presentSections.includes(this.sectionName)) {
        this._dynamicFormService.removeSection(this.sectionName);
      }
      this.saveFormData();
      isAllRequiredVisited = this.dynamicFormsComponent.isAllRequiredVisited(this._dynamicFormService.navigationSectionIndex);
      if (isAllRequiredVisited) {
        this.sectionIdEventEmitter.emit(this.data.sectionId);
      }
    }
  }

  isGenerateNoticeButtonEnable() {
    return this._dynamicFormService.isGenerateNoticeButtonEnable(
      this.data.form.valid
    );
  }

  hideExtraAsterisk() {
    this._dynamicFormService.hideExtraAsterisk();
  }

  setExplicityDefaultValues() {
    this.data?.fields?.forEach((item: any) => {
      if (item && item.hasOwnProperty(NoticeGenerationConstants.keyText)) {
        const isRequired = item?.templateOptions?.required;
        const currentValue = this.data.form.get(item?.key)?.value;
        if (item?.templateOptions?.type === NoticeGenerationConstants.checkBoxText && isRequired && (!currentValue)) {
          this.data.form.get(item?.key).setValue(null);
        }
      }
    });
  }

  getFieldLabel(value: any) {
    // Method to get field label to display in popup
    let fieldLabel = null;
    if (this.data?.form?.get(value)?._fields[0]?.templateOptions?.label) {
      fieldLabel = this.data?.form?.get(value)?._fields[0]?.templateOptions?.label;
    } else {
      fieldLabel = this.data?.form?.get(value)?._fields[0]?.templateOptions?.name;
    }
    return fieldLabel;
  }
}
