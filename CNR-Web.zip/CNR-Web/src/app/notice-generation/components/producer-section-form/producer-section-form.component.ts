import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { debounceTime, distinctUntilChanged, map, switchMap, take } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { DynamicFormsComponent } from '../dynamic-forms/dynamic-forms.component';
import { HttpClient } from '@angular/common/http';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { Router } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { DynamicFormHttpService } from 'app/notice-generation/service/dynamic-form-http.service';

@Component({
  selector: 'app-producer-section-form',
  templateUrl: './producer-section-form.component.html',
  styleUrls: ['./producer-section-form.component.scss']
})

export class ProducerSectionFormComponent implements OnInit, AfterViewInit {
  searchTextModel = '';
  form = new FormGroup({});
  model = {};
  options = {};
  producerSearchForm: FormGroup;
  searchProducerBy = '';
  @Input() data;
  @Output() sectionIdEventEmitter = new EventEmitter<number>();
  producerCopy: number;
  producerMailType: string;
  sectionName: string;
  formIndexValue = 0;
  sectionForm = new FormGroup({});
  uspsValue: boolean;
  sectionFormData;
  producerSearchValue;
  isNoticeGenerated: boolean;
  lastFormIndex = 0;
  currentSectionId: string;
  addProducerId = false;
  isVisitedFirst = false;
  producerRecordCount = 0;
  producerDropdownList = [];
  showDropdownField = false;
  selectedProducer = null;
  producers = [];

  constructor(
    private dynamicFormsComponent: DynamicFormsComponent,
    private dynamicFormHttpService: DynamicFormHttpService,
    private dynamicFormService: DynamicFormService,
    private http: HttpClient,
    private popupService: PopupService,
    private translate: TranslateService,
    private spinnerService: SpinnerService,
    private router: Router) {
    this.dynamicFormService.componentMethodCalled$.subscribe(
      (res: any) => {
        if (Number(res.requested) === Number(this.data.sectionId) || Number(res.current) === Number(this.data.sectionId)) {
          if (Number(res.requested) === Number(this.data.sectionId) && !this.isVisitedFirst) {
            if (this.data && this.data?.form) {
              this.data?.form?.resetAll();
            }
            this.isVisitedFirst = true;
          }
          this.onClickPrefillValidateForm();
        }

      }
    );
  }

  ngOnInit(): void {
    this.dynamicFormService.saveSectionId(this.data.sectionId);
    this.sectionName = this.data.sectionName;
    this.data.form = this.sectionForm;
    this.searchProducerBy = this.dynamicFormService.getProducerCode();
    sessionStorage.setItem(NoticeGenerationConstants.producerSearchBy.searchProducerBy, this.searchProducerBy);
    this.producerSearchForm = new FormGroup({
      producerSearchTerm: new FormControl('', [])
    });
    this.sectionFormData = this.dynamicFormService.getSectionFormData(this.sectionName);

    this.dynamicFormHttpService.getProducerCount().subscribe((res: any) => {
      if (res) {
        this.producerRecordCount = res;

        if (this.producerRecordCount <= 50) {
          this.getProducerDropdownList();
        } else {
          this.showDropdownField = true;
        }
        this.dynamicFormService.fieldRuleValidatorForAllFields();
      }
    }, error => {
      if (error.status === 500) {
        this.dynamicFormService.showAlert(error.error.message);
      }
      this.spinnerService.stop();
    });

    this.producerSearchValue = JSON.parse(this.dynamicFormService
      .getStoredData(NoticeGenerationConstants.producerSearchBy.producerSearchTerm));
    this.isNoticeGenerated = this.dynamicFormService.getNoticeStatus();
    this.lastFormIndex = this.dynamicFormService.getLastFormIndex();
    this.currentSectionId = sessionStorage.getItem(this.dynamicFormService.getCurrentFormSectionIdKey());
  }

  ngAfterViewInit() {
    this.producerCopy = this.data.form.get(NoticeGenerationConstants.producerForm.producerCopies).value
      ? this.data.form.get(NoticeGenerationConstants.producerForm.producerCopies).value : '';
    this.producerMailType = this.data.form.get(NoticeGenerationConstants.producerForm.producerMailType).value
      ? this.data.form.get(NoticeGenerationConstants.producerForm.producerMailType).value : '';
    this.uspsValue = this.data.form.get(NoticeGenerationConstants.producerForm.fill3817Producer).value
      ? this.data.form.get(NoticeGenerationConstants.producerForm.fill3817Producer).value : false;
    this.data.options.resetModel();
    this.data.form.get(NoticeGenerationConstants.producerForm.producerCopies).setValue(this.producerCopy);
    this.data.form.get(NoticeGenerationConstants.producerForm.producerMailType).setValue(this.producerMailType);
    this.data.form.get(NoticeGenerationConstants.producerForm.fill3817Producer).setValue(this.uspsValue);
    if (this.data.form.get(NoticeGenerationConstants.producerForm.producerId)) {
      this.data.form.get(NoticeGenerationConstants.producerForm.producerId).setValue(null);
    }

    if (this.sectionFormData) {
      this.dynamicFormService.prefillFormData(this.data.form, this.sectionFormData);
    }

    if (this.producerSearchValue) {
      this.producerSearchForm.get(NoticeGenerationConstants.producerSearchBy.producerSearchTerm).setValue(this.producerSearchValue);
    }
    this.dynamicFormService.scrollToTop();
  }
  generateNotice(form: FormGroup) {
    if (this.data.form.valid) {
      this.addProducerFormData(form);
      this.dynamicFormService.noticeFieldData(this.sectionName, form);
    }
    if (this.dynamicFormService.checkRequiredSectionDataAvailable(this.data)) {
      this.dynamicFormService.generateNoticeData(this.sectionName, form);
    }
  }
  getDefaultValues(data, keys) {
    const field = data.filter(d => d.key === keys);
    return field[0].defaultValue;
  }

  search = (text$: Observable<string>) => {
    return text$.pipe(
      debounceTime(NoticeGenerationConstants.producerForm.debounceTime),
      distinctUntilChanged(),
      switchMap(term => {
        term = term.trim();
        return this.getData(term);
      }),
    );
  }

  getData(term) {
    const result = this.getAutoSearchList(term);
    result.subscribe((data) => {
      if (data.indexOf(NoticeGenerationConstants.producerForm.noMatch) > 1) {
        return;
      }
    });
    return result;
  }

  getAutoSearchList(term): Observable<any> {
    const searchBy = this.searchProducerBy === NoticeGenerationConstants.producerForm.producerName ?
      NoticeGenerationConstants.producerSearchBy.name : NoticeGenerationConstants.producerSearchBy.code;
    if (term && term.length > NoticeGenerationConstants.producerForm.minimumTermLength) {
      return this.http.get<any>(NoticeGenerationConstants.webApis.producerCode + `&${searchBy}=${term}`).pipe(map(result =>
        this.handledata(result.paginationData)
      ));
    } else {
      return of([]);
    }
  }

  handledata(response) {
    const autoSuggestList = [];
    if (response && response.length > 0) {
      this.addProducerId = response[0].printProducerCode;
      response.forEach(element => {
        autoSuggestList.push(element);
      });
    } else {
      autoSuggestList.push(NoticeGenerationConstants.producerForm.noMatch);
    }
    return autoSuggestList;
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  onSubmit(form) {
    this.validateAllFormFields(form);
    if (this.data.form.valid) {
      this.addProducerFormData(form);
      this.sectionIdEventEmitter.emit(this.data.sectionId);
    }
  }

  addProducerFormData(form) {
    this.validateAllFormFields(form);
    this.dynamicFormsComponent.isvisitedSection[this.currentSectionId] = true;
    this.producerSearchForm.controls.producerSearchTerm.markAsTouched();
    this.dynamicFormsComponent.isPageValid = false;
    const formName = this.dynamicFormService.getCurrentFormName();
    const presentSections = this.dynamicFormService.getSectionsForCurrentForm(formName);
    if (this.data.form.valid) {
      if (!presentSections.includes(this.sectionName)) {
        this.dynamicFormService.addSection(this.sectionName);
      }
      this.isGreenChecked();
      if (this.dynamicFormsComponent.isPageValid) {
        this.dynamicFormService.noticeFieldData(this.sectionName, form);
      }
      else {
        const updatedData = [];
        let formData = [];
        let iterator = 0;
        const noticeData = (sessionStorage.noticeData && JSON.parse(sessionStorage.noticeData)) ?
        JSON.parse(sessionStorage.noticeData) : [];

        if (noticeData && noticeData.length) {
          for (const i of noticeData) {
            if (i && i.name === formName) {
              formData = i.formData;
              const data = i.components;
              data.forEach(element => {
                if (element.name !== this.sectionName) {
                  updatedData.push(element);
                }
              });
              break;
            }
            iterator++;
          }
        }
        this.dynamicFormService.pushDataToNoticeData(updatedData, formData);
        // this.dynamicFormService.removeSection(this.sectionName);
      }
      this.saveFormData();
    }
  }

  isGreenChecked() {
    const fieldArr = [];
    let defaultFields = false;
    this.data.fields.forEach(ele => {
      if (ele.key) {
        for (const i in this.data.model) {
          if (ele.key === i) {
            fieldArr.push({ name: i, value: `${this.data.model[i]}` });
            const temp = `${this.data.model[i]}`;
            defaultFields = (ele.key.includes(NoticeGenerationConstants.mailType || NoticeGenerationConstants.copies
              || NoticeGenerationConstants.producerForm.fill3817Producer)) ? true : false;
            if (((ele.key === NoticeGenerationConstants.producerForm.fill3817Producer) &&
              (temp !== this.data.form.get(NoticeGenerationConstants.producerForm.fill3817Producer).value)) ||
              ((ele.key === NoticeGenerationConstants.producerForm.producerCopies) &&
                (temp !== this.data.form.get(NoticeGenerationConstants.producerForm.producerCopies).value)) ||
              ((ele.key === NoticeGenerationConstants.producerForm.producerMailType) &&
                (temp !== this.data.form.get(NoticeGenerationConstants.producerForm.producerMailType).value))) {
              this.dynamicFormsComponent.isPageValid = true;
              this.dynamicFormsComponent.isSectionValid = true;
            }
            else {

              if (!defaultFields && temp && temp !== 'null' && temp !== 'false') {
                this.dynamicFormsComponent.isPageValid = true;
                this.dynamicFormsComponent.isSectionValid = true;
                break;
              }
            }
          }
        }
      }
    });
  }
  onProductSelectChange(producer, isDropdownSelect = false) {
    let producerData;
    if (isDropdownSelect) {
      producerData = producer;
    } else {
      producerData = producer['item'];
    }
    if (producerData && producerData !== NoticeGenerationConstants.producerForm.noMatch) {
      this.data.form.patchValue({
        'PPostalCode': producerData.postalCode,
        'ProducerAddr1': producerData.address1,
        'ProducerAddr2': producerData.address2,
        'ProducerCity': producerData.city,
        'ProducerStateProv': isDropdownSelect ? producerData.stateProvidence : producerData.stateProvince,
        'ProducerName': producerData.name + (this.addProducerId ? ' ' + producerData.code.trim() : '')
      });
      this.data.form.get(NoticeGenerationConstants.producerForm.producerId).setValue(producerData.id);
    } else if (producerData && producerData === NoticeGenerationConstants.producerForm.noMatch) {
      setTimeout(() => {
        this.producerSearchForm.get(NoticeGenerationConstants.producerSearchBy.producerSearchTerm).setValue('');
      }, 10);
    }
  }

  formatProducerResults = (value) => {
    if (value) {
      return this.dynamicFormService.formatProducerResult(value, this.addProducerId);
    }
  }

  formatProducerInput = (value) => {
    if (value) {
      return this.dynamicFormService.formatProducerInput(value);
    }
  }

  resetProducerForm() {
    this.data.form.reset();
    this.producerSearchForm.get(NoticeGenerationConstants.producerSearchBy.producerSearchTerm).setValue('');
    this.data.form.get(NoticeGenerationConstants.producerForm.producerCopies).setValue(this.producerCopy);
    this.data.form.get(NoticeGenerationConstants.producerForm.producerMailType).setValue(this.producerMailType);
    this.data.form.get(NoticeGenerationConstants.producerForm.fill3817Producer).setValue(this.uspsValue);
    this.data.form.get(NoticeGenerationConstants.producerForm.producerId).setValue(null);
    this.producerSearchForm.markAsPristine();
    this.producerSearchForm.markAsUntouched();
    this.dynamicFormsComponent.isPageValid = false;
    this.selectedProducer = null;
    this.saveFormData();
  }

  resetProducerField() {
    this.producerSearchForm.get(NoticeGenerationConstants.producerSearchBy.producerSearchTerm).setValue('');
    this.producerSearchForm.markAsPristine();
    this.producerSearchForm.markAsUntouched();
  }

  moveToCriteriaSelection(form: FormGroup) {
    this.popupService.showConfirmation({
      title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
      message: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.back_on_criteria_Selection'),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button')
    })
      .pipe(take(1)).subscribe(res => {
        if (res) {
          form.reset();
          sessionStorage.removeItem(NoticeGenerationConstants.insurerForm.serviceCenterData);
          this.dynamicFormsComponent.noticeData = [];
          this.dynamicFormService.previousPolicyNumber = null;
          this.dynamicFormService.isNoticeRegenerated = false;
          this.isVisitedFirst = false;
          this.router.navigate([AppConstants.uiRoutes.noticeGeneration +
            NoticeGenerationConstants.routeSeparator +
            AppConstants.uiRoutes.criteriaSelection]);
        } else {
          window.scrollTo(0, 0);
        }
      });
  }

  saveFormData() {
    if (this.producerSearchForm) {
      const value = this.producerSearchForm.get(NoticeGenerationConstants.producerSearchBy.producerSearchTerm).value;
      this.dynamicFormService.setStoreData(NoticeGenerationConstants.producerSearchBy.producerSearchTerm, value);
    }
    this.dynamicFormService.saveSectionFormData(this.sectionName, this.data.form.value);
  }

  onClickPrefillValidateForm() {
    this.validateAllFormFields(this.data.form);
    this.dynamicFormsComponent.isSectionValid = false;
    this.dynamicFormsComponent.isPageValid = false;
    this.isGreenChecked();
    const formName = this.dynamicFormService.getCurrentFormName();
    const presentSections = this.dynamicFormService.getSectionsForCurrentForm(formName);
    if (this.data.form.valid) {
      this.dynamicFormsComponent.isSectionValid = true;
      this.dynamicFormService.isProducerFormValid = true;
      if (this.dynamicFormsComponent.isPageValid) {
        if (!presentSections.includes(this.sectionName)) {
          this.dynamicFormService.addSection(this.sectionName);
        }
        this.dynamicFormService.noticeFieldData(this.sectionName, this.data.form);
      } else {
        if (presentSections.includes(this.sectionName)) {
          this.dynamicFormService.removeSection(this.sectionName);
        }
      }
      if (this.dynamicFormsComponent.isAllRequiredVisited(this.dynamicFormService.navigationSectionIndex)) {
        this.dynamicFormService.SectionClicked(this.dynamicFormService.navigationSectionIndex);
      }
    }
    this.saveFormData();
  }

  isGenerateNoticeButtonEnable() {
    return this.dynamicFormService.isGenerateNoticeButtonEnable(this.data.form.valid);
  }

  getProducerDropdownList() {
    this.dynamicFormHttpService.getSectionFieldOptions(this.data.optionsUrl).subscribe(res => {
      if (res) {
        res.map(i => {
          i.producerLable =
            (this.searchProducerBy === 'ProducerCode' ? i.code + ' - ' : '')
            + i.name
            + (i.address1 ? ', ' : '')
            + i.address1
            + (i.address2 ? ', ' : '')
            + i.address2
            + (i.city ? ', ' : '')
            + i.city
            + (i.stateProvidence ? ', ' : '')
            + i.stateProvidence
            + (i.postalCode ? ', ' : '')
            + i.postalCode;
          return i;
        });
        this.producerDropdownList = res;
        this.producers = this.producerDropdownList;
        this.showDropdownField = true;
      }
    }, error => {
      if (error.status === 500) {
        this.dynamicFormService.showAlert(error.error.message);
      }
      this.spinnerService.stop();
    });
  }

  customSearchFn(event) {
    const data = this.producerDropdownList.filter(x => x.name.toLowerCase().startsWith(event.term.toLowerCase()));
    this.producers = event.term ? data : this.producerDropdownList;
  }

  setdropdownData() {
    this.producers = this.producerDropdownList;
  }
}
