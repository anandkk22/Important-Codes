import { AfterViewInit, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { InsurerDetails } from 'app/notice-generation/infrastructure/interface/insurerDetails.interface';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormHttpService } from 'app/notice-generation/service/dynamic-form-http.service';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { FormlyFormOptions } from '@ngx-formly/core';
import { AppConstants } from 'app/app.constants';
import { ActivatedRoute } from '@angular/router';
import { NgSelectComponent } from '@ng-select/ng-select';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'add-edit-form',
  templateUrl: './add-edit-form.component.html',
  styleUrls: ['./add-edit-form.component.scss']
})
export class AddEditFormComponent implements OnInit, AfterViewInit, OnDestroy {
  selectedDropdownData = null;
  dropdownDeatils: InsurerDetails[];
  formIndexValue = 0;
  currentSection = {
    name: '',
    displayName: ''
  };
  showAddRadioButtonSection = false;
  addToSectionForm = this.formBuilder.group({
    addToNotice: 'onlyNotice',
  });
  valueAddedSectionData = [];
  addToMasterFilesAPICalls = [];
  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  currentSectionParam = {
    sectionName: null
  };
  index = 0;
  @Input() data: any;
  options: FormlyFormOptions = {};
  form = new FormGroup({});
  selectedLabel = null;
  isItalic = false;
  subscriptions: Subscription[] = [];
  isSupplementalForm: boolean;
  formModel: any;
  checkCancellationEffectiveDt = false;
  isLoading = false;
  currentSupplementalForm: any;
  @ViewChild('select') select: NgSelectComponent;
  constructor(
    private popupService: PopupService,
    private translate: TranslateService,
    private dynamicFormHttpService: DynamicFormHttpService,
    private formBuilder: FormBuilder,
    private dynamicFormService: DynamicFormService,
    private spinnerService: SpinnerService,
    private route: ActivatedRoute,
    public activeModal: NgbActiveModal
    ) {  }
  resData;
  popUpSubscription: Subscription;
  showPopUp = false;
  previousDate: any;
  valueChanged = false;
  ngOnInit(): void {
    this.isLoading = true;
    this.route.queryParams.subscribe(params => {
      this.isSupplementalForm = Boolean(params['supplementalForm']);
    });
    if (this.isSupplementalForm) {
      this.route.queryParams.subscribe(params => {
        this.currentSupplementalForm = params[NoticeGenerationConstants.formCode];
      });
      if (this.data) {
        this.data.formDataObject = this.data?.formDataObject?.filter(
          (x) => x.name === this.currentSupplementalForm);
        this.currentSection.name =  this.data.formDataObject[0].components[this.data.sectionId].name;
        this.currentSection.displayName = this.data.formDataObject[0].components[this.data.sectionId].displayName;
        this.currentSectionParam.sectionName = this.currentSection.displayName;
      }
    }
    else {
      this.currentSection.name = this.data.formDataObject[this.formIndexValue].components[this.data.sectionId].name;
      this.currentSection.displayName = this.data.formDataObject[this.formIndexValue].components[this.data.sectionId].displayName;
      this.currentSectionParam.sectionName = this.currentSection.displayName;
    }

    this.dynamicFormHttpService.getSectionFieldOptions(this.data.optionsUrl).subscribe((res) => {
      if (res) {
        this.isLoading = false;
        this.dropdownDeatils = res;
        this.resData = this.dropdownDeatils;
        if (this.dropdownDeatils && this.dropdownDeatils.length > 0) {
          this.dropdownDeatils.sort(this.dynamicFormService.sortDropdownData('name'));
        }
      }
    }, error => {
      if (error.status === 500) {
        this.dynamicFormService.showAlert(error.error.message);
      }
      this.spinnerService.stop();
    });
    this.selectedLabel = this.getLabel(null);
    this.formModel = JSON.parse(this.dynamicFormService.getStoredData(NoticeGenerationConstants.criteriaSelectionData));

  }

  ngAfterViewInit() {
    const idFieldKey = this.dynamicFormService.getIdFieldKey(this.currentSection.name);
    if (idFieldKey !== '' && idFieldKey !== null) {
      this.data.form.get(idFieldKey)?.setValue(null);
    }

    if (this.data.isEdit) {
      this.prefillFormData();
      this.data.form.enable();
    } else {
      this.reset();
      this.data.form.disable();
      this.setEffectiveDateTime(this.currentSection.name);
    }
    this.dynamicFormService.fieldRuleValidatorForAllFields();
    setTimeout(() => {
      this.showPopUp = true;
    }, 100);
    this.dynamicFormService.onEffectiveDateChange(this.showCancellationDateWarning.bind(this));

  }

  getName() {
    return this.translate.instant('NOTICE_GEN_TAB.COMMON_SECTION.add_to_masterfile', { sectionName: `${this.currentSectionParam.sectionName.toString()}` });
  }

  prefillFormData() {
    for (const key in this.data.editRecord) {
      if (this.data.editRecord.hasOwnProperty(key)) {
        this.data.form.get(key)?.setValue(this.data.editRecord[key]);
      }
    }
  }

  onDropdownDetailsChange(data: any, select?: NgSelectComponent) {
    this.checkCancellationEffectiveDt = false;
    this.selectedDropdownData = (data === 'newEntry') ? data : data?.id;
    this.selectedLabel = this.getLabel(data);
    if (this.selectedDropdownData === 'newEntry') {
      this.reset();
      select.clearModel();
      this.selectedDropdownData = 'newEntry';
      this.showAddRadioButtonSection = true;
      this.addToSectionForm.get('addToNotice')?.setValue('onlyNotice');
      select.close();
    } else {
      this.showAddRadioButtonSection = false;
    }
    this.data.form.enable();

    this.dropdownDeatils.forEach(element => {
      if (Number(this.selectedDropdownData) === element.id) {
        this.setAdminData(element);
      }
    });
    this.setEffectiveDateTime(this.currentSection.name);
  }

  addToNotice(isSaveClicked) {
    const allRecords = [...this.data.tableData, ...this.valueAddedSectionData];
    const fieldNames = this.dynamicFormService.getTypeAndFields(this.currentSection.name).fieldNames;
    const checkRecord = this.data.form.value;

    const effectiveDate = this.data.form.get(NoticeGenerationConstants.fieldNames.mortgagee.effectiveDate)?.value;
    const isDateInValid = this.dynamicFormService.isDateValid(effectiveDate);
    if (this.data.form.valid) {
      const showDaysNoticeWarning = (effectiveDate === undefined || effectiveDate === null)
        ? false : this.getMinDaysDetails(effectiveDate);
      if (showDaysNoticeWarning) {
        this.showPopUp = false;
        this.subscriptions.push(
          this.popupService.showConfirmation({
            title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
            message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.lookup_days_warning_pre') +
              this.getPolicyEffectiveDateDetails().minDays +
              this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.lookup_days_warning_post'),
            positiveLabel: this.translate.instant('BUTTON.ok_button'),
            negativeLabel: this.translate.instant('BUTTON.cancel_button')
          })
            .pipe(take(1)).subscribe(res => {
              if (!res) {
                const formData = this.data.form.value;
                if (this.currentSection.name === NoticeGenerationConstants.mortgageeText) {
                  formData.isIgnored = true;
                  formData.invalidCurrentDate = isDateInValid ? true : false;
                  formData.inValidCurrentAndDayNoticeDate = isDateInValid ? true : false;
                }
                this.valueAddedSectionData.push(formData);
                if (this.addToSectionForm.get('addToNotice').value === 'masterFile') {
                  const masterData = this.data.form.value;
                  if (this.currentSection.name === NoticeGenerationConstants.mortgageeText) {
                    masterData.isIgnored = true;
                    masterData.invalidCurrentDate = isDateInValid ? true : false;
                    masterData.inValidCurrentAndDayNoticeDate = isDateInValid ? true : false;
                  }
                  this.addToMasterFilesAPICalls.push(masterData);
                }

                if (isSaveClicked) {
                  this.saveToNotice();
                } else {
                  this.select.clearModel();
                  this.reset();
                  this.showAddRadioButtonSection = false;
                }
              } else {
                this.showPopUp = false;
              }
            })
        );
      } else {
        const formValue = this.data.form.value;
        if (this.currentSection.name === NoticeGenerationConstants.mortgageeText &&
          formValue.hasOwnProperty(NoticeGenerationConstants.cnrCRDeclEffectDt) &&
          formValue.CNNRCRDeclEffectDt === null) {
          formValue.isIgnored = true;
          formValue.invalidCurrentDate = isDateInValid ? true : false;
          formValue.inValidCurrentAndDayNoticeDate = false;
        }
        this.valueAddedSectionData.push(formValue);
        if (this.addToSectionForm.get('addToNotice').value === 'masterFile') {
          const masterData = this.data.form.value;
          if (this.currentSection.name === NoticeGenerationConstants.mortgageeText &&
            masterData.hasOwnProperty(NoticeGenerationConstants.cnrCRDeclEffectDt) &&
            masterData.CNNRCRDeclEffectDt === null) {
            masterData.isIgnored = true;
            masterData.invalidCurrentDate = isDateInValid ? true : false;
            masterData.inValidCurrentAndDayNoticeDate = false;
          }
          this.addToMasterFilesAPICalls.push(masterData);
        }
        if (isSaveClicked) {
          this.saveToNotice();
        } else {
          this.select.clearModel();
          this.reset();
          this.showAddRadioButtonSection = false;
        }
      }
    } else {
      this.markAllFieldsAsTouched(this.data.form);
    }
    document.getElementById('modal-popup-scroll').scrollIntoView();
    this.selectedLabel = this.translate.instant('NOTICE_GEN_TAB.COMMON_SECTION.add_new_select', { sectionName: `${this.currentSectionParam.sectionName.toString()}` });
  }

  save() {
    this.showPopUp = false;
    this.dynamicFormService.clearMortgageeIgnoreData();
    if (!this.data.isEdit) {
      if (this.data.form.disabled) {
        this.saveToNotice();
      } else {
        this.addToNotice(true);
      }
    } else {
      if (this.data.form.valid) {
        const tableRecords = [];
        this.data.tableData.forEach((item, index) => {
          if (index !== this.data.recordIndex) {
            tableRecords.push(item);
          }
        });
        const allRecords = [...tableRecords, ...this.valueAddedSectionData];
        const checkRecord = this.data.form.value;

        const effectiveDate = this.data.form.get(NoticeGenerationConstants.fieldNames.mortgagee.effectiveDate)?.value;
        if (this.data.form.valid) {
          if (this.dynamicFormService.isDateValid(effectiveDate)) {
            this.subscriptions.push(
              this.popupService.showConfirmation({
                title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
                message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.non_compliance_warning'),
                positiveLabel: this.translate.instant('BUTTON.ok_button'),
                negativeLabel: this.translate.instant('BUTTON.cancel_button')
              })
                .pipe(take(1)).subscribe(res => {
                  if (!res) {
                    const userResponse = {
                      isRemove: false,
                      index: this.data.recordIndex,
                      data: this.data.form.value
                    };
                    this.reset();
                    this.sendDataToParent(userResponse);
                  } else {
                    this.showPopUp = true;
                  }
                })
            );
          } else {
            const userResponse = {
              isRemove: false,
              index: this.data.recordIndex,
              data: this.data.form.value
            };
            this.reset();
            this.sendDataToParent(userResponse);
          }
        } else {
          this.markAllFieldsAsTouched(this.data.form);
        }
      }
    }
    this.selectedLabel = this.translate.instant('NOTICE_GEN_TAB.COMMON_SECTION.add_new_select', { sectionName: `${this.currentSectionParam.sectionName.toString()}` });
  }

  reset() {
    if (this.data.isEdit) {
      this.showPopUp = false;
    }
    this.data.form.reset();
    this.dynamicFormService.setPremiumAdjDefaultValues(this.data.form, this.data.fields);
    this.selectedDropdownData = null;
    const idFieldKey = this.dynamicFormService.getIdFieldKey(this.currentSection.name);
    if (idFieldKey !== '' && idFieldKey !== null) {
      this.data.form.get(idFieldKey)?.setValue(null);
    }
    this.setEffectiveDateTime(this.currentSection.name);
    this.dynamicFormService.fieldRuleValidatorForAllFields();
    this.data.form.disable();
  }

  onCancel() {
    this.showPopUp = false;
    this.reset();
    this.valueAddedSectionData = [];
    this.addToMasterFilesAPICalls = [];
    this.activeModal.close(null);
  }

  deleteFromAddecSection(row, index) {
    if (index >= 0) {
      this.valueAddedSectionData.splice(index, 1);
    }
  }

  setAdminData(value) {
    this.reset();
    this.data.form.enable();
    this.selectedDropdownData = value.id;

    const fieldNames = this.dynamicFormService.getTypeAndFields(this.currentSection.name).fieldNames;
    this.data.form.get(fieldNames.id)?.setValue(value.id);
    this.data.form.get(fieldNames.name)?.setValue(value.name);
    this.data.form.get(fieldNames.addr1)?.setValue(value.address1);
    this.data.form.get(fieldNames.addr2)?.setValue(value.address2);
    this.data.form.get(fieldNames.city)?.setValue(value.city);
    this.data.form.get(fieldNames.state)?.setValue(value.stateProvidence);
    this.data.form.get(fieldNames.postalCode)?.setValue(value.postalCode);

  }

  markAllFieldsAsTouched(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.markAllFieldsAsTouched(control);
      }
    });
  }

  removeRecordFromNotice() {
    if (this.data.recordIndex >= 0) {
      this.subscriptions.push(
        this.popupService.showConfirmation({
          title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
          message: this.translate.instant('NOTICE_GEN_TAB.COMMON_SECTION.remove_record') +
            this.currentSection.displayName.toLowerCase() + this.translate.instant('?'),
          positiveLabel: this.translate.instant('BUTTON.confirm_button'),
          negativeLabel: this.translate.instant('BUTTON.cancel_button')
        })
          .pipe(take(1)).subscribe(res => {
            if (res) {
              const userReponse = {
                isRemove: true,
                index: this.data.recordIndex,
                data: null
              };
              this.data.isEdit = false;
              this.reset();
              this.sendDataToParent(userReponse);
            }
          })
      );
    }
  }

  saveToMasterFile() {
    const addToMasterData = [];
    const typeFields = this.dynamicFormService.getTypeAndFields(this.currentSection.name);
    this.addToMasterFilesAPICalls.forEach(element => {
      const param = {
        name: element[typeFields.fieldNames.name],
        address1: element[typeFields.fieldNames.addr1],
        address2: element[typeFields.fieldNames.addr2],
        city: element[typeFields.fieldNames.city],
        stateProvidence: element[typeFields.fieldNames.state],
        postalCode: element[typeFields.fieldNames.postalCode],
        type: typeFields.type
      };
      addToMasterData.push(param);
    });


    this.dynamicFormHttpService.addAdditionalPartiesRecords(addToMasterData)
    .subscribe(res => {
      this.select.clearModel();
      this.reset();
      this.showAddRadioButtonSection = false;
      const tableData = this.valueAddedSectionData;
      this.valueAddedSectionData = [];
      this.addToMasterFilesAPICalls = [];
      this.sendDataToParent(tableData);
    }, error => {
      if (error.status === 500) {
        this.dynamicFormService.showAlert(error.error.message);
      }
      this.spinnerService.stop();
    });
  }

  sendDataToParent(data: any) {
    const formData = { isDataSent: true, formData: data };
    this.activeModal.close(formData);
  }

  getLabel(data) {
    this.isItalic = data ? false : true;
    if (data === 'newEntry') {
      return this.translate.instant('NOTICE_GEN_TAB.COMMON_SECTION.add_new', { sectionName: `${this.currentSectionParam.sectionName.toString()}` });
    }
    return data ? data.name + ' ' + data.address1 + ', ' + data.address2 + ', ' + data.city + ', ' + data.stateProvidence + ' '
      + data.postalCode :
      this.translate.instant('NOTICE_GEN_TAB.COMMON_SECTION.add_new_select', { sectionName: `${this.currentSectionParam.sectionName.toString()}` });
  }

  ngOnDestroy() {
    this.dynamicFormService.clearFormData();
    this.subscriptions.forEach(sub => {
      sub.unsubscribe();
    });
    this.showPopUp = false;
  }
  setdropdownData() {
    this.dropdownDeatils = this.resData;
  }
  customSearchFn(event) {
    const data = event && this.resData.filter(x => x.name.toLowerCase().startsWith(event.term.toLowerCase()));
    this.dropdownDeatils = (event && event.term) ? data : this.resData;
    if (!event) {
      this.selectedLabel = this.translate.instant('NOTICE_GEN_TAB.COMMON_SECTION.add_new_select', { sectionName: `${this.currentSectionParam.sectionName.toString()}` });
      this.reset();
      this.data.form.disable();
    }
  }
  setEffectiveDateTime(sectionName: any) {
    if (sectionName.includes(NoticeGenerationConstants.sectionNames.mortgagee)) {
      const fieldNames = this.dynamicFormService.getTypeAndFields(sectionName).fieldNames;
      const policyData = this.dynamicFormService.getPolicyDetails();
      if (policyData && policyData.hasOwnProperty(NoticeGenerationConstants.transactionDateKey)
        && policyData.hasOwnProperty(NoticeGenerationConstants.transactionTimeKey)) {
        const transactionTime = this.dynamicFormService.getTansactionTime(policyData.transactionTime[0].value);
        this.data.form.get(fieldNames.effectiveDate)?.setValue(policyData.transactionDate[0].value);
        this.data.form.get(fieldNames.effectiveTime)?.setValue(transactionTime);
      }
    }
  }

  getPolicyEffectiveDateDetails() {
    return this.dynamicFormService.getPolicyEffectiveDateDetails();
  }

  getMinDaysDetails(effectiveDate: any) {
    return this.dynamicFormService.getMinDaysDetails(this.formModel, effectiveDate);
  }

  checkPreviousEffectiveDate(effectiveDate) {
    let isEffectiveDtChanged = true;
    if (!this.previousDate) {
      isEffectiveDtChanged = true;
    }
    else if (this.previousDate !== effectiveDate) {
      isEffectiveDtChanged = true;
    } else {
      isEffectiveDtChanged = false;
    }
    return isEffectiveDtChanged;
  }

  showCancellationDateWarning(effectiveDate) {
    this.valueChanged = this.checkPreviousEffectiveDate(effectiveDate);
    if (effectiveDate && effectiveDate !== undefined && this.showPopUp && this.valueChanged
       && document.activeElement.id !== NoticeGenerationConstants.saveButtonId &&
       document.activeElement.id !== NoticeGenerationConstants.cancelButtonId) {
      const showDaysNoticeWarning = this.getMinDaysDetails(effectiveDate);
      this.previousDate = effectiveDate;
      if (showDaysNoticeWarning) {
        this.popUpSubscription = this.popupService.showConfirmation({
          title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
          message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.lookup_days_warning_pre') +
            this.getPolicyEffectiveDateDetails().minDays +
            this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.lookup_days_warning_post'),
          positiveLabel: this.translate.instant('BUTTON.ok_button'),
          negativeLabel: this.translate.instant('BUTTON.cancel_button')
        })
          .pipe(take(1)).subscribe((res: any) => {
            this.popUpSubscription.unsubscribe();
            if (res) {
              this.showPopUp = true;
            }
          });
      }
    }
  }

 /*
 // This is for future reference code related to Mortgagee non compliance warnings popups
 onFormChange() {
    this.checkCancellationEffectiveDt = true;
  }

  onFormFocusOut(formData) {
    this.listenToEffectiveDtChange(formData.get(NoticeGenerationConstants.fieldNames.mortgagee.effectiveDate).value);
  }

  listenToEffectiveDtChange(effectiveDate) {
    this.data?.form?.get(NoticeGenerationConstants.fieldNames.mortgagee.effectiveDate)?.valueChanges.subscribe((selectedValue: any) => {
      if (this.checkCancellationEffectiveDt && this.currentSection.name.includes(NoticeGenerationConstants.mortgageeText)) {
        if (selectedValue && selectedValue !== undefined && selectedValue !== effectiveDate)  {
            this.showCancellationDateWarning(effectiveDate);
        }
      }
    });
  } */

  saveToNotice() {
    if (this.addToMasterFilesAPICalls.length !== 0) {
      this.saveToMasterFile();
    } else {
      this.select.clearModel();
      this.reset();
      this.showAddRadioButtonSection = false;
      const res = this.valueAddedSectionData;
      this.valueAddedSectionData = [];
      this.sendDataToParent(res);
    }
  }
}
