import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { FormlyFormOptions } from '@ngx-formly/core';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { AppConstants } from 'app/app.constants';
import { InsurerDetails } from 'app/notice-generation/infrastructure/interface/insurerDetails.interface';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormHttpService } from 'app/notice-generation/service/dynamic-form-http.service';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import {  take } from 'rxjs/operators';
import { DynamicFormsComponent } from '../dynamic-forms/dynamic-forms.component';

@Component({
  selector: 'app-insurer-section-form',
  templateUrl: './insurer-section-form.component.html',
  styleUrls: ['./insurer-section-form.component.scss']
})
export class InsurerSectionFormComponent implements OnInit, AfterViewInit {
  @Input() data;
  @Output() sectionIdEventEmitter = new EventEmitter<number>();
  insurerDeatils: InsurerDetails[];
  showFont = true;
  selectedInsurer: InsurerDetails = NoticeGenerationConstants.resetInsurer;
  selectedServiceCenter: InsurerDetails;
  formModel = {};
  insurerData = null;
  sectionName: string;
  formIndexValue = 0;
  sectionForm = new FormGroup({});
  sectionFormData;
  isNoticeGenerated: boolean;
  lastFormIndex = 0;
  currentSectionId: string;
  isUseServiceCenterAddress = false;
  isVisitedFirst = false;
  options: FormlyFormOptions = {};

  constructor(
    private _dynamicFormService: DynamicFormService,
    private dynamicFormHttpService: DynamicFormHttpService,
    private popupService: PopupService,
    private translate: TranslateService,
    private router: Router,
    private dynamicFormsComponent: DynamicFormsComponent,
    private spinnerService: SpinnerService
  ) {
    this._dynamicFormService.componentMethodCalled$.subscribe(
      (res: any) => {

        if (Number(res.requested) === Number(this.data.sectionId) || Number(res.current) === Number(this.data.sectionId)) {
          if (Number(res.requested) === Number(this.data.sectionId) && !this.isVisitedFirst) {
            if (this.data && this.data?.form) {
              this.data?.form?.resetAll();
            }
            this.isVisitedFirst = true;
          }
          this.onClickPrefillValidateForm();
        }

      }
    );
  }

  ngOnInit(): void {
    this._dynamicFormService.saveSectionId(this.data.sectionId);
    this.sectionName = this.data.sectionName;
    this.data.form = this.sectionForm;
    this.data.options = this.options;
    this._dynamicFormService.onUseServiceCenterChange(this.onUseServiceCenterAddressChange.bind(this));
    this.sectionFormData = this._dynamicFormService.getSectionFormData(this.sectionName);

    this.dynamicFormHttpService.getSectionFieldOptions(this.data.optionsUrl).subscribe((res: InsurerDetails[]) => {
      if (res) {
        this.insurerDeatils = res;
        if (this.insurerDeatils && this.insurerDeatils.length > 0) {
          this.insurerDeatils.sort(this._dynamicFormService.sortDropdownData('name'));
        }
        if (this.sectionFormData) {
          this.insurerData = this.sectionFormData[NoticeGenerationConstants.insurerForm.insurerId];
          this.insurerDeatils.forEach(element => {
            if (Number(this.insurerData) === element.id) {
              this.selectedInsurer = element;
              this._dynamicFormService.insurerSelectedValues = element;
            }
          });
          this.isUseServiceCenterAddress = this.sectionFormData[NoticeGenerationConstants.insurerForm.useServiceCenterAddress];
        }
      }
    }, error => {
      if (error.status === 500) {
        this._dynamicFormService.showAlert(error.error.message);
      }
      this.spinnerService.stop();
    });

    this.isNoticeGenerated = this._dynamicFormService.getNoticeStatus();
    this.lastFormIndex = this._dynamicFormService.getLastFormIndex();
    this.currentSectionId = this._dynamicFormService.getStoredData(this._dynamicFormService.getCurrentFormSectionIdKey());
  }

  ngAfterViewInit() {
    this.data.form.reset();
    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerCopies).setValue(1);
    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerId).setValue(null);
    if (this.sectionFormData) {
      this._dynamicFormService.prefillFormData(this.data.form, this.sectionFormData);
    } else {
      this.isUseServiceCenterAddress = this._dynamicFormService.insurerUseServiceCenterAddressDefaultValue;
      if (this.isUseServiceCenterAddress) {
        this.onUseServiceCenterAddressChange();
      }
    }
    this._dynamicFormService.fieldRuleValidatorForAllFields();
    this._dynamicFormService.scrollToTop();
  }

  reset() {
    this.data.form.reset();
    this.selectedInsurer = NoticeGenerationConstants.resetInsurer;
    this._dynamicFormService.insurerSelectedValues = null;
    this.data.form.reset();
    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerCopies).setValue(1);
    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerId).setValue(null);
    this.insurerData = null;
    this.isUseServiceCenterAddress = this._dynamicFormService.insurerUseServiceCenterAddressDefaultValue;
    if (this.isUseServiceCenterAddress) {
      this.onUseServiceCenterAddressChange();
    }
    this._dynamicFormService.fieldRuleValidatorForAllFields();
    this.saveFormData();
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
        const control = formGroup.get(field);
        if (control instanceof FormControl) {
            control.markAsTouched({ onlySelf: true });
        } else if (control instanceof FormGroup) {
            this.validateAllFormFields(control);
        }
    });
  }
  generateNotice(form: FormGroup) {
    if (this._dynamicFormService.checkRequiredSectionDataAvailable(this.data)) {
      this.saveFormData();
      this._dynamicFormService.generateNoticeData(this.sectionName, form);
    }
  }
  onSubmit(form) {
    this.validateAllFormFields(form);
    this.dynamicFormsComponent.isvisitedSection[this.currentSectionId] = true;
    if (form.valid) {
      this.saveFormData();
      this.dynamicFormsComponent.isPageValid = true;
      this.dynamicFormsComponent.isSectionValid = true;
      this.dynamicFormsComponent.currentSection.push(3);
      this._dynamicFormService.noticeFieldData(this.sectionName, form);
      this.sectionIdEventEmitter.emit(this.data.sectionId);
    }
  }

  moveToCriteriaSelection(form: FormGroup) {
    this.popupService.showConfirmation({
      title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
      message: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.back_on_criteria_Selection'),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button')
    })
      .pipe(take(1)).subscribe(res => {
        if (res) {
          this._dynamicFormService.removeStoredData(NoticeGenerationConstants.insurerForm.serviceCenterData);
          this.dynamicFormsComponent.noticeData = [];
          this._dynamicFormService.previousPolicyNumber = null;
          this._dynamicFormService.isNoticeRegenerated = false;
          this. isVisitedFirst = false;
          this.router.navigate([AppConstants.uiRoutes.noticeGeneration +
            NoticeGenerationConstants.routeSeparator +
            AppConstants.uiRoutes.criteriaSelection]);
        } else {
          window.scrollTo(0, 0);
        }
      });
    }

  onInsurerDetailsChange() {
    this.insurerDeatils.forEach(element => {
      if (Number(this.insurerData) === element.id) {
        this.selectedInsurer = element;
        this._dynamicFormService.insurerSelectedValues = element;
      }
    });

    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerId).setValue(this.selectedInsurer.id);
    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerName).setValue(this.selectedInsurer.name);
    if (!this.isUseServiceCenterAddress) {
      this.setInsurerValue(this.selectedInsurer);
    }
    this.saveFormData();
  }

  onUseServiceCenterAddressChange() {
    this.selectedServiceCenter = this.getSelectedServiceCenter();
    if (this.isUseServiceCenterAddress) {
      this.setInsurerValue(this.selectedServiceCenter);
    } else {
      if (this.selectedInsurer.id) {
        this.data.form.get(NoticeGenerationConstants.insurerForm.insurerId).setValue(this.selectedInsurer.id);
        this.data.form.get(NoticeGenerationConstants.insurerForm.insurerName).setValue(this.selectedInsurer.name);
        this.setInsurerValue(this.selectedInsurer);
      } else {
        this.setInsurerValue(this.selectedInsurer);
      }
    }
    this.saveFormData();
  }

  setInsurerValue(value) {
    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerAddr1).setValue(value.address1);
    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerAddr2).setValue(value.address2);
    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerCity).setValue(value.city);
    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerStateProv).setValue(value.stateProvidence);
    this.data.form.get(NoticeGenerationConstants.insurerForm.insurerPostalCode).setValue(value.postalCode === '' ? null : value.postalCode);
    this._dynamicFormService.fieldRuleValidatorForAllFields();
  }

  getSelectedServiceCenter() {
    if (!sessionStorage.selectedServiceCenter) {
      this._dynamicFormService.serviceCenters.forEach(element => {
        if (Number(sessionStorage.serviceCenterData) === element.id) {
          this._dynamicFormService.setStoreData(NoticeGenerationConstants.insurerForm.selectedServiceCenter, element);
        }
      });
    }
    const value = JSON.parse(this._dynamicFormService.getStoredData(NoticeGenerationConstants.insurerForm.selectedServiceCenter));
    return value;
  }

  saveFormData() {
    const currentIName = this.data?.form.get(NoticeGenerationConstants.insurerForm.insurerName)?.value;
    if (currentIName === this.selectedInsurer.name) {
      this.data?.form.get(NoticeGenerationConstants.insurerForm.insurerId).setValue(
        this.selectedInsurer.id !== 0 ? this.selectedInsurer.id : null
        );
    }
    else {
      this.data?.form.get(NoticeGenerationConstants.insurerForm.insurerId).setValue(null);
    }
    const data = {
      ...this.data?.form.value,
      UseServiceCenterAddress: this.isUseServiceCenterAddress
    };

    this._dynamicFormService.setStoreData(NoticeGenerationConstants.insurerSelectedValues, this._dynamicFormService.insurerSelectedValues);
    this._dynamicFormService.saveSectionFormData(this.sectionName, data);
  }

  onClickPrefillValidateForm() {
      this.validateAllFormFields(this.data.form);
    if (this.data.form.valid) {
      this._dynamicFormService.noticeFieldData(this.sectionName, this.data.form);
      this.saveFormData();
      this.dynamicFormsComponent.isSectionValid = true;
      this.dynamicFormsComponent.isPageValid = true;
    }
    else {
      this.dynamicFormsComponent.isSectionValid = false;
    }
    }

  isGenerateNoticeButtonEnable() {
    return this._dynamicFormService.isGenerateNoticeButtonEnable(this.data.form.valid);
  }
}
