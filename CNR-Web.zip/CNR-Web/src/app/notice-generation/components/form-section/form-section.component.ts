import {
  AfterViewInit, ChangeDetectorRef,
  Component, EventEmitter, Input,
  OnDestroy,
  OnInit, Output
} from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { AppConstants } from 'app/app.constants';
import { InsurerDetails } from 'app/notice-generation/infrastructure/interface/insurerDetails.interface';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { take } from 'rxjs/operators';
import { DynamicFormsComponent } from '../dynamic-forms/dynamic-forms.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs/Subscription';
import { AddEditFormComponent } from '../add-edit-form/add-edit-form.component';

@Component({
  selector: 'app-form-section',
  templateUrl: './form-section.component.html',
  styleUrls: ['./form-section.component.scss']
})
export class FormSectionComponent implements OnInit, AfterViewInit, OnDestroy {
  @Input() data;
  @Output() sectionIdEventEmitter = new EventEmitter<number>();
  sectionForm = new FormGroup({});
  insurerDeatils: InsurerDetails[];
  showFont = true;
  selectedInsurer: InsurerDetails = NoticeGenerationConstants.resetInsurer;
  selectedServiceCenter: InsurerDetails;
  formModel = {};
  formIndexValue = 0;
  currentSection = {
    name: '',
    displayName: ''
  };
  tableData = [];
  currentSectionParam = {
    sectionName: null
  };
  winRef = null;
  sectionFormData;
  lastFormIndex = 0;
  isNoticeGenerated: boolean;
  currentSectionId: string;
  subscriptions: Subscription[] = [];
  isVisitedFirst = false;
  currentFormName: string;
  mainFormName: string;
  supplementalForm: string;
  constructor(
    private _dynamicFormService: DynamicFormService,
    private popupService: PopupService,
    private translate: TranslateService,
    private router: Router,
    private dynamicFormsComponent: DynamicFormsComponent,
    private spinnerService: SpinnerService,
    private cd: ChangeDetectorRef,
    private modalService: NgbModal
  ) {
    this.clearFormData();
    this._dynamicFormService.componentMethodCalled$.subscribe(
      (res: any) => {
        if (Number(res.requested) === Number(this.data.sectionId) || Number(res.current) === Number(this.data.sectionId)) {
          if (Number(res.requested) === Number(this.data.sectionId) && !this.isVisitedFirst) {
            if (this.data && this.data?.form) {
              this.data?.form?.resetAll();
            }
            this.tableData = [];
            this.isVisitedFirst = true;
          }
          this.onClickPrefillValidateForm();
        }
      }
    );
  }

  ngOnInit(): void {
    this._dynamicFormService.saveSectionId(this.data.sectionId);
    this.currentSection.name = this.data.sectionName;
    this.currentSection.displayName = this.data.displayName;
    this.currentSectionParam.sectionName = this.currentSection.displayName;
    this.sectionFormData = this._dynamicFormService.getSectionFormData(this.currentSection.name);
    if (this.sectionFormData) {
      this.tableData = this.sectionFormData;
    }
    this.lastFormIndex = this._dynamicFormService.getLastFormIndex();
    this.isNoticeGenerated = this._dynamicFormService.getNoticeStatus();
    this.currentSectionId = sessionStorage.getItem(this._dynamicFormService.getCurrentFormSectionIdKey());

    this.currentFormName = this._dynamicFormService.getCurrentFormName();
    this.mainFormName = sessionStorage.MainFormName;
    this.supplementalForm = sessionStorage.supplementalFormCode;
  }

  ngAfterViewInit() {
    this.data.options.resetModel();
    this._dynamicFormService.scrollToTop();
  }

  reset() {
    this.tableData = [];
    this.saveFormData();
    this.setAdditionalPartiesGreentick();
    this.cd.detectChanges();
    this._dynamicFormService.clickHiddenElement();
  }

  markAllFieldsAsTouched(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.markAllFieldsAsTouched(control);
      }
    });
  }

  onSubmit() {
    this.dynamicFormsComponent.isSectionValid = true;
    this.dynamicFormsComponent.isvisitedSection[this.currentSectionId] = true;
    if (this.tableData && this.tableData.length !== 0) {
      this.dynamicFormsComponent.isPageValid = true;
    }
    else {
      this.dynamicFormsComponent.isPageValid = false;
    }
    this._dynamicFormService.noticeFieldDataCommonComp(this.currentSection.name, this.tableData);
    this.saveFormData();
    this.sectionIdEventEmitter.emit(this.data.sectionId);
  }
  generateNotice() {
    this._dynamicFormService.noticeFieldDataCommonComp(this.currentSection.name, this.tableData);
    if (this._dynamicFormService.checkRequiredSectionDataAvailable(this.data)) {
      this._dynamicFormService.setNoticeStatus(true);
      this._dynamicFormService.generateNoticeData(this.currentSection.name, this.tableData);
    }
    this.saveFormData();
  }
  moveToCriteriaSelection(form: FormGroup) {
    this.subscriptions.push(
      this.popupService.showConfirmation({
        title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
        message: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.back_on_criteria_Selection'),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: this.translate.instant('BUTTON.cancel_button')
      })
        .pipe(take(1)).subscribe(res => {
          if (res) {
            form.reset();
            this.dynamicFormsComponent.noticeData = [];
            this._dynamicFormService.previousPolicyNumber = null;
            this._dynamicFormService.isNoticeRegenerated = false;
            this.isVisitedFirst = false;
            sessionStorage.removeItem(NoticeGenerationConstants.insurerForm.serviceCenterData);
            this.router.navigate([AppConstants.uiRoutes.noticeGeneration +
              NoticeGenerationConstants.routeSeparator +
              AppConstants.uiRoutes.criteriaSelection]);
          } else {
            window.scrollTo(0, 0);
          }
        })
    );
  }

  openAddEditModal() {
    const modalData = {
      model: this.data.model,
      fields: this._dynamicFormService.reOrderFieldSequence(this.data, this.formIndexValue),
      form: this.sectionForm,
      options: this.data.options,
      optionsUrl: this.data.optionsUrl,
      sectionId: this.data.sectionId,
      formDataObject: this.data.formDataObject,
      isEdit: false,
      editRecord: null,
      tableData: this.tableData
    };

    const modalRef = this.modalService.open(AddEditFormComponent);
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((userResponse) => {
      this.receiveAddFormDataFromParent(userResponse);
    });
  }

  deleteRecordFromNotice(row, index) {
    if (index >= 0) {
      this.subscriptions.push(
        this.popupService.showConfirmation({
          title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
          message: this.translate.instant('NOTICE_GEN_TAB.COMMON_SECTION.remove_record') +
            this.currentSection.displayName.toLowerCase() + this.translate.instant('?'),
            positiveLabel: this.translate.instant('BUTTON.confirm_button'),
          negativeLabel: this.translate.instant('BUTTON.cancel_button')
        })
          .pipe(take(1)).subscribe(res => {
            if (res) {
              this.tableData.splice(index, 1);
              this.setAdditionalPartiesGreentick();
              this.saveFormData();
              this.cd.detectChanges();
              this.subscriptions.forEach(sub => {
                sub.unsubscribe();
              });
              this._dynamicFormService.clickHiddenElement();
            }
          })
      );
    }
  }

  editRecord(row, index) {
    if (index >= 0) {
      const modalData = {
        model: this.data.model,
        fields: this._dynamicFormService.reOrderFieldSequence(this.data, this.formIndexValue),
        form: this.sectionForm,
        options: this.data.options,
        optionsUrl: this.data.optionsUrl,
        sectionId: this.data.sectionId,
        formDataObject: this.data.formDataObject,
        isEdit: true,
        editRecord: row,
        recordIndex: index,
        tableData: this.tableData
      };

      const modalRef = this.modalService.open(AddEditFormComponent);
      modalRef.componentInstance.data = modalData;
      modalRef.result.then((userResponse) => {
        this.receiveEditFormDataFromParent(userResponse);
      });
    }
  }

  manipulateWinFormData(data: any) {
    this.clearFormData();
    this._dynamicFormService.storeFormData(data);
  }

  clearFormData() {
    this._dynamicFormService.clearFormData();
  }

  receiveAddFormDataFromParent(event: any) {
    const response = event;
    if (response && response.isDataSent) {
      this.spinnerService.start();
      this.tableData = [...this.tableData, ...response.formData];
      this.saveFormData();
      this.setAdditionalPartiesGreentick();
      const showPopup = this.popupService.showAlert({
        title: this.translate.instant('MESSAGES.Confirmation.alertTitle'),
        message: this.currentSection.displayName + this.translate.instant('NOTICE_GEN_TAB.COMMON_SECTION.added_message'),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: ''
      }) .pipe(take(1)).subscribe((res: any) => {
        showPopup.unsubscribe();
       });
      const formName = this._dynamicFormService.getCurrentFormName();
      const  presentSections = this._dynamicFormService.getSectionsForCurrentForm(formName);
      if (this.tableData && this.tableData.length) {
        if (!presentSections.includes(this.currentSection.name))  {
           this._dynamicFormService.addSection(this.currentSection.name);
      } }
      else {
        this._dynamicFormService.removeSection(this.currentSection.name);
      }
      this.saveFormData();
      this.cd.detectChanges();
      this.spinnerService.stop();
      this._dynamicFormService.clickHiddenElement();
    }
  }

  receiveEditFormDataFromParent(event: any) {
    const response = event;
    if (response && response.isDataSent) {
      this.spinnerService.start();
      if (response.formData.isRemove) {
        this.tableData.splice(response.formData.index, 1);
      } else {
        this.tableData[response.formData.index] = response.formData.data;
        const showPopup = this.popupService.showAlert({
          title: this.translate.instant('MESSAGES.Confirmation.alertTitle'),
          message: this.currentSection.displayName + this.translate.instant('NOTICE_GEN_TAB.COMMON_SECTION.update_message'),
          positiveLabel: this.translate.instant('BUTTON.ok_button'),
          negativeLabel: ''
        });
        this.subscriptions.push(
          showPopup.subscribe(res => {
            this.subscriptions.forEach(sub => {
              sub.unsubscribe();
            });
          })
        );
      }
      this.saveFormData();
      this.setAdditionalPartiesGreentick();
      this.cd.detectChanges();
      this.spinnerService.stop();
      this._dynamicFormService.clickHiddenElement();
    }
  }

  saveFormData() {
    this._dynamicFormService.saveSectionFormData(this.currentSection.name, this.tableData);
  }
  onClickPrefillValidateForm() {
      this.dynamicFormsComponent.isSectionValid = true;
      const formName = this._dynamicFormService.getCurrentFormName();
      const presentSections = this._dynamicFormService.getSectionsForCurrentForm(formName);
      if (this.tableData && this.tableData.length) {
        this.dynamicFormsComponent.isPageValid = true;
        if (!presentSections.includes(this.currentSection.name))  {
           this._dynamicFormService.addSection(this.currentSection.name);
      } }
      else {
       this._dynamicFormService.removeSection(this.currentSection.name);
        this.dynamicFormsComponent.isPageValid = false;
      }
      this._dynamicFormService.noticeFieldDataCommonComp(this.currentSection.name, this.tableData);
      this.saveFormData();
  }

  setAdditionalPartiesGreentick() {
    if (this.tableData && this.tableData.length > 0) {
      if (this.currentFormName === this.mainFormName) {
        if (!this.dynamicFormsComponent.previousSection.includes(this.currentSection.name)) {
          this.dynamicFormsComponent.previousSection.push(this.currentSection.name);
          this._dynamicFormService.setStoreData(NoticeGenerationConstants.previousVisitedSections,
            this.dynamicFormsComponent.previousSection);
        }
      } else if (this.currentFormName === this.supplementalForm) {
        if (!this.dynamicFormsComponent.supplemntalPreviousSection.includes(this.currentSection.name)) {
          this.dynamicFormsComponent.supplemntalPreviousSection.push(this.currentSection.name);
          const updatedData = [{ 'name': this.supplementalForm, 'visitedSections': this.dynamicFormsComponent.supplemntalPreviousSection }];
          this._dynamicFormService.setStoreData(NoticeGenerationConstants.supplemntalPreviousVisitedSections,
            updatedData);
        }
      }
    } else if (this.tableData && this.tableData.length === 0) {
      if (this.currentFormName === this.mainFormName) {
        const index = this.dynamicFormsComponent.previousSection.indexOf(this.currentSection.name);
        if (index !== -1) {
          this.dynamicFormsComponent.previousSection.splice(index, 1);
          this._dynamicFormService.setStoreData(NoticeGenerationConstants.previousVisitedSections,
            this.dynamicFormsComponent.previousSection);
        }
      } else if (this.currentFormName === this.supplementalForm) {
        const index = this.dynamicFormsComponent.supplemntalPreviousSection.indexOf(this.currentSection.name);
        if (index !== -1) {
          this.dynamicFormsComponent.supplemntalPreviousSection.splice(index, 1);
          const updatedData = [{ 'name': this.supplementalForm, 'visitedSections': this.dynamicFormsComponent.supplemntalPreviousSection }];
          this._dynamicFormService.setStoreData(NoticeGenerationConstants.supplemntalPreviousVisitedSections,
            updatedData);
        }
      }
    }
    this._dynamicFormService.clickHiddenElement();
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => {
      sub.unsubscribe();
    });
  }
}
