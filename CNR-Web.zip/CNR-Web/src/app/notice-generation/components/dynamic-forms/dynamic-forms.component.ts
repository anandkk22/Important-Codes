import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { select, Store } from '@ngrx/store';
import { FormlyFieldConfig, FormlyFormOptions } from '@ngx-formly/core';
import { DynamicFormHttpService } from 'app/notice-generation/service/dynamic-form-http.service';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { IFormSectionNames } from 'app/notice-generation/infrastructure/interface/formSectionNames.interface';
import { ISupplementalForm } from 'app/notice-generation/infrastructure/interface/supplementalForm.interface';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { filter, take } from 'rxjs/operators';
import { environment } from '@env';
import { AppConstants } from 'app/app.constants';
import { IFormSectionIsRequired } from 'app/notice-generation/infrastructure/interface/sectionIsRequired.interface';
import { saveAs } from 'file-saver';
@Component({
  selector: 'app-dynamic-forms',
  templateUrl: './dynamic-forms.component.html',
  styleUrls: ['./dynamic-forms.component.scss']
})
export class DynamicFormsComponent implements OnInit {

  defaultValue;
  form = new FormGroup({});
  formData;
  formModel: any = {};
  sectionIndex = 0;
  formIndex = 0;
  formFields: FormlyFieldConfig[] = [{}];
  formSectionNames: IFormSectionNames[] = [];
  supplimentalFormsNames: ISupplementalForm[] = [];
  sectionIsRequired: IFormSectionIsRequired[] = [];
  options: FormlyFormOptions = {};
  isDataAvailable = false;
  isLookupDataAvailable = false;
  result: any;
  formCode: '';
  serviceCenterData;
  documentLinks = [];
  formTitle = '';
  isServiceCenterValid = false;
  serviceCenter = false;
  selectServiceCenterLabel = 'Select Service Center';
  showFont = true;
  selectedServiceCenter = {};
  formSection: string = NoticeGenerationConstants.policyText;
  isPageValid = false;
  previousSection = [];
  sectionTitle = '';
  currentSection = [];
  generateNotice = false;
  noticeData = [];
  getSupplementalForm = false;
  helpForm: string;
  supplemntalPreviousSection = [];
  supplementalForm: string;
  supplementalFormCode;
  supplementalFormTitle: string;
  supplementalSectionNames: IFormSectionNames[] = [];
  serviceCenterValue = null;
  typistValue = null;
  currentSectionId: any;
  isSectionValid = false;
  isvisitedSection = [];
  nextRequiredSection: number;
  currentFormName: string;
  mainFormName: string;
  showFormSizeWarning = false;
  constructor(
    private _dynamicFormService: DynamicFormService,
    private store: Store<{ reducer }>,
    private route: ActivatedRoute,
    private router: Router,
    private dynamicFormHttpService: DynamicFormHttpService,
    private popupService: PopupService,
    private translate: TranslateService,
    private spinnerService: SpinnerService) {
    this.store.pipe(select('reducer')).subscribe((values) => {
      if (values) {
        this.formModel = values;
        this._dynamicFormService.setStoreData(NoticeGenerationConstants.criteriaSelectionData, this.formModel);
      }
    });

    if (!window.location.href.includes(AppConstants.uiRoutes.addEditForm) &&
      !window.location.href.includes(AppConstants.uiRoutes.lookupDate) &&
      !window.location.href.includes(AppConstants.uiRoutes.supplementalDynamicForm)) {
      this.router.events
        .pipe(filter((rs): rs is NavigationEnd => rs instanceof NavigationEnd))
        .subscribe(event => {
          if (
            event.id === 1 &&
            event.url === event.urlAfterRedirects
          ) {
            this.popupService.showConfirmation({
              title: NoticeGenerationConstants.refreshConfirmationPopup.confirm_title,
              message: NoticeGenerationConstants.refreshConfirmationPopup.back_on_criteria_Selection,
              positiveLabel: NoticeGenerationConstants.refreshConfirmationPopup.ok_button,
              negativeLabel: NoticeGenerationConstants.refreshConfirmationPopup.cancel_button
            })
              .pipe(take(1)).subscribe(res => {
                if (res) {
                  this.noticeData = [];
                  this.router.navigate([AppConstants.uiRoutes.noticeGeneration +
                    NoticeGenerationConstants.routeSeparator + AppConstants.uiRoutes.criteriaSelection]);
                } else {
                  this.formModel = JSON.parse(this._dynamicFormService.getStoredData(NoticeGenerationConstants.criteriaSelectionData));
                  this.sectionIndex = Number(this._dynamicFormService.getStoredData(this._dynamicFormService.getCurrentFormSectionIdKey()));
                  this._dynamicFormService.showLookupWarningPopup = false;
                  this._dynamicFormService.showDoubleWarningPoup = false;
                  this.ngOnInit();
                }
              });
          }
        });
  }
    this.route.queryParams.subscribe(params => {
      this.getSupplementalForm = Boolean(params['supplementalForm']);
      this._dynamicFormService.setToLocal(NoticeGenerationConstants.isSupplementalform, this._dynamicFormService.isSupplementalForm);
    });


    if (this.getSupplementalForm) {
      this.formModel = JSON.parse(this._dynamicFormService.getStoredData(NoticeGenerationConstants.criteriaSelectionData));
      this.selectedServiceCenter = sessionStorage.serviceCenterData ? JSON.parse(JSON.parse(sessionStorage.serviceCenterData)) : (
        sessionStorage.selectedServiceCenter ? JSON.parse(sessionStorage.selectedServiceCenter).id : ''),
        this.helpForm = this._dynamicFormService.getStoredData('helpForm');
      this.supplementalForm = JSON.parse(this._dynamicFormService.getStoredData('supplementalForm'));
      this.getFormData();
    }

    this._dynamicFormService.getAllStateCodes();
    this._dynamicFormService.daysNoticeWarningLogData = NoticeGenerationConstants.daysNoticeWarningLogData;
  }
  ngOnInit(): void {
    if (Object.keys(this.formModel).length > 0) {
      this.getFormData();
    }
    if (!this.serviceCenterData) {
      this.getServiceCenterDetails();
      this.isServiceCenterValid = true;
    }
    this._dynamicFormService.setNoticeStatus(false);
    this.currentSectionId = this._dynamicFormService.getStoredData(this._dynamicFormService.getCurrentFormSectionIdKey());
    this.getStoredData();
  }

  getFormData() {
    this.dynamicFormHttpService.getFormData(this.formModel.policy, this.formModel.jurisdiction,
      this.formModel.action, this.formModel.circumstance, this.formModel.lob).
      subscribe((formData: any) => {
        this.formData = formData;
        this._dynamicFormService.setPrefill(this.formData);
        this._dynamicFormService.getAmtFieldNames(this.formData);
        if (this.formData) {
          this.setFormData();
          this.getStoredData();
        }
      }, error => {
        if (error.status === 500) {
          this._dynamicFormService.showAlert(error.error.message);
        }
        this.spinnerService.stop();
      });
  }
  setFormData() {
    this.getReasonsForActionsData(this.formData);
    if (this.formData.length > 1) {
      this.formData.forEach(ele => {
        if (ele.isSupplemental && this.getSupplementalForm &&
          (sessionStorage.supplementalFormCode && ele.name === sessionStorage.supplementalFormCode)) {
          this.setForm(ele);
        } else if (!ele.isSupplemental && !this.getSupplementalForm) {
          this.formCode = ele.name.slice(0, -4);
          this._dynamicFormService.currentFormCode = this.formCode;
          this.setForm(ele);
          this.supplimentalFormsNames = this._dynamicFormService.getSupplementalForms(this.formData);
        }
      });
    } else {
      this.formCode = this.formData[0].name.slice(0, -4);
      this.getSectionDetails(this.formData, 0);
      this.getDocumentLinks(this.formData, 0);
      this.getSectionIsRequired(this.formData, 0);
      this.getFormTitle(this.formData[0].name, this.formModel.jurisdiction,
        this.formModel.action, this.formModel.circumstance, this.formModel.lob);
      this._dynamicFormService.currentFormCode = this.formCode;
      this.getFormWarning(this.formData[0]);

    }
  }
  getSectionDetails(formData, index: number) {
    this.formIndex = index;
    if (this._dynamicFormService.getStoredData('supplementalForm') && this._dynamicFormService.getNoticeStatus()) {
      this.formIndex = index - 1;
    }
    this.formSectionNames = this._dynamicFormService.getSectionsfromAPI(formData, this.formIndex);
  }
  setForm(ele) {
    this.getDocumentLinks(this.formData, this.formData.indexOf(ele));
    this.getSectionDetails(this.formData, this.formData.indexOf(ele));
    this.getSectionIsRequired(this.formData, this.formData.indexOf(ele));
    this._dynamicFormService.currentFormCode = ele.name;
    this.getFormTitle(ele.name, this.formModel.jurisdiction,
      this.formModel.action, this.formModel.circumstance, this.formModel.lob);
    this.getFormWarning(ele);
  }

  getFormWarning(form) {
    if (form.warnings && form.warnings.length > 0) {
      if (form.warnings.filter(e => e.type === NoticeGenerationConstants.formSizeWarning).length > 0) {
        this.showFormSizeWarning = true;
      }

    }
  }

  getSectionIsRequired(formData, index: number) {
    this.formIndex = index;
    this.sectionIsRequired = this._dynamicFormService.getIsRequiredfromAPI(formData, this.formIndex);
    this.isvisitedSection = new Array(this.sectionIsRequired.length).fill(false);
  }
  getFormSection(section) {
    this.currentFormName = this._dynamicFormService.getCurrentFormName();
    this.mainFormName = sessionStorage.MainFormName;
    this.setGreenCheck();
    this.formSection = section.includes(NoticeGenerationConstants.policyText) ? NoticeGenerationConstants.policyText : section;
    this.sectionTitle = section.includes(NoticeGenerationConstants.policyText) ? NoticeGenerationConstants.policyText :
      section.includes(NoticeGenerationConstants.insuredForm.insured) ? section + NoticeGenerationConstants.insuredForm.applicant : section;
    this.isPageValid = this.isPageValid;
    this.isSectionValid = this.isSectionValid;
  }

  setGreenCheck() {

    let sectionName = null;
    this.formSectionNames.forEach(element => {
      if (element.displayName.includes(this.formSection)) {
        sectionName = element.name;
      }
    });
    const formName = this._dynamicFormService.getCurrentFormName();
    let data;
    if (this._dynamicFormService.isSupplementalForm) {
      if (this.isPageValid) {
        data = JSON.parse(this._dynamicFormService.getStoredData(NoticeGenerationConstants.supplemntalPreviousVisitedSections));
        if (data) {
          data.filter(item => {
            if (item.name === formName) {
              this.supplemntalPreviousSection = item.visitedSections;
            }
          });
        }
        if (!this.supplemntalPreviousSection.includes(sectionName)) {
          this.supplemntalPreviousSection.push(sectionName);
        }
      } else { // removed optinal sections if already added for page invalid
        if (sectionName === NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment) {
          this.supplemntalPreviousSection = this.supplemntalPreviousSection.filter(function (item) {
            return item !== NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment;
          });
        }
        else if (sectionName === NoticeGenerationConstants.producerText) {
          this.supplemntalPreviousSection = this.supplemntalPreviousSection.filter(function (item) {
            return item !== NoticeGenerationConstants.producerText;
          });
        }
      }
      const updatedData = [{ 'name': formName, 'visitedSections': this.supplemntalPreviousSection }];
      this._dynamicFormService.setStoreData(NoticeGenerationConstants.supplemntalPreviousVisitedSections, updatedData);

    } else {
      if (this.isPageValid) {
        if (!this.previousSection.includes(sectionName)) {
          this.previousSection.push(sectionName);
        }
      }
      else { // removed optinal sections if already added for page invalid
        if (sectionName === NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment) {
          this.previousSection = this.previousSection.filter(function (item) {
            return item !== NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment;
          });
        }
        else if (sectionName === NoticeGenerationConstants.producerText) {
          this.previousSection = this.previousSection.filter(function (item) {
            return item !== NoticeGenerationConstants.producerText;
          });
        }
      }
      if (this.previousSection && this.previousSection.length > 0) {
        this._dynamicFormService.setStoreData(NoticeGenerationConstants.previousVisitedSections, this.previousSection);
      }
    }
  }
  onServiceCenterChanged(value: any) {
    this.showFont = (value === this.selectServiceCenterLabel) ? true : false;
    if (value) {
      this.isServiceCenterValid = true;
      this._dynamicFormService.setStoreData(NoticeGenerationConstants.insurerForm.serviceCenterData, value);
      sessionStorage.setItem(NoticeGenerationConstants.insurerForm.serviceCenterData, value);
    } else {
      this.isServiceCenterValid = false;
    }
    this.serviceCenterData.forEach(element => {
      if (Number(value) === element.id) {
        this.selectedServiceCenter = element;
        this._dynamicFormService.setStoreData(NoticeGenerationConstants.insurerForm.selectedServiceCenter, this.selectedServiceCenter);
      }
    });
  }

  showSection(sectionIndex: number) {
    this._dynamicFormService.triggerSubmitManually.next(sectionIndex - 1);
  }

  getServiceCenterDetails() {
    this.dynamicFormHttpService.getServiceCenterDetails().subscribe(serviceCenterData => {
      if (serviceCenterData) {
        this.serviceCenterData = serviceCenterData;
        this.manipulateSessionServiceCenter();
        if (this.serviceCenterData && this.serviceCenterData.length > 0) {
          this.serviceCenterData.sort(this._dynamicFormService.sortDropdownData('name'));
        }

        this.serviceCenter = true;

        if (this.serviceCenterData.filter(val => val.id === Number(this.serviceCenterValue)).length === 0) {
          this.serviceCenterValue = null;
        }
        this._dynamicFormService.serviceCenters = this.serviceCenterData;
        this.serviceCenterData.forEach(element => {
          if (Number(this.serviceCenterValue) === element.id) {
            this.selectedServiceCenter = element;
            this._dynamicFormService.setStoreData(NoticeGenerationConstants.insurerForm.selectedServiceCenter, this.selectedServiceCenter);
          }
        });
      }
    }, error => {
      if (error.status === 500) {
        this._dynamicFormService.showAlert(error.error.message);
      }
      this.spinnerService.stop();
    });

  }

  getDocumentLinks(formData: any, index: number) {
    this.documentLinks = this._dynamicFormService.getDocumentLinks(formData, index);
  }

  getFormTitle(rtfName: string, jurisdiction: string, actionId: number, circumstanceId: number, lobId: []) {
    let lobData = '';
    lobId.forEach((element, index) => {
      lobData = (index === (lobId.length - 1)) ? lobData + 'LobId=' + element :
        lobData + 'LobId=' + element + NoticeGenerationConstants.urlGenerate.andSymbol;
    });
    lobData.trim();
    this.dynamicFormHttpService.getFormTitle(rtfName, jurisdiction, actionId, circumstanceId, lobData)
      .subscribe(formTitleData => {
        if (formTitleData) {
          if (this.getSupplementalForm) {
            this.supplementalFormTitle = formTitleData.title;
          } else {
            this.formTitle = formTitleData.title;
          }
        }
      }, error => {
        if (error.status === 500) {
          this._dynamicFormService.showAlert(error.error.message);
        }
        this.spinnerService.stop();
      });
  }
  addendumForm() {
    this.dynamicFormHttpService.getAddendumForm()
      .subscribe(response => {
        if (response) {
          saveAs(response.body, NoticeGenerationConstants.addendum);
        }
      }, error => {
        if (error.status === 500) {
          this._dynamicFormService.showAlert(error.error.message);
        }
        this.spinnerService.stop();
      });
  }
  helpFormCall(helpForm) {
    this._dynamicFormService.setStoreData('helpForm', helpForm);
    this.dynamicFormHttpService.getHelpForm(helpForm)
      .subscribe(response => {
        if (response) {
          saveAs(response.body, helpForm);
        }
      }, error => {
        if (error.status === 500) {
          this._dynamicFormService.showAlert(error.error.message);
        }
        this.spinnerService.stop();
      });
  }

  supplementalNav(form) {
    sessionStorage.setItem(NoticeGenerationConstants.localStorageKeys.isSupplementalFirstLoad, 'true');
    this._dynamicFormService.setStoreData('supplementalForm', form.name);
    this._dynamicFormService.setToLocal(NoticeGenerationConstants.supplementalFormCode, form.formCode);
    this._dynamicFormService.currentFormCode = form.formCode;
    this.generateNotice = this._dynamicFormService.getNoticeStatus();
    if (this.generateNotice || (this._dynamicFormService.isNoticeRegenerated && this._dynamicFormService.isNoticeRegeneratedExactMatch)) {
      this.getSupplementalForm = true;

      const url = environment.appUrl +
        AppConstants.uiRoutes.noticeGeneration +
        NoticeGenerationConstants.routeSeparator + NoticeGenerationConstants.supplementalDynamicForm +
        NoticeGenerationConstants.urlGenerate.querySymbol + NoticeGenerationConstants.supplementalForm +
        NoticeGenerationConstants.urlGenerate.equalSymbol + this.getSupplementalForm +
        NoticeGenerationConstants.formCodeText + form.formCode ;
      window.open(url, '_blank').focus();
    } else {
      this.popupService.showAlert({
        title: '',
        message: this.translate.instant('NOTICE_GEN_TAB.FILL_FORM.generate_notice_error'),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: ''
      });
    }
  }

  onTypistChange() {
    this.typistValue = this.typistValue.trim();
    if (this.typistValue) {
      this._dynamicFormService.setStoreData(NoticeGenerationConstants.typistData, this.typistValue);
    } else {
      this._dynamicFormService.removeStoredData(NoticeGenerationConstants.typistData);
    }
  }

  getStoredData() {
    this.manipulateSessionServiceCenter();
    let data;
    if (this._dynamicFormService.getStoredData(NoticeGenerationConstants.supplemntalPreviousVisitedSections) !== null &&
      this._dynamicFormService.getStoredData(NoticeGenerationConstants.supplemntalPreviousVisitedSections) !== '') {
      const formName = this._dynamicFormService.getCurrentFormName();
      data = JSON.parse(this._dynamicFormService.getStoredData(NoticeGenerationConstants.supplemntalPreviousVisitedSections));
      data.filter(item => {
        if (item.name === formName) {
          this.supplemntalPreviousSection = item.visitedSections;
        }
      });
    }
    if (this._dynamicFormService.getStoredData(NoticeGenerationConstants.previousVisitedSections) !== null &&
      this._dynamicFormService.getStoredData(NoticeGenerationConstants.previousVisitedSections) !== '') {
      this.previousSection = JSON.parse(this._dynamicFormService.getStoredData(NoticeGenerationConstants.previousVisitedSections));
    }
    const ServiceCenterLocalvalue = JSON.parse(this._dynamicFormService
      .getStoredData(NoticeGenerationConstants.insurerForm.selectedServiceCenter));
    const typistLocalValue = JSON.parse(this._dynamicFormService.getStoredData(NoticeGenerationConstants.typistData));
    if (ServiceCenterLocalvalue) {
      this.serviceCenterValue = ServiceCenterLocalvalue.id;
    }
    if (typistLocalValue) {
      this.typistValue = typistLocalValue;
    }


    if (this.formData) {
      this.currentFormName = this._dynamicFormService.getCurrentFormName();
      const componentsDetails = this.formData.find(x => x.name === this.currentFormName).components;
      const componentNames = componentsDetails.map((obj) => {
        return obj.name;
      });
      const visitedData = [];
      componentNames.forEach(compEle => {
        if (this._dynamicFormService.isSupplementalForm) {
          visitedData.push(
            this.supplemntalPreviousSection.includes(compEle) ? true : false
          );
        } else {
          visitedData.push(
            this.previousSection.includes(compEle) ? true : false
          );
        }
      });
      this.isvisitedSection = visitedData;
    }

    if (this._dynamicFormService.getStoredData(NoticeGenerationConstants.insurerSelectedValues)) {
      this._dynamicFormService.insurerSelectedValues = JSON.parse(
        this._dynamicFormService.getStoredData(NoticeGenerationConstants.insurerSelectedValues));
    }
  }
  showSectionAlert(id) {
    if (Number(this.currentSectionId) === 0) {
      this._dynamicFormService.showNavigationPrefillWarning = true;
    }
    this.popupService.showAlert({
      title: '',
      message: this.formSectionNames[id].displayName + ' ' + this.translate.instant('DYNAMIC_FORMS.infoIsRequired'),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: '',
    });
  }
  onClickBack() {
    this._dynamicFormService.isNavigationPrefilledClicked = false;
    this.currentSectionId = this._dynamicFormService.getStoredData(this._dynamicFormService.getCurrentFormSectionIdKey());
    this._dynamicFormService.callComponentMethod({ 'requested': this.currentSectionId - 1, 'current': this.currentSectionId });

    this.isvisitedSection[this.currentSectionId] = true;
    if (this.isSectionValid) {
      const obj = {
        sectionId: this.currentSectionId,
        isBackTriggered: true
      };
      this._dynamicFormService.backButtonClicked(obj);
    }
    else {
      this.showSectionAlert(this.currentSectionId);
    }
  }
  nextRequiredNotVisited() {
    for (let i = 0; i < this.sectionIsRequired.length; i++) {
      if (this.sectionIsRequired[i].isRequired && this.isvisitedSection[i] === false) {
        return i;
      }
    }
  }
  checkAllRequiredVisited(item) {
    this.nextRequiredSection = this.nextRequiredNotVisited();
    if (this.nextRequiredSection !== undefined) {
      if (item === Number(this.nextRequiredSection)) {
        this._dynamicFormService.SectionClicked(item);
      }
      else if (item < this.currentSectionId) {
        this._dynamicFormService.SectionClicked(item);
      } else if (item < Number(this.nextRequiredSection)) {
        this._dynamicFormService.SectionClicked(item);
      }
      else {
        this.showSectionAlert(this.nextRequiredSection);
      }
    }
    else {
      this._dynamicFormService.SectionClicked(item);
    }
  }

  onclickPrefillSec(item: number) {
    this._dynamicFormService.fieldRuleValidatorForAllFields();
    this._dynamicFormService.navigationSectionIndex = item;
    this._dynamicFormService.isNavigationPrefilledClicked = true;
    this.currentSectionId = this._dynamicFormService.getStoredData(this._dynamicFormService.getCurrentFormSectionIdKey());
    if (item !== Number(this.currentSectionId)) {
      this._dynamicFormService.callComponentMethod({ 'requested': item, 'current': this.currentSectionId });
      if (this.sectionIsRequired[this.currentSectionId].isRequired) {
        if (this.isSectionValid) {
          this.isvisitedSection[this.currentSectionId] = true;
          if ((item === Number(this.currentSectionId) + 1) ||
            (this.isvisitedSection[item])
          ) {
            this._dynamicFormService.SectionClicked(item);
          }
          else {
            this.checkAllRequiredVisited(item);
          }
        }
        else {
          this.showSectionAlert(this.currentSectionId);
        }
      }
      else {
        this.isvisitedSection[this.currentSectionId] = true;
        if (
          (item === Number(this.currentSectionId) + 1) ||
          (this.isvisitedSection[item])
        ) {
          this._dynamicFormService.SectionClicked(item);
        }
        else {
          this.checkAllRequiredVisited(item);
        }
      }

    }

  }
  highlightSection(i: number) {
    this.currentSectionId = this._dynamicFormService.getStoredData(this._dynamicFormService.getCurrentFormSectionIdKey());
    if (i === Number(this.currentSectionId)) {
      return true;
    }
    else {
      return false;
    }
  }

  getReasonsForActionsData(formData) {
    let foundField = false;
    let lookupDataUrl = null;
    this.formData[0].components[0].fields.forEach(data => {
      if (data.optionsUrl !== null && data.optionsUrl.includes(NoticeGenerationConstants.reasonsAPIurl)) {
        foundField = true;
        this._dynamicFormService.getdropdownOptions(data.optionsUrl, data.name).subscribe(result => {
          this._dynamicFormService.reasonForActionOptions = result;
          this.isDataAvailable = true;
        }, error => {
          this.isDataAvailable = true;
          if (error.status === 500) {
            this._dynamicFormService.showAlert(error.error.message);
          }
          this.spinnerService.stop();
        });
      }
      if (data.optionsUrl !== null && data.optionsUrl.includes('DaysOfNotice')) {
        lookupDataUrl = data.optionsUrl;
      }
    });
    if (!foundField) {
      this.isDataAvailable = true;
    }
    this.getLookupData(lookupDataUrl); // LookupTableDataFuncCall

    // Day's notice warning log data
    if (lookupDataUrl) {
      this._dynamicFormService.daysNoticeWarningLogData.serverDate = lookupDataUrl.substring(lookupDataUrl.indexOf('MailingDate=') + 12);
    }
  }

  getLookupData(optionsUrl) {
    const formModel = JSON.parse(
      this._dynamicFormService.getStoredData(NoticeGenerationConstants.criteriaSelectionData)
    );
    const filterData = new Set();
    const isCompanyDaysNoticeData = false;
    this.dynamicFormHttpService
      .getLookupTableData(optionsUrl)
      .subscribe((result: any) => {
        if (result && result.length > 0) {
          this._dynamicFormService.lookupTableData = result;
          this._dynamicFormService.lookupTableData.forEach(data => {
            if (Array.isArray(formModel.lob)) {
              for (let i = 0; i < formModel.lob.length; i++) {
                if (
                  data.circumstanceId === formModel.circumstance &&
                  data.lobId === formModel.lob[i]
                ) {
                  filterData.add(data); // state mandate and customized data
                }
              }
            }
          });
          const filterData1 = [...filterData];
          const whiteData = this._dynamicFormService.lookupTableData.filter(item => !filterData1.includes(item));
          // Lookup Date Validation Logic
          this._dynamicFormService.lookupDateValidation(filterData1, isCompanyDaysNoticeData);
          // get lookup table child window
          this._dynamicFormService.getChildWindowLookupData(filterData1, whiteData);
        }
        this.isLookupDataAvailable = true;
      }, error => {
        this.isLookupDataAvailable = true;
        if (error.status === 500) {
          this._dynamicFormService.showAlert(error.error.message);
        }
        this.spinnerService.stop();
      });
  }


  manipulateSessionServiceCenter() {
    const data = this._dynamicFormService.manipulateSessionServiceCenter(this.serviceCenterData);
    this.serviceCenterValue = data ? null : this.serviceCenterValue;
  }

  openDocumentFile(pdfUrl: any) {
    const url = this._dynamicFormService.openDocumentFile(pdfUrl);
    if (url !== '') {
      window.open(url);
    }
  }

  isAllRequiredVisited(item) {
    let isVisited = true;
    this.nextRequiredSection = this.nextRequiredNotVisited();
    if (this.nextRequiredSection !== undefined) {
      if (item === Number(this.nextRequiredSection)) {
        isVisited = true;
      }
      else if (item < Number(this.currentSectionId)) {
        isVisited = true;
      } else if (item < Number(this.nextRequiredSection)) {
        isVisited = true;
      }
      else if (
        (item === Number(this.currentSectionId) + 1) ||
        (this.isvisitedSection[item])
      ) {
        isVisited = true;
      }
      else {
        isVisited = false;
      }
    }
    else {
      isVisited = true;
    }
    return isVisited;
  }

  startSpinnerService() {
    this.spinnerService.start();
   }

  checkIfServiceCenterExist(serviceCenterId) {
    const serviceCenterIds = this.serviceCenterData.map(x => x.id);
    if (!serviceCenterIds.includes(serviceCenterId)) {
      this.serviceCenterValue = null;
      sessionStorage.removeItem(NoticeGenerationConstants.insurerForm.serviceCenterData);
      sessionStorage.removeItem(NoticeGenerationConstants.insurerForm.selectedServiceCenter);
      return false;
    }
    return true;
  }
}
