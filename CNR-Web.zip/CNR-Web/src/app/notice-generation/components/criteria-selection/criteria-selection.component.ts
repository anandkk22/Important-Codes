import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Store } from '@ngrx/store';
import '@wk/components/dist/tooltip';
import { Router } from '@angular/router';
import '@wk/components/dist/tooltip';
import '@wk/components/dist/accordion';
import { CriteriaSelectionService } from 'app/notice-generation/service/criteria-selection.service';
import { StartFormSelection } from 'app/notice-generation/state/action/selection-citeria.actions';
import { forkJoin, Subscription } from 'rxjs';
import { PolicyType } from 'app/notice-generation/infrastructure/interface/policyType.interface';
import { Action } from 'app/notice-generation/infrastructure/interface/action.interface';
import { LOB } from 'app/notice-generation/infrastructure/interface/lob.interface';
import { Circumstance } from 'app/notice-generation/infrastructure/interface/circumstance.interface';
import { AppConstants } from 'app/app.constants';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { SpinnerService } from '@wk/nils-core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CircumstanceDefinitionComponent } from '../circumstance-definition/circumstance-definition.component';
@Component({
  selector: 'app-criteria-selection',
  templateUrl: './criteria-selection.component.html',
  styleUrls: ['./criteria-selection.component.scss']
})
export class CriteriaSelectionComponent implements OnInit {
  actions: Action[] = [];
  circumstances: Circumstance[] = [];
  criteriaSelectionFormGroup: FormGroup;
  isDataAvailable = false;
  jurisdictions;
  lobs: LOB[] = [];
  policyTypes: PolicyType[] = [];
  submitted = false;
  subscriptions: Subscription[] = [];
  circumstanceDefUrl = AppConstants.circumstanceDefUrl;
  selectedJurisdiction = null;
  selectedAction = null;
  selectedCircumstance = null;
  selectedLob = null;
  selectedJurisdictionLabel = 'Select Jurisdiction';
  selectedActionLabel = 'Select Action';
  selectedCircumstanceLabel = 'Select Circumstance';
  selectedLobLabel = 'Select Sublines of Business';
  selectedLOBs = [];
  dropdownSettings;
  selectedItems = [];
  showSection = false;
  showSelected = [];
  jurisdictionData;
  actionData;
  circumstanceData;
  lobData;
  noSublines = NoticeGenerationConstants.noSublines;
  selectedServiceCenter;
  constructor(
    private criteriaSelectionService: CriteriaSelectionService,
    private store: Store,
    private fb: FormBuilder,
    private router: Router,
    private dynamicFormService: DynamicFormService,
    private spinnerService: SpinnerService,
    private modalService: NgbModal
  ) {}
  ngOnInit(): void {
    let selectedServiceCenter = null;
    if (JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.insurerForm.selectedServiceCenter))) {
      selectedServiceCenter =  sessionStorage.getItem(NoticeGenerationConstants.insurerForm.selectedServiceCenter);
    }
    sessionStorage.clear();
    if (selectedServiceCenter) {
      sessionStorage.setItem(NoticeGenerationConstants.insurerForm.serviceCenterData, JSON.parse(selectedServiceCenter)?.id);
    } else {
      sessionStorage.setItem(NoticeGenerationConstants.insurerForm.serviceCenterData, '');
    }
    sessionStorage.setItem(NoticeGenerationConstants.insurerForm.selectedServiceCenter, selectedServiceCenter);


    this.initForm();
    this.fetchPoliciesAndJurisdictions();
    this.dynamicFormService.previousPolicyNumber = null;
    this.dynamicFormService.isNoticeRegenerated = false;
    this.dynamicFormService.isNoticeRegeneratedExactMatch = false;
    this.dynamicFormService.insurerSelectedValues = null;
  }
  resetCalculations() {
    this.selectedJurisdiction = this.selectedJurisdictionLabel;
  }
  initForm() {
    this.criteriaSelectionFormGroup = this.fb.group({
      policy: ['M', [Validators.required]]
    });
  }

  get policy(): any { return this.criteriaSelectionFormGroup.get('policy'); }

  get criteriaSelectionControls() {
    return this.criteriaSelectionFormGroup.controls;
  }

  fetchPoliciesAndJurisdictions() {
    const allPolicies = this.criteriaSelectionService.getPolicies();
    const allJurisdictions = this.criteriaSelectionService.getJurisdiction();
    this.subscriptions.push(
      forkJoin([allPolicies, allJurisdictions]).subscribe(
        (res: any) => {
          if (res) {
            this.policyTypes = res[0];
            this.jurisdictions = res[1];
            this.jurisdictionData = this.jurisdictions;
            this.isDataAvailable = true;
          }
        }, error => {
          if (error.status === 500) {
            this.dynamicFormService.showAlert(error.error.message);
          }
          this.spinnerService.stop();
        }
      )
    );
  }
  customSearchFn(event, key) {
    switch (key) {
      case 'Jurisdiction': {
      const data  =  this.jurisdictionData.filter(x => x.name.toLowerCase().startsWith(event.term.toLowerCase()));
        this.jurisdictions = event.term ? data : this.jurisdictionData;
        break;
      }
      case 'Action': {
        const data  =  this.actionData.filter(x => x.name.toLowerCase().startsWith(event.term.toLowerCase()));
        this.actions = event.term ? data : this.actionData;
        break;
      }
      case 'Circumstance': {
        const data  =  this.circumstanceData.filter(x => x.name.toLowerCase().startsWith(event.term.toLowerCase()));
        this.circumstances = event.term ? data : this.circumstanceData;
        break;
      }
      case 'LOB': {
        const data  =  this.lobData.filter(x => x.name.toLowerCase().startsWith(event.term.toLowerCase()));
        this.lobs = event.term ? data : this.lobData;
        break;
      }
    }

  }

  onJurisdictionChanged(jurisdiction) {

    this.circumstances = [];
    this.selectedAction = null;
    this.selectedCircumstance = null;
    this.selectedLob = null;
    this.selectedActionLabel = 'Select Action';
    this.selectedCircumstanceLabel = 'Select Circumstance';
    this.selectedLobLabel = 'Select Sublines of Business';
    this.lobs = [];
    this.selectedLOBs = [];
    this.showSelected = [];
    this.submitted = false;
    this.showSection = false;
    if (jurisdiction) {
      this.selectedJurisdiction = jurisdiction;
      this.selectedJurisdictionLabel = jurisdiction.name;
      this.criteriaSelectionService.mapCriteriaSelectionOptions().subscribe(() => {
        this.criteriaSelectionService.getActions(this.policy.value, jurisdiction.code).subscribe((res: Action[]) => {
          res.map(i => {
            i.codeName = i.code + ' - ' + i.name;
            return i;
          });
          this.actions = res.sort(this.criteriaSelectionService.compare('code'));
          this.actionData  = this.actions;
        }, error => {
          if (error.status === 500) {
            this.dynamicFormService.showAlert(error.error.message);
          }
          this.spinnerService.stop();
        });
      });
    } else {
      this.jurisdictions = this.jurisdictionData;
    }
  }

  onActionChanged(action) {
    this.lobs = [];
    this.showSelected = [];
    this.selectedLOBs = [];
    this.selectedCircumstance = null;
    this.selectedLob = null;
    this.selectedCircumstanceLabel = 'Select Circumstance';
    this.selectedLobLabel = 'Select Sublines of Business';
    this.showSection = false;
    this.submitted = false;

    if (action) {
      this.selectedAction = action;
      this.selectedActionLabel = action.name;
      this.criteriaSelectionService.getCircumstances(
        this.policy.value,
        this.selectedJurisdiction.code,
        action.id)
        .subscribe((res: Circumstance[]) => {
          this.circumstances = res;
          this.circumstanceData = this.circumstances;
        }, error => {
          if (error.status === 500) {
            this.dynamicFormService.showAlert(error.error.message);
          }
          this.spinnerService.stop();
        });
    } else {
      this.actions  = this.actionData;
    }
  }

  onCircumstanceChanged(circumstance) {
    this.selectedLob = null;
    this.selectedLobLabel = 'Select Sublines of Business';
    this.submitted = false;
    this.showSelected = [];
    this.showSection = false;
    if (circumstance) {
      this.selectedCircumstance = circumstance;
      this.selectedCircumstanceLabel = circumstance.name;
      this.criteriaSelectionService.getLobs(
        this.policy.value,
        this.selectedJurisdiction.code,
        this.selectedAction.id,
        circumstance.id)
        .subscribe((res: LOB[]) => {
          this.lobs = res;
          this.lobs = this.addGroupName(res, 'All Sublines of Business');
          this.lobData = this.lobs;
          this.selectedLOBs = [];
        }, error => {
          if (error.status === 500) {
            this.dynamicFormService.showAlert(error.error.message);
          }
          this.spinnerService.stop();
        });
    } else {
      this.circumstances = this.circumstanceData;
    }
  }
  onLobChange(lob) {
    if (lob) {
      this.selectedLob = lob;
      this.selectedLobLabel = lob.name;
    } else {
      this.lobs = this.lobData;
    }
  }
  showSelectedVal(lob) {
    if (lob && lob.length > 0) {
        this.selectedLOBs = lob;
        this.showSection = true;
        this.showSelected = lob.map(a => a.abbreviation);
        sessionStorage.setItem(NoticeGenerationConstants.localStorageKeys.selectedLOB, this.showSelected.join(', ').toString());
    } else {
      this.showSection = false;
      this.showSelected = [];
    }
  } addGroupName(data, type) {
    data.forEach(element => {
      element.all = type;
    });
    return data;
  }
  getSelectValue(selectedvalue, message) {
    return selectedvalue && selectedvalue.name ? selectedvalue.name : message;
  }

  fillForm() {
    this.submitted = true;
    if (this.criteriaSelectionFormGroup.valid && this.isValid()) {
      const criteriaDetails = {
        policy: this.policy.value,
        jurisdiction: this.selectedJurisdiction.code,
        action: this.selectedAction.id,
        circumstance: this.selectedCircumstance.id,
        lob: this.selectedLob ? [this.selectedLob.id] : this.selectedLOBs.map(a => a.id),
        actionName: this.selectedAction.name,
        lobName: this.selectedLob ? [this.selectedLob.name] : this.selectedLOBs.map(a => a.name)
      };
      this.store.dispatch(new StartFormSelection(criteriaDetails));
      this.router.navigate([AppConstants.uiRoutes.noticeGeneration +
        NoticeGenerationConstants.routeSeparator + AppConstants.uiRoutes.fillForm]);
    } else {
      return;
    }
  }

  filterArray(array) {
    return array.map(a => a.id);

  }
  isValid() {
    return this.selectedJurisdiction && this.selectedAction &&
      this.selectedCircumstance && (this.selectedLob || this.selectedLOBs.length) ? true : false;
  }
  resetAll(id) {
    this.resetFormFieldData();
    this.setdropdownData(id);
    this.submitted = false;
    this.circumstances = [];
    this.actions = [];
    this.lobs = [];
    this.selectedLOBs  = [];
  }

  resetForm(id) {
    this.resetFormFieldData();
    this.setdropdownData(id);
    this.submitted = false;
    this.circumstances = [];
    this.actions = [];
    this.lobs = [];
    this.selectedLOBs = [];
    this.criteriaSelectionFormGroup.reset();
    this.criteriaSelectionFormGroup.get('policy').setValue(this.policyTypes[0].code);
  }
  setdropdownData(key) {
    switch (key) {
      case 'Jurisdiction': {
        this.jurisdictions = this.jurisdictionData;
        break;
      }
      case 'Action': {
        this.actions  = this.actionData;
        break;
      }
      case 'Circumstance': {
        this.circumstances = this.circumstanceData;
        break;
      }
      case 'LOB': {
        this.lobs = this.lobData;
        break;
      }
      case 'ALL': {
        this.jurisdictions = this.jurisdictionData;
        this.actions  = this.actionData;
        this.circumstances = this.circumstanceData;
        this.lobs = this.lobData;
      }
    }
  }
  resetFormFieldData() {
    this.selectedJurisdiction = null;
    this.selectedAction = null;
    this.selectedCircumstance = null;
    this.selectedLob = null;
    this.selectedJurisdictionLabel = 'Select Jurisdiction';
    this.selectedActionLabel = 'Select Action';
    this.selectedCircumstanceLabel = 'Select Circumstance';
    this.selectedLobLabel = 'Select Sublines of Business';
    this.showSection = false;
    this.showSelected = [];
  }

  onCircumstanceDefeinitionClick() {
    const modalRef = this.modalService.open(CircumstanceDefinitionComponent);
  }

  startSpinnerService() {
   this.spinnerService.start();
  }
}
