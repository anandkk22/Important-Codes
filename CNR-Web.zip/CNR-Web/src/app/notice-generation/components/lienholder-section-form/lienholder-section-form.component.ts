import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl, FormGroup, NgForm } from '@angular/forms';
import { NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import { AppConstants } from 'app/app.constants';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormHttpService } from 'app/notice-generation/service/dynamic-form-http.service';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { filter, take } from 'rxjs/operators';
import { DynamicFormsComponent } from '../dynamic-forms/dynamic-forms.component';

@Component({
  selector: 'app-lienholder-section-form',
  templateUrl: './lienholder-section-form.component.html',
  styleUrls: ['./lienholder-section-form.component.scss']
})
export class LienholderSectionFormComponent implements OnInit, AfterViewInit {
  @Input() data;
  @Output() sectionIdEventEmitter = new EventEmitter<number>();
  sectionName: string;
  formIndexValue = 0;
  formModel = {};
  lastFormIndex = 0;
  isNoticeGenerated: boolean;
  constructor(
    private _dynamicFormService: DynamicFormService,
    private dynamicFormHttpService: DynamicFormHttpService,
    private popupService: PopupService,
    private translate: TranslateService,
    private router: Router,
    private dynamicFormsComponent: DynamicFormsComponent
  ) {
   }

  ngOnInit(): void {
    this.sectionName = this.data.formDataObject[this.formIndexValue].components[this.data.sectionId].name;
    this.lastFormIndex = this._dynamicFormService.getLastFormIndex();
    this.isNoticeGenerated = this._dynamicFormService.getNoticeStatus();
  }

  ngAfterViewInit() {
    this.data.options.resetModel();
  }

  reset() {
    this.data.options.resetModel();
  }
  generateNotice(form: FormGroup) {
    this.saveFormData();
    this._dynamicFormService.generateNoticeData(this.sectionName, form);
  }
  saveFormData() {
    this._dynamicFormService.saveSectionFormData(this.sectionName, this.data.form.value);
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
        const control = formGroup.get(field);
        if (control instanceof FormControl) {
            control.markAsTouched({ onlySelf: true });
        } else if (control instanceof FormGroup) {
            this.validateAllFormFields(control);
        }
    });
  }

  onSubmit() {
    this.validateAllFormFields(this.data.form);
    if (this.data.form.valid) {
      sessionStorage.setItem(NoticeGenerationConstants.localStorageKeys.formData, JSON.stringify(this.data.form.value));
      this.dynamicFormsComponent.isPageValid = true;
      this.sectionIdEventEmitter.emit(5);
    }
  }

  moveToCriteriaSelection(form: FormGroup) {
    this.popupService.showConfirmation({
      title: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.confirm_title'),
      message: this.translate.instant('NOTICE_GEN_TAB.CONFIRMATION.back_on_criteria_Selection'),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button')
    })
      .pipe(take(1)).subscribe(res => {
        if (res) {
          form.reset();
          sessionStorage.removeItem(NoticeGenerationConstants.insurerForm.serviceCenterData);
          this.router.navigate([AppConstants.uiRoutes.noticeGeneration +
            NoticeGenerationConstants.routeSeparator +
            AppConstants.uiRoutes.criteriaSelection]);
        } else {
          window.scrollTo(0, 0);
        }
      });
  }
}
