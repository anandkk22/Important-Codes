import { Component, ComponentFactoryResolver, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormlyFieldConfig, FormlyFormOptions } from '@ngx-formly/core';
import { RenderDynamicContentDirective } from 'app/notice-generation/directives/render-dynamic-content.directive';
import { PolicySectionFormComponent } from '../policy-section-form/policy-section-form.component';
import { Store, select } from '@ngrx/store';
import { NoticeGenerationConstants } from 'app/notice-generation/infrastructure/notice-generation.constant';
import { DynamicFormHttpService } from 'app/notice-generation/service/dynamic-form-http.service';
import { PremiumAdjustmentSectionFormComponent } from '../premium-adjustment-section-form/premium-adjustment-section-form.component';
import { DynamicFormService } from 'app/notice-generation/service/dynamic-form.service';
import { InsurerSectionFormComponent } from '../insurer-section-form/insurer-section-form.component';
import { FormSectionComponent } from '../form-section/form-section.component';
import { ProducerSectionFormComponent } from '../producer-section-form/producer-section-form.component';
import { InsuredSectionFormComponent } from '../insured-section-form/insured-section-form.component';
import { take } from 'rxjs/operators';
import { SpinnerService } from '@wk/nils-core';

@Component({
  selector: 'app-dynamic-forms-placeholder',
  templateUrl: './dynamic-forms-placeholder.component.html',
  styleUrls: ['./dynamic-forms-placeholder.component.css']
})
export class DynamicFormsPlaceholderComponent implements OnInit {

  @Input() sectionIndexValue = 0;
  @Input() formIndexValue = 0;
  form = new FormGroup({});
  @Input() formDataObject = {};
  formFields: FormlyFieldConfig[] = [{}];
  formModel: any = {};
  options: FormlyFormOptions = {};
  lobAbbr = '';
  @Output() formSection: EventEmitter<number> = new EventEmitter();
  @ViewChild(RenderDynamicContentDirective, { static: true }) adHost!: RenderDynamicContentDirective;
  currentFormName: string;
  constructor(
    private _dynamicFormService: DynamicFormService,
    private componentFactoryResolver: ComponentFactoryResolver,
    private dynamicFormHttpService: DynamicFormHttpService,
    private spinnerService: SpinnerService,
    private store: Store<{ reducer }>) {
    this.store.pipe(select('reducer')).subscribe((values) => {
      if (values) {
        this.formModel = values;
      } else {
        this.formModel = JSON.parse(sessionStorage.getItem(NoticeGenerationConstants.criteriaSelectionData));
      }
    });
  }

  ngOnInit(): void {
    this._dynamicFormService.emitDate.subscribe((result) => {
      if (result) {
        if (result.key === NoticeGenerationConstants.transactionDateText) {
          this.formModel = {
            ...this.formModel,
            TransactionDt: result.value
          };
        }
      }
    });
    if (this.formDataObject) {
      const LOBData = this._dynamicFormService.getLOBData();
      this.dynamicFormHttpService.getLOBsAbbreviations(LOBData).subscribe((res: any) => {
        this._dynamicFormService.getLOBsAbbreviations(res);
        this.formFields = this._dynamicFormService.getFormFields(
          this.formDataObject[this.formIndexValue].components[this.sectionIndexValue]);
        this.loadComponent();
      }, error => {
        if (error.status === 500) {
          this._dynamicFormService.showAlert(error.error.message);
        }
        this.spinnerService.stop();
      });
    }
  }

  loadComponent() {
    let componentFactory;
    let sectionType = this.formDataObject[this.formIndexValue].components[this.sectionIndexValue].name;
    const optionsUrl = this.formDataObject[this.formIndexValue].components[this.sectionIndexValue].optionsUrl;
    const sectionName = this.formDataObject[this.formIndexValue].components[this.sectionIndexValue].displayName;
    sectionType = this._dynamicFormService.getSectionTypes(sectionType);
    this.formSection.emit(sectionName);
    switch (sectionType) {
      case NoticeGenerationConstants.policyText:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(PolicySectionFormComponent);
        break;

      case NoticeGenerationConstants.premiumAdjutsmentForm.premiumAdjustment:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(PremiumAdjustmentSectionFormComponent);
        break;

      case NoticeGenerationConstants.insurerText:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(InsurerSectionFormComponent);
        break;

      case NoticeGenerationConstants.producerText:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(ProducerSectionFormComponent);
        break;
      case NoticeGenerationConstants.insuredForm.insured:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(InsuredSectionFormComponent);
        break;

      case NoticeGenerationConstants.sectionNames.mortgagee:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(FormSectionComponent);
        break;

      case NoticeGenerationConstants.sectionNames.lienholder:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(FormSectionComponent);
        break;

      case NoticeGenerationConstants.sectionNames.certholder:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(FormSectionComponent);
        break;

      case NoticeGenerationConstants.sectionNames.addInt:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(FormSectionComponent);
        break;

      case NoticeGenerationConstants.sectionNames.tp:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(FormSectionComponent);
        break;

      case NoticeGenerationConstants.sectionNames.wcc:
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(FormSectionComponent);
        break;
      /*
      case 'Registrar':
        componentFactory = this.componentFactoryResolver.resolveComponentFactory(RegistrarFormSectionComponent);
        break;
      */
    }

    const viewContainerRef = this.adHost.viewContainerRef;
    viewContainerRef.clear();
    const componentRef: any = viewContainerRef.createComponent(componentFactory);
    const data = {
      model: this.formModel,
      fields: this.formFields,
      form: this.form,
      options: this.options,
      optionsUrl: optionsUrl,
      sectionId: this.sectionIndexValue,
      sectionName: this.formDataObject[this.formIndexValue].components[this.sectionIndexValue].name,
      displayName: sectionName,
      formDataObject: this.formDataObject
    };
    componentRef.instance.data = data;
    componentRef.instance.sectionIdEventEmitter.
      subscribe(arg => {
          this.sectionIndexValue = arg + 1;
          this.reusableLoadComponent(this.sectionIndexValue);
        });
    this.setFormFieldsValue(data.fields);

    this._dynamicFormService.backButtonClickedEvent.pipe(take(1)).subscribe((msg: any) => {
      if (this.sectionIndexValue !== Number(msg.sectionId) - 1) {
        if (msg.isBackTriggered) {
          this.sectionIndexValue = Number(msg.sectionId) - 1;
          this.reusableLoadComponent(this.sectionIndexValue);
        }
    }
    this._dynamicFormService.showLookupWarningPopup = false;
    this._dynamicFormService.showDoubleWarningPoup = false;
    this._dynamicFormService.showNavigationPrefillWarning = false;
    });

    this._dynamicFormService.sectionClickedEvent.subscribe((msg: number) => {
      if (this.sectionIndexValue !== msg) {
        this.sectionIndexValue = msg;
        this.reusableLoadComponent(this.sectionIndexValue);
      }
      this._dynamicFormService.showLookupWarningPopup = false;
      this._dynamicFormService.showDoubleWarningPoup = false;
      this._dynamicFormService.showNavigationPrefillWarning = false;
    });
  }

  setFormFieldsValue(formFields) {
    formFields.forEach(item => {
      if (item && item.templateOptions) {
        if (item.key === NoticeGenerationConstants.policyTypeCodeText) {
          item.defaultValue = (this.formModel.lob.length > 1) ? NoticeGenerationConstants.packagePolicy : this.formModel.lobName ;

        }
        if (item.key === NoticeGenerationConstants.lobText) {
          this.currentFormName = this._dynamicFormService.getCurrentFormName();
          if (this.currentFormName) {
            const lobAbbrs = sessionStorage.getItem(this.currentFormName + NoticeGenerationConstants.lobAbbText);
            if (lobAbbrs) {
              item.defaultValue = lobAbbrs;
            }
          }
        }
      }
    });
  }
  reusableLoadComponent(secId: number) {
    this.formFields = this._dynamicFormService.getFormFields(this.formDataObject[this.formIndexValue].components[secId]);
    this.loadComponent();
  }
}
