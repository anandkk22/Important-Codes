import { CustomDatepickerComponent } from '../custom-template-components/field-types/datepicker/datepicker.component';
import { LookupDatepickerComponent } from '../custom-template-components/field-types/lookup-datepicker/lookup-datepicker.component';
import { MailTypeComponent } from '../custom-template-components/field-types/mail-type/mail-type.component';
import { ReasonsDropdownComponent } from '../custom-template-components/field-types/reasons-dropdown/reasons-dropdown.component';
import { LabelWrapperComponent } from '../custom-template-components/field-wrapper/label-wrapper.component';
import { DynamicFormValidationService } from '../service/dynamic-form-validation.service';

 export const validationDetails = {
    validators: [
      {
        name: 'alphanumeric',
        validation: DynamicFormValidationService.alphanumericValidator
      },
      {
        name: 'date',
        validation: DynamicFormValidationService.dateValidator
      },
      {
        name: 'decimal',
        validation: DynamicFormValidationService.decimalValidator
      },
      {
        name: 'noSpace',
        validation: DynamicFormValidationService.noSpaceValidator
      },
      {
        name: 'postalCode',
        validation: DynamicFormValidationService.postalCodeValidator
      },
      {
        name: 'dateInvalid',
        validation: DynamicFormValidationService.dateFormatValidator
      },
      {
        name: 'phoneNumber',
        validation: DynamicFormValidationService.phoneNumberValidator
      }
  ],
  types: [
    {
      name: 'lookup', component: LookupDatepickerComponent,
      defaultOptions: {
        templateOptions: {
          type: 'date'
        }
      }
    },
    {
      name: 'mailType', component: MailTypeComponent,
      defaultOptions: {
        templateOptions: {
          type: 'radio'
        }
      }
    },
    {
      name: 'datepicker', component: CustomDatepickerComponent,
      defaultOptions: {
        templateOptions: {
          type: 'date'
        }
      }
    },
    {
      name: 'reasonsDropdown',
      component: ReasonsDropdownComponent,
      defaultOptions: {
        templateOptions: {
          type: 'date'
        }
      }
    }
  ],
    wrappers: [
      { name: 'labelWrapper', component: LabelWrapperComponent },
    ],
    validationMessages: [
      { name: 'required', message: DynamicFormValidationService.requiredValidationMessage },
      { name: 'min', message: DynamicFormValidationService.minNumberValidationMessage },
      { name: 'max', message: DynamicFormValidationService.maxNumberValidationMessage },
      { name: 'minlength', message: DynamicFormValidationService.minlengthValidationMessage },
      { name: 'maxlength', message: DynamicFormValidationService.maxlengthValidationMessage },
      { name: 'alphanumeric', message: DynamicFormValidationService.alphanumericValidationMessage },
      { name: 'date', message: DynamicFormValidationService.dateValidationMessage },
      { name: 'decimal', message: DynamicFormValidationService.decimalValidationMessage },
      { name: 'noSpace', message: DynamicFormValidationService.requiredValidationMessage },
      { name: 'postalCode', message: DynamicFormValidationService.postalCodeValidationMessage },
      { name: 'dateInvalid', message: DynamicFormValidationService.dateFormatMessage },
      { name: 'phoneNumber', message: DynamicFormValidationService.phoneNumberValidationMessage }
    ],
  };
