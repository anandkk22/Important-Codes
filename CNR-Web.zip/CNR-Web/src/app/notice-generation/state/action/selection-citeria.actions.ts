import { Action } from '@ngrx/store';
import { ActionTypes } from '../enum/actionTypes';

export class StartFormSelection implements Action {
    type = ActionTypes.FormSelectionStarted;

    constructor(public payload: any) { }
}
