import { StartFormSelection } from '../action/selection-citeria.actions';
import { ActionTypes } from '../enum/actionTypes';

const initialState = '';
export function SelectionCriteriaReducer(
    state = initialState,
    action: StartFormSelection
) {
    switch (action.type) {
        case ActionTypes.FormSelectionStarted:
            return action.payload;
        default:
            return state;
    }
}
