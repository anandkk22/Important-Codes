export enum EventType {
    requiredField= 'RequiredField',
    updateFieldValue= 'UpdateFieldValue'
}
