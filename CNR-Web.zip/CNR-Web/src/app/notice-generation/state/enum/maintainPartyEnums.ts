export enum maintainPartyEnums {
    addInt = 0,
    certHolder = 1,
    lienHolder = 2,
    mortgagee = 3,
    TP = 4,
    WCC = 5
}
