export enum ActionTypes {
    FormSelectionStarted = 'FORMSELETIONSTARTED',
}
