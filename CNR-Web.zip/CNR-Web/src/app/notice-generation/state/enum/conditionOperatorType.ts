
export enum ConditionOperatorType {
    equals= 'Equals',
    notEquals= 'NotEquals'
}








