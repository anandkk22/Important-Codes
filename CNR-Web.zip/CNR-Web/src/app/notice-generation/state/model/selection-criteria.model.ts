export class SelectionCriteriaModel {
    policy: string;
    jurisdiction: string;
    action: string;
    circumstance: number;
    lob: number;
}
