import { Component, OnInit } from '@angular/core';
import { LoggerService } from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { NavigationEnd, Router } from '@angular/router';
import { SharedDataService } from '@global';
import { AppConstants } from './app.constants';
import { environment } from '@env';

declare let gtag: Function;
@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html'
})
export class AppComponent implements OnInit {
  isDataAvailable = false;
  constructor(private _logger: LoggerService, private _translate: TranslateService,
    private router: Router, private sharedDataService: SharedDataService) {
    this._logger.info('AppComponent : constructor ');

    this._logger.info('"AppComponent : constructor => language configured');

    this._logger.error('"AppComponent : constructor => this is a test log to check server logging');

    this._translate.addLangs(AppConstants.ngxTranslateConfig.supportedBrowserLanguages);
    this._translate.setDefaultLang(AppConstants.ngxTranslateConfig.fallbackBrowserLanguage);

    const browserLang = _translate.getBrowserLang();

    this._logger.info('AppComponent : constructor => Current browserLang Is :' + browserLang);

    const languageConfiguredForApplication = browserLang.match(AppConstants.ngxTranslateConfig.supportedBrowserLanguages.join('|'))
      ? browserLang : AppConstants.ngxTranslateConfig.fallbackBrowserLanguage;

    this._translate.use(languageConfiguredForApplication);
    this._logger.info('AppComponent : constructor => Application language is set to :' + languageConfiguredForApplication);
  }


  // Note: Code is intentionally commented not removed as WK team wanted to implement this in future.

  ngOnInit() {
    try {
      // Added to check the value returned on server
      this.router.events.subscribe(event => {
        if (event instanceof NavigationEnd) {
          gtag('config', window['wkEnvConfig'].gtagMeasurementId,
            {
              'page_path': event.urlAfterRedirects
            }
          );
        }
      });
    } catch (error) {
      // In case Google Analytics error out, we need to know the the reason why it failed
    }
  }
}
