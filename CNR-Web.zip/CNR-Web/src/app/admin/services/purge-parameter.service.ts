import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constants } from '../infrastructure/constants';

@Injectable()
export class PurgeParametrService {

    constructor(private http: HttpClient) { }

    public getPurgeParameterDetails() {
        return this.http.get(`${Constants.webApis.getPurgeParameter}`);
    }

    public addPurgeParameter(param) {
        return this.http.post(`${Constants.webApis.getPurgeParameter}`, param);
    }

    public editPurgeParameter(param) {
        return this.http.put(`${Constants.webApis.getPurgeParameter}`, param);
    }


    isRetationValid(purgeParameterFormvalue, retationPeriodDays) {
        if (purgeParameterFormvalue && purgeParameterFormvalue.automaticPurgeFeature === false) {
            return true;
        }
        return retationPeriodDays > 0 && retationPeriodDays <= 365 && (Number.isInteger(retationPeriodDays)) ? true : false;
    }
}
