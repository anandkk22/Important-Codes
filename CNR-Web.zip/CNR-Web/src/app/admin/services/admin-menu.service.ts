import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { Constants } from '../infrastructure/constants';
import { AdminFieldsData, GridRowData } from '../infrastructure/models/admin-menu.model';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { DefaultSettings } from '../infrastructure/models/default-settings.model';
import { UpdateEditionByJurisdiction } from '../infrastructure/models/form-edition-by-jurisdiction';
import { saveAs } from 'file-saver';

@Injectable()
export class AdminMenuService {
  defaultSettingData: any;

  constructor(private http: HttpClient) { }

  public getTableMaintainParties(type: any) {
    return this.http.get(`${Constants.webApis.getTableMaintainParties}`.replace('{type}', type));
  }

  public getAllParties(url) {
    return this.http.get(`${Constants.webApis.getAllParties}${url}`);
  }

  public getSingleRowData(recordID: any) {
    return this.http.get(`${Constants.webApis.getSingleRowData}`.replace('{recordID}', recordID));
  }

  public deleteRecords(records) {
    const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body: records };
    return this.http.delete(`${Constants.webApis.adminMenuDeleteRecords}`, options);
  }

  public updateSingleRowData(recordID: any, formData: AdminFieldsData) {
    return this.http.put(`${Constants.webApis.updateSingleRowData}`.replace('{recordID}', recordID), formData);
  }

  public addRecord(record) {
    return this.http.post(
      Constants.webApis.maintainParties, record);
  }

  public getReportDate() {
    return this.http.get(`${Constants.webApis.getReportToandFromDate}`);
  }

  public getTransactionLimit() {
    return this.http.get(`${Constants.webApis.getTransactionLimit}`);
  }

  public getCnrDefaultSettings() {
    return this.http.post(Constants.webApis.getCnrDefaultSettings, null);
  }

  public getRecordsReport(url) {
    return this.http.get(`${Constants.webApis.getReportReport}${url}`);
  }

  public getDefaultSettings() {
    return this.http.get(`${Constants.webApis.getDefaultSettings}`);
  }

  public updateDefaultSettings(defaultSettings: DefaultSettings) {
    return this.http.put(`${Constants.webApis.getAccountDefault}`, defaultSettings);
  }

  public getEditionByJurisdiction() {
    return this.http.get(`${Constants.webApis.getEditionByJurisdiction}`);
  }

  public updateEditionByJurisdiction(updateSettings: UpdateEditionByJurisdiction[]) {
    return this.http.put(`${Constants.webApis.updateEditionByJurisdiction}`, updateSettings);
  }

  public downloadFile(formattedPath) {
    return this.http.put(`${Constants.webApis.downloadFile}`.replace('{fileName}', formattedPath), '',
      { responseType: Constants.responseType.blobType as 'json', observe: 'response' });
  }

  public loadFile(response: any, fileName: any) {
    saveAs(response.body, fileName);
  }

  public downloadFileFromNils(formattedPath) {
    return this.http.put(`${Constants.webApis.downloadFileNils}`.replace('{fileName}', formattedPath), '',
      { responseType: Constants.responseType.blobType as 'json', observe: 'response' });
  }

  isThresholdValuePassing(fromDate, toDate) {
      return this.http.get(`${Constants.webApis.getReportCount}`.replace('{dateFrom}', fromDate).replace('{dateTo}', toDate));
  }
}
