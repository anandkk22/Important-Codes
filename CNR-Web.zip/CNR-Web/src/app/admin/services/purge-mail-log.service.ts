import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Constants } from '../infrastructure/constants';
import { AppConstants } from 'app/app.constants';
import { Subject} from 'rxjs';
@Injectable()
export class PurgeMailLogService {
    pageSizeDropdown: HTMLElement;
    constructor(private http: HttpClient) { }

    public getPurgeReportDates() {
        return this.http.get(`${Constants.webApis.getPurgeReportDates}`);
    }

    public getReportUrl(dateFrom, dateTo, pageNo, pageSize) {
        let url = '';
        url = `${Constants.urlGeenrate.questionMark}${Constants.urlGeenrate.dateFrom}${Constants.urlGeenrate.equalTo}${dateFrom}${Constants.urlGeenrate.andSymbol}${Constants.urlGeenrate.dateTo}${Constants.urlGeenrate.equalTo}${dateTo}${Constants.urlFilter.pageNo}${pageNo}${Constants.urlFilter.pageSize}${pageSize}`;
        return url.trim();
    }

    public manipulatePageSizes() {
        setTimeout(function () {
            this.addMorePageSizes();
        }.bind(this));
    }
    public getPurgeReport(url) {
        return this.http.get(`${Constants.webApis.getPurgeReport}${url}`);
    }

    public loadUpadtedPageSizes() {
        setTimeout(function () {
            this.pageSizeDropdown = document.querySelector('#pagination-bar-dynamic .wk-field-select');
            this.addMorePageSizes();
        }.bind(this), 250);
    }

    public addMorePageSizes() {
        for (let i = 0; i < Constants.pageSizes.length; i++) {
            this.pageSizeDropdown[i].value = Constants.pageSizes[i].toString();
            this.pageSizeDropdown[i].innerHTML = Constants.pageSizes[i];
        }
    }

    public getPurgeRecUrl(beginDate, endDate) {
        let url = '';
        url = `${Constants.webApis.purgeRecords}${beginDate}${Constants.urlGeenrate.endDate}${endDate}`;
        return url.trim();
    }

    public purgeRecords(url) {
        return this.http.delete(url);
    }

    public getCountBasedOnLimit(total, limit) {
        const afterDivision = total / limit;
        if (afterDivision === Math.floor(afterDivision)) {
            return Math.floor(afterDivision);
        } else {
            return Math.floor(afterDivision) + 1;
        }
    }

    public getExcelRowLimit(total, limit, noOfExcel) {
        const arr = [];
        for (let i = 0; i < noOfExcel; i++) {
            const obj = {};
            obj[AppConstants.mailLogDownload.start] = i * limit;
            if ( i + 1 === noOfExcel) {
                obj[AppConstants.mailLogDownload.end] = total + 1;
            } else {
                obj[AppConstants.mailLogDownload.end] = ((i + 1) * limit);
            }
            arr.push(obj);
        }
        return arr;
    }

    public dowmloadSubject() {
        return new Subject<void>();
    }
}
