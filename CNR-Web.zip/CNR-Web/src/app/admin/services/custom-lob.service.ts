import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constants } from '../infrastructure/constants';

@Injectable({
  providedIn: 'root'
})
export class CustomLobService {

  constructor(private http: HttpClient) { }

  getLOBs() {
    return this.http.get(`${Constants.webApis.getLobs}`.replace('{adminMenuItem}', '0'));
  }

  getCustomLOBs() {
    return this.http.get(`${Constants.webApis.customLobs}`);
  }

  saveCustomLob(lobId, customLob) {
    const lobObj = {
      lobid: Number(lobId),
      customizedLob: customLob.trim()
    };
    return this.http.post(`${Constants.webApis.customLobs}`, lobObj);
  }

  editCustomLob(lobid, customLob, lob) {
    const editLobObj = {
      lobid: lobid,
      oldCustomizedLob: lob,
      newCustomizedLob: customLob.trim()
    };
    return this.http.put(`${Constants.webApis.customLobs}`, editLobObj);
  }

  deleteLOB(row) {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
      }),
      body: {
        lobid: Number(row.lobid),
        customizedLob: row.customizedLob,
      },
    };
    return this.http.delete(`${Constants.webApis.customLobs}`, options);
  }
}
