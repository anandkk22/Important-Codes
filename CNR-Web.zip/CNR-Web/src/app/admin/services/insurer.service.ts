import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constants } from '../infrastructure/constants';

@Injectable()
export class InsurerService {

    constructor(private http: HttpClient) { }

    public getInsurers(paginationData) {
        const url = Constants.webApis.getInsurers + '&PageNo=' + paginationData.pageNo + '&PageSize=' + paginationData.pageSize +
         '&SortOnItem=' + paginationData.sortOnItem + '&Orderby=' + paginationData.orderby;
        return this.http.get(`${url}`);
    }

    public deleteInsurer(recordId) {
        return this.http.delete(`${Constants.webApis.deleteInsurer}`.replace('{insurerId}', recordId));
    }

    public deleteInsurers(param) {
        const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body : param };
        return this.http.delete(`${Constants.webApis.deleteInsurers}`, options );
    }

    public addInsurer(params) {
        return this.http.post(`${Constants.webApis.addInsurer}`, params);
    }

    public getInsurerData(recordID) {
        return this.http.get(`${Constants.webApis.editInsurer}`.replace('{insurerId}', recordID));
    }

    public saveEdittedInsurer(params, insurerId) {
        return this.http.put(`${Constants.webApis.saveEdittedInsurer}`.replace('{insurerId}', insurerId), params);
    }

    public getFormattedInsurers(res) {
        const formattedInsurers = [];
        if (res && res.paginationData) {
            res.paginationData.forEach(element => {
                if (element.insurerId) {
                    const recordID = element.insurerId;
                    delete element.insurerId;
                    element.recordID = recordID;
                }
                formattedInsurers.push(element);
            });
        }
        return formattedInsurers;
    }

}
