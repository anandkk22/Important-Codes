import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Constants } from '../infrastructure/constants';
import { checkKey } from 'app/admin/infrastructure/models/admin-menu.model';
@Injectable()
export class DaysNoticeRequirementsService {

  constructor(private http: HttpClient) { }

  public getJurisdictions() {
    return this.http.get(`${Constants.webApis.getJurisdictions}`);
  }

  public getLobs(adminMenuItem) {
    return this.http.get(`${Constants.webApis.getLobs}`.replace('{adminMenuItem}', adminMenuItem));
  }

  public getActions() {
    return this.http.get(`${Constants.webApis.getActions}`);
  }

  public getCircumstances() {
    return this.http.get(`${Constants.webApis.getCircumstances}`);
  }

  public getAllDaysNotice(noticeData) {
    return this.http.post(`${Constants.webApis.getAllDaysNotice}`, noticeData);
  }

  public addDaysNotice(addNoticeData) {
    return this.http.post(`${Constants.webApis.addDaysNotice}`, addNoticeData);
  }

  public deleteDaysNotice(records) {
    const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body : records };
    return this.http.delete(`${Constants.webApis.deleteDaysNotice}`, options);
  }

  public updateDaysNotices(rowsData) {
    return this.http.put(`${Constants.webApis.updateDaysNotice}`, rowsData);
  }

  addGroupName(data, type) {
    data.forEach(element => {
      element.all = type;
    });
    return data;
  }

  getJurisdictionsCodes(jurisdictions) {
    const jurisdictionsCodes = [];
    jurisdictions.forEach(element => {
      jurisdictionsCodes.push(element.code);
    });
    return jurisdictionsCodes;
  }

  getSelectedIds(actions) {
    const actionIds = [];
    actions.forEach(element => {
      actionIds.push(element.id);
    });
    return actionIds;
  }

  getJurisdictionsForAdd(jurisdictions) {
    const jurisdictionsNeeds = [];
    jurisdictions.forEach(element => {
        const obj = {};
        obj[Constants.editdaysProperties.stateCode] = element.code;
        obj[Constants.editdaysProperties.stateName] = element.name;
        jurisdictionsNeeds.push(obj);
    });
    return jurisdictionsNeeds;
  }

  getActionsForAdd(action) {
    const actionsNeeds = [];
    action.forEach(element => {
        const obj = {};
        obj[Constants.editdaysProperties.actionId] = element.id;
        obj[Constants.editdaysProperties.actionDesc] = element.name;
      actionsNeeds.push(obj);
    });
    return actionsNeeds;
  }

  getSLobsForAdd(lobs) {
    const actionsNeeds = [];
    lobs.forEach(element => {
        const obj = {};
        obj[Constants.editdaysProperties.lobId] = element.id;
        obj[Constants.editdaysProperties.lob] = element.name;
        actionsNeeds.push(obj);
    });
    return actionsNeeds;
  }

  getCircumstanceForAdd(circumstance) {
    const circumstanceNeed = [];
    circumstance.forEach(element => {
        const obj = {};
        obj[Constants.editdaysProperties.circumstanceId] = element.id;
        obj[Constants.editdaysProperties.circumstanceDescription] = element.name;
        circumstanceNeed.push(obj);
    });
    return circumstanceNeed;
  }

  mergeAllFields(pairs, daysNoticeForm) {
    const pairsNeed = [];
    pairs.forEach(element => {
      const summary = {...element[0], ...element[1], ...element[2], ...element[3], ...daysNoticeForm};
      pairsNeed.push(summary);
    });
    return pairsNeed;
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > checkKey.threeOne && (charCode < checkKey.fourEight || charCode > checkKey.fiveSeven)) {
      return false;
    }
    return true;
  }

  getDeleteFormate(rows) {
    const deleteFormate = [];
    rows.forEach(element => {
        const rowVal = {};
        rowVal[Constants.editdaysProperties.stateCode] = element.stateCode;
        rowVal[Constants.editdaysProperties.actionId] = element.actionId;
        rowVal[Constants.editdaysProperties.lobId] = element.lobId;
        rowVal[Constants.editdaysProperties.circumstanceId] = element.circumstanceId;
        deleteFormate.push(rowVal);
    });
    return deleteFormate;
  }

  collectGridWithCheckBoxOnly(all) {
    const onlyCheckBox = [];
    all.forEach(element => {
      if (!element.isDefaults) {
        onlyCheckBox.push(element);
      }
    });
    return onlyCheckBox;
  }
  getFormatedUpdateDays(data, days) {
      const selectedRows = data.selectedRows;
      const daysType = data.daysType;
      let minDays;
      let maxDays;
      if (data.daysType === Constants.editDaysType.minDays) {
            minDays = days;
            maxDays = '';
      } else if (data.daysType === Constants.editDaysType.maxDays) {
            minDays = '';
            maxDays = days;
      }
      const updateFormate = [];
      selectedRows.forEach(element => {
          const changeValue = {};
          changeValue[Constants.editdaysProperties.stateCode] = element.stateCode;
          changeValue[Constants.editdaysProperties.actionId] = element.actionId;
          changeValue[Constants.editdaysProperties.lobId] = element.lobId;
          changeValue[Constants.editdaysProperties.circumstanceId] = element.circumstanceId;
          changeValue[Constants.editdaysProperties.stateName] = element.stateName;
          changeValue[Constants.editdaysProperties.actionDesc] = element.actionDesc;
          changeValue[Constants.editdaysProperties.lob] = element.lob;
          changeValue[Constants.editdaysProperties.circumstanceDescription] = element.circumstanceDescription;
          changeValue[Constants.editdaysProperties.daysNotice] = minDays;
          changeValue[Constants.editdaysProperties.daysNoticeMax] = maxDays;
          updateFormate.push(changeValue);
      });
      return updateFormate;
  }

  getJurisdictionsForScroll(allRow) {
    const jurisdictions = allRow.map((obj) => obj.stateCode);
    const removedDuplicate = jurisdictions.filter((value, index, array) => array.indexOf(value) === index);
    return removedDuplicate;
  }

  showSingleRowOnly(notices, row) {
    const allData = notices;
    allData.forEach(element => {
      if (element.accountNumber === Constants.accountNumber.oneTwoSixNine) {
        element.isDefaults = true;
      } else if ((row.accountNumber === element.accountNumber) && (row.stateCode === element.stateCode) &&
      (row.actionId === element.actionId) && (row.circumstanceId === element.circumstanceId) && (row.lobId === element.lobId)) {
        element.isDefaults = false;
        element.isSelected = true;
      } else {
        element.isDefaults = false;
        element.isSelected = false;
      }
    });
    return allData;
  }

  getRowColor(row) {
    if (row.isDefaults) {
      return Constants.rowColor.yellowOpa;
    } else if (!row.isDefaults && row.isSelected) {
      return Constants.rowColor.orangeOpa;
    }
  }

  getViewText(count) {
    if (count && count > 1) {
      return Constants.viewText.were;
    } else {
      return Constants.viewText.was;
    }
  }

  isValid(allJurisdictions, allActions, allLobs, allCircumstances) {
    return allJurisdictions.length === 0 || allActions.length === 0 || allLobs.length === 0
     || allCircumstances.length === 0 ? false : true;
  }

  public getCountOfAllDaysNotice(noticeData) {
    return this.http.post(`${Constants.webApis.getCountOfAllDaysNotice}`, noticeData);
  }

}
