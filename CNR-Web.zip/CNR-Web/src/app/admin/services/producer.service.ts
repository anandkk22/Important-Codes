import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constants } from '../infrastructure/constants';

@Injectable()
export class ProducerService {

    constructor(private http: HttpClient) { }

    public getProducers(url) {
        return this.http.get(`${url}`);
    }

    public deleteProducers(param) {
        const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body: param };
        return this.http.delete(`${Constants.webApis.deleteProducers}`, options);
    }

    public addProducer(producerDetails) {
        return this.http.post(`${Constants.webApis.addProducer}`, this.getProducerDetails(producerDetails));
    }

    public saveEdittedProducer(producerDetails) {
        return this.http.put(`${Constants.webApis.addProducer}`, this.getProducerDetails(producerDetails));
    }

    public uploadFiles(uploadedFile) {
        const formData = new FormData();
        formData.append('file', uploadedFile, uploadedFile.name);
        return this.http.post(`${Constants.webApis.producerUploadExcel}`, formData);
    }

    public producerUpload() {
        return this.http.post(`${Constants.webApis.producerUpload}`, '');
    }

    public getProducerTemporary(pageNo, pageSize) {
        return this.http.get(`${Constants.webApis.getProducerTemporary}`.replace('{pageNo}', pageNo).replace('{pageSize}', pageSize));
    }

    public getProducerDetails(producerDetails) {
        if ('stateProvidence' in producerDetails) {
            const stateProvince = producerDetails.stateProvidence;
            delete producerDetails.stateProvidence;
            producerDetails.stateProvince = stateProvince;
        }
        return producerDetails;
    }
    public getstateDetails(producerDetails) {
        if ('stateProvince' in producerDetails) {
            const stateProvidence = producerDetails.stateProvince;
            delete producerDetails.stateProvince;
            producerDetails.stateProvidence = stateProvidence;
        }
        return producerDetails.stateProvidence;
    }

    public getFormattedProducers(res) {
        const formattedProducers = [];
        if (res && res.paginationData) {
            res.paginationData.forEach(element => {
                if ('id' in element) {
                    const recordID = element.id;
                    delete element.id;
                    element.recordID = recordID;
                }
                if ('stateProvince' in element) {
                    const stateProvidence = element.stateProvince;
                    delete element.stateProvince;
                    element.stateProvidence = stateProvidence;
                }
                formattedProducers.push(element);
            });
        }
        return formattedProducers;
    }

    getFilterSearchUrl(tableData, event) {
        let url = Constants.webApis.getProducers;
        if (event && Object.keys(event).length > 0) {
            Object.keys(event).forEach(key => {
                if (key === 'Jurisdiction') {
                    const allStates = event[key].split(',');
                    let stateUrl = '';
                    allStates.forEach((state, i) => {
                        stateUrl = i === 0 ? stateUrl + 'StateProvince=' + state : stateUrl + '&StateProvince=' + state;
                    });
                    stateUrl.trim();
                    url = url + stateUrl + '&';
                } else {
                    url = url + key + '=' + event[key] + '&';
                }
            });
        }
        url = url + 'PageNo=' + tableData.pageNo + '&PageSize=' + tableData.pageSize + '&SortOnItem=' + tableData.sortOnItem +
            '&Orderby=' + tableData.orderby;
        return url;
    }

}
