import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { Constants } from '../infrastructure/constants';

@Injectable()
export class ServiceCenterService {

    constructor(private http: HttpClient) { }

    public getAllServiceCenter(url) {
        return this.http.get(`${Constants.webApis.getAllServiceCenter}${url}`);
      }

      public addServiceCenter(formData) {
        return this.http.post(`${Constants.webApis.addServiceCenter}`, formData);
      }

      public updateServiceCenter(recordId, formData) {
        return this.http.put(`${Constants.webApis.updateServiceCenter}`.replace('{recordId}', recordId), formData);
      }

      public getSingleServiceCenterRowData(recordID: any) {
        return this.http.get(`${Constants.webApis.getSingleServiceCenterRowData}`.replace('{recordId}', recordID));
      }

      public deleteServiceCenter(records) {
        const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body : records };
        return this.http.delete(`${Constants.webApis.deleteServiceCenter}`, options);
      }

}
