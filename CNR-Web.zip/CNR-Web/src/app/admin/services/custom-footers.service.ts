import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constants } from '../infrastructure/constants';

@Injectable()
export class CustomFootersService {

  constructor(private http: HttpClient) { }

  public getCustomFooters(stateCode) {
    return this.http.get(`${Constants.webApis.getCustomFooters}`.replace('{stateCode}', stateCode));
  }

  public getJurisdictions() {
    return this.http.get(`${Constants.webApis.getCustomFooterJurisdiction}`);
  }

  public getFormNumber(stateCode) {
    return this.http.get(`${Constants.webApis.getAccountFormNumber}`.replace('{stateCode}', stateCode));
  }

  public doesFormStateMappingExists(data) {
    return this.http.get(`${Constants.webApis.doesFormStateMappingExists}`.replace('{stateCode}', data.jurisdiction)
      .replace('{formId}', data.formNumber));
  }

  public addCustomFooters(param) {
    return this.http.post(`${Constants.webApis.customFooters}`, param);
  }

  public editCustomFooters(param) {
    return this.http.put(`${Constants.webApis.customFooters}`, param);
  }

  public deleteCustomFooters(records) {
    let url = Constants.webApis.deleteCustomFooter + records.stateCode;
    url = records.formId ? url + '&formId=' + records.formId : url;
    return this.http.delete(`${url}`);
  }

  getSelectedFormNumber(rtfName, formNumbers) {
    let formId = null;
    formNumbers.forEach(formNumber => {
      if (formNumber.rtfName && (formNumber.rtfName === rtfName)) {
        formId = formNumber.formId;
      }
    });

    return formId;
  }

  isNCExist(jurisdictions) {
    let isExist = false;
    jurisdictions.forEach(element => {
      if (element.code === Constants.northCarolinaStateCode) {
        isExist = true;
      }
    });

    return isExist;
  }

  getCustomFooterSaveParam(customFooterFormValue) {
    const param = {
      'stateCode': customFooterFormValue.jurisdiction,
      'formId': customFooterFormValue.formNumber,
      'insurerFormId': customFooterFormValue.insurerFormID?.trim(),
      'insurerFooter': customFooterFormValue.insurerName?.trim()
    };

    return param;
  }

  isCustomFooterValid(customFooterForm) {
    if (customFooterForm.invalid) {
      return true;
    } else {
      const insurerFormID = customFooterForm.value.insurerFormID.trim();
      const insurerName = customFooterForm.value.insurerName.trim();
      if (insurerFormID.length > 0 && insurerName.length > 0) {
        return false;
      } else {
        return true;
      }
    }
  }

}
