import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constants } from '../infrastructure/constants';

@Injectable()
export class SignatureFilesService {

    constructor(private http: HttpClient) { }

    getSignatures() {
      return this.http.get(`${Constants.webApis.signatures}`);
    }

    deleteSignature(signature) {
      return this.http.delete(`${Constants.webApis.deletetSignature}`.replace('{signatureFileName}', signature.graphicFilename)
        .replace('{signatureId}', signature.signatureId));
    }

    searchSignatureFile(searchTerm) {
      return this.http.get(`${Constants.webApis.searchSignature}`.replace('{searchTerm}', searchTerm));
    }

    uploadFiles(uploadedFile) {
      const formData = new FormData();
      formData.append('signature', uploadedFile, uploadedFile.name);
      return this.http.post(`${Constants.webApis.uploadSignature}`, formData);

    }
}

