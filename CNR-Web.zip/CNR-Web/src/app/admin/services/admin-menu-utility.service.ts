import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Constants } from '../infrastructure/constants';
import { PopupService } from '@wk/nils-core';
import { Constants as GlobalConstants} from '@global/infrastructure/constants';
import { BehaviorSubject, forkJoin, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminMenuUtilityService {

  maintainSignatureParams = new BehaviorSubject(null);

  constructor(
    private translate: TranslateService,
    private popupService: PopupService,
  ) { }

  getSelectedRecordUrl(recordIds) {
    const recordArray = recordIds;
    let url = '';
    recordArray.forEach((element, index) => {
      url = (index === (recordArray.length - 1)) ? url + Constants.urlGeenrate.recordId + element :
        url + Constants.urlGeenrate.recordId + element + Constants.urlGeenrate.andSymbol;
    });
    url.trim();
    return url;
  }

  filterServiceCenterUrl(pageNo, pageSize, sortOnItem, orderby) {
    let url = '';
    url = Constants.urlServiceCenterUrl.pageNo + pageNo + Constants.urlFilter.pageSize + pageSize +
          Constants.urlFilter.sortOnItem + sortOnItem + Constants.urlFilter.orderby + orderby;
    return url.trim();
  }

  getFormatedServiceCenter(form) {
    const formatted = {
      code: form.code,
      name: form.name,
      addr1: form.address1,
      addr2: form.address2,
      city: form.city,
      stateProv: form.stateProvidence,
      postalCode: form.postalCode
    };
    return formatted;
  }

  public getFormattedGridServiceCenter(res) {
    const formattedInsurers = [];
    if (res && res.paginationData) {
        res.paginationData.forEach(element => {
            if (element.id) {
                const recordID = element.id;
                delete element.id;
                element.recordID = recordID;
            }
            formattedInsurers.push(element);
        });
    }
    return formattedInsurers;
  }

  getServiceCenterDeleteUrl(recordIdList) {
    const recordArray = recordIdList;
    let url = '';
    recordArray.forEach((element, index) => {
      url = (index === (recordArray.length - 1)) ? url + Constants.serviceCenterUrl.recordIdList + element :
        url + Constants.serviceCenterUrl.recordIdList + element + Constants.serviceCenterUrl.andSymbol;
    });
    return url.trim();
  }

  getColumnData(columnData) {
    const allColumnDatas = Constants.columnData;
    const returnColumnData = [];
    allColumnDatas.forEach(column => {
      columnData.forEach(reqColumn => {
        if (column.header === reqColumn) {
          returnColumnData.push(column);
        }
      });
    });
    return returnColumnData;
  }

  showSucessModal(message) {
    this.popupService.showSuccess({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: '',
    });
  }

  getFormDataAndTypeId(formValues, typeId) {
    const param = {
      ...formValues
    };
    param.type = typeId;
    return param;
  }

  getGridFilterUrl(type, pageNo, pageSize, sortOnItem, orderby) {
    let url = '';
    url = Constants.urlFilter.type + type + Constants.urlFilter.pageNo + pageNo
          + Constants.urlFilter.pageSize + pageSize + Constants.urlFilter.sortOnItem + sortOnItem + Constants.urlFilter.orderby + orderby;
    url.trim();
    return url;
  }

  showAlert(message) {
    this.popupService.showAlert({
      title: '',
      message: message,
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: '',
    });
  }

  getSubUrlDetails(currentSubUrl) {
    const administratorMenu = this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.administratorMenu');
    let urlIndex = null;
    let subUrlIndex = null;
    GlobalConstants.headerOptions.forEach((option, index) => {
      if (option.key === administratorMenu) {
        urlIndex = index;
        option.subUrls.forEach((el, i) => {
          if (el === currentSubUrl) {
            subUrlIndex = i;
          }
        });
      }
    });
    const url = GlobalConstants.headerOptions[urlIndex].subUrls[subUrlIndex];
    return url;
  }

  addGroupName(data, type) {
    data.forEach(element => {
      element.all = type;
    });
    return data;
  }

  soryByAlphabet(allData) {
    return allData.sort((a, b) => a.name.localeCompare(b.name));
  }

  getRecordsFormat() {
    const getRecords = document.getElementsByClassName('wk-pagination-results');
    const getTextContent = getRecords[0].textContent;
    const splitTextContent = getTextContent.split(' ');
    const getRecordReportTotalCount = this.numberWithCommas(splitTextContent[0]) + ' ' + splitTextContent[1] + ' '
        + this.numberWithCommas(splitTextContent[2]) + ' ' + splitTextContent[3] + ' ' + this.numberWithCommas(splitTextContent[4]) + ' '
        + splitTextContent[5];
    document.getElementsByClassName('wk-pagination-results')[0].innerHTML = getRecordReportTotalCount;
  }

  numberWithCommas(num) {
    return num.replace(Constants.numberWithComma, ',');
  }

  getFormattedFildsData(fieldsDetails) {
    Object.keys(fieldsDetails).forEach(key => {
      if (fieldsDetails[key] === null) {
        fieldsDetails[key] = '';
      }
    });
    return fieldsDetails;
  }

  isEdittedDataDeleted(editRowId, deletedIds) {
    return  deletedIds.includes(editRowId);
  }
}
