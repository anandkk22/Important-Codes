import { Injectable } from '@angular/core';
import { Constants } from '../infrastructure/constants';
@Injectable()
export class RecordReportUtilityService {

  constructor() { }

  getReportUrl(dateFrom, dateTo, pageNo, pageSize) {
    let url = '';
    url = dateFrom + Constants.reportUrl.dateTo + dateTo + Constants.reportUrl.pageNo + pageNo + Constants.reportUrl.pageSize + pageSize;
    return url.trim();
  }

  addCheckBoxForNotices(recordReportMaster) {
    if (recordReportMaster.gridRowSelected.length > 0) {
      recordReportMaster.paginationData.forEach(element => {
        if (recordReportMaster.gridRowSelected.some(e => e.cnrUserDataV4ID === element.cnrUserDataV4ID)) {
            Object.assign(element, {isSelected: true});
        } else {
            Object.assign(element, {isSelected: false});
        }
      });
    } else {
      recordReportMaster.paginationData.forEach(element => {
        element.isSelected = false;
      });
    }
    return recordReportMaster;
  }

  checkIfAtleastOneSelected(reports) {
    if (reports.gridRowSelected.length === 0) {
      return false;
    } else if (reports.totalCount === reports.gridRowSelected.length) {
      return false;
    } else if ((reports.totalCount > reports.gridRowSelected.length)
                && (reports.gridRowSelected.length > 0)) {
      return true;
    }
  }

  isChecked(data) {
    if (data.gridRowSelected.length === 0) {
      return false;
    } else if (data.totalCount === data.gridRowSelected.length) {
      return true;
    } else if ((data.totalCount > data.gridRowSelected.length)
                && (data.gridRowSelected.length > 0)) {
      return false;
    }
  }

}
