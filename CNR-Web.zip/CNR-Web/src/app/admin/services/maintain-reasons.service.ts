import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { MaintainReasonsConstants } from '../infrastructure/maintain-reasons-constants';

@Injectable()
export class MaintainReasonsService {

  constructor(private http: HttpClient) { }

  public getJurisdictions() {
    return this.http.get(`${MaintainReasonsConstants.webApis.getJurisdictions}`);
  }

  public getLobs(adminMenuItem) {
    return this.http.get(`${MaintainReasonsConstants.webApis.getLobs}`.replace('{adminMenuItem}', adminMenuItem));
  }

  public getActions() {
    return this.http.get(`${MaintainReasonsConstants.webApis.getActions}`);
  }

  public getCircumstances() {
    return this.http.get(`${MaintainReasonsConstants.webApis.getCircumstances}`);
  }

  public getAllmaintainReasons(noticeData) {
    return this.http.post(`${MaintainReasonsConstants.webApis.getAllReasons}`, noticeData);
  }

  public addReason(addData) {
    return this.http.post(`${MaintainReasonsConstants.webApis.addReason}`, addData);
  }

  public deleteReason(deleteData) {
    const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body : deleteData };
    return this.http.delete(`${MaintainReasonsConstants.webApis.deleteReason}`, options );
  }

  public editReason(reasonId, editedText) {
    return this.http.put(`${MaintainReasonsConstants.webApis.editReason}`.replace('{reasonId}', reasonId), editedText);
  }

  public deleteAllReasons(params) {
    const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body : params };
    return this.http.delete(`${MaintainReasonsConstants.webApis.deleteAllReasons}`, options);
  }

}
