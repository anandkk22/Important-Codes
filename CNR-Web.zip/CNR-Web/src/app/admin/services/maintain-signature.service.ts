import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Constants } from '../infrastructure/constants';

@Injectable()
export class MaintainSignatureService {

  constructor(private http: HttpClient) { }

  getJurisdictions() {
    return this.http.get(`${Constants.webApis.getAccountJurisdiction}`);
  }

  getInsurers() {
    return this.http.get(`${Constants.webApis.getAccountInsurers}`);
  }

  getServiceCenters() {
    return this.http.get(`${Constants.webApis.getAllServiceCenter}`);
  }

  getAccountSignatures() {
    return this.http.get(`${Constants.webApis.getAccountSignatures}`);
  }

  getSignatureList(obj) {
    return this.http.post(`${Constants.webApis.getSignatureList}`, obj);
  }

  deleteSignature(signature) {
    const options = { headers: new HttpHeaders().set('Content-Type', 'application/json'), body: this.getDeleteParam(signature) };
    return this.http.delete(`${Constants.webApis.signatureMapped}`, options);
  }

  mapSignature(signatureUploadData) {
    return this.http.post(`${Constants.webApis.signatureMapped}`, signatureUploadData);
  }

  updateSignature(signature) {
    return this.http.put(`${Constants.webApis.signatureMapped}`,  this.updateSignatureParam(signature));
  }

  getMapSignatureParam(selectedJurisdictions, selectedInsures, selectedServiceCenters, selectedMappedSinagute) {
    const param = [];
    const jurisdictionsCodes = this.getCodes(selectedJurisdictions, 'code');
    const insurerCodes = this.getCodes(selectedInsures, 'insurerId');
    const branchids = this.getCodes(selectedServiceCenters, 'id');
    const selectedSignature = [selectedMappedSinagute.graphicFilename];

    jurisdictionsCodes.forEach(element1 => {
      insurerCodes.forEach(element2 => {
        branchids.forEach(element3 => {
          selectedSignature.forEach(element4 => {
            const data = {
              stateCode: element1,
              insurerId: element2,
              branchId: element3,
              graphicFileName: element4
            };
            param.push(data);
          });
        });
      });
    });

    return param;
  }

  getViewLinkReqParams(selectedMappedJurisdictions, selectedMappedInsures,
    selectedMappedServiceCenters, selectedMappedSinagute) {

    const params = {
      graphicFileName: selectedMappedSinagute && selectedMappedSinagute.graphicFilename || null,
      stateCodes: this.getCodes(selectedMappedJurisdictions, Constants.signatureParamNames[0]) || [],
      insurerIds: this.getCodes(selectedMappedInsures, Constants.signatureParamNames[1]) || [],
      branchIds: this.getCodes(selectedMappedServiceCenters, Constants.signatureParamNames[2]) || []
    };

    return params;
  }

  getCodes(selectedValues, key) {
    const codes = [];
    selectedValues.forEach(element => {
      if (element[key]) {
        codes.push(element[key]);
      }
    });
    return codes;
  }

  getDeleteParam(signature) {
    const param = {
      stateCode: signature.stateCode || null,
      insurerId: signature.insurerId || null,
      branchId: signature.branchId || null
    };
    return param;
  }

  getSateCodes(states) {
    const stateCodes = [];
    states.forEach(element => {
      if (element.stateCode && (stateCodes.indexOf(element.stateCode) === -1)) {
        stateCodes.push(element.stateCode);
      }
    });
    return stateCodes;
  }

  updateSignatureParam(signature) {
    const param = {
      stateCode: signature.stateCode || null,
      insurerId: signature.insurerId || null,
      branchId: signature.branchId || null,
      graphicFileName: signature.graphicFileName || null
    };
    return param;
  }

  getGraphicFilename(signaturePath) {
    const spilttedPath = signaturePath.split('\\');
    const mappedSignatureFileName = spilttedPath[spilttedPath.length - 1 ];
    return mappedSignatureFileName;
  }

  getUpdatedSignaturesPath(swippedSignatures, index) {
    let signatureFileName = null;
    swippedSignatures.forEach(element => {
      if (element.index && (element.index === index) && element.signaturesPath) {
        signatureFileName = element.signaturesPath;
      }
    });

    return signatureFileName;
  }

  isSwapped(swippedSignatures, index) {
    const swipdata = {
      isSwipped : false,
      graphicFileName: null
    };

    swippedSignatures.forEach((element) => {
      if ((element.index === 0) && (index === 0)) {
        swipdata.isSwipped = true;
        swipdata.graphicFileName = element.oldMappedSignature;
      }
      else if (element.index && (element.index === index)) {
        swipdata.isSwipped = true;
        swipdata.graphicFileName = element.oldMappedSignature;
      }
    });

    return swipdata;
  }

}

