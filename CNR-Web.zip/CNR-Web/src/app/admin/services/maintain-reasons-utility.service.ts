import { Injectable } from '@angular/core';

@Injectable()
export class MaintainReasonsUtilityService {


  collectWKDefaultRow(all) {
      const onlyCheckBox = [];
      all.forEach(element => {
        if (!element.wkDefaultRow) {
          onlyCheckBox.push(element);
        }
      });
      return onlyCheckBox;
  }

  allCheckBoxToChecked(grid) {
    grid.forEach(element => {
        if (element.wkDefaultRow) {
          element.isDefaults = true;
        }
      });
    return grid;
  }

  isDataAvailable(allJurisdictions, allActions, allLobs, allCircumstances) {
    return allJurisdictions.length === 0 || allActions.length === 0 || allLobs.length === 0
     || allCircumstances.length === 0 ? false : true;
  }

  isAtleastOne(rowSelected, wkDefaultRow) {
    if (rowSelected.length === 0) {
      return false;
    } else if (wkDefaultRow.length === rowSelected.length) {
      return false;
    } else if (rowSelected.length > 0 && rowSelected.length < wkDefaultRow.length) {
      return true;
    }
  }

  isAllChecked(selected, defaultRow) {
    if (selected.length === 0) {
      return false;
    } else if (defaultRow.length === selected.length) {
      return true;
    } else if (selected.length > 0 && selected.length < defaultRow.length) {
      return false;
    }
  }

  checkValidReasonEdit(text) {
    const editedText = text.trim();
    if (editedText === '') {
      return true;
    }
    return false;
  }

  scrollToState(state) {
    document.getElementById(state).scrollIntoView({
      behavior: 'smooth',
      block: 'start',
      inline: 'nearest'
    });
  }
}
