import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import '@wk/components/dist/accordion';
import { AppConstants } from 'app/app.constants';
import { SharedDataService } from '@global';
import { DefaultSettings } from 'app/admin/infrastructure/models/default-settings.model';
import { AdminMenuService } from 'app/admin/services/admin-menu.service';
import { Title } from '@angular/platform-browser';
import { Constants } from '@global/infrastructure/constants';
import { PopupService, SpinnerService } from '@wk/nils-core';
@Component({
  selector: 'app-admin-menu',
  templateUrl: './admin-menu.component.html',
  styleUrls: ['./admin-menu.component.scss']
})
export class AdminMenuComponent implements OnInit {
  cnrv4Api = this.translate.instant('ADMIN_PANEL_SCREEN.MAINTAIN_SETTINGS.Maintain_api_token_subscription.CNRV4_API');
  recordsReportLink = AppConstants.uiRoutes.recordsReport;
  userMaintenanceLink = AppConstants.userMaintenancePageLink;
  defeaultSettingsResponse = null;
  isDataAvaliable: Boolean = false;
  maintainPartiesRouterLinks = [AppConstants.uiRoutes.additionalInterests, AppConstants.uiRoutes.certificateholders,
    AppConstants.uiRoutes.insurers, AppConstants.uiRoutes.lienHolders, AppConstants.uiRoutes.mortgagees,
    AppConstants.uiRoutes.producers, AppConstants.uiRoutes.serviceCenters];
  signatureFilesRouterLinks = [AppConstants.uiRoutes.signatureFiles, AppConstants.uiRoutes.signatureMappings];
  purgeOptionsRouterLinks = [AppConstants.uiRoutes.purgeParameters, AppConstants.uiRoutes.purgeMailLog];
  maintainSettingsRouterLinks = [AppConstants.maintainApiToken,  AppConstants.uiRoutes.customFooters, AppConstants.uiRoutes.customizedLOB,
  AppConstants.uiRoutes.daysNoticeRequirements, AppConstants.uiRoutes.defaultSettings, AppConstants.uiRoutes.editionsByJurisdiction,
  AppConstants.uiRoutes.maintainReasons
  ];
  isPurgeMailLogAvailable: Boolean = false;

  constructor(private translate: TranslateService,
    private sharedDataService: SharedDataService,
    private adminMenuService: AdminMenuService,
    private titleService: Title,
    private popupService: PopupService,
    private spinnerService: SpinnerService) {
    this.titleService.setTitle(Constants.tabTitles[3]);
  }

  ngOnInit(): void {
    this.getCnrDefaultSettings();
  }

  getCnrDefaultSettings() {
    this.adminMenuService.getCnrDefaultSettings().subscribe(res => {
      if (res === null) {
        this.getDefaultSettingsDetails();
      }
    });
  }

  checkApiSubscription() {
    const userInfo: any = this.sharedDataService.getUserInfo();
    return userInfo.subscriptions.includes(this.cnrv4Api) ? true : false;
  }

  doNavigation() {
    window.open(AppConstants.maintainApiToken);
  }

  getDefaultSettingsDetails() {
    this.adminMenuService.getDefaultSettings().subscribe((res: DefaultSettings) => {
      if (res) {
        this.adminMenuService.defaultSettingData = res;
        this.defeaultSettingsResponse = res;
        this.isPurgeMailLogAvailable = this.defeaultSettingsResponse && this.defeaultSettingsResponse.mailLogEnabled;
        this.isDataAvaliable = true;
      }
    }, async (error) => {
      const message = error.error.Message;
      this.showAlert(message);
      this.spinnerService.stop();
    });
  }

  showAlert(message) {
    this.popupService.showAlert({
      title: this.translate.instant('MESSAGES.Confirmation.alertTitle'),
      message: message,
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: '',
    });
  }


}
