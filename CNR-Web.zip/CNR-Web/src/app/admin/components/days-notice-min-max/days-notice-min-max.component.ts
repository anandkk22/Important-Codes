import { Component, OnInit, Input } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Constants } from 'app/admin/infrastructure/constants';
import { TranslateService } from '@ngx-translate/core';
import { DaysNoticeRequirementsService } from 'app/admin/services/days-notice-requirements.service';
import { PopupService } from '@wk/nils-core';
import { Title } from '@angular/platform-browser';
import { Constants as GlobalConstant } from '@global/infrastructure/constants';

@Component({
  selector: 'days-notice-min-max',
  templateUrl: './days-notice-min-max.component.html',
  styleUrls: ['./days-notice-min-max.component.scss']
})
export class DaysNoticeMinMaxComponent implements OnInit {
  @Input() data;
  daysHeading: any;
  daysFormName: any;
  daysFieldError: any;
  responseError: any;
  daysView = false;
  errorView = false;
  failedRows = [];
  sucessView = false;
  viewRecordsView = false;
  unsucessfulRecords: any;
  sucessfulRecords: any;
  totalRequestRecords: any;
  viewText: any;
  public daysMinMaxForm: FormGroup = new FormGroup({
    daysMinMax: new FormControl('', [Validators.required]),
  });
  isClickedMinMAxDays = false;
  selectedRows = [];
  isAddMinMaxHeadeing = false;
  isAddMinMax = false;

  constructor(
    public activeModal: NgbActiveModal,
    private translate: TranslateService,
    private daysService: DaysNoticeRequirementsService,
    private popupService: PopupService,
    private titleService: Title) {
        this.titleService.setTitle(GlobalConstant.tabTitles[15]);
    }

  ngOnInit(): void {
    if (this.data.daysType === Constants.editDaysType.addMinMax) {
      this.failedRows = this.data.unsuccessfulDaysNotices;
      this.unsucessfulRecords = this.data.totalUnsucessfulRecords || 0;
      this.sucessfulRecords = this.data.totalRequestRecords - this.data.totalUnsucessfulRecords || 0;
      if (this.failedRows.length === 0) {
        this.popupService.showSuccess({
          title: '',
          message: this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.added_Days_Notice_Requirements'),
          positiveLabel: this.translate.instant('BUTTON.ok_button'),
          negativeLabel: '',
      });
      } else {
      this.viewText = this.daysService.getViewText(this.unsucessfulRecords);
      this.isAddMinMaxHeadeing = true;
      this.isAddMinMax = true;
      }
    }
    else {
      this.daysView = true;
      this.errorView = false;
      this.isClickedMinMAxDays = false;
      if (this.data.daysType === Constants.editDaysType.minDays) {
        this.daysHeading = this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.edit_min_days_heading');
        this.daysFormName = this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.minimum_days_field_name');
        this.daysFieldError = this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.minimum_days_field_error');
      }
      else {
        this.daysHeading = this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.edit_max_days_heading');
        this.daysFormName = this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.maximum_days_field_name');
        this.daysFieldError = this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.maximum_days_field_error');
      }
    }
  }

  numberOnly(event): boolean {
    return this.daysService.numberOnly(event);
  }
  updatedMinMAxDays() {
    this.isClickedMinMAxDays = true;
    if (this.daysMinMaxForm.valid) {
      const updateData = this.daysService.getFormatedUpdateDays(this.data, this.daysMinMaxForm.value.daysMinMax);
      this.daysService.updateDaysNotices(updateData).subscribe(res => {
        if (res) {
          this.daysView = false;
          this.responseError = res;
          this.failedRows = this.responseError.unsuccessfulDaysNotices;
          this.unsucessfulRecords = this.responseError.totalUnsucessfulRecords;
          this.totalRequestRecords = this.responseError.totalRequestRecords;
          this.sucessfulRecords = this.totalRequestRecords - this.unsucessfulRecords;
          this.viewText = this.daysService.getViewText(this.unsucessfulRecords);
          if (this.responseError && this.sucessfulRecords === this.totalRequestRecords) {
            this.sucessView = true;
          } else {
            this.errorView = true;
          }
        }
      });
    }
  }

  clearMinMAxDays() {
    this.daysMinMaxForm.get('daysMinMax').setValue('');
    this.isClickedMinMAxDays = false;
  }

  cancelUpdate() {
    this.activeModal.close(Constants.editDaysReload.noReload);
  }

  cancelViewRecords() {
    this.failedRows = [];
    this.activeModal.close(Constants.editDaysReload.reload);
  }

  successOk() {
    this.activeModal.close(Constants.editDaysReload.reload);
  }

  viewRecords() {
    this.errorView = false;
    this.viewRecordsView = true;
    this.isAddMinMax = false;
  }

}
