import { Component, OnInit } from '@angular/core';
import { AppConstants } from 'app/app.constants';
import '@wk/components/dist/accordion';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AdminMenuService } from 'app/admin/services/admin-menu.service';
import { DefaultSettingOption, DefaultSettings, MailTypes } from 'app/admin/infrastructure/models/default-settings.model';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import { Constants } from '../../infrastructure/constants';
import { Title } from '@angular/platform-browser';
import { Constants as GlobalConstant } from '@global/infrastructure/constants';

@Component({
    selector: 'app-default-account-settings',
    templateUrl: './default-account-settings.component.html',
    styleUrls: ['./default-account-settings.component.scss']
})
export class DefaultAccountSettingsComponent implements OnInit {
    backToPrevious = '/' + AppConstants.uiRoutes.adminMenu;
    defaultSettingForm: FormGroup;
    mailTypes: MailTypes[] = [];
    mailCertiOptions = [];
    defaultMailTypeSettings: DefaultSettingOption[] = [];
    producerSettings: DefaultSettingOption[] = [];
    miscSettings: DefaultSettingOption[] = [];
    defaultSetting = this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.SUB_HEADING.default_setting');
    producersCopy: number;
    produerData: number;
    defautlSettingArray = [...Constants.defautlSettingOptions];
    constructor(
        private router: Router,
        private fb: FormBuilder,
        private adminMenuService: AdminMenuService,
        private translate: TranslateService,
        private popupService: PopupService,
        private titleService: Title) {
        this.titleService.setTitle(GlobalConstant.tabTitles[16]);
    }

    ngOnInit(): void {
        this.mailTypes = Constants.mailTypes;
        this.createSearchForm();
        if (this.adminMenuService.defaultSettingData) {
            this.createDefaultSettingData();
        } else {
            this.getDefaultSettings();
        }

        this.getMailingCertificateOptions();
        this.getDefaultMailTypeSettings();
        this.getProducerSettings();
        this.getMiscSettings();
    }

    createSearchForm() {
        this.defaultSettingForm = this.fb.group(
            Constants.AccountSettingsFormObject
        );
    }

    createDefaultSettingData() {
        this.defautlSettingArray.forEach(item => {
            if (item) {
                this.defaultSettingForm.get(item).setValue(this.adminMenuService.defaultSettingData[item]);
            }
        });
    }

    navigateToPrevious() {
        this.router.navigate([AppConstants.uiRoutes.adminMenu]);
    }

    getDefaultSettings() {
        this.adminMenuService.defaultSettingData = [];
        this.adminMenuService.getDefaultSettings().subscribe((res: DefaultSettings) => {
            this.adminMenuService.defaultSettingData = res;
            this.createDefaultSettingData();
        });
    }

    getMailingCertificateOptions() {
        this.mailCertiOptions = [
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.insured'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.insured_control_name')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.producer'),
                controlName:
                    this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.producer_control_name')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.mortgagee'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.mortgagee_control_name')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.lien_holder'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.lien_holder_control_name')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.certified_holder'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.certified_holder_control_name')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.additional_interest'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.additional_interest_control_name')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.third_party'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MAILING_CERTIFICATE_OPTIONS.third_party_control_name')
            }
        ];
        return this.mailCertiOptions.sort(this.sortFieldName);
    }

    getDefaultMailTypeSettings() {
        this.defaultMailTypeSettings = [
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.insured'),
                controlName:
                    this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.insured_control_name'),
                controlOptions: this.mailTypes.length - 1,
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.producer'),
                controlName:
                    this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.producer_control_name'),
                controlOptions: this.mailTypes.length,
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.mortgagee'),
                controlName:
                    this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.mortgagee_control_name'),
                controlOptions: this.mailTypes.length - 1,
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.lien_holder'),
                controlName:
                    this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.lien_holder_control_name'),
                controlOptions: this.mailTypes.length - 1,
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.certificate_holder'),
                controlName:
                this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.certificate_holder_control_name'),
                controlOptions: this.mailTypes.length - 1,
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.additional_interest'),
                controlName:
                    this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.additional_interest_control_name'),
                controlOptions: this.mailTypes.length - 1,
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.superint_insurance'),
                controlName:
                this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.superint_insurance_control_name'),
                controlOptions: this.mailTypes.length - 1,
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.third_party'),
                controlName:
                    this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.third_party_control_name'),
                controlOptions: this.mailTypes.length - 1,
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.worker_compensation'),
                controlName:
                    this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.worker_compensation_control_name'),
                controlOptions: this.mailTypes.length - 1,
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.assigned_risk_plan'),
                controlName:
                this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.assigned_risk_plan_control_name'),
                controlOptions: this.mailTypes.length - 1,
            }
        ];
        const defaultMailTypeSet = this.defaultMailTypeSettings.sort(this.sortFieldName);
        this.findProducerCopy();
        return defaultMailTypeSet;
    }

    getProducerSettings() {
        this.producerSettings = [
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.PRODUCER_SETTINGS.producer_code_lookup'),
                controlName:
                    this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.PRODUCER_SETTINGS.producer_code_lookup_control_name')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.PRODUCER_SETTINGS.lookup_producer_mail_log'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.PRODUCER_SETTINGS.lookup_producer_mail_log_control_name')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.PRODUCER_SETTINGS.print_producer_code'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.PRODUCER_SETTINGS.print_producer_code_control_name')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.PRODUCER_SETTINGS.required_producer_info'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.PRODUCER_SETTINGS.required_producer_info_control_name')
            }
        ];
        const producerSet = this.producerSettings.sort(this.sortFieldName);
        this.findProducerData();
        return producerSet;
    }

    getMiscSettings() {
        this.miscSettings = [
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.enableMailLog'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.enableMailLogControlName')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.lieuOfCarrier'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.lieuOfCarrierControl')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.printTypist'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.printTypistControlName')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.requireInsurerAddress'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.requireInsurerAddressControlName')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.userServiceCenter'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.userServiceCenterControlName')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.generateEnvlopPages'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.generateEnvlopPagesControlName')
            },
            {
                name: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.displayAllFormFields'),
                controlName: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MISC_SETTINGS.displayAllFormFieldsControlName')
            }
        ];
        return this.miscSettings.sort(this.sortFieldName);
    }

    reset() {
        this.getDefaultSettings();
    }

    sortFieldName(a, b) {
        return (a.name > b.name) ? 1 : ((b.name > a.name) ? -1 : 0);
    }

    findProducerCopy() {
        this.producersCopy = this.defaultMailTypeSettings.findIndex(ele => ele.name === this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.DEFAULT_MAIL_TYPE_SETTINGS.producer'));
    }

    findProducerData() {
        this.produerData = this.producerSettings.findIndex(ele => ele.name === this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.PRODUCER_SETTINGS.producer_code_lookup'));
    }

    onSubmit() {
        this.adminMenuService.updateDefaultSettings(this.defaultSettingForm.value).subscribe(res => {
            if (!res) {
                this.popupService.showSuccess({
                    title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
                    message: this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.HEADING') + this.translate.instant('ADMIN_MENUS.DEFAULT_ACCOUNT_SETTINGS.MESSAGES.update_message'),
                    positiveLabel: this.translate.instant('BUTTON.ok_button'),
                    negativeLabel: '',
                });
            }
        });
    }
}
