import { Component, OnDestroy, OnInit, Input } from '@angular/core';
import { environment } from '@env';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { TranslateService } from '@ngx-translate/core';
import { Constants } from 'app/admin/infrastructure/constants';

@Component({
  selector: 'map-signature-confirmation-modal',
  templateUrl: './map-signature-confirmation-modal.component.html',
  styleUrls: ['./map-signature-confirmation-modal.component.scss']
})
export class MapSignatureConfirmationModalComponent implements OnInit {
  @Input() data;
  mappedRecordsModal: Boolean = false;
  mappedConfimationModal: Boolean = false;
  sucessfulMappedRecords = '';
  unsucessfulMappRecords = '';
  isSucessfullyMappedGrid = false;
  isUnSucessfullyMappedGrid = false;
  mappedFilename = null;

  constructor(
    public activeModal: NgbActiveModal,
    private translate: TranslateService
  ) { }

  ngOnInit(): void {
    this.openModal();
  }

  openModal() {
    this.mappedConfimationModal = true;
    if (this.data.added.length > 0) {
      this.sucessfulMappedRecords = this.data.added.length > 1 ? this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.multipule_signature_mapped',
      { fileName: this.data.fileName, recordCount: this.data.added.length }) : this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.single_signature_mapped',
      { fileName: this.data.fileName, recordCount: this.data.added.length });
      this.mappedFilename = Constants.webApis.openImageFile.replace('{signatureFileName}', this.data.fileName);
    }

    if (this.data.existing.length > 0) {
      this.unsucessfulMappRecords = this.data.existing.length > 1 ? this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.multipule_signature_not_mapped',
      { fileName: this.data.fileName, recordCount: this.data.existing.length }) : this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.single_signature_not_mapped',
      { fileName: this.data.fileName, recordCount: this.data.existing.length });
    }
    this.isUnSucessfullyMappedGrid = this.data.existing.length > 0 && this.data.added.length === 0 ? true : false;
    this.isSucessfullyMappedGrid =  this.data.added.length > 0 ? true : false;
  }

  sucessfullyMapped() {
    this.isSucessfullyMappedGrid = true;
    this.isUnSucessfullyMappedGrid = false;
  }

  unsucessfullyMapped() {
    this.isUnSucessfullyMappedGrid = true;
    this.isSucessfullyMappedGrid = false;
  }

  viewRecords() {
    this.mappedConfimationModal = false;
    this.mappedRecordsModal = true;
  }

  cancelViewRecords() {
    this.activeModal.close(true);
  }

  close() {
    this.activeModal.close(true);
  }


}
