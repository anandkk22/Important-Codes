import { Component, OnDestroy, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import { Constants } from 'app/admin/infrastructure/constants';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { MaintainSignatureService } from 'app/admin/services/maintain-signature.service';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { Constants as GlobalConstant } from '@global/infrastructure/constants';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SignatureMappedModalComponent } from '../signature-mapped-modal/signature-mapped-modal.component';

@Component({
  selector: 'signature-lists',
  templateUrl: './signature-lists.component.html',
  styleUrls: ['./signature-lists.component.scss'],
  providers: [MaintainSignatureService]
})
export class SignatureListsComponent implements OnInit, OnDestroy {
  activeSubscription: Subscription;
  maintainSignatureParams;
  isDataAvaliable: Boolean = false;
  signatureLists = [];
  stateCodes = [];
  mentainSignatureResultUrl = this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.mentainSignatureResultUrl');
  signaturesPath = null;
  swippedIndex = -1;
  clickedItemIindex = -1;
  selectedRowIndex = -1;
  swippedSignatures = [];
  paginationOptions = {
    currentPage: Constants.signatureMappingPaginationDetails.pageNo,
    pageSize: Constants.signatureMappingPaginationDetails.pageSize
  };
  signatureMappingRes: any = {
    pageNo: Constants.signatureMappingPaginationDetails.pageNo,
    pageSize: Constants.signatureMappingPaginationDetails.pageSize,
    totalCount: Constants.signatureMappingPaginationDetails.totalCount,
    isDataPaginated: false,
    paginationData: []
  };
  selectedState = null;
  isFilterApplied: Boolean = false;
  maintainSignatureReqParams = null;
  allStates = [];
  pageSizeDropdown: HTMLElement;
  isPaginationClicked: Boolean = false;
  isLoading: Boolean = false;
  copySignatureMappingRes = [];

  constructor(
    private maintainSignatureService: MaintainSignatureService,
    private adminMenuUtilityService: AdminMenuUtilityService,
    private translate: TranslateService,
    private router: Router,
    private popupService: PopupService,
    private titleService: Title,
    private modalService: NgbModal
    ) {
      this.titleService.setTitle(GlobalConstant.tabTitles[21]);
      this.activeSubscription = router.events.subscribe((event) => {
        if ((event instanceof NavigationEnd) && (event.id === 1) && (event.url === event.urlAfterRedirects)) {
          this.navigateToSignatureMapping();
        }
      });
    }

  ngOnInit(): void {
    this.adminMenuUtilityService.maintainSignatureParams?.pipe(take(1)).subscribe(obj => {
      this.maintainSignatureReqParams = obj;
      this.getSignatureList(this.maintainSignatureReqParams, true);
    });
  }

  getSignatureList(signatureParams, isInitialload) {
    this.isLoading = true;
    const params = {
      ...signatureParams,
      'paging': {
        'pageNo': this.signatureMappingRes.pageNo,
        'pageSize': this.signatureMappingRes.pageSize
      }
    };
    this.activeSubscription = this.maintainSignatureService.getSignatureList(params).subscribe((res: any) => {
      if (res) {
        this.isLoading = false;
        this.isPaginationClicked = false;
        this.signatureMappingRes.paginationData = res.paginationData;
        this.copySignatureMappingRes = JSON.parse(JSON.stringify(res.paginationData));
        this.signatureMappingRes.totalCount = res.totalCount;
        this.signatureMappingRes.isDataPaginated =
        res.totalCount > Constants.signatureMappingPaginationDetails.pageSize ? true : false;
        this.loadUpadtedPageSizes();
       if (isInitialload) {
        this.stateCodes = [...res.stateCodes];
        this.stateCodes.push(Constants.all);
        this.allStates =  [...res.stateCodes];
       }
        this.isDataAvaliable = true;
      }
    });
  }

  navigateToSignatureMapping() {
    const maintainSignatureRoute = this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.mentainSignatureUrl');
    this.router.navigate([maintainSignatureRoute]);
  }

  deleteSignature(signature) {
    const signatureFileName = signature.graphicFileName;
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
      message: this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.deleteSignature',
        { signatureFileName: signatureFileName }),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.activeSubscription = this.maintainSignatureService.deleteSignature(signature).subscribe((response: any) => {
          this.adminMenuUtilityService.showSucessModal(this.translate.instant('MESSAGES.ALERT.deleted_record'));
          this.clickedItemIindex = -1;
          this.reloadSignatureGrid();
        });
      }
    });
  }

  reloadSignatureGrid() {
    if (this.isFilterApplied) {
      const filterParam = this.maintainSignatureReqParams;
      filterParam.stateCodes = [this.selectedState];
      this.getSignatureList(filterParam, false);
    } else {
      const filterParam = this.maintainSignatureReqParams;
      filterParam.stateCodes = this.allStates;
      this.getSignatureList(this.maintainSignatureReqParams, false);
    }
  }

  getSignaturePath(graphicFilename) {
    return graphicFilename ? Constants.webApis.openImageFile.replace('{signatureFileName}', graphicFilename) : '';
  }

  updateSignature(signature, index) {
    const swipdata: any = this.maintainSignatureService.isSwapped(this.swippedSignatures, index);
    const isIndexValid = this.swippedIndex !== -1 ? true : false;
    if ( isIndexValid && this.signaturesPath && swipdata.isSwipped) {
      const newSignatureFileName = signature.graphicFileName;
      this.popupService.showConfirmation({
        title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
        message: this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.updateSignature',
          { oldSignatureFileName: this.copySignatureMappingRes[index].graphicFileName, newSignatureFileName: newSignatureFileName }),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: this.translate.instant('BUTTON.cancel_button'),
      }).pipe(take(1)).subscribe(res => {
        if (res) {
          signature.graphicFileName = newSignatureFileName;
          this.activeSubscription = this.maintainSignatureService.updateSignature(signature).subscribe((response: any) => {
            if (response) {
              this.adminMenuUtilityService.showSucessModal(this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.updateConfirmation'));
              this.clickedItemIindex = -1;
              this.swippedSignatures = [];
              this.reloadSignatureGrid();
            }
          });
        }
      });
    } else {
      this.adminMenuUtilityService.showAlert(this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.validate_update_signature'));
    }
  }

  swipeSignature(graphicFileName, i, oldMappedSignature) {
    this.signaturesPath = graphicFileName;
    this.swippedIndex = i;
    const signature = {
      signaturesPath : this.signaturesPath,
      index: this.swippedIndex,
      oldMappedSignature: oldMappedSignature
    };
    this.swippedSignatures.push(signature);
    this.signatureMappingRes.paginationData.forEach((signatue, index) => {
      if ((index === i) && (signatue.graphicFileName)) {
        signatue.graphicFileName = graphicFileName;
      }
    });
  }

  showIcon(j, i) {
    this.selectedRowIndex = i;
    this.clickedItemIindex = j;
  }

  filterSignatureMapping (stateCode) {
    if (stateCode === Constants.all) {
      this.selectedState = null;
      this.isFilterApplied = false;
      this.reloadSignatureGrid();
    } else {
      this.selectedState = stateCode;
      this.isFilterApplied = true;
      this.reloadSignatureGrid();
    }
  }

  onPageClick(event) {
    this.isPaginationClicked = true;
    this.manipulatePageSizes();
    const detail = event.detail;
    this.signatureMappingRes.pageNo = detail;
    this.loadUpadtedPageSizes();
    this.reloadSignatureGrid();
    setTimeout(() => {
      this.adminMenuUtilityService.getRecordsFormat();
    }, 0);
  }

  pageSizeChange(event) {
    this.isPaginationClicked = true;
    this.manipulatePageSizes();
    const detail = event.detail;
    this.signatureMappingRes.pageSize = detail;
    this.signatureMappingRes.pageNo = 1;
    this.loadUpadtedPageSizes();
    this.reloadSignatureGrid();
    setTimeout(() => {
      this.adminMenuUtilityService.getRecordsFormat();
    }, 0);
  }

  manipulatePageSizes() {
    setTimeout(function () {
      this.adminMenuUtilityService.addMorePageSizes();
    }.bind(this));
  }

  openMappedSignature(graphicFileName) {
    const modalRef = this.modalService.open(SignatureMappedModalComponent);
    modalRef.componentInstance.graphicFileName = graphicFileName;
  }

  loadUpadtedPageSizes() {
    setTimeout(function () {
      this.pageSizeDropdown = document.querySelector(Constants.dropDownClassName);
      this.addMorePageSizes();
      this.adminMenuUtilityService.getRecordsFormat();
    }.bind(this), 250);
  }

  addMorePageSizes() {
    for (let i = 0; i < Constants.pageSizes.length; i++) {
      this.pageSizeDropdown[i].value = Constants.pageSizes[i].toString();
      this.pageSizeDropdown[i].innerHTML = Constants.pageSizes[i];
    }
  }


  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

}
