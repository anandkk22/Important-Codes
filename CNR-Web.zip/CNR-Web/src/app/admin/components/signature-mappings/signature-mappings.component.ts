import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Constants } from 'app/admin/infrastructure/constants';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { MaintainSignatureService } from 'app/admin/services/maintain-signature.service';
import { AppConstants } from 'app/app.constants';
import { Subscription } from 'rxjs';
import { MapSignatureConfirmationModalComponent } from './map-signature-confirmation-modal/map-signature-confirmation-modal.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Title } from '@angular/platform-browser';
import { Constants as GlobalConstant } from '@global/infrastructure/constants';

@Component({
  selector: 'signature-mappings',
  templateUrl: './signature-mappings.component.html',
  styleUrls: ['./signature-mappings.component.scss'],
  providers: [MaintainSignatureService]
})
export class SignatureMappingsComponent implements OnInit, OnDestroy {
  activeSubscription: Subscription;
  jurisdictions = [];
  insures = [];
  serviceCenters = [];
  accountSignatures = [];
  selectedJurisdictions = [];
  selectedInsures = [];
  selectedServiceCenters = [];
  selectedMappedJurisdictions = [];
  selectedMappedInsures = [];
  selectedMappedServiceCenters = [];
  selectedSinagute = null;
  selectedSinaguteLabel = this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.selectSignatureFile');
  selectedMappedSinagute = null;
  selectedMappedSinaguteLabel = this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.selectSignatureFile');
  mentainSignatureUrl = this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.mentainSignatureUrl');


  constructor(
    private maintainSignatureService: MaintainSignatureService,
    private adminMenuUtilityService: AdminMenuUtilityService,
    private translate: TranslateService,
    private router: Router,
    private modalService: NgbModal,
    private titleService: Title) {
        this.titleService.setTitle(GlobalConstant.tabTitles[21]);
    }

  ngOnInit(): void {
    this.getInitialData();
  }

  getInitialData() {
    this.getJurisdiction();
    this.getInsurer();
    this.getServiceCenters();
    this.getAccountSignatures();
  }

  getJurisdiction() {
    this.activeSubscription = this.maintainSignatureService.getJurisdictions().subscribe((res: any) => {
      this.jurisdictions = this.adminMenuUtilityService.addGroupName(res, Constants.maintainSignature.allJurisdictions);
    });
  }

  getInsurer() {
    this.activeSubscription = this.maintainSignatureService.getInsurers().subscribe((res: any) => {
      this.insures = this.adminMenuUtilityService.addGroupName(res.paginationData, Constants.maintainSignature.allInsurers);
    });
  }

  getServiceCenters() {
    this.activeSubscription = this.maintainSignatureService.getServiceCenters().subscribe((res: any) => {
      const serviceCentersOrder = this.adminMenuUtilityService.soryByAlphabet(res.paginationData);
      this.serviceCenters = this.adminMenuUtilityService.addGroupName(serviceCentersOrder, Constants.maintainSignature.allServiceCenters);
    });
  }

  getAccountSignatures() {
    this.activeSubscription = this.maintainSignatureService.getAccountSignatures().subscribe((res: any) => {
      if (res) {
        this.accountSignatures = res;
      }
    });
  }

  isDataAvaliable() {
    return this.jurisdictions.length > 0 && this.insures.length > 0 && this.serviceCenters.length > 0 &&
      this.accountSignatures.length > 0 ? true : false;
  }

  onSignatureChanged(signature) {
    this.selectedSinagute = signature;
    this.selectedSinaguteLabel = signature.graphicFilename;
  }

  onMappedSignatureChanged(signature) {
    this.selectedMappedSinagute = signature;
    this.selectedMappedSinaguteLabel = signature.graphicFilename;
  }

  isValid() {
    return this.selectedJurisdictions.length === 0 || this.selectedInsures.length === 0 ||
      this.selectedServiceCenters.length === 0 || this.selectedSinagute === null ? true : false;
  }

  resetSignatures() {
    this.selectedJurisdictions = [];
    this.selectedInsures = [];
    this.selectedServiceCenters = [];
    this.selectedSinagute = null;
    this.selectedSinaguteLabel = this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.selectSignatureFile');
  }

  resetViewLinks() {
    this.selectedMappedJurisdictions = [];
    this.selectedMappedInsures = [];
    this.selectedMappedServiceCenters = [];
    this.selectedMappedSinagute = null;
    this.selectedMappedSinaguteLabel = this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.selectSignatureFile');
  }

  onClickViewLink() {
    const signatureDetails = this.maintainSignatureService.getViewLinkReqParams(this.selectedMappedJurisdictions,
      this.selectedMappedInsures, this.selectedMappedServiceCenters, this.selectedMappedSinagute);
    this.routeToSignatureGridPage(signatureDetails);
  }

  routeToSignatureGridPage(signatureDetails) {
    this.adminMenuUtilityService.maintainSignatureParams.next(signatureDetails);
    const signatureResultRoute = this.translate.instant('ADMIN_MENUS.MAINTAIN_SIGNATURES.mentainSignatureResultUrl');
    this.router.navigate([signatureResultRoute]);
  }

  mapSignature() {
    const signatureUploadData = this.maintainSignatureService.getMapSignatureParam(this.selectedJurisdictions, this.selectedInsures,
      this.selectedServiceCenters, this.selectedSinagute);
    this.activeSubscription = this.maintainSignatureService.mapSignature(signatureUploadData).subscribe((res: any) => {
      if (res) {
        const modalRef = this.modalService.open(MapSignatureConfirmationModalComponent);
        modalRef.componentInstance.data = res;
        modalRef.result.then((userResponse) => {
          if (userResponse) {
            this.resetSignatures();
          }
        });
      }
    });
  }

  navigateToPrevious() {
    this.router.navigate([AppConstants.uiRoutes.adminMenu]);
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

}
