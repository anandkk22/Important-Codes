import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Constants } from 'app/admin/infrastructure/constants';

@Component({
  selector: 'app-signature-mapped-modal',
  templateUrl: './signature-mapped-modal.component.html',
  styleUrls: ['./signature-mapped-modal.component.scss']
})
export class SignatureMappedModalComponent implements OnInit {
  @Input() graphicFileName;
  isFileNamePresent: Boolean = false;

  constructor(
    public activeModal: NgbActiveModal) { }

  ngOnInit() {
    this.isFileNamePresent = this.graphicFileName ? true : false;
  }

  getSignaturePath(graphicFilename) {
    return graphicFilename ? Constants.webApis.openImageFile.replace('{signatureFileName}', graphicFilename) : '';
  }

  closeModal() {
    this.activeModal.close();
  }

}
