import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Constants } from '@global/infrastructure/constants';
import { TranslateService } from '@ngx-translate/core';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { PurgeParametrService } from 'app/admin/services/purge-parameter.service';
import { AppConstants } from 'app/app.constants';
import { Subscription } from 'rxjs';
import { Title } from '@angular/platform-browser';

@Component({
    selector: 'app-configure-purge-parameters',
    templateUrl: './configure-purge-parameters.component.html',
    styleUrls: ['./configure-purge-parameters.component.scss'],
    providers: [PurgeParametrService]
})

export class ConfigurePurgeParametersComponent implements OnInit, OnDestroy {

    activeSubscription: Subscription;
    purgeParameterDetails: any;
    purgeParameterForm: FormGroup;
    isDataAvaliable: Boolean = false;
    isOn: Boolean = true;
    isReadOnly = true;
    purgeParameterUrl =  this.translate.instant('ADMIN_MENUS.PURGE_PARAMETERS.purgeUrl');

    constructor(private purgeParametrService: PurgeParametrService,
        private router: Router,
        private fb: FormBuilder,
        private translate: TranslateService,
        private adminMenuUtilityService: AdminMenuUtilityService,
        private titleService: Title) {
            this.titleService.setTitle(Constants.tabTitles[22]);
        }

    ngOnInit() {
        this.createFormControl();
        this.getPurgeParameterDetails();
        this.initPurgeParameterForm();
    }

    createFormControl() {
        this.purgeParameterForm = this.fb.group({
            retationPeriod: [''],
            automaticPurgeFeature: []
        });
    }

    getPurgeParameterDetails() {
        this.activeSubscription = this.purgeParametrService.getPurgeParameterDetails().subscribe(res => {
            if (res) {
                this.purgeParameterDetails = res;
                this.initPurgeParameterForm();
                this.isDataAvaliable = true;
            }
        });
    }

    initPurgeParameterForm() {
        this.purgeParameterForm.patchValue({
            retationPeriod: this.purgeParameterDetails && this.purgeParameterDetails.retentionDays.toString(),
            automaticPurgeFeature: this.purgeParameterDetails && this.purgeParameterDetails.purgeEnabled
        });
        this.isReadOnly = this.purgeParameterDetails && this.purgeParameterDetails.purgeEnabled ? false : true;
    }

    changeRetationPeriod() {
        this.isReadOnly = this.purgeParameterForm.value && this.purgeParameterForm.value.automaticPurgeFeature ? false : true;
    }

    navigateToAdminMenu() {
        this.router.navigate([AppConstants.uiRoutes.adminMenu]);
    }

    savePurgeParameter() {
       const retationPeriodDays = Number(this.purgeParameterForm.value.retationPeriod);
        const isValid = this.purgeParametrService.isRetationValid(this.purgeParameterForm.value, retationPeriodDays);
        if (!isValid) {
            this.adminMenuUtilityService.showAlert(this.translate.instant('ADMIN_MENUS.PURGE_PARAMETERS.validRetentionPeriod'));
            return;
        }
        const purgeParam = {
            acctNum: this.purgeParameterDetails && this.purgeParameterDetails.acctNum,
            retentionDays: this.purgeParameterForm.value && this.purgeParameterForm.value.automaticPurgeFeature ?
                retationPeriodDays : 31,
            purgeEnabled: this.purgeParameterForm.value && this.purgeParameterForm.value.automaticPurgeFeature,
            isRetaintionAdded: false
        };
        if (this.purgeParameterDetails && this.purgeParameterDetails.isRetaintionAdded) {
            this.purgeParametrService.editPurgeParameter(purgeParam).subscribe(res => {
                this.getPurgeParameterDetails();
            });
        } else {
            this.purgeParametrService.addPurgeParameter(purgeParam).subscribe(res => {
                this.getPurgeParameterDetails();
            });
        }
    }

    resetPurgeParameter() {
        this.initPurgeParameterForm();
    }

    ngOnDestroy() {
        this.activeSubscription.unsubscribe();
    }
}
