import { Component, Input, OnChanges, OnInit, Output, EventEmitter, ViewChild, ElementRef } from '@angular/core';
import * as fileSaver from 'file-saver';
import { TranslateService } from '@ngx-translate/core';
import { Constants } from '@global/infrastructure/constants';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'export-excel-file',
  templateUrl: './export-excel.component.html',
  styleUrls: ['./export-excel.component.scss']
})
export class ExportExcelComponent implements OnInit, OnChanges {
  @Input() recordReportInfo;
  @Input() excelSelectedRows;
  @Input() exportExcelClicked: any;
  @Input() masterAccountId;
  @Input() fromDate;
  @Input() toDate;
  @Output() excelDownloaded = new EventEmitter();
  @ViewChild('fileContentRef') fileContentRef: ElementRef;
  imageUrl = '';
  currentYear;
  excelFileName = this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.export_records_report');
  noticeGeneratedViaApiText = this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.notice_generated_via_api');
  today;
  constructor(
    private translate: TranslateService,
  ) { }

  ngOnInit(): void {
    this.today = new Date();
    this.currentYear = this.today.getFullYear();
    const path = environment.cnrPreview ? Constants.cnrPreviewPath : Constants.cnrPath;
    this.imageUrl = environment.portalUrl + path + Constants.webApis.imageUrl;
  }

  ngOnChanges() {
    if (this.exportExcelClicked) {
      this.exportExcel();
    }
  }

  getRecordReportHeading(viaAPI) {
    const recordReports = [
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.service_center'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.jurisdiction'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.action'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.lines_of_business'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.circumstance'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.mail_type'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.typist_initials'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.entered'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.effective'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.mailed'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.policy_number'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_name'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_addr1'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_addr2'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_city'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_jurisdiction'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_postal_code'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_name'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_addr1'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_addr2'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_city'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_jurisdiction'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_postal_code'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_name'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_addr1'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_addr2'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_city'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_jurisdiction'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_postal_code'), },
      { heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.notice_generated_via_api'), },
    ];
    if (!viaAPI) {
      recordReports.splice(recordReports.findIndex(a => a.heading === this.noticeGeneratedViaApiText) , 1);
    }
    return recordReports;
  }



  exportExcel() {
    const fileName = this.excelFileName + this.masterAccountId + Constants.fileTypes.excelExtension;
    setTimeout(() => {
      const formattedHTML = this.getFormattedHtml();
      this.download(formattedHTML, fileName);
    }, );
  }

  download(data, fileName) {
    const blob = new Blob([data], { type: Constants.fileTypes.msexcel });
    fileSaver.saveAs(blob, fileName);
    this.excelDownloaded.emit(true);
  }

  getFormattedHtml() {
    let formattedHTML = null;
    formattedHTML = this.fileContentRef.nativeElement;
    return formattedHTML.innerHTML;
  }

  keepZero(val) {
    if ((typeof val === 'string') && (val.charAt(0) === '0')) {
      const modified = Constants.keepLeadingZero.start + val + Constants.keepLeadingZero.end;
      return modified;
    } else {
      return (val === null || val === '') ? Constants.keepLeadingZero.empty : val;
    }
  }

}
