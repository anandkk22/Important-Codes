import { Component, OnInit, ViewChild } from '@angular/core';
import { DaysNoticeRequirementsService } from 'app/admin/services/days-notice-requirements.service';
import { NgSelectComponent } from '@ng-select/ng-select';
import { Router } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { Constants } from 'app/admin/infrastructure/constants';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { PopupService} from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { take } from 'rxjs/operators';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DaysNoticeMinMaxComponent } from 'app/admin/components/days-notice-min-max/days-notice-min-max.component';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { Title } from '@angular/platform-browser';
import { Constants as GlobalConstant } from '@global/infrastructure/constants';
import { environment } from '@env';
@Component({
  selector: 'app-days-notice-requirements',
  templateUrl: './days-notice-requirements.component.html',
  styleUrls: ['./days-notice-requirements.component.scss']
})
export class DaysNoticeRequirementsComponent implements OnInit {
  @ViewChild('selecter') ngselect: NgSelectComponent;
  allJurisdictions = [];
  selectedJurisdictions = [];
  allActions = [];
  selectedActions = [];
  allLobs = [];
  selectedLobs = [];
  allCircumstances = [];
  selectedCircumstances = [];
  allDaysNotices = [];
  filterJurisdiction = [];
  public daysNoticeForm: FormGroup = new FormGroup({
    defaults: new FormControl('1', [Validators.required]),
    daysNotice: new FormControl('', [Validators.required]),
    daysNoticeMax: new FormControl(''),
  });
  isAtleastOneRowSelected = false;
  isAllChecked = false;
  noticesGridRowSelected = [];
  collectionOfGridWithCheckBoxOnly = [];
  isClickedDisplay = false;
  isClickedAddDays = false;
  isFoundFilterData = false;
  isGreaterThanMinimumDays = false;
  isBulkDelete = false;
  displayFormType = Constants.daysNoticeFormType.display;
  addFormType = Constants.daysNoticeFormType.addDays;
  mindays = Constants.editDaysType.minDays;
  maxdays = Constants.editDaysType.maxDays;
  single = Constants.editDaysType.single;
  multiple = Constants.editDaysType.multiple;
  addDaysColumn = false;
  daysParameterUrl =  this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.days_notice_url');
  constructor(
    private daysService: DaysNoticeRequirementsService,
    private router: Router,
    private popupService: PopupService,
    private translate: TranslateService,
    private modalService: NgbModal,
    private adminMenuUtilityService: AdminMenuUtilityService,
    private titleService: Title) {
        this.titleService.setTitle(GlobalConstant.tabTitles[15]);
    }

  ngOnInit(): void {
    this.getFilterFields();
  }

  navigateToAdminMenu() {
    this.router.navigate([AppConstants.uiRoutes.adminMenu]);
  }

  toggleAddDays() {
    this.addDaysColumn = !this.addDaysColumn;
  }

  getFilterFields() {
    this.getJurisdictions();
    this.getActions();
    this.getLobs();
    this.getCircumstances();
  }

  getJurisdictions() {
    this.daysService.getJurisdictions().subscribe((res: any) => {
      this.allJurisdictions = this.daysService.addGroupName(res, Constants.daysNotice.allJurisdictions);
    });
  }

  getActions() {
    this.daysService.getActions().subscribe((res: any) => {
      this.allActions = this.daysService.addGroupName(res, Constants.daysNotice.allActions);
    });
  }

  getLobs() {
    const adminMenuItem = 2;
    this.daysService.getLobs(adminMenuItem).subscribe((res: any) => {
      this.allLobs = this.daysService.addGroupName(res, Constants.daysNotice.allLobs);
    });
  }

  getCircumstances() {
    this.daysService.getCircumstances().subscribe((res: any) => {
      this.allCircumstances = this.daysService.addGroupName(res, Constants.daysNotice.allCircumstance);
    });
  }

  numberOnly(event): boolean {
    return this.daysService.numberOnly(event);
  }

  cancelDisplay() {
    this.selectedJurisdictions = [];
    this.selectedActions = [];
    this.selectedLobs = [];
    this.selectedCircumstances = [];
    this.isClickedDisplay = false;
    this.isClickedAddDays = false;
    this.addDaysColumn = false;
    this.daysNoticeForm.get(Constants.editdaysProperties.daysNotice).setValue('');
    this.daysNoticeForm.get(Constants.editdaysProperties.daysNoticeMax).setValue('');
    this.daysNoticeForm.get(Constants.editdaysProperties.defaults).setValue('1');
  }

  checkIsValidForm(type) {
    this.isClickedDisplay = true;
    if (type === Constants.daysNoticeFormType.addDays) {
      this.isClickedAddDays = true;
    }
    if (this.dropDownValid() && type === Constants.daysNoticeFormType.display) {
      this.getCountOfAllDaysNotice();
    } else if (this.dropDownValid() && type === Constants.daysNoticeFormType.addDays && this.daysNoticeForm.valid) {
      if (this.daysNoticeForm.value.daysNoticeMax !== '') {
        if (Number(this.daysNoticeForm.value.daysNotice) <= Number(this.daysNoticeForm.value.daysNoticeMax)) {
          this.isGreaterThanMinimumDays = false;
          this.addDays();
        } else {
          this.isGreaterThanMinimumDays = true;
        }
      } else {
        this.isGreaterThanMinimumDays = false;
        this.addDays();
      }
    }
  }

  dropDownValid() {
    if (this.selectedJurisdictions.length > 0 && this.selectedActions.length > 0
        && this.selectedLobs.length > 0  && this.selectedCircumstances.length > 0) {
      return true;
    } else {
      return false;
    }
  }

  addDays() {
    const jurisdictionsForAdd = this.daysService.getJurisdictionsForAdd(this.selectedJurisdictions);
    const actionForAdd = this.daysService.getActionsForAdd(this.selectedActions);
    const lobForAdd = this.daysService.getSLobsForAdd(this.selectedLobs);
    const circumstanceForAdd = this.daysService.getCircumstanceForAdd(this.selectedCircumstances);
    const addNoticeData = {
      states: [...jurisdictionsForAdd],
      actions: [...actionForAdd],
      lobs: [...lobForAdd],
      circumstances: [...circumstanceForAdd],
      daysNotice: this.daysNoticeForm.value.daysNotice,
      daysNoticeMax: this.daysNoticeForm.value.daysNoticeMax
    };
    this.daysService.addDaysNotice(addNoticeData).subscribe((res: any) => {
      this.isClickedAddDays = false;
      this.daysNoticeForm.get(Constants.editdaysProperties.daysNotice).setValue('');
      this.daysNoticeForm.get(Constants.editdaysProperties.daysNoticeMax).setValue('');
      if (res.unsuccessfulDaysNotices && (res.unsuccessfulDaysNotices.length === 0)) {
        this.popupService.showSuccess({
          title: '',
          message: this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.added_Days_Notice_Requirements'),
          positiveLabel: this.translate.instant('BUTTON.ok_button'),
          negativeLabel: '',
        }).pipe(take(1)).subscribe(response => {
          if (response) {
            this.getCountOfAllDaysNotice();
          }
        });
      } else {
        const modalRef = this.modalService.open(DaysNoticeMinMaxComponent);
        res.daysType = Constants.editDaysType.addMinMax;
        modalRef.componentInstance.data = res;
        modalRef.result.then((userResponse) => {
        });
      }
    });
  }

  displayDays() {
    this.isFoundFilterData = false;
    this.allDaysNotices = [];
    const noticeData = this.getDefeaultParams();
    this.daysService.getAllDaysNotice(noticeData).subscribe((res: any) => {
       this.allDaysNotices = res;
       this.updateResponse();
    });
  }

  updateResponse() {
    this.collectionOfGridWithCheckBoxOnly = [];
    this.noticesGridRowSelected = [];
    this.addCheckBoxForNotices();
    this.isClickedDisplay = false;
    this.isFoundFilterData = true;
    this.checkIfAtleastOneRowSelected();
    this.filterJurisdiction = this.daysService.getJurisdictionsForScroll(this.allDaysNotices);
  }

  scrollToState(state) {
    document.getElementById(state).scrollIntoView({
      behavior: 'smooth',
      block: 'start',
      inline: 'nearest'
    });
  }

  addCheckBoxForNotices() {
    if (this.allDaysNotices.length > 0) {
      this.allDaysNotices.forEach(element => {
        if (element.accountNumber === Constants.accountNumber.oneTwoSixNine) {
          element.isDefaults = true;
        } else {
          element.isDefaults = false;
          element.isSelected = false;
        }
      });
      this.collectionOfGridWithCheckBoxOnly = this.daysService.collectGridWithCheckBoxOnly(this.allDaysNotices);
    }
  }

  allCheckBoxToChecked() {
    if (this.allDaysNotices.length > 0) {
      this.allDaysNotices.forEach(element => {
        if (element.accountNumber === Constants.accountNumber.oneTwoSixNine) {
          element.isDefaults = true;
        } else {
          element.isDefaults = false;
          element.isSelected = true;
          this.addToSelectedtable(element);
        }
      });
    }
  }

  checkIfAtleastOneRowSelected() {
    if (this.noticesGridRowSelected.length === 0) {
      this.isAtleastOneRowSelected = false;
      this.isAllChecked = false;
    } else if (this.collectionOfGridWithCheckBoxOnly.length === this.noticesGridRowSelected.length) {
      this.isAtleastOneRowSelected = false;
      this.isAllChecked = true;
    } else if (this.noticesGridRowSelected.length > 0 &&
              this.noticesGridRowSelected.length < this.collectionOfGridWithCheckBoxOnly.length) {
      this.isAtleastOneRowSelected = true;
      this.isAllChecked = false;
    } else {
      this.isAtleastOneRowSelected = false;
      this.isAllChecked = false;
    }
  }

  changeCheckbox(oneRow) {
    oneRow.isSelected = !oneRow.isSelected;
    if (!oneRow.isSelected) {
      this.removeFromSelectedtable(oneRow);
    } else if (oneRow.isSelected) {
      this.addToSelectedtable(oneRow);
    }
    this.checkIfAtleastOneRowSelected();
  }

  addToSelectedtable(oneRow) {
    this.noticesGridRowSelected.push(oneRow);
  }

  removeFromSelectedtable(oneRow) {
    const index = this.noticesGridRowSelected.findIndex(d => (
      (d.accountNumber === oneRow.accountNumber) && (d.stateCode === oneRow.stateCode) &&
    (d.actionId === oneRow.actionId) && (d.circumstanceId === oneRow.circumstanceId) && (d.lobId === oneRow.lobId) ));
    this.noticesGridRowSelected.splice(index, 1);
  }

  selectAllCheckbox() {
    if (this.isAllChecked) {
      this.noticesGridRowSelected = [];
      this.allCheckBoxToChecked();
    } else {
      this.noticesGridRowSelected = [];
      this.addCheckBoxForNotices();
    }
    this.checkIfAtleastOneRowSelected();
  }

  singleRecord(singleRow) {
    this.deleteRecord([singleRow]);
    this.isBulkDelete = false;
  }

  multipleRecord() {
    this.isBulkDelete = true;
    this.deleteRecord(this.noticesGridRowSelected);
  }

  deleteRecord(row) {
    const expectedFormate = this.daysService.getDeleteFormate(row);
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
      message: this.isBulkDelete ?
      this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.confirm_delete_the_Days_Requirements') :
      this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.confirm_delete_the_Days_Requirement'),
      positiveLabel: this.translate.instant('BUTTON.delete_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.daysService.deleteDaysNotice(expectedFormate)
        .subscribe( response => {
          this.popupService.showSuccess({
              title: '',
              message: this.isBulkDelete ? this.translate.instant('MESSAGES.ALERT.deleted_records') :
              this.translate.instant('MESSAGES.ALERT.deleted_record') ,
              positiveLabel: this.translate.instant('BUTTON.ok_button'),
              negativeLabel: '',
          });

          this.isBulkDelete = false;
          this.displayDays();
        });
      }
    });
  }

  editDays(type) {
    const modalRef = this.modalService.open(DaysNoticeMinMaxComponent);
    const data = {
      daysType: type,
      selectedRows: this.noticesGridRowSelected
    };
    modalRef.componentInstance.data = data;
    modalRef.result.then((userResponse) => {
      if (Constants.editDaysReload.reload === userResponse) {
        this.noticesGridRowSelected = [];
        this.displayDays();
      }
    });
  }

  customSearch(term: string, item: any) {
    return item.name.toLowerCase().startsWith(term.toLowerCase());
  }

  getRowColor(row) {
    return this.daysService.getRowColor(row);
  }

  singlEdit(row, type) {
    if (!row.isDefaults) {
      this.noticesGridRowSelected = [];
      this.addToSelectedtable(row);
      this.editDays(type);
      this.checkIfAtleastOneRowSelected();
      this.allDaysNotices = this.daysService.showSingleRowOnly(this.allDaysNotices, row);
    }
  }

  isValid() {
    return this.daysService.isValid(this.allJurisdictions, this.allActions, this.allLobs, this.allCircumstances);
  }

  getCountOfAllDaysNotice() {
    const noticeData = this.getDefeaultParams();
    this.daysService.getCountOfAllDaysNotice(noticeData).subscribe((res: any) => {
       const thresholdCountRes = environment.daysNoticeThreshold.toString().replace(/,/g, '').replace(Constants.numberWithComma, ',');
       this.allDaysNotices = [];
       if (res === AppConstants.zero) {
        this.updateResponse();
      }
      else if (res < environment.daysNoticeThreshold && res !== 0) {
        this.displayDays();
      } else {
        const message = this.translate.instant('ADMIN_MENUS.DAYS_NOTICE_REQUIREMENTS.threshold_error_message',
          { thresholdCount: thresholdCountRes});
        this.adminMenuUtilityService.showAlert(message);
        this.isFoundFilterData = false;
      }
    });
  }

  getDefeaultParams() {
    const defaults = this.daysNoticeForm.value.defaults;
    const jurisdictionsCodes = this.daysService.getJurisdictionsCodes(this.selectedJurisdictions);
    const actionIds = this.daysService.getSelectedIds(this.selectedActions);
    const lobIds = this.daysService.getSelectedIds(this.selectedLobs);
    const circumstanceIds = this.daysService.getSelectedIds(this.selectedCircumstances);
    const noticeData = {
      displayDefault: defaults,
      stateCodes: jurisdictionsCodes,
      actionIds: actionIds,
      lobIds: lobIds,
      circumstanceIds: circumstanceIds
    };
    return noticeData;
  }

}
