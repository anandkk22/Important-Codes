import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { RecordsReport } from 'app/admin/infrastructure/models/recordsReport.model';
import { AdminMenuService } from 'app/admin/services/admin-menu.service';
import { AppConstants } from 'app/app.constants';
import { Constants } from '@global/infrastructure/constants';
import * as moment from 'moment';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { SharedDataService } from '@global';
import { Title } from '@angular/platform-browser';
import { RecordReportUtilityService } from 'app/admin/services/record-report-utility.service';
import { PopupService } from '@wk/nils-core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { RecordReportGridComponent } from './record-report-grid/record-report-grid.component';
import { Constants as AdminConstants } from 'app/admin/infrastructure/constants';
@Component({
  selector: 'app-records-report',
  templateUrl: './records-report.component.html',
  styleUrls: ['./records-report.component.scss']
})
export class RecordsReportComponent implements OnInit {
  headerName = this.translate.instant('ADMIN_MENUS.HEADINGS.records_report');
  recordsReport = this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.records-report');
  generateReportBtn = this.translate.instant('BUTTON.generate_report');
  resetBtn = this.translate.instant('BUTTON.reset_button');
  exportToExcel = this.translate.instant('BUTTON.export_to_excel');
  backToPrevious = '/' + AppConstants.uiRoutes.adminMenu;
  generateRecReportForm: FormGroup;
  recordReportInfo = {
    accountNo: null,
    generatedViaAPI: null
  };
  isChecked = false;
  isAtleastOneSelected = false;
  clickedGenerateReports = false;
  isValidFromDate = false;
  isValidToDate = false;
  fromDate;
  toDate;
  maxDate;
  generateReportUrl = AppConstants.uiRoutes.recordsReportGrid;
  isDataAvaliable: Boolean = false;

  constructor(
    private translate: TranslateService,
    private adminMenuService: AdminMenuService,
    private router: Router,
    private adminMenuUtilityService: AdminMenuUtilityService,
    private sharedDataService: SharedDataService,
    private titleService: Title,
    private recordReportService: RecordReportUtilityService,
    private popupService: PopupService,
    private modalService: NgbModal) {
        this.titleService.setTitle(Constants.tabTitles[18]);
  }

  ngOnInit(): void {
    this.maxDate = new Date(10000, 0, 1).toISOString().slice(0, 10);
    const url = this.adminMenuUtilityService.getSubUrlDetails(this.recordsReport);
    const userInfo: any = this.sharedDataService.getUserInfo();
    this.getReportDate();
    this.generateRecReportForm = new FormGroup(
      {
        dateFrom: new FormControl(''),
        dateTo: new FormControl('')
      },
      [Validators.required, this.dateRangeValidator]
    );
    this.recordReportInfo.accountNo = userInfo.cnr_master_account_id;
    this.recordReportInfo.generatedViaAPI = userInfo.subscriptions.includes(Constants.cnrApi);

  }

  getReportDate() {
    this.adminMenuService.getReportDate().subscribe((res: RecordsReport) => {
      if (res) {
        res.dateFrom = moment(res.dateFrom).format(Constants.dateFormat.yymmddFormat);
        res.dateTo = moment(res.dateTo).format(Constants.dateFormat.yymmddFormat);
        this.generateRecReportForm.controls.dateFrom.setValue(res.dateFrom);
        this.generateRecReportForm.controls.dateTo.setValue(res.dateTo);
        this.isDataAvaliable = true;
      }
    });
  }

  reset() {
    this.getReportDate();
    this.isValidFromDate = false;
    this.isValidToDate = false;
    this.clickedGenerateReports = false;
  }

  navigateToPrevious() {
    this.router.navigate([AppConstants.uiRoutes.adminMenu]);
  }

  onFromDateChange() {
    this.fromDate = this.generateRecReportForm.get('dateFrom').value;
    this.isValidFromDate = !(moment(this.fromDate, Constants.dateFormat.yymmddFormat, true).isValid()) ? true : false;
    if (this.isValidFromDate) {
      this.generateRecReportForm.get('dateFrom').reset();
    }

  }

  onToDateChange() {
    this.toDate = this.generateRecReportForm.get('dateTo').value;
    this.isValidToDate = !(moment(this.toDate, Constants.dateFormat.yymmddFormat, true).isValid()) ? true : false;
    if (this.isValidToDate) {
      this.generateRecReportForm.get('dateTo').reset();
    }
  }

  onGenerateClick() {
    if (!this.isValidToDate && !this.isValidFromDate && !this.generateRecReportForm.invalid) {
      this.fromDate = this.generateRecReportForm.get('dateFrom').value;
      this.toDate = this.generateRecReportForm.get('dateTo').value;
      this.adminMenuService.isThresholdValuePassing(this.fromDate, this.toDate).subscribe((res: any) => {
        if (res) {
          const thresholdCount = res.thresholdCount.toString().replace(/,/g, '').replace(AdminConstants.numberWithComma, ',');
          if (res.isThresholdExceeded) {
            this.popupService.showAlert({
              title: '',
              message: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.MESSAGE.threshold_warning',
                { thresholdCount:  thresholdCount}),
              positiveLabel: this.translate.instant('BUTTON.ok_button'),
              negativeLabel: '',
            });
          } else {
            const modalRef = this.modalService.open(RecordReportGridComponent);
            const recordReportData = {
              dateFrom: this.fromDate,
              dateTo: this.toDate,
              generatedReportCount: res.recordsCount
            };
            modalRef.componentInstance.recordReportData = recordReportData;
          }
        }
      });
    }
  }

  private dateRangeValidator: ValidatorFn = (): {
    [key: string]: any;
  } | null => {
    let invalid = false;
    const dateFrom = this.generateRecReportForm && this.generateRecReportForm.get('dateFrom').value;
    const dateTo = this.generateRecReportForm && this.generateRecReportForm.get('dateTo').value;
    if (dateFrom && dateTo) {
      invalid = new Date(dateFrom).valueOf() > new Date(dateTo).valueOf();
    }
    return invalid ? { invalidRange: { dateFrom, dateTo } } : null;
  }


}
