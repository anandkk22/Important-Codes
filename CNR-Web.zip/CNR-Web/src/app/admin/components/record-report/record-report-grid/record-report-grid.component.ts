import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Constants } from '@global/infrastructure/constants';
import { TranslateService } from '@ngx-translate/core';
import { RecordsReportView } from 'app/admin/infrastructure/models/recordsReport.model';
import { AdminMenuService } from 'app/admin/services/admin-menu.service';
import { RecordReportUtilityService } from 'app/admin/services/record-report-utility.service';
import { formatDate } from '@angular/common';
import { SharedDataService } from '@global';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { AppConstants } from 'app/app.constants';
import { take } from 'rxjs/operators';
import { PopupService } from '@wk/nils-core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-record-report-grid',
  templateUrl: './record-report-grid.component.html',
  styleUrls: ['./record-report-grid.component.scss']
})
export class RecordReportGridComponent implements OnInit {
  @Input() recordReportData;
  pageSizeDropdown: HTMLElement;
  recordReportMaster: RecordsReportView = {
    pageNo: 1,
    pageSize: 500,
    totalCount: 0,
    isDataPaginated: false,
    paginationData: [],
    gridRowSelected: []
  };
  paginationOptions = {
    currentPage: this.recordReportMaster.pageNo,
    pageSize: this.recordReportMaster.pageSize
  };
  exportExcelClicked = false;
  dateFrom;
  pageNumber;
  dateTo;
  isChecked = false;
  isAtleastOneSelected = false;
  noticeGeneratedViaApiText = this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.notice_generated_via_api');
  recordReportInfo = {
    accountNo: null,
    generatedViaAPI: null
  };
  isDataAvaliable: Boolean = false;
  getRecords;
  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  defaultPaginationPageSize = this.recordReportMaster.pageSize;
  isLoading = false;
  generatedReportCount = 0;

  constructor(
    private translate: TranslateService,
    private recordReportService: RecordReportUtilityService,
    private adminMenuService: AdminMenuService,
    private sharedDataService: SharedDataService,
    private adminMenuUtilityService: AdminMenuUtilityService,
    private popupService: PopupService,
    public activeModal: NgbActiveModal
  ) { }

  ngOnInit() {
        this.dateFrom =  this.recordReportData.dateFrom;
        this.dateTo = this.recordReportData.dateTo;
        this.pageNumber = this.recordReportData.pageNumber;
        this.generatedReportCount = this.recordReportData.generatedReportCount;
    this.recordReportMaster.pageNo = 1;
    this.recordReportMaster.gridRowSelected = [];
    const userInfo: any = this.sharedDataService.getUserInfo();
    this.recordReportInfo.accountNo = userInfo.cnr_master_account_id;
    this.recordReportInfo.generatedViaAPI = userInfo.subscriptions.includes(Constants.cnrApi);
    this.getRecordsReport(true, true);
  }

  getRecordsReport(pageData, firstLoad) {
    const locale = 'en-US';
    const dateFrom = formatDate(this.dateFrom, Constants.dateFormat.format, locale);
    const dateTo = formatDate(this.dateTo, Constants.dateFormat.format, locale);
    const pageNumber = (pageData ? this.recordReportMaster.pageNo : 0);
    const reportUrl = this.recordReportService.getReportUrl(dateFrom, dateTo, pageNumber, this.recordReportMaster.pageSize);
   // if (this.isChecked ) {
      this.isLoading = true;
    // }
    this.adminMenuService.getRecordsReport(reportUrl).subscribe((response: RecordsReportView) => {
      if (response) {
        if (!pageData) {
          this.recordReportMaster.gridRowSelected = response.paginationData;
          if (this.isChecked && this.recordReportMaster.gridRowSelected.length > 0) {
            this.exportExcelClicked = true;
          }
        } else {
          this.recordReportMaster.totalCount = this.generatedReportCount;
          this.recordReportMaster.paginationData = response.paginationData;
          if (this.generatedReportCount > this.defaultPaginationPageSize) {
            this.recordReportMaster.isDataPaginated = true;
          } else {
            this.recordReportMaster.isDataPaginated = false;
          }
          if (firstLoad) {
            this.loadUpadtedPageSizes();
          }
          this.recordReportMaster = this.recordReportService.addCheckBoxForNotices(this.recordReportMaster);
          this.isLoading = false;
        }
        this.isDataAvaliable = true;
      }
    });
  }

  onPageClick(event) {
    this.manipulatePageSizes();
    const detail = event.detail;
    this.recordReportMaster.pageNo = detail;
    this.getRecordsReport(true, false);
    setTimeout(() => {
      this.adminMenuUtilityService.getRecordsFormat();
    }, 0);
  }

  pageSizeChange(event) {
    this.manipulatePageSizes();
    const detail = event.detail;
    this.recordReportMaster.pageSize = detail;
    this.recordReportMaster.pageNo = 1;
    this.getRecordsReport(true, false);
    setTimeout(() => {
      this.adminMenuUtilityService.getRecordsFormat();
    }, 0);
  }

  manipulatePageSizes() {
    setTimeout(function () {
      this.addMorePageSizes();
    }.bind(this));
  }

  loadUpadtedPageSizes() {
    setTimeout(function () {
      this.pageSizeDropdown = document.querySelector('#pagination-bar-dynamic .wk-field-select');
      this.addMorePageSizes();
      this.adminMenuUtilityService.getRecordsFormat();
    }.bind(this), 250);
  }

  addMorePageSizes() {
    for (let i = 0; i < Constants.pageSizes.length; i++) {
      this.pageSizeDropdown[i].value = Constants.pageSizes[i].toString();
      this.pageSizeDropdown[i].innerHTML = Constants.pageSizes[i];
    }
  }

  exportExcel() {
    if (this.isChecked) {
      this.popupService.showConfirmation({
        title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
        message: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.MESSAGE.excel_message'),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: this.translate.instant('BUTTON.cancel_button'),
      }).pipe(take(1)).subscribe(res => {
        if (res) {
          this.getRecordsReport(false, false);
        }
      });
    } else {
      this.exportExcelClicked = true;
    }
  }

  excelDownloaded(status) {
    if (status) {
      this.exportExcelClicked = false;
      this.recordReportMaster.gridRowSelected = [];
      this.recordReportMaster = this.recordReportService.addCheckBoxForNotices(this.recordReportMaster);
      this.isAtleastOneSelected = this.recordReportService.checkIfAtleastOneSelected(this.recordReportMaster);
      this.isChecked = this.recordReportService.isChecked(this.recordReportMaster);
      this.isLoading = false;
    }
  }

  changeCheckbox(data) {
    data.isSelected = !data.isSelected;
    if (!data.isSelected) {
      this.removeFromSelectedtable(data.cnrUserDataV4ID);
    } else if (data.isSelected) {
      this.addToSelectedtable(data);
    }
    this.isAtleastOneSelected = this.recordReportService.checkIfAtleastOneSelected(this.recordReportMaster);
    this.isChecked = this.recordReportService.isChecked(this.recordReportMaster);
  }

  checkAllCheckbox() {
    if (this.isChecked) {
      this.isAtleastOneSelected = true;
    } else {
      this.recordReportMaster.gridRowSelected = [];
      this.recordReportMaster = this.recordReportService.addCheckBoxForNotices(this.recordReportMaster);
      this.isAtleastOneSelected = this.recordReportService.checkIfAtleastOneSelected(this.recordReportMaster);
      this.isChecked = this.recordReportService.isChecked(this.recordReportMaster);
    }
  }

  addToSelectedtable(oneRow) {
    this.recordReportMaster.gridRowSelected.push(oneRow);
    this.recordReportMaster.gridRowSelected.sort((a, b) => (a.branch.localeCompare(b.branch) || a.stateCode.localeCompare(b.stateCode)
      || a.entryDateTime.localeCompare(b.entryDateTime) || a.policyNumber.localeCompare(b.policyNumber)));
  }

  removeFromSelectedtable(cnrUserDataV4ID) {
    const index = this.recordReportMaster.gridRowSelected.findIndex(d => d.cnrUserDataV4ID === cnrUserDataV4ID);
    this.recordReportMaster.gridRowSelected.splice(index, 1);
  }

  getRecordReportHeading(viaAPI) {
    const recordReports = [
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.service_center'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.jurisdiction'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.action'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.lines_of_business'),
        whiteSpace: true, width120px: true, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.circumstance'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.mail_type'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.typist_initials'),
        whiteSpace: true, width120px: true, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.entered'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.effective'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.mailed'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.policy_number'),
        whiteSpace: true, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_name'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_addr1'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_addr2'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_city'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_jurisdiction'),
        whiteSpace: true, width120px: true, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.insurer_postal_code'),
        whiteSpace: false, width120px: true, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_name'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_addr1'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_addr2'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_city'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_jurisdiction'),
        whiteSpace: true, width120px: true, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.producer_postal_code'),
        whiteSpace: true, width120px: true, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_name'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_addr1'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_addr2'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_city'),
        whiteSpace: false, width120px: false, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_jurisdiction'),
        whiteSpace: true, width120px: true, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.addressee_postal_code'),
        whiteSpace: true, width120px: true, width150px: false
      },
      {
        heading: this.translate.instant('ADMIN_MENUS.RECORDS_REPORT.RECORDS_REPORT_TABLE_HEADING.notice_generated_via_api'),
        whiteSpace: false, width120px: true, width150px: true
      },
    ];
    if (!viaAPI) {
      recordReports.splice(recordReports.findIndex(a => a.heading === this.noticeGeneratedViaApiText), 1);
    }
    return recordReports;
  }

  closeModal() {
    this.activeModal.close();
  }

}
