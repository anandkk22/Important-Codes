import { Component, OnInit, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { ProducerService } from 'app/admin/services/producer.service';
import { HttpErrorResponse } from '@angular/common/http';
import { Constants } from '@global/infrastructure/constants';
import { take } from 'rxjs/operators';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { AppConstants } from 'app/app.constants';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UploadProducersErrorComponent } from '../upload-producers-error/upload-producers-error.component';
@Component({
  selector: 'app-upload-producers',
  templateUrl: './upload-producers.component.html',
  styleUrls: ['./upload-producers.component.scss'],
  providers: [ProducerService]
})
export class UploadProducersComponent implements OnInit {
  wkLogoImg = AppConstants.assetPath + AppConstants.wkLogoImgName;
  uploadedFile = null;
  uploadedFileName = this.translate.instant('ADMIN_MENUS.UPLOAD_PRODUCERS.uploadProducerExcel');
  isExcelFile = false;
  fileExtension: string;
  producersGridData;
  pageNo = Constants.pagination.pageNo;
  pageSize = Constants.pagination.pageSize;
  isUploadSuccessful = null;
  uploadedExcel = false;
  gridRowTotalCount = 0;
  paginationStatus = false;
  pageSizeDropdown: HTMLElement;
  uploadingToTempTable = false;
  producersGridDataErrors;
  paginationOptions = Constants.paginationOptions;
  @ViewChild('fileInput') fileInput: any;

  constructor(
    private translate: TranslateService,
    private popupService: PopupService,
    private producerService: ProducerService,
    private spinnerService: SpinnerService,
    private adminMenuUtilityService: AdminMenuUtilityService,
    private modalService: NgbModal,
    public activeModal: NgbActiveModal
  ) { }

  ngOnInit(): void {
  }

  onSelectFile(files: FileList) {
    if (files.length !== 0) {
      this.uploadingToTempTable = false;
      this.uploadedExcel = false;
      this.uploadedFile = files.item(0);
      this.uploadedFileName = this.uploadedFile?.name;
      this.fileExtension = this.uploadedFileName.substring(this.uploadedFileName.indexOf('.') + 1).toLowerCase();
      if (this.fileExtension === Constants.xlFileExtensions.xlsx) {
          this.isExcelFile = true;
      } else {
        this.removeFile();
        this.adminMenuUtilityService
        .showAlert(this.translate.instant(this.translate.instant('ADMIN_MENUS.UPLOAD_PRODUCERS.fileExtension')));
      }
    }
  }

  removeFile() {
    this.fileInput.nativeElement.value = '';
    if (!this.uploadingToTempTable) {
      this.isExcelFile = false;
      this.uploadedFile = null;
      this.uploadedFileName = this.translate.instant('ADMIN_MENUS.UPLOAD_PRODUCERS.uploadProducerExcel');
      this.uploadedExcel = false;
      this.paginationStatus = false;
    }
  }

  uploadXLFile() {
    this.paginationStatus = false;
    this.uploadedExcel = false;
    this.uploadingToTempTable = true;
    if (this.uploadedFile) {
      this.producerService.uploadFiles(this.uploadedFile).subscribe((res: any) => {
        this.uploadingToTempTable = false;
        this.uploadedExcel = true;
        if (res) {
          this.isUploadSuccessful = res.isUploadSuccessful;
          if (this.isUploadSuccessful) {
            this.gridRowTotalCount = res.totalCount;
            this.producersGridData = res.producers;
          } else {
            this.paginationOptions.totalItems = res.totalCount;
            this.producersGridDataErrors = res.producers;
          }
          if (res.totalCount > this.pageSize) {
            this.paginationStatus = true;
            this.loadUpadtedPageSizes();
          } else {
            this.paginationStatus = false;
          }
        }
      },
      (errors: HttpErrorResponse) => {
        if (errors.status === Constants.responseError.fourTwoTwo) {
          this.adminMenuUtilityService.showAlert(errors.error.Message);
          this.removeFile();
          this.spinnerService.stop();
          this.uploadingToTempTable = false;
        }
      }
    );
    } else {
      this.adminMenuUtilityService.showAlert(this.translate.instant(this.translate.instant('ADMIN_MENUS.UPLOAD_PRODUCERS.fileUploadValidation')));
    }
  }

  onPageClick(event) {
    this.manipulatePageSizes();
    const detail = event.detail;
    this.pageNo = detail;
    this.getProducerTemporary();
  }

  pageSizeChange(event) {
    this.manipulatePageSizes();
    const detail = event.detail;
    this.pageSize = detail;
    this.getProducerTemporary();
  }

  getProducerTemporary() {
    this.producerService.getProducerTemporary(this.pageNo, this.pageSize).subscribe((res: any) => {
      if (res) {
        this.producersGridData = res;
      }
    });
  }

  uploadToAccount() {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
      message: this.translate.instant('ADMIN_MENUS.UPLOAD_PRODUCERS.areYouSureUploading'),
      positiveLabel: this.translate.instant('BUTTON.confirm_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.producerService.producerUpload().subscribe(val => {
          this.popupService.showSuccess({
            title: '',
            message: this.translate.instant('ADMIN_MENUS.UPLOAD_PRODUCERS.producersAddedSuccessfully') ,
            positiveLabel: this.translate.instant('BUTTON.ok_button'),
            negativeLabel: '',
          }).pipe(take(1)).subscribe(response => {
            this.activeModal.close(true);
          });
        });
      }
    });
  }

  manipulatePageSizes() {
    setTimeout(function() {
      this.addMorePageSizes();
    }.bind(this));
  }

  loadUpadtedPageSizes() {
    setTimeout(function() {
      this.pageSizeDropdown = document.querySelector(Constants.paginationBar);
      this.addMorePageSizes();
    }.bind(this), 250);
  }

  addMorePageSizes() {
    for (let i = 0; i < Constants.sizeTwoHundred.length; i++) {
      this.pageSizeDropdown[i].value = Constants.sizeTwoHundred[i].toString();
      this.pageSizeDropdown[i].innerHTML = Constants.sizeTwoHundred[i];
    }
  }

  viewError(errorData) {
    const modalRef = this.modalService.open(UploadProducersErrorComponent);
    modalRef.componentInstance.data = errorData;
  }

  onPageClickError(e) {
    this.manipulatePageSizes();
    this.paginationOptions.currentPage = e.detail;
  }

  pageSizeChangeError(e) {
    this.manipulatePageSizes();
    this.paginationOptions.currentPage = 1;
    this.paginationOptions.pageSize = e.detail;
  }

  closeModal() {
    this.activeModal.close();
  }

}
