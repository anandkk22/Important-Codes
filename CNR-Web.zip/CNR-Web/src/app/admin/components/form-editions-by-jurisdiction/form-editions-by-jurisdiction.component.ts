import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { TranslateService } from '@ngx-translate/core';
import { AdminMenuService } from 'app/admin/services/admin-menu.service';
import { FormEditionByJurisdiction } from 'app/admin/infrastructure/models/form-edition-by-jurisdiction';
import { Subscription } from 'rxjs';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { Constants } from '../../infrastructure/constants';
import { take } from 'rxjs/operators';
import { Title } from '@angular/platform-browser';
import { Constants as GlobalConstant } from '@global/infrastructure/constants';

@Component({
  selector: 'app-form-editions-by-jurisdiction',
  templateUrl: './form-editions-by-jurisdiction.component.html',
  styleUrls: ['./form-editions-by-jurisdiction.component.scss']
})
export class FormEditionsByJurisdictionComponent implements OnInit, OnDestroy {
  activeSubscription: Subscription;
  headerName = this.translate.instant('ADMIN_MENUS.EDITIONS_BY_JURISDICTION.headerName');
  editionsByJurisdiction = this.translate.instant('ADMIN_MENUS.EDITIONS_BY_JURISDICTION.editionsByJurisdiction');
  defaultEditionByJurisdcition;
  editionByJurisdictionForm: FormGroup;
  selectedItems = [];
  policyCodes = Constants.policyCodes;
  stateCodes = [];
  colHeading = [];
  noRecordMessage = false;
  isDataAvaliable: Boolean = false;


  constructor(
    private router: Router,
    private fb: FormBuilder,
    private translate: TranslateService,
    private adminMenuService: AdminMenuService,
    private adminMenuUtilityService: AdminMenuUtilityService,
    private popupService: PopupService,
    private spinnerService: SpinnerService,
    private titleService: Title) {
        this.titleService.setTitle(GlobalConstant.tabTitles[17]);
    }

  ngOnInit(): void {
    this.getEditionByJurisdiction();
    this.createSearchForm();
    this.getColHeading();
  }

  navigateToPrevious() {
    this.router.navigate([AppConstants.uiRoutes.adminMenu]);
  }

  getColHeading() {
    this.colHeading = [
      this.translate.instant('ADMIN_MENUS.EDITIONS_BY_JURISDICTION.TABLE_HEADING.form'),
      this.translate.instant('ADMIN_MENUS.EDITIONS_BY_JURISDICTION.TABLE_HEADING.edition'),
      this.translate.instant('ADMIN_MENUS.EDITIONS_BY_JURISDICTION.TABLE_HEADING.policyCodes'),
      this.translate.instant('ADMIN_MENUS.EDITIONS_BY_JURISDICTION.TABLE_HEADING.title'),
      this.translate.instant('ADMIN_MENUS.EDITIONS_BY_JURISDICTION.TABLE_HEADING.useThisEdition'),
    ];
  }

  createSearchForm() {
    this.editionByJurisdictionForm = this.fb.group({
      useThisEdition: [],
    });
  }

  getEditionByJurisdiction() {
    this.activeSubscription = this.adminMenuService.getEditionByJurisdiction().subscribe((res: FormEditionByJurisdiction) => {
      if (res) {
        this.isDataAvaliable = true;
        this.defaultEditionByJurisdcition = res;
        if (this.defaultEditionByJurisdcition.length > 0) {
          this.noRecordMessage = false;
          this.editionByJurisdictionForm.get('useThisEdition').
          setValue(res.baseForms[0].userAccountFormDbDTO.map(obj => obj.useThisEdition));
        } else {
          this.noRecordMessage = true;
        }
      }
    });
  }

  scrollToState(state) {
    document.getElementById(state).scrollIntoView({
      behavior: 'smooth'
    });
  }

  onSubmit() {
    this.adminMenuService.updateEditionByJurisdiction(this.selectedItems).subscribe(response => {
      if (!response) {
        this.popupService.showSuccess({
          title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
          message: this.translate.instant('ADMIN_MENUS.EDITIONS_BY_JURISDICTION.headerName') + this.translate.instant('ADMIN_MENUS.EDITIONS_BY_JURISDICTION.MESSAGES.update_message'),
          positiveLabel: this.translate.instant('BUTTON.ok_button'),
          negativeLabel: '',
        }).pipe(take(1)).subscribe(resp => {
          if (resp) {
            setTimeout(() => {
              document.getElementById('main-scroll').scrollIntoView();
            }, 0);
          }
        });
      }
    });
  }

  reset() {
    this.getEditionByJurisdiction();
  }

  activaDeactivate(userAccountForm, selectedFormId) {
    for (let i = 0; i < userAccountForm.length; i++) {
      if (userAccountForm[i].formId !== selectedFormId) {
        userAccountForm[i].useThisEdition = false;
      }
      this.selectedItems.push(
        {
          edition: userAccountForm[i].useThisEdition,
          stateCode: userAccountForm[i].stateCode,
          formId: userAccountForm[i].formId
        }
      );
    }
  }


  downloadForm(filePath, fileName) {
    this.adminMenuService.downloadFile(filePath).subscribe(response => {
      if (response) {
        this.adminMenuService.loadFile(response, fileName);
      }
    }, async (error) => {
      const message = JSON.parse(await error.error.text()).Message;
      this.showAlert(message);
      this.spinnerService.stop();
    });
  }

  downloadPolicyCode(filePath) {
    this.adminMenuService.downloadFileFromNils(filePath).subscribe(response => {
      this.adminMenuService.loadFile(response, Constants.policyFilename);
    }, async (error) => {
      const message = JSON.parse(await error.error.text()).Message;
      this.showAlert(message);
      this.spinnerService.stop();
    });
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

  showAlert(message) {
    this.popupService.showAlert({
      title: this.translate.instant('MESSAGES.Confirmation.alertTitle'),
      message: message,
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: '',
    });
  }
}
