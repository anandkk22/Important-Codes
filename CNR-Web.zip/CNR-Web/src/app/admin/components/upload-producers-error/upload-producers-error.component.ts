import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-upload-producers-error',
  templateUrl: './upload-producers-error.component.html',
  styleUrls: ['./upload-producers-error.component.scss']
})
export class UploadProducersErrorComponent implements OnInit {
  @Input() data;
  constructor(
    public activeModal: NgbActiveModal
  ) { }

  ngOnInit(): void {
  }

  errorOk() {
    this.activeModal.close();
  }

}
