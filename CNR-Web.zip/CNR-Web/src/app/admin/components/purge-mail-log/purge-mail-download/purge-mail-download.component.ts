import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { SharedDataService } from '@global';
import { ActivatedRoute } from '@angular/router';
import { PurgeMailLogService } from 'app/admin/services/purge-mail-log.service';
import { PurgeReport } from 'app/admin/infrastructure/models/purge-report.model';
import { Subject} from 'rxjs';
import { AppConstants } from 'app/app.constants';

@Component({
  selector: 'app-purge-mail-download',
  templateUrl: './purge-mail-download.component.html',
  styleUrls: ['./purge-mail-download.component.scss'],
  providers: [PurgeMailLogService]
})
export class PurgeMailDownloadComponent implements OnInit {

  purgeTableHeading = [];
  chkApiSubscription;
  purgeReportInfo = {
    accountNo: null,
    generatedViaAPI: null
  };
  cnrv4Api = this.translate.instant('ADMIN_PANEL_SCREEN.MAINTAIN_SETTINGS.Maintain_api_token_subscription.CNRV4_API');
  generatedViaApiText = this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.generatedViaApi');
  downloadingFile = this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.messages.downloadingFile');
  allPurgeRecords = [];
  allPurgeRecordsExport = [];
  counter;
  creatingExcel = 0;
  exportingExcelNo = null;
  reportUrl = '';
  accountNumber;
  startDate;
  endDate;
  totalCount;
  exportExcelClicked: Subject<void> = this.purgeMaillogService.dowmloadSubject();
  showMessage = '';
  noOfExcel = 0;
  downloadStarted = false;



  constructor(
    private purgeMaillogService: PurgeMailLogService,
    private translate: TranslateService,
    private sharedDataService: SharedDataService,
    private activatedRoute: ActivatedRoute,
  ) { }

    ngOnInit(): void {
        this.activatedRoute.queryParams.subscribe(params => {
        this.accountNumber = params.accountNo;
        this.startDate = params.startDate;
        this.endDate = params.endDate;
        this.totalCount = Number(params.totalcount);
        });
        this.showMessage = '';
        this.downloadStarted = false;
        this.checkApiSubscription();
        this.getColumnHeading();
    }

    exportExcel() {
        this.allPurgeRecords = [];
        this.allPurgeRecordsExport = [];
        this.exportingExcelNo = null;
        this.downloadStarted = true;
        this.counter = 0;
        this.noOfExcel = 0;
        this.showMessage = this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.messages.preparingForDownload');
        const calculateRequests = this.purgeMaillogService
        .getCountBasedOnLimit(this.totalCount, AppConstants.mailLogDownload.apiRequestLimit);
        for (let i = 0; i < calculateRequests; i++) {
            this.getCall(i + 1);
        }
    }

    getCall(pageNo) {
        this.reportUrl = this.purgeMaillogService
        .getReportUrl(this.startDate, this.endDate, pageNo, AppConstants.mailLogDownload.apiRequestLimit);
        this.purgeMaillogService.getPurgeReport(this.reportUrl).subscribe((response: PurgeReport) => {
        this.allPurgeRecordsExport = this.allPurgeRecordsExport.concat(response.paginationData);
            if (this.allPurgeRecordsExport.length === this.totalCount) {
                this.prepareRowData();
            }
        });
    }

    prepareRowData() {
        this.noOfExcel = this.purgeMaillogService
        .getCountBasedOnLimit(this.totalCount, AppConstants.mailLogDownload.downloadExcelLimit);
        const excelRowLimit = this.purgeMaillogService
        .getExcelRowLimit(this.totalCount, AppConstants.mailLogDownload.downloadExcelLimit, this.noOfExcel);
        this.excelDownladingEngine(this.noOfExcel, excelRowLimit);
    }

    excelDownladingEngine(maxCount, modelArray) {
        this.counter = 0;
        const intervalId = setInterval(() => {
            if ((this.counter !== this.exportingExcelNo) && (modelArray.length >= this.counter)) {
                this.generateExcel(modelArray[this.counter]);
            }
            if (this.counter === maxCount) { clearInterval(intervalId); }
        }, 500);
    }

    generateExcel(partOfData) {
        this.exportingExcelNo = this.counter;
        if ( partOfData !== undefined) {
            this.partToPrint(partOfData.start, partOfData.end);
        }
    }

    partToPrint(start, end) {
        this.allPurgeRecords = [];
        this.allPurgeRecords = this.allPurgeRecordsExport.slice(start, end);
        const timeDelay = this.counter === 0 ? AppConstants.mailLogDownload.minTime : AppConstants.mailLogDownload.maxTime;
        setTimeout(() => {
            this.exportExcelClicked.next();
        }, timeDelay);
    }

    excelDownloaded(status) {
        if (status) {
            this.counter += 1;
            this.showMessage = this.downloadingFile + this.counter
            + AppConstants.mailLogDownload.of + this.noOfExcel;
            if (this.counter === this.noOfExcel) {
                setTimeout(() => {
                    this.showMessage = this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.messages.downloadCompleted');
                }, 20000);
            }
        }
    }

    checkApiSubscription() {
        const userInfo: any = this.sharedDataService.getUserInfo();
        this.chkApiSubscription = userInfo.subscriptions.indexOf(this.cnrv4Api) !== -1 ? true : false;
        this.purgeReportInfo.accountNo = userInfo.cnr_master_account_id;
    }

    getColumnHeading() {
        this.purgeTableHeading = [
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.row'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.insurer'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.insurerName'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.address1'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.address2'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.city'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.jurisdiction'),
                width_100: true,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.postalCode'),
                width_100: true,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.name'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.address1'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.address2'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.city'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.state'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.postalCode'),
                width_100: true,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.policyNumber'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.dateOfMailing'),
                width_100: true,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.mailType'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.typist'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.generatedViaApi'),
                width_100: true,
                width_160: false,
                isVisible: this.chkApiSubscription,
            },
        ];
        if (!this.checkApiSubscription) {
            this.purgeTableHeading.splice(this.purgeTableHeading.findIndex(a => a.heading === this.generatedViaApiText), 1);
        }
    }

}
