import { Component, Input, OnDestroy, OnInit, Output, EventEmitter } from '@angular/core';
import { environment } from '../../../../../environments/environment';
import { Constants } from '@global/infrastructure/constants';
import { Observable } from 'rxjs';
import { Subscription } from 'rxjs/Subscription';
import * as fileSaver from 'file-saver';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-export-purge-records',
  templateUrl: './export-purge-records.component.html',
  styleUrls: ['./export-purge-records.component.scss']
})
export class ExportPurgeRecordsComponent implements OnInit, OnDestroy {
  @Input() exportToExcel;
  private excelClickSubscription: Subscription;
  @Input() exportExcelClicked: Observable<void>;
  excelFileName = '';
  imageUrl = '';
  currentYear;
  @Input() purgeTableHeading;
  @Input() chkApiSubscription;
  @Input() masterAccountId;
  @Input() startDate;
  @Input() endDate;
  @Output() excelDownloaded = new EventEmitter();

  constructor(
    private translate: TranslateService) {
  }

  ngOnInit() {
      const today = new Date();
      this.currentYear = today.getFullYear();
      this.excelFileName = this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.exportToExcelFileName');
      this.imageUrl = environment.portalUrl + Constants.cnrPath + Constants.webApis.imageUrl;
      this.excelClickSubscription = this.exportExcelClicked.subscribe(() => this.exportExcel());
  }

  exportExcel() {
      const fileName = this.masterAccountId +  this.excelFileName + Constants.fileTypes.excelExtension;
      const formattedHTML = this.getFormattedHtml();
      this.download(formattedHTML, fileName);
  }

  download(data, fileName) {
      const blob = new Blob([data], { type: Constants.fileTypes.msexcel });
      fileSaver.saveAs(blob, fileName);
      this.excelDownloaded.emit(true);
  }

  getFormattedHtml() {
      let formattedHTML = null;
      formattedHTML = document.getElementById(Constants.excelFile.downloadExcel);
      return formattedHTML.innerHTML;
  }

  ngOnDestroy() {
      this.excelClickSubscription.unsubscribe();
  }

  keepZero(val) {
    if ((typeof val === 'string') && (val.charAt(0) === '0')) {
      const modified = Constants.keepLeadingZero.start + val + Constants.keepLeadingZero.end;
      return modified;
    } else {
      return (val === null || val === '') ? Constants.keepLeadingZero.empty : val;
    }
  }

}
