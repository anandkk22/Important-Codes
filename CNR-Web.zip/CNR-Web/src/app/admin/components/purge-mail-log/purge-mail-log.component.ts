import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormGroup, FormControl, ValidatorFn, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Constants } from '@global/infrastructure/constants';
import { TranslateService } from '@ngx-translate/core';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { AppConstants } from 'app/app.constants';
import { Subject, Subscription } from 'rxjs';
import { formatDate } from '@angular/common';
import { PurgeMailLogService } from 'app/admin/services/purge-mail-log.service';
import { PopupService } from '@wk/nils-core';
import { take } from 'rxjs/operators';
import * as moment from 'moment';
import { PurgeReport, PurgeReportDate } from '../../infrastructure/models/purge-report.model';
import { DatePipe } from '@angular/common';
import { SharedDataService } from '@global';
import { Title } from '@angular/platform-browser';
import { Constants as AdminConstants } from 'app/admin/infrastructure/constants';

@Component({
    selector: 'app-purge-mail-log',
    templateUrl: './purge-mail-log.component.html',
    styleUrls: ['./purge-mail-log.component.scss'],
    providers: [PurgeMailLogService]
})

export class PurgeMailLogComponent implements OnInit, OnDestroy {
    activeSubscription: Subscription;
    purgeMailLogUrl = this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.pugeMailLogUrl');
    purgeForm: FormGroup;
    purgeReportDates = [];
    purgeReports = [];
    isPurgeReportGenerated = false;
    isPurged = false;
    isDataAvaliable: Boolean = false;
    purgeTableHeading = [];
    exportExcelClicked: Subject<void> = new Subject<void>();
    fromDate;
    toDate;
    startDate = '';
    endDate = '';
    accountNumber: number;
    allPurgeRecords = [];
    allPurgeRecordsExport = [];
    counter;
    creatingExcel = 0;
    exportingExcelNo = null;
    purgeReportMaster: PurgeReport = {
        pageNo: 1,
        pageSize: 500,
        totalCount: 0,
        isDataPaginated: false,
        paginationData: [],
        gridRowSelected: [],
    };

    purgeReportInfo = {
        accountNo: null,
        generatedViaAPI: null
    };
    isValidFromDate = false;
    isValidToDate = false;
    chkApiSubscription;
    cnrv4Api = this.translate.instant('ADMIN_PANEL_SCREEN.MAINTAIN_SETTINGS.Maintain_api_token_subscription.CNRV4_API');
    generatedViaApiText = this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.generatedViaApi');
    maxDate;
    reportUrl = '';
    getDateFrom;
    getDateTo;
    pageSizeDropdown: HTMLElement;
    getRecords;

    constructor(private purgeMaillogService: PurgeMailLogService,
        private router: Router,
        private translate: TranslateService,
        private adminMenuUtilityService: AdminMenuUtilityService,
        private popupService: PopupService,
        public datepipe: DatePipe,
        private sharedDataService: SharedDataService,
        private titleService: Title) {
        this.titleService.setTitle(Constants.tabTitles[22]);
    }

    ngOnInit() {
        this.maxDate = new Date(10000, 0, 1).toISOString().slice(0, 10);
        this.getPurgeReportDates();
        this.purgeForm = new FormGroup(
            {
                dateFrom: new FormControl(''),
                dateTo: new FormControl('')
            },
            [Validators.required, this.dateRangeValidator]
        );
        this.checkApiSubscription();
        this.getColumnHeading();
    }

    checkApiSubscription() {
        const userInfo: any = this.sharedDataService.getUserInfo();
        this.chkApiSubscription = userInfo.subscriptions.indexOf(this.cnrv4Api) !== -1 ? true : false;
        this.purgeReportInfo.accountNo = userInfo.cnr_master_account_id;
    }

    getColumnHeading() {
        this.purgeTableHeading = [
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.row'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.insurer'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.insurerName'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.address1'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.address2'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.city'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.jurisdiction'),
                width_100: true,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.postalCode'),
                width_100: true,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.name'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.address1'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.address2'),
                width_100: false,
                width_160: true,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.city'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.state'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.postalCode'),
                width_100: true,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.policyNumber'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.dateOfMailing'),
                width_100: true,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.mailType'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.typist'),
                width_100: false,
                width_160: false,
                isVisible: true,
            },
            {
                heading: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.tableHeader.generatedViaApi'),
                width_100: true,
                width_160: false,
                isVisible: this.chkApiSubscription,
            },
        ];
        if (!this.checkApiSubscription) {
            this.purgeTableHeading.splice(this.purgeTableHeading.findIndex(a => a.heading === this.generatedViaApiText), 1);
        }
    }


    getPurgeReportDates() {
        this.activeSubscription = this.purgeMaillogService.getPurgeReportDates().subscribe((res: PurgeReportDate) => {
            if (res) {
                this.isDataAvaliable = true;
                res.dateFrom = moment(res.dateFrom).format(Constants.dateFormat.yymmddFormat);
                res.dateTo = moment(res.dateTo).format(Constants.dateFormat.yymmddFormat);
                this.purgeForm.controls.dateFrom.setValue(res.dateFrom);
                this.purgeForm.controls.dateTo.setValue(res.dateTo);
            }
        });
    }

    generatePurgeReport(pageData) {
        this.isPurged = false;
        this.fromDate = this.purgeForm.get('dateFrom').value;
        this.toDate = this.purgeForm.get('dateTo').value;
        this.isValidFromDate = !(moment(this.fromDate, Constants.dateFormat.yymmddFormat, true).isValid()) ? true : false;
        this.isValidToDate = !(moment(this.toDate, Constants.dateFormat.yymmddFormat, true).isValid()) ? true : false;
        const locale = 'en-US';
        this.getDateFrom = formatDate(this.fromDate, Constants.dateFormat.format, locale);
        this.getDateTo = formatDate(this.toDate, Constants.dateFormat.format, locale);
        this.reportUrl = this.purgeMaillogService.getReportUrl(this.getDateFrom, this.getDateTo,
            this.purgeReportMaster.pageNo, this.purgeReportMaster.pageSize);

      if (!this.isValidFromDate && !this.isValidToDate && !this.purgeForm.invalid) {
        this.purgeMaillogService.getPurgeReport(this.reportUrl).subscribe((response: PurgeReport) => {
            if (!pageData) {
                this.isPurgeReportGenerated = true;
            } else {
                this.purgeReportMaster.totalCount = response.totalCount;
                this.purgeReportMaster.paginationData = response.paginationData;
                this.isPurgeReportGenerated = true;
            }
          this.purgeMaillogService.loadUpadtedPageSizes();
          setTimeout(() => {
            this.adminMenuUtilityService.getRecordsFormat();
          }, 250);
        });
      }
    }

    exportExcel() {
        if (this.purgeReportMaster.totalCount < AppConstants.mailLogDownload.oneExcelFileLimit) {
            this.getAllData();
        } else {
            this.getConfirmation();
        }
    }

    getConfirmation() {
        this.popupService.showConfirmation({
            title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
            message: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.messages.moreThanLimit'),
            positiveLabel: this.translate.instant('BUTTON.continue'),
            negativeLabel: this.translate.instant('BUTTON.ok_button'),
          }).pipe(take(1)).subscribe(res => {
            if (res) {
                const href = AppConstants.downloadPurgeMailLogURL + AppConstants.mailLogDownload.accountNo + this.accountNumber
                + AppConstants.mailLogDownload.startDate + this.startDate + AppConstants.mailLogDownload.endDate + this.endDate
                + AppConstants.mailLogDownload.totalcount + this.purgeReportMaster.totalCount;
                window.open(href, AppConstants.mailLogDownload.purge, AppConstants.mailLogDownload.windowSize); return false;
            }
          });
    }

    getAllData() {
        this.reportUrl = this.purgeMaillogService.getReportUrl(this.getDateFrom, this.getDateTo, 0, 1);
        this.purgeMaillogService.getPurgeReport(this.reportUrl).subscribe((response: PurgeReport) => {
          this.allPurgeRecords = response.paginationData;
            setTimeout(() => {
                this.exportExcelClicked.next();
            }, 2000);
        });
    }

    onDateChange() {
        this.isValidFromDate = false;
        this.isValidToDate = false;
    }

    getTransactionLimit() {
        this.purgeReportMaster.pageNo = 1;
        this.generatePurgeReport(true);
        this.startDate = this.datepipe.transform(this.fromDate, Constants.dateFormat.excelDateFormat);
        this.endDate = this.datepipe.transform(this.toDate, Constants.dateFormat.excelDateFormat);
        this.accountNumber = this.purgeReportInfo.accountNo;
    }

    navigateToAdminMenu() {
        this.router.navigate([AppConstants.uiRoutes.adminMenu]);
    }

    reset() {
        this.getPurgeReportDates();
        this.isPurgeReportGenerated = false;
        this.isPurged = false;
        this.purgeReportMaster.paginationData = [];
        this.isValidFromDate = false;
        this.isValidToDate = false;
    }

    getpurgeReport() {
        this.popupService.showConfirmation({
            title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
            message: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.preparePurgeRecordMsg'),
            positiveLabel: this.translate.instant('BUTTON.confirm_button'),
            negativeLabel: this.translate.instant('BUTTON.cancel_button'),
        }).pipe(take(1)).subscribe(res => {
            if (res) {
                const locale = 'en-US';
                const dateFrom = formatDate(this.fromDate, Constants.dateFormat.excelDateFormat, locale);
                const dateTo = formatDate(this.toDate, Constants.dateFormat.excelDateFormat, locale);
                const reportUrl = this.purgeMaillogService.getPurgeRecUrl(dateFrom, dateTo);
                this.purgeMaillogService.purgeRecords(reportUrl)
                    .subscribe(response => {
                        this.popupService.showSuccess({
                            title: '',
                            message: this.translate.instant('ADMIN_MENUS.PURGE_MAIL_LOG.purgingRecords'),
                            positiveLabel: this.translate.instant('BUTTON.ok_button'),
                            negativeLabel: '',
                        });
                        this.isPurged = true;
                        this.isPurgeReportGenerated = false;
                        this.purgeReportMaster.paginationData = [];
                    });
            }
        });
    }

    onPageClick(event) {
        this.purgeMaillogService.manipulatePageSizes();
        const detail = event.detail;
        this.purgeReportMaster.pageNo = detail;
        this.generatePurgeReport(true);
        setTimeout(() => {
            this.adminMenuUtilityService.getRecordsFormat();
        }, 0);
    }

    pageSizeChange(event) {
        this.purgeMaillogService.manipulatePageSizes();
        const detail = event.detail;
        this.purgeReportMaster.pageSize = detail;
        this.purgeReportMaster.pageNo = 1;
        this.generatePurgeReport(true);
        setTimeout(() => {
            this.adminMenuUtilityService.getRecordsFormat();
        }, 0);
    }

    private dateRangeValidator: ValidatorFn = (): {
        [key: string]: any;
    } | null => {
        let invalid = false;
        const dateFrom = this.purgeForm && this.purgeForm.get('dateFrom').value;
        const dateTo = this.purgeForm && this.purgeForm.get('dateTo').value;
        if (dateFrom && dateTo) {
            invalid = new Date(dateFrom).valueOf() > new Date(dateTo).valueOf();
        }
        return invalid ? { invalidRange: { dateFrom, dateTo } } : null;
    }

    onFromDateChange() {
      this.fromDate = this.purgeForm.get('dateFrom').value;
      this.isValidFromDate = !(moment(this.fromDate, Constants.dateFormat.yymmddFormat, true).isValid()) ? true : false;
      if (this.isValidFromDate) {
        this.purgeForm.get('dateFrom').reset();
      }

    }

    onToDateChange() {
      this.toDate = this.purgeForm.get('dateTo').value;
      this.isValidToDate = !(moment(this.toDate, Constants.dateFormat.yymmddFormat, true).isValid()) ? true : false;
      if (this.isValidToDate) {
        this.purgeForm.get('dateTo').reset();
      }
    }

    ngOnDestroy() {
        this.activeSubscription.unsubscribe();
    }
}
