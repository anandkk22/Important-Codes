import { Component, OnDestroy, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { environment } from '@env';
import { SharedDataService } from '@global';
import { TranslateService } from '@ngx-translate/core';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { Constants } from 'app/admin/infrastructure/constants';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { SignatureFilesService } from 'app/admin/services/signature-files.service';
import { AppConstants } from 'app/app.constants';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { Constants as GlobalConstant } from '@global/infrastructure/constants';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'signature-files',
  templateUrl: './signature-files.component.html',
  styleUrls: ['./signature-files.component.scss'],
  providers: [SignatureFilesService]
})
export class SignatureFilesComponent implements OnInit, OnDestroy {
  signatureRequirements = [...Constants.signatureRequirements];
  signatures = [];
  isDataAvaliable: Boolean = false;
  uploadedFile = null;
  uploadedFileName: string;
  isSearchedApplied: Boolean = false;
  searchFile = '';
  accountNo = null;
  signatureFilesUrl = this.translate.instant('ADMIN_MENUS.SIGNATURE_FILES.signatureFilesUrl');
  activeSubscription: Subscription;

  constructor(
    private signatureFilesService: SignatureFilesService,
    private router: Router,
    private adminMenuUtilityService: AdminMenuUtilityService,
    private translate: TranslateService,
    private popupService: PopupService,
    private sharedDataService: SharedDataService,
    private spinnerService: SpinnerService,
    private titleService: Title) {
        this.titleService.setTitle(GlobalConstant.tabTitles[20]);
    }

  ngOnInit(): void {
    const userInfo: any = this.sharedDataService.getUserInfo();
    this.accountNo = userInfo.cnr_master_account_id;
    this.getSignatures();
  }

  getSignatures() {
    this.activeSubscription = this.signatureFilesService.getSignatures().subscribe((res: any) => {
      if (res) {
        this.signatures = [...res];
        this.isDataAvaliable = true;
      }
    });
    this.uploadedFileName = this.translate.instant('ADMIN_MENUS.SIGNATURE_FILES.noSignatureFile');
  }

  onSelectFile(files: FileList) {
    this.uploadedFile = files.item(0);
    this.uploadedFileName = this.uploadedFile?.name;
  }

  deleteSignature(signature) {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
      message: this.translate.instant('ADMIN_MENUS.SIGNATURE_FILES.deleteSignatureFile', { signatureFileName: signature.graphicFilename }),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.signatureFilesService.deleteSignature(signature).subscribe((response: any) => {
          this.adminMenuUtilityService.showSucessModal(this.translate.instant('ADMIN_MENUS.SIGNATURE_FILES.deleteedConfirmation',
            { signatureFileName: signature.graphicFilename }));
          this.getSignatures();
        });
      }
    });
  }

  navigateToPrevious() {
    this.router.navigate([AppConstants.uiRoutes.adminMenu]);
  }

  onKeyDownEvent(event) {
    this.signatureFilesService.searchSignatureFile(this.searchFile).subscribe((res: any) => {
      if (res) {
        this.signatures = [...res];
        this.isSearchedApplied = true;
      }
    });
  }

  uploadFile() {
    if (this.uploadedFile) {
      const fileFormat = this.uploadedFileName.split('.');
      const fileExtension = this.uploadedFileName.substring(this.uploadedFileName.indexOf('.') + 1).toLowerCase();
      if (fileFormat.length > 2) {
        this.adminMenuUtilityService.showAlert(this.translate.instant('ADMIN_MENUS.SIGNATURE_FILES.fileFormat'));
        this.cancel();
      }
      else if (fileExtension !== Constants.imgFileExtensions.jpg && fileExtension !== Constants.imgFileExtensions.jpeg) {
        this.adminMenuUtilityService.showAlert(this.translate.instant('ADMIN_MENUS.SIGNATURE_FILES.fileFormat'));
        this.cancel();
      } else {
        this.uploadSignature();
      }
    }
    else {
      this.adminMenuUtilityService.showAlert(this.translate.instant('ADMIN_MENUS.SIGNATURE_FILES.fileValidation'));
    }
  }

  uploadSignature() {
    if (this.uploadedFile) {
      this.signatureFilesService.uploadFiles(this.uploadedFile).subscribe(res => {
        if (res === this.translate.instant('ADMIN_MENUS.SIGNATURE_FILES.fileUploadConfirmation')) {
          this.adminMenuUtilityService.showSucessModal(
            this.translate.instant('ADMIN_MENUS.SIGNATURE_FILES.signatureUploaded', { fileName: this.uploadedFileName }));
          this.getSignatures();
        } else {
          this.adminMenuUtilityService.showAlert(res);
        }
        this.cancel();
      }, (err: HttpErrorResponse) => {
        if (err.status === 422) {
          this.cancel();
          this.adminMenuUtilityService.showAlert(this.translate.instant(err.error.Message));
          this.spinnerService.stop();
        }
      });
    }
  }

  cancel() {
    this.uploadedFile = null;
    this.uploadedFileName = this.translate.instant('ADMIN_MENUS.SIGNATURE_FILES.noSignatureFile');
  }

  clearSearch() {
    this.searchFile = '';
    this.getSignatures();
    this.isSearchedApplied = false;
  }

  getSignaturePath(graphicFilename) {
    return graphicFilename ? Constants.webApis.openImageFile.replace('{signatureFileName}', graphicFilename) : '';
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }

}
