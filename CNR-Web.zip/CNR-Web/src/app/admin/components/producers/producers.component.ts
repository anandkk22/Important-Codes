import { Component, OnInit, OnDestroy } from '@angular/core';
import '@wk/components/dist/accordion';
import { ActionMode, AdminMenuMasterData } from 'app/admin/infrastructure/models/admin-menu.model';
import { TranslateService } from '@ngx-translate/core';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { Subscription } from 'rxjs';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { take } from 'rxjs/operators';
import { AppConstants } from 'app/app.constants';
import { HttpErrorResponse } from '@angular/common/http';
import { ProducerService } from 'app/admin/services/producer.service';
import { Constants } from '@global/infrastructure/constants';
import { Router } from '@angular/router';
import { Title } from '@angular/platform-browser';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UploadProducersComponent } from '../upload-producers/upload-producers.component';

@Component({
    selector: 'app-maintain-producers',
    templateUrl: './producers.component.html',
    styleUrls: ['./producers.component.scss'],
    providers: [ProducerService]
})

export class MaintainProducersComponent implements OnInit, OnDestroy {

    activeSubscription: Subscription;
    requiredColumnData = ['Code', 'Name', 'Address 1', 'Address 2', 'City', 'Jurisdiction', 'Postal Code', 'Actions'];
    isDataAvaliable: Boolean = false;
    isMultipuleDelete: Boolean = false;
    backToPrevious = '/' + AppConstants.uiRoutes.adminMenu;
    isGridRowEditing = false;
    slectedProducerData = null;
    reloadGrid = false;
    isFilterSearched = false;
    searchDetails = null ;
    formFields = {
        code: '',
        name: '',
        address1: '',
        address2: '',
        city: '',
        stateProvidence: '',
        postalCode: ''
    };
    adminMenuMasterData: AdminMenuMasterData = {
        headerName: this.translate.instant('ADMIN_MENUS.MAINTAIN_PRODUCERS.add_producer'),
        addsChar: this.translate.instant('ADMIN_MENUS.HEADINGS.sChar'),
        fieldsDetails: {... this.formFields},
        tableData: {
            columnData: [],
            rowData: [],
            pageNo: 1,
            pageSize: 200,
            sortOnItem: 0,
            orderby: 0,
            isDataPaginated: true,
            totalCount: null,
            gridRowSelected: []
        },
        isEdit: false,
        showCodeField: true,
        isValidPostCode: true,
        deleteOrExport: false,
        isExpand: false,
        isFilterSearch: true,
        filterSearchData: {
            heading: this.translate.instant('ADMIN_MENUS.MAINTAIN_PRODUCERS.find_producer'),
            searchFields: ['code', 'name', 'jurisdiction']
        },
        maxCharacters: {
            nameMaxChar: Constants.adminMenus[3].producerMaxCharacters.name,
            address1MaxChar: Constants.adminMenus[3].producerMaxCharacters.address1,
            address2MaxChar: Constants.adminMenus[3].producerMaxCharacters.address2,
            cityMaxChar: Constants.adminMenus[3].producerMaxCharacters.city,
            jurisdictionMaxChar: Constants.adminMenus[3].producerMaxCharacters.jurisdiction,
            postalCodeMaxChar: Constants.adminMenus[3].producerMaxCharacters.postalCode,
            codeMaxChar: Constants.adminMenus[3].producerMaxCharacters.code
        },
        addEditByForm: true
    };
    formData = null;
    isEditActive = false;

    constructor(private translate: TranslateService,
        private adminMenuUtilityService: AdminMenuUtilityService,
        private producerService: ProducerService,
        private popupService: PopupService,
        private spinnerService: SpinnerService,
        private router: Router,
        private titleService: Title,
    private modalService: NgbModal) {
            this.titleService.setTitle(Constants.tabTitles[10]);
        }

    ngOnInit(): void {
        this.adminMenuMasterData.tableData.columnData = this.adminMenuUtilityService.getColumnData(this.requiredColumnData);
        this.getProducers(this.producerService.getFilterSearchUrl(this.adminMenuMasterData.tableData, null), false);
    }

    getProducers(url, isSelectedData) {
        this.reloadGrid = false;
        this.activeSubscription = this.producerService.getProducers(url).subscribe((res: any) => {
           if (res) {
               if (isSelectedData) {
                   this.adminMenuMasterData.tableData.gridRowSelected = this.producerService.getFormattedProducers(res);
                   this.reloadGrid = true;
               } else {
                   this.adminMenuMasterData.tableData.rowData = this.producerService.getFormattedProducers(res);
                   this.adminMenuMasterData.tableData.totalCount = res.totalCount;
                   this.adminMenuMasterData.tableData.isDataPaginated = res.isDataPaginated;
                   if ((this.adminMenuMasterData.tableData.rowData.length === 0) &&
                    (this.adminMenuMasterData.tableData.pageNo !== 1)) {
                    const pageNo = (this.adminMenuMasterData.tableData.pageNo - 1);
                    this.adminMenuMasterData.tableData.pageNo = pageNo;
                    this.getProducers(this.producerService.getFilterSearchUrl(this.adminMenuMasterData.tableData, null), false);
                } else {
                    this.reloadGrid = true;
                 }
              }
            this.isDataAvaliable = true;
           }
        });
    }

    actionClick(event) {
        if (event && ((event.form && event.form.invalid) || event.mode === null)) {
            return;
        }
        else {
            if (event && event.mode) {
                this.checkEventMode(event);
            }
        }
    }

    columnClicked(event) {
        if ( event && event.mode) {
            this.checkEventMode(event);
        }
    }

    checkEventMode(event) {
        switch (event.mode) {
            case ActionMode.upload:
                this.isGridRowEditing = false;
                this.isEditActive = false;
                break;
            case ActionMode.add:
                this.adminMenuMasterData.isExpand = true;
                this.addProducer(event);
                break;
            case ActionMode.save:
                this.saveEditedProoducer(event);
                break;
            case ActionMode.cancel:
                this.adminMenuMasterData.isEdit = false;
                this.isGridRowEditing = false;
                this.adminMenuMasterData.isExpand = false;
                this.isEditActive = false;
                break;
            case ActionMode.reset:
                this.prefillProducerData();
                this.adminMenuMasterData.isValidPostCode = true;
                break;
            case ActionMode.edit:
                this.isGridRowEditing = true;
                this.adminMenuMasterData.isEdit = true;
                this.adminMenuMasterData.addEditByForm = true;
                this.adminMenuMasterData.isExpand = true;
                this.slectedProducerData = null;
                this.slectedProducerData = this.adminMenuUtilityService.getFormattedFildsData(event.row);
                this.prefillProducerData();
                this.isEditActive = true;
                break;
            case ActionMode.delete:
                this.isMultipuleDelete = false;
                const producer =  event.row.name.length > 0 ?  event.row.name.trim() : '';
                const deleteMessage = this.translate.instant('ADMIN_MENUS.MAINTAIN_PRODUCERS.delete_producer', { producer: producer });
                this.deleteRecord(deleteMessage, [event.row.recordID]);
                break;
            case ActionMode.bulkDelete:
                this.isMultipuleDelete = true;
                const ids = [];
                event.gridData.forEach(data => {
                    if (data.recordID) {
                        ids.push(data.recordID);
                    }
                });
                const bulkDeleteMessage = this.translate.instant('ADMIN_MENUS.MAINTAIN_PRODUCERS.delete_producers');
                this.deleteRecord(bulkDeleteMessage, ids);
                break;
            case ActionMode.pageUpdate:
                this.getProducers(this.producerService.getFilterSearchUrl(this.adminMenuMasterData.tableData, null), false);
                break;
            case ActionMode.getAllData:
                const tableData = {
                    pageNo: 0,
                    pageSize: 0,
                    sortOnItem: 0,
                    orderby: 0,
                };
                this.reloadGrid = false;
                if (this.isFilterSearched) {
                    this.getProducers(this.producerService.getFilterSearchUrl(tableData, this.searchDetails), true);
                } else {
                    this.getProducers(this.producerService.getFilterSearchUrl(tableData, null), true);
                }
                break;
            default:
                break;
        }
    }

    prefillProducerData() {
        this.adminMenuMasterData.fieldsDetails.code = this.slectedProducerData.code;
        this.adminMenuMasterData.fieldsDetails.name = this.slectedProducerData.name;
        this.adminMenuMasterData.fieldsDetails.address1 = this.slectedProducerData.address1;
        this.adminMenuMasterData.fieldsDetails.address2 = this.slectedProducerData.address2;
        this.adminMenuMasterData.fieldsDetails.city = this.slectedProducerData.city;
        this.adminMenuMasterData.fieldsDetails.stateProvidence = this.slectedProducerData.stateProvidence ?
        this.slectedProducerData.stateProvidence.trim() : this.slectedProducerData.stateProvidence;
        this.adminMenuMasterData.fieldsDetails.postalCode = this.slectedProducerData.postalCode;
    }

    deleteRecord(message, param) {
        this.popupService.showConfirmation({
            title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
            message: message,
            positiveLabel: this.translate.instant('BUTTON.delete_button'),
            negativeLabel: this.translate.instant('BUTTON.cancel_button'),
        }).pipe(take(1)).subscribe(res => {
            if (res) {
                this.producerService.deleteProducers(param).subscribe(deleteInsurersRes => {
                    const deleteMessage = this.isMultipuleDelete ? this.translate.instant('MESSAGES.ALERT.deleted_records') :
                    this.translate.instant('MESSAGES.ALERT.deleted_record');
                    this.adminMenuUtilityService.showSucessModal(this.translate.instant(deleteMessage));
                    if (this.adminMenuMasterData.isEdit) {
                        const isPresent = this.adminMenuUtilityService.isEdittedDataDeleted(this.slectedProducerData.recordID, param);
                        if (isPresent) {
                            this.resetSaveEditData(this.formData);
                        }
                    } else {
                        if (this.isFilterSearched) {
                            this.getProducers(this.producerService.getFilterSearchUrl(this.adminMenuMasterData.tableData,
                                 this.searchDetails), false);
                        } else {
                            this.getProducers(this.producerService.getFilterSearchUrl(this.adminMenuMasterData.tableData, null), false);
                        }
                    }
                    this.adminMenuMasterData.tableData.gridRowSelected =  [];
                    this.adminMenuMasterData.deleteOrExport = false;
                });
            }
        });
    }

    addProducer(event) {
        this.producerService.addProducer(event.data).subscribe(res => {
            this.adminMenuUtilityService.showSucessModal(this.translate.instant('ADMIN_MENUS.MAINTAIN_PRODUCERS.added_producer'));
                this.resetSaveEditData(event);
        },
            (errors: HttpErrorResponse) => {
                this.changePostalValidation(errors);
        });
    }

    saveEditedProoducer(event) {
        const producerDetails = {
            id: this.slectedProducerData.recordID,
            ...event.data
        };
        this.producerService.saveEdittedProducer(this.producerService.getProducerDetails(producerDetails)).subscribe(res => {
            this.adminMenuUtilityService.showSucessModal(this.translate.instant('ADMIN_MENUS.MAINTAIN_PRODUCERS.edit_producer'));
            this.resetSaveEditData(event);
        },
            (errors: HttpErrorResponse) => {
                this.changePostalValidation(errors);
            });
    }

    resetSaveEditData(event) {
        event.form.resetForm();
        this.adminMenuMasterData.tableData.sortOnItem = 0;
        this.adminMenuMasterData.tableData.pageNo = 1;
        this.adminMenuMasterData.tableData.gridRowSelected =  [];
        this.adminMenuMasterData.isValidPostCode = true;
        this.adminMenuMasterData.isExpand = false;
        this.adminMenuMasterData.fieldsDetails.code = '';
        this.adminMenuMasterData.fieldsDetails.name = '';
        this.adminMenuMasterData.fieldsDetails.address1 = '';
        this.adminMenuMasterData.fieldsDetails.address2 = '';
        this.adminMenuMasterData.fieldsDetails.city = '';
        this.adminMenuMasterData.fieldsDetails.stateProvidence = '';
        this.adminMenuMasterData.fieldsDetails.postalCode = '';
        this.adminMenuMasterData.isEdit = false;
        this.isGridRowEditing = false;
        this.isEditActive = false;
        if (this.isFilterSearched) {
            this.getProducers(this.producerService.getFilterSearchUrl(this.adminMenuMasterData.tableData, this.searchDetails),
             false);
        } else {
            this.getProducers(this.producerService.getFilterSearchUrl(this.adminMenuMasterData.tableData, null), false);
        }
    }

    changePostalValidation(errors) {
        if (errors.status === 400) {
            this.adminMenuMasterData.isValidPostCode = false;
            this.adminMenuMasterData.fieldsDetails.stateProvidence =
            this.producerService.getstateDetails(this.adminMenuMasterData.fieldsDetails);
        }
        this.spinnerService.stop();
    }

    filterSearchClicked(event) {
        this.isFilterSearched = event.isFilterSearched;
        if (event && event.isFilterSearched) {
            this.searchDetails = event.searchDetails;
            this.getProducers(this.producerService.getFilterSearchUrl(this.adminMenuMasterData.tableData, event.searchDetails),
             false);
        } else {
            this.adminMenuMasterData.tableData.pageNo = 1;
            this.adminMenuMasterData.tableData.pageSize = 200;
            this.adminMenuMasterData.tableData.sortOnItem = 0;
            this.adminMenuMasterData.tableData.orderby = 0;
            this.getProducers(this.producerService.getFilterSearchUrl(this.adminMenuMasterData.tableData, null), false);
        }
    }

    getExpandedStatus(status) {
        if (status) {
            this.adminMenuMasterData.isExpand = false;
        }  else {
            this.adminMenuMasterData.isExpand = true;
        }
    }

    navigateToPrevious() {
        this.router.navigate([AppConstants.uiRoutes.adminMenu]);
    }

    getFormData(event) {
        this.formData = event;
    }

    isProducerClick(event) {
        if (event) {
           const modalRef = this.modalService.open(UploadProducersComponent);
           modalRef.result.then((userResponse) => {
               if (userResponse) {
                this.getProducers(this.producerService.getFilterSearchUrl(this.adminMenuMasterData.tableData, null), false);
               }
          });
        }
    }

    ngOnDestroy() {
        this.activeSubscription.unsubscribe();
    }

}
