import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import '@wk/components/dist/accordion';
import { PopupService } from '@wk/nils-core';
import { CustomLobService } from 'app/admin/services/custom-lob.service';
import { AppConstants } from 'app/app.constants';
import { forkJoin, Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { Constants } from 'app/admin/infrastructure/constants';

import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { Title } from '@angular/platform-browser';
import { Constants as GlobalConstant } from '@global/infrastructure/constants';

@Component({
  selector: 'app-customized-lob',
  templateUrl: './customized-lob.component.html',
  styleUrls: ['./customized-lob.component.scss'],
  providers: [CustomLobService]
})
export class CustomizedLobComponent implements OnInit {
  lobs: any = [];
  customLobs: any = [];
  isDataAvailable = false;
  subscriptions: Subscription[] = [];
  isEdit = false;
  isExpanded = true;
  lobRow: any;
  highlightLob: any = '';
  customLobsForm: FormGroup;

  constructor(private customLobService: CustomLobService,
    private formBuilder: FormBuilder,
    private popupService: PopupService,
    private translate: TranslateService,
    private router: Router,
    private adminMenuUtilityService: AdminMenuUtilityService,
    private titleService: Title) {
        this.titleService.setTitle(GlobalConstant.tabTitles[14]);
    }

  ngOnInit(): void {
    this.customLobsForm = this.formBuilder.group({
      lob: ['', Validators.required],
      customLob: ['', [
        Validators.required,
        this.validateInput,
        Validators.maxLength(Constants.customLOBMaxLength)
      ]],
    });
    this.fetchLOBs();
  }


  validateInput(userControl: AbstractControl) {
    const invalidWordsList = Constants.invalidWords;

    length = invalidWordsList.length;
    while (length--) {
      if (userControl.value && userControl.value.indexOf(invalidWordsList[length]) !== -1) {
        return { 'invalidWords': true };
      }
    }
    return null;
  }

  fetchLOBs() {
    const allLobs = this.customLobService.getLOBs();
    const allCustomLobs = this.customLobService.getCustomLOBs();
    this.subscriptions.push(
      forkJoin([allLobs, allCustomLobs]).subscribe(
        (res: any) => {
          if (res) {
            this.lobs = res[0];
            this.customLobs = res[1];
            this.isDataAvailable = true;
          }
        }
      )
    );
  }

  fetchCustomLobs() {
    this.customLobService.getCustomLOBs().subscribe(
      (res: any) => {
        this.customLobs = res;
      }
    );
  }

  onSubmit() {
    if (this.isEdit) {
      this.edit();
    } else {
      this.add();
    }
  }

  add() {
    this.customLobService.saveCustomLob(
      this.customLobsForm.get('lob').value,
      this.customLobsForm.get('customLob').value
    ).subscribe(res => {
      this.popupService.showSuccess({
        title: '',
        message: this.customLobsForm.get('customLob').value + ' ' + this.translate.instant('ADMIN_MENUS.CUSTOMIZED_LOB.lobAdded'),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: '',
      });
      this.fetchCustomLobs();
      this.resetAndEnable();
    });
  }

  editCustomLOB(row, index) {
    this.lobRow = row;
    this.isEdit = true;
    this.isExpanded = true;
    this.setFormFields(row);
    this.highlightLob = this.customLobsForm.get('customLob').value;
    this.customLobsForm.get('lob').disable();
    const el =  document.getElementById('formSection');
    el.scrollIntoView();
  }

  setFormFields(row) {
    this.customLobsForm.get('lob').setValue(row.lobid);
    this.customLobsForm.get('customLob').setValue(row.customizedLob);
  }

  edit() {
    this.customLobService.editCustomLob(
      this.lobRow.lobid,
      this.customLobsForm.get('customLob').value,
      this.lobRow.customizedLob
    ).subscribe(res => {
      this.popupService.showSuccess({
        title: '',
        message: this.lobRow.customizedLob + ' ' + this.translate.instant('ADMIN_MENUS.CUSTOMIZED_LOB.lobUpdated'),
        positiveLabel: this.translate.instant('BUTTON.ok_button'),
        negativeLabel: '',
      });
      this.highlightLob = '' ;
      this.isEdit = false;
      this.resetAndEnable();
      this.fetchCustomLobs();
    });
  }

  delete(row) {
    this.highlightLob = '';
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
      message: this.translate.instant('ADMIN_MENUS.CUSTOMIZED_LOB.deleteConfirmation') + ' ' + row.customizedLob + '?',
      positiveLabel: this.translate.instant('BUTTON.delete_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.customLobService.deleteLOB(row).subscribe(response => {
          this.popupService.showSuccess({
            title: '',
            message: this.translate.instant('MESSAGES.ALERT.deleted_record'),
            positiveLabel: this.translate.instant('BUTTON.ok_button'),
            negativeLabel: '',
          });
          this.isEdit = false;
          this.resetAndEnable();
          this.fetchCustomLobs();
        });
      }
    });
  }

  cancel() {
    this.isExpanded = false;
    this.isEdit = false;
    this.resetAndEnable();
    this.highlightLob = '';
  }

  expandForm(event) {
    event.stopPropagation();
  }

  isManualExpanded() {
    this.isExpanded = !this.isExpanded;
  }

  reset() {
    this.customLobsForm.patchValue({
      customLob: this.lobRow.customizedLob
    });
  }

  resetAndEnable() {
    this.customLobsForm.reset();
    this.customLobsForm.get('lob').setValue('');
    this.customLobsForm.get('lob').enable();
  }

  navigateToPrevious() {
    this.router.navigate([AppConstants.uiRoutes.adminMenu]);
  }
}
