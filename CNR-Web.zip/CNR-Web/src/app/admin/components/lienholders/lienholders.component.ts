import { Component, OnDestroy, OnInit } from '@angular/core';
import '@wk/components/dist/accordion';
import { ActionMode, AdminMenuMasterData, GridRowData, AdminFieldsData, maintainPartyEnums } from 'app/admin/infrastructure/models/admin-menu.model';
import { TranslateService } from '@ngx-translate/core';
import { AdminMenuService } from 'app/admin/services/admin-menu.service';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { take } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { AppConstants } from 'app/app.constants';
import { HttpErrorResponse } from '@angular/common/http';

import { Router } from '@angular/router';
import { Constants } from '@global/infrastructure/constants';
import { Title } from '@angular/platform-browser';

@Component({
    selector: 'app-maintain-lienholder',
    templateUrl: './lienholders.component.html',
    styleUrls: ['./lienholders.component.scss']
})
export class MaintainLienholderComponent implements OnInit, OnDestroy {
    isGridRowEditing = false;
    reloadGrid = false;
    backToPrevious = '/' + AppConstants.uiRoutes.adminMenu;
    activeSubscription: Subscription;
    lienholderPartyType = 2;
    recordId = 0;
    recordName = [];
    adminMenuMasterData: AdminMenuMasterData = {
        headerName: this.translate.instant('ADMIN_MENUS.HEADINGS.maintain_lienholder'),
        addsChar: this.translate.instant('ADMIN_MENUS.HEADINGS.sChar'),
        fieldsDetails: {
            code: '',
            name: '',
            address1: '',
            address2: '',
            city: '',
            stateProvidence: '',
            postalCode: ''
        },
        tableData: {
            columnData: [
                {
                    field: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.field_Name'),
                    header: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.header_Name'),
                    width: '15%',
                    sortBy: 0
                },
                {
                    field: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.field_Addr1'),
                    header: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.header_Addr1'),
                    width: '25%',
                    sortBy: 1
                },
                {
                    field: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.field_Addr2'),
                    header: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.header_Addr2'),
                    width: '15%',
                    sortBy: 2
                },
                {
                    field: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.field_City'),
                    header: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.header_City'),
                    width: '10%',
                    sortBy: 3
                },
                {
                    field: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.field_State'),
                    header: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.header_Jurisdiction'),
                    width: '10%',
                    sortBy: 4
                },
                {
                    field: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.field_PostalCode'),
                    header: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.header_PostalCode'),
                    width: '10%',
                    sortBy: 5
                },
                {
                    field: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.field_Actions'),
                    header: this.translate.instant('ADMIN_MENUS.COLUMN_DATA_FIELD_NAME.header_Actions'),
                    width: '10%',
                    sortBy: null
                },
            ],
            rowData: [],
            pageNo: 1,
            pageSize: 200,
            sortOnItem: 0,
            orderby: 0,
            isDataPaginated: true,
            totalCount: null,
            gridRowSelected: []
        },
        isEdit: false,
        showCodeField: false,
        isValidPostCode: true,
        deleteOrExport: false,
        isExpand: false,
        maxCharacters: {
            nameMaxChar: Constants.adminMenus[0].addIntCertHoldLineHoldMorgMaxCharacters.name,
            address1MaxChar: Constants.adminMenus[0].addIntCertHoldLineHoldMorgMaxCharacters.address1,
            address2MaxChar: Constants.adminMenus[0].addIntCertHoldLineHoldMorgMaxCharacters.address2,
            cityMaxChar: Constants.adminMenus[0].addIntCertHoldLineHoldMorgMaxCharacters.city,
            jurisdictionMaxChar: Constants.adminMenus[0].addIntCertHoldLineHoldMorgMaxCharacters.jurisdiction,
            postalCodeMaxChar: Constants.adminMenus[0].addIntCertHoldLineHoldMorgMaxCharacters.postalCode,
            codeMaxChar: Constants.adminMenus[0].addIntCertHoldLineHoldMorgMaxCharacters.code
        },
        addEditByForm: true
    };

    isBulkDelete = false;
    formData = null;
    isEditActive = false;
    isDataAvalailable = false;

    constructor(
        private translate: TranslateService,
        private adminMenuService: AdminMenuService,
        private popupService: PopupService,
        private adminMenuUtilityService: AdminMenuUtilityService,
        private spinnerService: SpinnerService,
        private router: Router,
        private titleService: Title) {
            this.titleService.setTitle(Constants.tabTitles[8]);
        }

    ngOnInit() {
        this.router.navigate([`/${Constants.headerOptions[3].subUrls[1]}`]);
        this.getLienholderRecords();
    }

    getExpandedStatus(status) {
        if (status) {
            this.adminMenuMasterData.isExpand = false;
            }  else {
                this.adminMenuMasterData.isExpand = true;
            }
    }

    getLienholderRecords() {
        this.reloadGrid = false;
        let pageNo = this.adminMenuMasterData.tableData.pageNo;
        const pageSize = this.adminMenuMasterData.tableData.pageSize;
        const sortOnItem = this.adminMenuMasterData.tableData.sortOnItem;
        const orderby = this.adminMenuMasterData.tableData.orderby;
        const getFilterUrl =  this.adminMenuUtilityService.
        getGridFilterUrl(this.lienholderPartyType, pageNo, pageSize, sortOnItem, orderby);
        this.activeSubscription = this.adminMenuService.getAllParties(getFilterUrl)
        .subscribe((res: any) => {
            if (res) {
                this.adminMenuMasterData.tableData.rowData = res.paginationData;
                this.adminMenuMasterData.tableData.totalCount = res.totalCount;
                this.adminMenuMasterData.tableData.isDataPaginated = res.isDataPaginated;
                if ((this.adminMenuMasterData.tableData.rowData.length === 0)   &&
                (this.adminMenuMasterData.tableData.pageNo !== 1)) {
                    pageNo = (this.adminMenuMasterData.tableData.pageNo - 1);
                    this.adminMenuMasterData.tableData.pageNo = pageNo;
                    this.getLienholderRecords();
                 } else {
                    this.reloadGrid = true;
                 }
                 this.isDataAvalailable = true;
            }
        });
    }

    getAllRowRecords(): void {
        this.reloadGrid = false;
        const getFilterUrl =  this.adminMenuUtilityService.getGridFilterUrl(this.lienholderPartyType, 0, 0, 0, 0);
        this.activeSubscription = this.adminMenuService.getAllParties(getFilterUrl)
        .subscribe((res: any) => {
            this.adminMenuMasterData.tableData.gridRowSelected = res.paginationData;
            this.reloadGrid = true;
        });
      }

    columnClicked(event) {
        if (event.mode === ActionMode.edit) {
            this.isGridRowEditing = true;
            this.isEditActive = true;
            this.adminMenuMasterData.isEdit = true;
            this.adminMenuMasterData.isExpand = true;
            this.recordId = event.row.recordID;
            this.adminMenuService.getSingleRowData(event.row.recordID).subscribe((res: GridRowData) => {
                res = this.adminMenuUtilityService.getFormattedFildsData(res);
                this.adminMenuMasterData.fieldsDetails.code = res.code;
                this.adminMenuMasterData.fieldsDetails.name = res.name;
                this.adminMenuMasterData.fieldsDetails.address1 = res.address1;
                this.adminMenuMasterData.fieldsDetails.address2 = res.address2;
                this.adminMenuMasterData.fieldsDetails.city = res.city;
                this.adminMenuMasterData.fieldsDetails.stateProvidence = res.stateProvidence;
                this.adminMenuMasterData.fieldsDetails.postalCode = res.postalCode;
            });
        } else if (event.mode === ActionMode.delete) {
            this.isBulkDelete = false;
            const recordID = [event.row.recordID];
            this.recordName = [event.row.name];
            this.deleteRecords(recordID);
        } else if (event.mode === ActionMode.bulkDelete) {
            this.isBulkDelete = true;
            const recordID = [];
            event.gridData.forEach(element => {
                recordID.push(element.recordID);
            });
            this.deleteRecords(recordID);
        } else if (event.mode === ActionMode.pageUpdate) {
            this.getLienholderRecords();
          } else if (event.mode === ActionMode.getAllData) {
            this.getAllRowRecords();
          }
    }

    actionClick(formData: any): void {
        if (formData.mode === ActionMode.cancel) {
            this.adminMenuMasterData.isEdit = false;
            this.isGridRowEditing = false;
            this.isEditActive = false;
            this.adminMenuMasterData.isExpand = false;
        }
        else if (formData.mode === ActionMode.reset) {
            this.adminMenuService.getSingleRowData(this.recordId).subscribe((res: GridRowData) => {
                this.adminMenuMasterData.fieldsDetails.code = res.code;
                this.adminMenuMasterData.fieldsDetails.name = res.name;
                this.adminMenuMasterData.fieldsDetails.address1 = res.address1;
                this.adminMenuMasterData.fieldsDetails.address2 = res.address2;
                this.adminMenuMasterData.fieldsDetails.city = res.city;
                this.adminMenuMasterData.fieldsDetails.stateProvidence = res.stateProvidence;
                this.adminMenuMasterData.fieldsDetails.postalCode = res.postalCode;
            });
            this.adminMenuMasterData.isValidPostCode = true;
        }
        if (formData.form.invalid) {
            return;
        }
        if (formData.mode === ActionMode.add) {
            this.adminMenuMasterData.isExpand = true;
            const getParams = this.adminMenuUtilityService.getFormDataAndTypeId(formData.data, maintainPartyEnums[2]);
            this.adminMenuService.addRecord(getParams).subscribe(res => {
                if (res) {
                    this.popupService.showSuccess({
                        title: '',
                        message: this.adminMenuMasterData.headerName + this.translate.instant('MESSAGES.ALERT.added_record'),
                        positiveLabel: this.translate.instant('BUTTON.ok_button'),
                        negativeLabel: '',
                    });
                    formData.form.resetForm();
                    this.adminMenuMasterData.tableData.orderby = 0;
                    this.adminMenuMasterData.tableData.sortOnItem = 0;
                    this.adminMenuMasterData.tableData.pageNo = 1;
                    this.adminMenuMasterData.tableData.gridRowSelected =  [];
                    this.getLienholderRecords();
                    this.adminMenuMasterData.isExpand = false;
                }
                this.adminMenuMasterData.isValidPostCode = true;
            },
                (errors: HttpErrorResponse) => {
                    if (errors.status === 400) {
                        this.adminMenuMasterData.isValidPostCode = false;
                    }
                    this.spinnerService.stop();
                });
        }
        else if (formData.mode === ActionMode.save) {
            const getParams = this.adminMenuUtilityService.getFormDataAndTypeId(formData.data, maintainPartyEnums[2]);
            this.adminMenuService.updateSingleRowData(this.recordId, getParams).subscribe(res => {
                if (res) {
                    this.popupService.showSuccess({
                        title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
                        message: this.adminMenuMasterData.headerName + this.translate.instant('ADMIN_PANEL_SCREEN.MAINTAIN_PARTIES.update_message'),
                        positiveLabel: this.translate.instant('BUTTON.ok_button'),
                        negativeLabel: '',
                    });
                    this.getLienholderRecords();
                    this.isGridRowEditing = false;
                    this.isEditActive = false;
                    this.adminMenuMasterData.tableData.orderby = 0;
                    this.adminMenuMasterData.tableData.sortOnItem = 0;
                    this.adminMenuMasterData.tableData.pageNo = 1;
                    this.adminMenuMasterData.tableData.gridRowSelected =  [];
                    this.recordId = null;
                    formData.form.resetForm();
                    this.adminMenuMasterData.isEdit = false;
                    this.adminMenuMasterData.isValidPostCode = true;
                    this.adminMenuMasterData.isExpand = false;
                }
            },
                (errors: HttpErrorResponse) => {
                    if (errors.status === 400) {
                        this.adminMenuMasterData.isValidPostCode = false;
                    }
                    this.spinnerService.stop();
                });
        }
    }

    deleteRecords(recordID: Number[]) {
        this.popupService.showConfirmation({
            title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
            message: this.isBulkDelete ?
                this.translate.instant('ADMIN_MENUS.Confirmation.delete_selected_lienholder') :
                this.translate.instant('ADMIN_MENUS.Confirmation.wish_to_delete') + this.recordName + this.translate.instant('ADMIN_MENUS.Confirmation.question'),
            positiveLabel: this.translate.instant('BUTTON.delete_button'),
            negativeLabel: this.translate.instant('BUTTON.cancel_button'),
        }).pipe(take(1)).subscribe(res => {
            if (res) {
                this.adminMenuService.deleteRecords(recordID)
                    .subscribe(response => {
                        this.popupService.showSuccess({
                            title: '',
                            message: this.isBulkDelete ? this.translate.instant('MESSAGES.ALERT.deleted_records') :
                            this.translate.instant('MESSAGES.ALERT.deleted_record') ,
                            positiveLabel: this.translate.instant('BUTTON.ok_button'),
                            negativeLabel: '',
                        });
                        if (this.adminMenuMasterData.isEdit) {
                            const isPresent = this.adminMenuUtilityService.isEdittedDataDeleted(this.recordId, recordID);
                            if (isPresent) {
                                this.resetData(this.formData);
                            }
                        }
                        this.adminMenuMasterData.tableData.gridRowSelected = [];
                        this.getLienholderRecords();
                        this.adminMenuMasterData.deleteOrExport = false;
                    });
            }
        });
    }

    navigateToPrevious() {
        this.router.navigate([AppConstants.uiRoutes.adminMenu]);
    }

    getFormData(event) {
        this.formData = event;
    }

    resetData(formData) {
        this.isGridRowEditing = false;
        this.isEditActive = false;
        this.adminMenuMasterData.tableData.orderby = 0;
        this.adminMenuMasterData.tableData.sortOnItem = 0;
        this.adminMenuMasterData.tableData.pageNo = 1;
        this.adminMenuMasterData.tableData.gridRowSelected = [];
        this.recordId = null;
        formData.form.resetForm();
        this.adminMenuMasterData.isEdit = false;
        this.adminMenuMasterData.isValidPostCode = true;
        this.adminMenuMasterData.isExpand = false;
    }

    ngOnDestroy() {
        this.activeSubscription.unsubscribe();
    }
}
