import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-unauthorize-admin-access',
  templateUrl: './unauthorize-admin-access.component.html',
  styleUrls: ['./unauthorize-admin-access.component.scss']
})
export class UnauthorizeAdminAccessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
