import { Component, OnInit, OnDestroy } from '@angular/core';
import '@wk/components/dist/accordion';
import { ActionMode, AdminMenuMasterData } from 'app/admin/infrastructure/models/admin-menu.model';
import { TranslateService } from '@ngx-translate/core';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { Subscription } from 'rxjs';
import { InsurerService } from 'app/admin/services/insurer.service';
import { GridRowData } from '@wk/nils-shared/lib/infrastructure/models/admin-menu.model';
import { PopupService, SpinnerService } from '@wk/nils-core';
import { take } from 'rxjs/operators';
import { AppConstants } from 'app/app.constants';
import { HttpErrorResponse } from '@angular/common/http';

import { Router } from '@angular/router';
import { Constants } from '@global/infrastructure/constants';
import { Title } from '@angular/platform-browser';

@Component({
    selector: 'app-maintain-insurers',
    templateUrl: './insurers.component.html',
    styleUrls: ['./insurers.component.scss'],
    providers: [InsurerService]
})

export class MaintainInsurersComponent implements OnInit, OnDestroy {
    activeSubscription: Subscription;
    requiredColumnData = ['ID', 'Code', 'Name', 'Address 1', 'Address 2', 'City', 'Jurisdiction', 'Postal Code', 'Actions'];
    isDataAvaliable: Boolean = false;
    isMultipuleDelete: Boolean = false;
    backToPrevious = '/' + AppConstants.uiRoutes.adminMenu;
    editInsurerId: number = null;
    isGridRowEditing = false;
    slectedInsurerData = null;
    reloadGrid = false;
    formFields = {
        code: '',
        name: '',
        address1: '',
        address2: '',
        city: '',
        stateProvidence: '',
        postalCode: ''
    };
    adminMenuMasterData: AdminMenuMasterData = {
        headerName: this.translate.instant('ADMIN_MENUS.MAINTAIN_INSURERS.add_insurer'),
        addsChar: this.translate.instant('ADMIN_MENUS.HEADINGS.sChar'),
        fieldsDetails: {...this.formFields},
        tableData: {
            columnData: [],
            rowData: [],
            pageNo: 1,
            pageSize: 200,
            sortOnItem: 0,
            orderby: 0,
            isDataPaginated: true,
            totalCount: null,
            gridRowSelected: []
        },
        isEdit: false,
        showCodeField: true,
        isValidPostCode: true,
        deleteOrExport: false,
        isExpand: false,
        maxCharacters: {
            nameMaxChar: Constants.adminMenus[2].insurerMaxCharacters.name,
            address1MaxChar: Constants.adminMenus[2].insurerMaxCharacters.address1,
            address2MaxChar: Constants.adminMenus[2].insurerMaxCharacters.address2,
            cityMaxChar: Constants.adminMenus[2].insurerMaxCharacters.city,
            jurisdictionMaxChar: Constants.adminMenus[2].insurerMaxCharacters.jurisdiction,
            postalCodeMaxChar: Constants.adminMenus[2].insurerMaxCharacters.postalCode,
            codeMaxChar: Constants.adminMenus[2].insurerMaxCharacters.code
        },
        addEditByForm: true
    };
    formData = null;
    isEditActive = false;

    constructor(private translate: TranslateService,
        private adminMenuUtilityService: AdminMenuUtilityService,
        private insurerService: InsurerService,
        private popupService: PopupService,
        private spinnerService: SpinnerService,
        private router: Router,
        private titleService: Title) {
            this.titleService.setTitle(Constants.tabTitles[7]);
        }

    ngOnInit(): void {
        this.adminMenuMasterData.tableData.columnData = this.adminMenuUtilityService.getColumnData(this.requiredColumnData);
        this.getInsurers(this.adminMenuMasterData.tableData, false);
    }

    getExpandedStatus(status) {
        if (status) {
            this.adminMenuMasterData.isExpand = false;
            }  else {
                this.adminMenuMasterData.isExpand = true;
            }
    }

    getInsurers(paginationData, isSelectedData) {
        this.reloadGrid = false;
        this.activeSubscription = this.insurerService.getInsurers(paginationData).
            subscribe((res: any) => {
                if (res) {
                    if (isSelectedData) {
                        this.adminMenuMasterData.tableData.gridRowSelected = this.insurerService.getFormattedInsurers(res);
                        this.reloadGrid = true;
                    } else {
                        this.adminMenuMasterData.tableData.rowData = this.insurerService.getFormattedInsurers(res);
                        this.adminMenuMasterData.tableData.totalCount = res.totalCount;
                        this.adminMenuMasterData.tableData.isDataPaginated = res.isDataPaginated;
                        if ((this.adminMenuMasterData.tableData.rowData.length === 0)
                        && (this.adminMenuMasterData.tableData.pageNo !== 1)) {
                            const pageNo = (this.adminMenuMasterData.tableData.pageNo - 1);
                            this.adminMenuMasterData.tableData.pageNo = pageNo;
                            this.getInsurers(this.adminMenuMasterData.tableData, false);
                        }
                        else {
                            this.reloadGrid = true;
                         }
                    }
                    this.isDataAvaliable = true;
                }
            });
    }

    columnClicked(event) {
        if ( event && event.mode) {
            this.checkEventMode(event);
        }
    }

    checkEventMode(event) {
        switch (event.mode) {
            case ActionMode.add:
                this.adminMenuMasterData.isExpand = true;
                this.addInsurer(event);
                break;
            case ActionMode.save:
                this.saveEditedInsurer(event);
                break;
            case ActionMode.cancel:
                this.adminMenuMasterData.isEdit = false;
                this.isGridRowEditing = false;
                this.isEditActive = false;
            this.adminMenuMasterData.isExpand = false;
                break;
            case ActionMode.reset:
                this.prefillInsurerData();
                this.adminMenuMasterData.isValidPostCode = true;
                break;
            case ActionMode.edit:
                this.isGridRowEditing = true;
                this.isEditActive = true;
                this.adminMenuMasterData.isEdit = true;
                this.editInsurerId = event.row.recordID;
                this.editInsurer(event.row.recordID);
                break;
            case ActionMode.delete:
                this.isMultipuleDelete = false;
                let insurer =  event.row.recordID ?  event.row.recordID + ' - ' : '';
                insurer = event.row.name.length > 0 ?  insurer + event.row.name.trim() : insurer + '';
                const deleteMessage = this.translate.instant('ADMIN_MENUS.MAINTAIN_INSURERS.delete_insurer', { insurer: insurer });
                this.deleteRecord(deleteMessage, event.row.recordID);
                break;
            case ActionMode.bulkDelete:
                this.isMultipuleDelete = true;
                const ids = [];
                event.gridData.forEach(data => {
                    if (data.recordID) {
                        ids.push(data.recordID);
                    }
                });
                const bulkDeleteMessage = this.translate.instant('ADMIN_MENUS.MAINTAIN_INSURERS.delete_insurers');
                this.deleteRecord(bulkDeleteMessage, ids);
                break;
            case ActionMode.pageUpdate:
                this.getInsurers(this.adminMenuMasterData.tableData, false);
                break;
            case ActionMode.getAllData:
                const tableData = {
                    pageNo: 0,
                    pageSize: 0,
                    sortOnItem: 0,
                    orderby: 0,
                };
                this.reloadGrid = false;
                this.getInsurers(tableData, true);
                break;
            default:
                break;
        }

    }
    editInsurer(recordID) {
        this.insurerService.getInsurerData(recordID).subscribe((res: GridRowData) => {
            this.slectedInsurerData = this.adminMenuUtilityService.getFormattedFildsData(res);
            this.adminMenuMasterData.isExpand = true;
            this.prefillInsurerData();
        });

    }

    prefillInsurerData() {
        this.adminMenuMasterData.fieldsDetails.code = this.slectedInsurerData.code.trim();
        this.adminMenuMasterData.fieldsDetails.name = this.slectedInsurerData.name;
        this.adminMenuMasterData.fieldsDetails.address1 = this.slectedInsurerData.address1;
        this.adminMenuMasterData.fieldsDetails.address2 = this.slectedInsurerData.address2;
        this.adminMenuMasterData.fieldsDetails.city = this.slectedInsurerData.city;
        this.adminMenuMasterData.fieldsDetails.stateProvidence = this.slectedInsurerData.stateProvidence;
        this.adminMenuMasterData.fieldsDetails.postalCode = this.slectedInsurerData.postalCode;
    }

    deleteRecord(message, param) {
        this.popupService.showConfirmation({
            title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
            message: message,
            positiveLabel: this.translate.instant('BUTTON.delete_button'),
            negativeLabel: this.translate.instant('BUTTON.cancel_button'),
        }).pipe(take(1)).subscribe(res => {
            if (res) {
                if (this.isMultipuleDelete) {
                    this.insurerService.deleteInsurers(param).subscribe(deleteInsurersRes => {
                        this.adminMenuUtilityService.showSucessModal(this.translate.instant('MESSAGES.ALERT.deleted_records'));
                        if (this.slectedInsurerData) {
                            const isPresent = this.adminMenuUtilityService.isEdittedDataDeleted(this.editInsurerId, param);
                            if (isPresent) {
                                this.resetData(this.formData);
                            }
                        }
                        this.adminMenuMasterData.deleteOrExport = false;
                        this.adminMenuMasterData.tableData.gridRowSelected = [];
                        this.getInsurers(this.adminMenuMasterData.tableData, false);
                    });
                } else {
                    this.insurerService.deleteInsurer(param).subscribe(deleteInsurerRes => {
                        this.adminMenuUtilityService.showSucessModal(this.translate.instant('MESSAGES.ALERT.deleted_record'));
                        if (this.slectedInsurerData) {
                            const isPresent = this.adminMenuUtilityService.isEdittedDataDeleted(this.editInsurerId, [param]);
                            if (isPresent) {
                                this.resetData(this.formData);
                            }
                        }
                        this.adminMenuMasterData.tableData.gridRowSelected = [];
                        this.getInsurers(this.adminMenuMasterData.tableData, false);
                    });
                }
            }
        });

    }

    actionClick(event) {
        if (event && ((event.form && event.form.invalid) || event.mode === null)) {
            return;
        }
        else {
            if (event && event.mode) {
                this.checkEventMode(event);
            }
        }
    }

    addInsurer(event) {
        this.insurerService.addInsurer(event.data).subscribe(res => {
            this.adminMenuUtilityService.showSucessModal(this.translate.instant('ADMIN_MENUS.MAINTAIN_INSURERS.added_insurer'));
            this.resetData(event);
        },
            (errors: HttpErrorResponse) => {
                this.changePostalValidation(errors);
            });
    }

    saveEditedInsurer(event) {
        this.insurerService.saveEdittedInsurer(event.data, this.editInsurerId).subscribe(res => {
            this.adminMenuUtilityService.showSucessModal(this.translate.instant('ADMIN_MENUS.MAINTAIN_INSURERS.edit_insurer'));
            this.resetData(event);
        },
            (errors: HttpErrorResponse) => {
                this.changePostalValidation(errors);
            });
    }

    changePostalValidation(errors) {
        if (errors.status === 400) {
            this.adminMenuMasterData.isValidPostCode = false;
        }
        this.spinnerService.stop();
    }

    resetData(event) {
        event.form.resetForm();
        this.isGridRowEditing = false;
        this.editInsurerId = null;
        this.adminMenuMasterData.fieldsDetails.code = '';
        this.adminMenuMasterData.fieldsDetails.name = '';
        this.adminMenuMasterData.fieldsDetails.address1 = '';
        this.adminMenuMasterData.fieldsDetails.address2 = '';
        this.adminMenuMasterData.fieldsDetails.city = '';
        this.adminMenuMasterData.fieldsDetails.stateProvidence = '';
        this.adminMenuMasterData.fieldsDetails.postalCode = '';
        this.adminMenuMasterData.isEdit = false;
        this.adminMenuMasterData.tableData.pageNo = 1;
        this.adminMenuMasterData.tableData.orderby = 0;
        this.adminMenuMasterData.tableData.sortOnItem = 0;
        this.adminMenuMasterData.isValidPostCode = true;
        this.adminMenuMasterData.isExpand = false;
        this.adminMenuMasterData.tableData.gridRowSelected =  [];
        this.isEditActive = false;
        this.getInsurers(this.adminMenuMasterData.tableData, false);
    }

    navigateToPrevious() {
        this.router.navigate([AppConstants.uiRoutes.adminMenu]);
       }

    getFormData(event) {
        this.formData = event;
    }

    ngOnDestroy() {
        this.activeSubscription.unsubscribe();
    }

}
