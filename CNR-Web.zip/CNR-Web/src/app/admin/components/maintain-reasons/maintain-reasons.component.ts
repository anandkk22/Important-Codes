import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { PopupService} from '@wk/nils-core';
import { TranslateService } from '@ngx-translate/core';
import { take } from 'rxjs/operators';
import { NgSelectComponent } from '@ng-select/ng-select';
import { MaintainReasonsService } from 'app/admin/services/maintain-reasons.service';
import { MaintainReasonsUtilityService } from 'app/admin/services/maintain-reasons-utility.service';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { MaintainReasonsConstants } from 'app/admin/infrastructure/maintain-reasons-constants';
import { DaysNoticeRequirementsService } from 'app/admin/services/days-notice-requirements.service';
import { Router } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { Title } from '@angular/platform-browser';
import { Constants, Constants as GlobalConstant } from '@global/infrastructure/constants';
import '@wk/components/dist/tooltip';
@Component({
  selector: 'app-maintain-reasons',
  templateUrl: './maintain-reasons.component.html',
  styleUrls: ['./maintain-reasons.component.scss']
})
export class MaintainReasonsComponent implements OnInit {
  @ViewChild('selecter') ngselect: NgSelectComponent;
  allJurisdictions = [];
  selectedJurisdictions = [];
  allActions = [];
  selectedActions = [];
  allLobs = [];
  selectedLobs = [];
  allCircumstances = [];
  selectedCircumstances = [];
  addReasonColumn = false;
  isFoundFilterData = false;
  allmaintainReasons = [];
  filterJurisdiction = [];
  collectionOfwkDefaultRow = [];
  reasonsGridRowSelected = [];
  isAtleastOneRowSelected = false;
  isAllChecked = false;
  wkDefault = true;
  editReasonId = null;
  editReasonText = '';
  editedReasonText = '';
  isBulkDelete = false;
  editView = false;
  isClickedDisplay = false;
  isClickedAddReason = false;
  editID = '';
  public reasonAddTextForm: FormGroup = new FormGroup({
    addReasonText: new FormControl('', [Validators.required])
  });
  reasonsParameterUrl =  this.translate.instant('ADMIN_MENUS.MAINTAIN_REASONS.maintain_reasons_url');
  isAllDeleted = false;
  maintainReasonsData = MaintainReasonsConstants.maintainReasonMasterData;
  paginationOptions = {
    currentPage: this.maintainReasonsData.pageNo,
    pageSize: this.maintainReasonsData.pageSize
  };
  pageSizeDropdown: HTMLElement;
  selectedStateCodes = [];
  isFilterApplied: Boolean = false;
  isAllReasonsLoaded: Boolean = false;
  filtteredJurisdictionCode = [];
  currentFilteredCrieria = null;
  maxLengthOfAddReasonText = MaintainReasonsConstants.maxLengthOfAddReasonText;

  constructor(
    private maintainService: MaintainReasonsService,
    private utilityService: MaintainReasonsUtilityService,
    private adminUtilityService: AdminMenuUtilityService,
    private daysNoticeService: DaysNoticeRequirementsService,
    private translate: TranslateService,
    private popupService: PopupService,
    private router: Router,
    private titleService: Title,
    private adminMenuUtilityService: AdminMenuUtilityService) {
        this.titleService.setTitle(GlobalConstant.tabTitles[24]);
    }

  ngOnInit(): void {
    this.getFilterFields();
  }

  navigateToAdminMenu() {
    this.router.navigate([AppConstants.uiRoutes.adminMenu]);
  }

  getFilterFields() {
    this.getJurisdictions();
    this.getActions();
    this.getLobs();
    this.getCircumstances();
  }

  getJurisdictions() {
    this.maintainService.getJurisdictions().subscribe((res: any) => {
      this.allJurisdictions = this.adminUtilityService.addGroupName(res, MaintainReasonsConstants.maintainReasons.allJurisdictions);
    });
  }

  getActions() {
    this.maintainService.getActions().subscribe((res: any) => {
      this.allActions = this.adminUtilityService.addGroupName(res, MaintainReasonsConstants.maintainReasons.allActions);
    });
  }

  getLobs() {
    this.maintainService.getLobs(MaintainReasonsConstants.adminMenuItem.one).subscribe((res: any) => {
      this.allLobs = this.adminUtilityService.addGroupName(res, MaintainReasonsConstants.maintainReasons.allLobs);
    });
  }

  getCircumstances() {
    this.maintainService.getCircumstances().subscribe((res: any) => {
      res.forEach(element => { element.disabled = false; });
      this.allCircumstances = res;
    });
  }

  isDataAvailable() {
    return this.utilityService.isDataAvailable(this.allJurisdictions, this.allActions, this.allLobs, this.allCircumstances);
  }

  toggleAddDays() {
    this.addReasonColumn = !this.addReasonColumn;
  }

  isValidMultipleSelect() {
    return this.selectedJurisdictions.length > 0 && this.selectedActions.length > 0 &&
    this.selectedLobs.length > 0 && this.selectedCircumstances.length > 0 ? true : false;
  }

  display() {
    this.isFilterApplied = false;
    this.isAllDeleted = false;
    const isvalid = this.isValidMultipleSelect();
    this.isClickedDisplay = true;
    this.selectedStateCodes = this.daysNoticeService.getJurisdictionsCodes(this.selectedJurisdictions);
    this.selectedStateCodes.push(MaintainReasonsConstants.all);
    if (isvalid) {
      this.resetPagination();
      this.displayReqParam(this.selectedJurisdictions);
    }
  }

  resetPagination() {
    this.maintainReasonsData.paginationData = [];
    this.maintainReasonsData.totalCount = 0;
    this.maintainReasonsData.isDataPaginated = false;
  }

  displayReqParam(selectedJurisdictions) {
    const noticeData = {
      stateCodes: this.isFilterApplied ? selectedJurisdictions : this.daysNoticeService.getJurisdictionsCodes(selectedJurisdictions),
      actionIds: this.daysNoticeService.getSelectedIds(this.selectedActions),
      lobIds: this.daysNoticeService.getSelectedIds(this.selectedLobs),
      circumstanceIds: this.daysNoticeService.getSelectedIds(this.selectedCircumstances),
      displayWKDefaults: this.wkDefault,
      paging: {
        pageNo: this.maintainReasonsData.pageNo,
        pageSize: this.maintainReasonsData.pageSize
      }
    };
    this.currentFilteredCrieria = noticeData;
    this.getDisplayData(noticeData);
  }

  getDisplayData(noticeData) {
    this.maintainService.getAllmaintainReasons(noticeData).subscribe((res: any) => {
      this.allmaintainReasons = res.paginationData;
      this.maintainReasonsData.paginationData = res.paginationData;
      this.maintainReasonsData.totalCount = res.totalCount;
      this.maintainReasonsData.isDataPaginated = res.isDataPaginated;
      this.loadUpadtedPageSizes();
      this.collectionOfwkDefaultRow = [];
      this.reasonsGridRowSelected = [];
      this.addCheckBoxForNotices();
      this.collectionOfwkDefaultRow = this.utilityService.collectWKDefaultRow(this.maintainReasonsData.paginationData);
      this.isClickedDisplay = false;
      this.isFoundFilterData = true;
      this.isAtleastOneRowSelected = this.utilityService.isAtleastOne(this.reasonsGridRowSelected, this.collectionOfwkDefaultRow);
      this.isAllChecked = this.utilityService.isAllChecked(this.reasonsGridRowSelected, this.collectionOfwkDefaultRow);
      this.filterJurisdiction = this.daysNoticeService.getJurisdictionsForScroll(this.maintainReasonsData.paginationData);
      this.isAllReasonsLoaded = true;
    });
  }

  checkSpace() {
    this.reasonAddTextForm.patchValue({
      addReasonText: this.reasonAddTextForm.value.addReasonText.trim()
    });
  }

  addReason() {
    const isvalid = this.isValidMultipleSelect();
    this.checkSpace();
    this.isClickedDisplay = true;
    this.isClickedAddReason = true;
    if (isvalid && this.reasonAddTextForm.valid) {
      const addData = {
        stateCodes: this.daysNoticeService.getJurisdictionsCodes(this.selectedJurisdictions),
        actionIds: this.daysNoticeService.getSelectedIds(this.selectedActions),
        lobIds: this.daysNoticeService.getSelectedIds(this.selectedLobs),
        circumstanceIds: this.daysNoticeService.getSelectedIds(this.selectedCircumstances),
        text: this.reasonAddTextForm.value.addReasonText
      };
      this.maintainService.addReason(addData).subscribe((res: any) => {
        this.reasonAddTextForm.patchValue({
          addReasonText: MaintainReasonsConstants.formsValue.empty
        });
        this.isClickedDisplay = false;
        this.isClickedAddReason = false;
        this.addReasonColumn = false;
        this.popupService.showSuccess({
          title: '',
          message: this.translate.instant('ADMIN_MENUS.MAINTAIN_REASONS.added_reasons_successfully'),
          positiveLabel: this.translate.instant('BUTTON.ok_button'),
          negativeLabel: '',
        });
        this.display();
      });
    }
  }

  addCheckBoxForNotices() {
    if (this.maintainReasonsData.paginationData.length > 0) {
      this.maintainReasonsData.paginationData.forEach(element => {
        if (!element.wkDefaultRow) {
          element.isSelected = false;
        }
      });
    }
  }

  allCheckBoxToChecked() {
    if (this.maintainReasonsData.paginationData.length > 0) {
      this.maintainReasonsData.paginationData.forEach(element => {
        if (!element.wkDefaultRow) {
          element.isSelected = true;
          this.addToSelectedtable(element);
        }
      });
    }
  }

  changeCheckbox(oneRow) {
    oneRow.isSelected = !oneRow.isSelected;
    if (!oneRow.isSelected) {
      this.removeFromSelectedtable(oneRow.id);
    } else if (oneRow.isSelected) {
      this.addToSelectedtable(oneRow);
    }
    this.isAtleastOneRowSelected = this.utilityService.isAtleastOne(this.reasonsGridRowSelected, this.collectionOfwkDefaultRow);
    this.isAllChecked = this.utilityService.isAllChecked(this.reasonsGridRowSelected, this.collectionOfwkDefaultRow);
  }

  selectAllCheckbox() {
    this.isAllDeleted = this.isAllChecked ? true : false;
    if (!this.isAllChecked) {
      this.reasonsGridRowSelected = [];
      this.addCheckBoxForNotices();
      this.isAtleastOneRowSelected = this.utilityService.isAtleastOne(this.reasonsGridRowSelected, this.collectionOfwkDefaultRow);
      this.isAllChecked = this.utilityService.isAllChecked(this.reasonsGridRowSelected, this.collectionOfwkDefaultRow);
    }
  }

  addToSelectedtable(oneRow) {
    this.reasonsGridRowSelected.push(oneRow);
  }

  removeFromSelectedtable(id) {
    const index = this.reasonsGridRowSelected.findIndex(d => d.id === id);
    this.reasonsGridRowSelected.splice(index, 1);
  }

  deleteSingleReason(id) {
    this.isBulkDelete = false;
    const reasonID = [id];
    this.deleteReasons(reasonID);
  }

  deleteMultipleReasons() {
    this.isBulkDelete = true;
    const reasonIDs = [];
    if (this.isAllDeleted) {
      const noticeData = {
        stateCodes: this.isFilterApplied ? this.filtteredJurisdictionCode : this.currentFilteredCrieria.stateCodes ,
        actionIds: this.currentFilteredCrieria.actionIds,
        lobIds: this.currentFilteredCrieria.lobIds,
        circumstanceIds: this.currentFilteredCrieria.circumstanceIds
      };
      this.deleteReasons(noticeData);
    } else {
      if (this.isAllDeleted) {
        this.reasonsGridRowSelected = this.maintainReasonsData.paginationData;
      }
      this.reasonsGridRowSelected.forEach(element => {
        reasonIDs.push(element.id);
      });
      this.deleteReasons(reasonIDs);
    }
  }

  deleteReasons(reasonIDs) {
    let deleteConfirmationMessage = '';
    if (this.isAllDeleted) {
      deleteConfirmationMessage = this.translate.instant('ADMIN_MENUS.MAINTAIN_REASONS.confirm_delete_the_maintain_all_reasons');
    } else if (this.isBulkDelete) {
      deleteConfirmationMessage = this.translate.instant('ADMIN_MENUS.MAINTAIN_REASONS.confirm_delete_the_maintain_reasons');
    } else {
      deleteConfirmationMessage = this.translate.instant('ADMIN_MENUS.MAINTAIN_REASONS.confirm_delete_the_maintain_reason');
    }
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
      message: deleteConfirmationMessage,
      positiveLabel: this.translate.instant('BUTTON.delete_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
       if (this.isAllDeleted) {
        this.maintainService.deleteAllReasons(reasonIDs)
        .subscribe( response => {
          this.recordDeleted();
        });
       } else {
        this.maintainService.deleteReason(reasonIDs)
        .subscribe( response => {
          this.recordDeleted();
        });
       }
      }
    });
  }

  recordDeleted() {
    this.popupService.showSuccess({
      title: '',
      message: this.isBulkDelete ? this.translate.instant('MESSAGES.ALERT.deleted_records') :
        this.translate.instant('MESSAGES.ALERT.deleted_record'),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: '',
    });
    this.isBulkDelete = false;
    this.isAllDeleted = false;
    if (this.isFilterApplied) {
      this.displayReqParam(this.filtteredJurisdictionCode);
    } else {
      this.displayReqParam(this.selectedJurisdictions);
    }
  }

  scrollToState(state) {
    this.utilityService.scrollToState(state);
  }

  cancelDisplay() {
    this.selectedJurisdictions = [];
    this.selectedActions = [];
    this.selectedLobs = [];
    this.selectedCircumstances = [];
    this.wkDefault = true;
    this.isClickedAddReason = false;
    this.isClickedDisplay = false;
    this.addReasonColumn = false;
    this.allCircumstances.forEach(element => { element.disabled = false; });
  }

  editReason(reason) {
    this.editID = reason.id;
    this.editView = true;
    this.editReasonId = reason.id;
    this.editReasonText = reason.text;
    this.editedReasonText = reason.text;
  }

  updateReason() {
   const editedReason = this.editedReasonText.trim();
   this.editedReasonText = editedReason;
   if (editedReason !== '') {
      const editText = {
        reasonText: editedReason
      };
      this.maintainService.editReason(this.editReasonId, editText).subscribe((res: any) => {
        this.editView = false;
        this.popupService.showSuccess({
            title: '',
            message: this.translate.instant('ADMIN_MENUS.MAINTAIN_REASONS.updated_reason_successfully'),
            positiveLabel: this.translate.instant('BUTTON.ok_button'),
            negativeLabel: '',
        });
        this.editID = '';
        if (this.isFilterApplied) {
          this.displayReqParam(this.filtteredJurisdictionCode);
        } else {
          this.displayReqParam(this.selectedJurisdictions);
        }
      });
    }
  }

  checkValidReasonEdit() {
    return this.utilityService.checkValidReasonEdit(this.editedReasonText);
  }

  resetReason() {
    this.editedReasonText = this.editReasonText;
  }

  cancelReason() {
    this.editView = false;
    this.editID = '';
  }

  onCircumstanceChange() {
    const selectedItems = this.selectedCircumstances.map(x => x.id);
    const data = this.allCircumstances.filter((p) => !selectedItems.includes(p.id));
    data.forEach((item) => {
      if (this.selectedCircumstances.length >= MaintainReasonsConstants.selectLimit) {
        item.disabled = true;
      } else {
        item.disabled = false;
      }
    });
}

  onPageClick(event) {
    this.manipulatePageSizes();
    const detail = event.detail;
    this.maintainReasonsData.pageNo = detail;
    this.displayReqParam(this.selectedJurisdictions);
    setTimeout(() => {
      this.adminMenuUtilityService.getRecordsFormat();
    }, 0);
  }

  pageSizeChange(event) {
    this.manipulatePageSizes();
    const detail = event.detail;
    this.maintainReasonsData.pageSize = detail;
    this.maintainReasonsData.pageNo = 1;
    this.displayReqParam(this.selectedJurisdictions);
    setTimeout(() => {
      this.adminMenuUtilityService.getRecordsFormat();
    }, 0);
  }

  manipulatePageSizes() {
    setTimeout(function () {
      this.addMorePageSizes();
    }.bind(this));
  }

  loadUpadtedPageSizes() {
    setTimeout(function () {
      this.pageSizeDropdown = document.querySelector(MaintainReasonsConstants.dropDownClassName);
      this.addMorePageSizes();
      this.adminMenuUtilityService.getRecordsFormat();
    }.bind(this), 250);
  }

  addMorePageSizes() {
    for (let i = 0; i < Constants.maintainReasonsPageSizes.length; i++) {
      this.pageSizeDropdown[i].value = Constants.maintainReasonsPageSizes[i].toString();
      this.pageSizeDropdown[i].innerHTML = Constants.maintainReasonsPageSizes[i];
    }
  }

  filterMaintainReasons(jurisdictionCode) {
    this.maintainReasonsData.totalCount = 0;
    this.maintainReasonsData.pageNo = 1;
    this.maintainReasonsData.isDataPaginated = false;
    if (jurisdictionCode === MaintainReasonsConstants.all) {
      this.isFilterApplied = false;
      this.displayReqParam(this.selectedJurisdictions);
      this.filtteredJurisdictionCode = [];
    } else {
      this.isFilterApplied = true;
      this.filtteredJurisdictionCode.push(jurisdictionCode);
      this.displayReqParam([jurisdictionCode]);
    }
  }

}
