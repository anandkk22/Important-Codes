import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { PopupService } from '@wk/nils-core';
import { Constants } from 'app/admin/infrastructure/constants';
import { AdminMenuUtilityService } from 'app/admin/services/admin-menu-utility.service';
import { CustomFootersService } from 'app/admin/services/custom-footers.service';
import { AppConstants } from 'app/app.constants';
import { Subscription } from 'rxjs';
import { take } from 'rxjs/operators';
import { Title } from '@angular/platform-browser';
import { Constants as GlobalConstant } from '@global/infrastructure/constants';

@Component({
  selector: 'custom-footers',
  templateUrl: './custom-footers.component.html',
  styleUrls: ['./custom-footers.component.scss'],
  providers: [CustomFootersService]
})
export class CustomFootersComponent implements OnInit, OnDestroy {

  customFooters = [];
  activeSubscription: Subscription;
  jurisdictions = [];
  isDataAvaliable: Boolean = false;
  customFooterForm: FormGroup;
  formNumbers = [];
  jurisdictionForm: FormGroup;
  editFooterData = null;
  isCustomFooterEdit: Boolean = false;
  editID = null;
  scrollId = Constants.scrolltoAddFooter;
  enteredState = null;
  showTable = true;
  edittedCustomFooterValue = null;
  isExpand: Boolean = false;

  constructor(private customFootersService: CustomFootersService,
    private translate: TranslateService,
    private router: Router,
    private popupService: PopupService,
    private adminMenuUtilityService: AdminMenuUtilityService,
    private fb: FormBuilder,
    private titleService: Title) {
        this.titleService.setTitle(GlobalConstant.tabTitles[13]);
    }

  ngOnInit() {
    this.getInitialData();
  }

  isManualExpanded() {
    this.isExpand = !this.isExpand;
  }

  expandForm(event) {
    event.stopPropagation();
  }

  getInitialData() {
    this.createCustomFooterFormGroup();
    this.getJurisdiction();
  }

  createJurisdictionForm() {
    this.jurisdictionForm = this.fb.group({
      jurisdiction: [null]
    });
    const isNCExist = this.customFootersService.isNCExist(this.jurisdictions);
    if (isNCExist) {
      this.prefillJurisdictionForm(Constants.northCarolinaStateCode);
      this.getCustomFooters(Constants.northCarolinaStateCode);
    }
  }

  prefillJurisdictionForm(sateCode) {
    this.jurisdictionForm.patchValue({
      jurisdiction: sateCode
    });
  }

  createCustomFooterFormGroup() {
    this.customFooterForm = this.fb.group({
      jurisdiction: [null, Validators.required],
      insurerFormID: [null, Validators.compose([Validators.required, Validators.minLength(1)])],
      formNumber: [null, Validators.required],
      insurerName: [null, Validators.compose([Validators.required, Validators.minLength(1)])]
    });
  }

  getJurisdiction() {
    this.activeSubscription = this.customFootersService.getJurisdictions().subscribe((res: any) => {
      if (res) {
        this.jurisdictions = res;
        this.createJurisdictionForm();
      }
    });
  }

  getCustomFooters(stateCode) {
    this.customFootersService.getCustomFooters(stateCode).subscribe((res: any) => {
      if (res) {
        this.customFooters = res;
        this.isDataAvaliable = true;
      }
    });
  }

  onSelectjurisdiction(event) {
    this.customFooterForm.get('formNumber').setValue(null);
    this.formNumbers = [];
    if (this.isCustomFooterEdit) {
      this.formNumbers = [];
      this.customFooterForm.get('formNumber').setValue(null);
    }
    if (event.target.value && event.target.value !== 'null') {
      const stateCode = event.target.value;
      if (stateCode) {
        this.getFormNumbers(stateCode);
      }
    }
  }

  onSelectFormNumber(event) {
    if (event.target.value && event.target.value === 'null') {
      this.customFooterForm.get('formNumber').setValue(null);
    }
  }

  getFormNumbers(stateCode) {
    this.customFootersService.getFormNumber(stateCode).subscribe((res: any) => {
        this.formNumbers = res;
    });
  }

  filterCustomFooter(event) {
    const stateCode = event.target.value;
    if (event.target.value && event.target.value === 'null') {
      this.customFooterForm.get('formNumber').setValue(null);
      this.customFooters = [];
    } else {
      this.getCustomFooters(stateCode);
    }
  }

  deleteCustomFooter(customFooter, index) {
    this.popupService.showConfirmation({
      title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
      message: this.translate.instant('ADMIN_MENUS.CUSTOM_FOOTERS.deleteConfirmation', { rtfName: customFooter.rtfName }),
      positiveLabel: this.translate.instant('BUTTON.ok_button'),
      negativeLabel: this.translate.instant('BUTTON.cancel_button'),
    }).pipe(take(1)).subscribe(res => {
      if (res) {
        this.customFootersService.deleteCustomFooters(customFooter).subscribe((response: any) => {
          this.adminMenuUtilityService.showSucessModal(this.translate.instant('MESSAGES.ALERT.deleted_record'));
          if (this.editID === index) {
            this.prefillJurisdictionForm(this.customFooterForm.value.jurisdiction);
            this.cancel();
          }
          this.getCustomFooters(this.jurisdictionForm.value.jurisdiction);
        });
      }
    });
  }

  cancel() {
    this.formNumbers = [];
    setTimeout(() => { this.isExpand = false; }, 500);
    this.editID = null;
    this.isCustomFooterEdit = false;
    this.edittedCustomFooterValue = null;
    this.createCustomFooterFormGroup();
  }

  addCustomFooter() {
    this.customFootersService.doesFormStateMappingExists(this.customFooterForm.value).subscribe((res: any) => {
      if (res) {
        this.popupService.showConfirmation({
          title: this.translate.instant('MESSAGES.Confirmation.confirmTitle'),
          message: this.translate.instant('ADMIN_MENUS.CUSTOM_FOOTERS.update'),
          positiveLabel: this.translate.instant('BUTTON.ok_button'),
          negativeLabel: this.translate.instant('BUTTON.cancel_button'),
        }).pipe(take(1)).subscribe(response => {
          if (response) {
            this.updateCustomFooter();
          }
        });
      } else {
        this.postCustomFooter();
      }
    });
  }

  postCustomFooter() {
    const param = this.customFootersService.getCustomFooterSaveParam(this.customFooterForm.value);
    this.enteredState = this.customFooterForm.value.jurisdiction;
    this.customFootersService.addCustomFooters(param).subscribe((addRes: any) => {
      this.prefillJurisdictionForm(this.customFooterForm.value.jurisdiction);
      this.cancel();
      this.adminMenuUtilityService.showSucessModal(this.translate.instant('ADMIN_MENUS.CUSTOM_FOOTERS.addConfirmation'));
      this.getCustomFooters(this.jurisdictionForm.value.jurisdiction);
    });
  }

  updateCustomFooter() {
    const param = this.customFootersService.getCustomFooterSaveParam(this.customFooterForm.value);
    this.enteredState = this.customFooterForm.value.jurisdiction;
    this.customFootersService.editCustomFooters(param).subscribe((editRes: any) => {
      this.prefillJurisdictionForm(this.customFooterForm.value.jurisdiction);
      this.cancel();
      this.adminMenuUtilityService.showSucessModal(this.translate.instant('ADMIN_MENUS.CUSTOM_FOOTERS.updateConfirmation'));
      this.getCustomFooters(this.jurisdictionForm.value.jurisdiction);
    });
  }

  editCustomFooter(customFooter, index) {
    this.formNumbers = [];
    this.isCustomFooterEdit = true;
    this.editID = index;
    this.edittedCustomFooterValue = customFooter;
    this.isExpand = true;
    this.customFootersService.getFormNumber(customFooter.stateCode).subscribe((res: any) => {
      if (res) {
        this.formNumbers = res;
        this.prefillCustomFooterForm(customFooter);
        document.getElementById(Constants.scrolltoAddFooter).scrollIntoView({
          behavior: 'smooth',
          block: 'start',
          inline: 'nearest'
        });
      }
    });
  }

  prefillCustomFooterForm(customFooter) {
    this.customFooterForm.patchValue({
      jurisdiction: customFooter.stateCode,
      insurerFormID: customFooter.insurerFormId,
      formNumber: this.customFootersService.getSelectedFormNumber(customFooter.rtfName, this.formNumbers),
      insurerName: customFooter.insurerFooter
    });
  }

  navigateToAdminMenu() {
    this.router.navigate([AppConstants.uiRoutes.adminMenu], { queryParams: { show: true } });
  }

  toggleTable() {
    this.showTable = !this.showTable;
  }

  reset() {
    if (this.customFooterForm.value.jurisdiction === this.edittedCustomFooterValue.stateCode) {
      this.prefillCustomFooterForm(this.edittedCustomFooterValue);
    } else {
      this.customFootersService.getFormNumber(this.edittedCustomFooterValue.stateCode).subscribe((res: any) => {
        if (res) {
          this.formNumbers = [];
          this.formNumbers = res;
          this.prefillCustomFooterForm(this.edittedCustomFooterValue);
        }
      });
    }
  }

  isCustomFooterValid() {
    return this.customFootersService.isCustomFooterValid(this.customFooterForm);
  }

  ngOnDestroy() {
    this.activeSubscription.unsubscribe();
  }
}
