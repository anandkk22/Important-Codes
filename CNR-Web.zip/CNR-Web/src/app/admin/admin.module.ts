import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NilsSharedModule } from '@wk/nils-shared';
import { AdminRoutingModule } from './admin-routing.module';
import { AdminMenuComponent } from './components/admin-menu/admin-menu.component';
import { environment } from '@env';
import { AdditionalInterestComponent } from './components/additional-interests/additional-interests.component';
import { RecordsReportComponent } from './components/record-report/records-report.component';
import { MaintainInsurersComponent } from './components/insurers/insurers.component';
import { AdminMenuService } from './services/admin-menu.service';
import { AdminMenuUtilityService } from './services/admin-menu-utility.service';
import { MaintainLienholderComponent } from './components/lienholders/lienholders.component';
import { MaintainProducersComponent } from './components/producers/producers.component';
import { CertificateHolderComponent } from './components/certificate-holders/certificate-holders.component';
import { ServiceCenterComponent } from './components/service-centers/service-centers.component';
import { ServiceCenterService } from './services/service-center.service';
import { MaintainMortgageesComponent } from './components/mortgagees/mortgagees.component';
import { ExportExcelComponent } from './components/export-excel/export-excel.component';
import { ConfigurePurgeParametersComponent } from './components/configure-purge-parameters/configure-purge-parameters.component';
import { SignatureFilesComponent } from './components/signature-files/signature-files.component';
import { DaysNoticeRequirementsComponent } from './components/days-notice-requirements/days-notice-requirements.component';
import { DaysNoticeRequirementsService } from './services/days-notice-requirements.service';
import { NgSelectModule } from '@ng-select/ng-select';
import { DaysNoticeMinMaxComponent } from './components/days-notice-min-max/days-notice-min-max.component';
import { DefaultAccountSettingsComponent } from './components/default-account-settings/default-account-settings.component';
import { RecordReportUtilityService } from './services/record-report-utility.service';
import { FormEditionsByJurisdictionComponent } from './components/form-editions-by-jurisdiction/form-editions-by-jurisdiction.component';
import { SignatureMappingsComponent } from './components/signature-mappings/signature-mappings.component';
import { SignatureListsComponent } from './components/signature-mappings/signature-lists/signature-lists.component';
import { CustomizedLobComponent } from './components/customized-lob/customized-lob.component';
import { MaintainReasonsComponent } from './components/maintain-reasons/maintain-reasons.component';
import { MaintainReasonsService } from './services/maintain-reasons.service';
import { MaintainReasonsUtilityService } from './services/maintain-reasons-utility.service';
import { UnauthorizeAdminAccessComponent } from './components/unauthorize-admin-access/unauthorize-admin-access.component';
import { CustomFootersComponent } from './components/custom-footers/custom-footers.component';
import { PurgeMailLogComponent } from './components/purge-mail-log/purge-mail-log.component';
import { ExportPurgeRecordsComponent } from './components/purge-mail-log/export-purge-records/export-purge-records.component';
import { UploadProducersComponent } from './components/upload-producers/upload-producers.component';
import { MapSignatureConfirmationModalComponent } from './components/signature-mappings/map-signature-confirmation-modal/map-signature-confirmation-modal.component';
import { UploadProducersErrorComponent } from './components/upload-producers-error/upload-producers-error.component';
import { RecordReportGridComponent } from './components/record-report/record-report-grid/record-report-grid.component';
import { PurgeMailDownloadComponent } from './components/purge-mail-log/purge-mail-download/purge-mail-download.component';
import { SignatureMappedModalComponent } from './components/signature-mappings/signature-mapped-modal/signature-mapped-modal.component';

@NgModule({
  declarations: [
    AdminMenuComponent,
    AdditionalInterestComponent,
    MaintainLienholderComponent,
    CustomizedLobComponent,
    RecordsReportComponent,
    MaintainInsurersComponent,
    CertificateHolderComponent,
    ServiceCenterComponent,
    MaintainProducersComponent,
    MaintainMortgageesComponent,
    MaintainInsurersComponent,
    ConfigurePurgeParametersComponent,
    ExportExcelComponent,
    SignatureFilesComponent,
    ConfigurePurgeParametersComponent,
    DaysNoticeRequirementsComponent,
    DaysNoticeMinMaxComponent,
    DefaultAccountSettingsComponent,
    FormEditionsByJurisdictionComponent,
    SignatureMappingsComponent,
    SignatureListsComponent,
    MaintainReasonsComponent,
    UnauthorizeAdminAccessComponent,
    CustomFootersComponent,
    PurgeMailLogComponent,
    ExportPurgeRecordsComponent,
    UploadProducersComponent,
    MapSignatureConfirmationModalComponent,
    UploadProducersErrorComponent,
    RecordReportGridComponent,
    PurgeMailDownloadComponent,
    SignatureMappedModalComponent
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    NilsSharedModule.loadConfig({
      environmentName: environment.environmentName,
      portalUrl: environment.portalUrl,
      appUrl: environment.appUrl,
      apiUrl: environment.apiUrl,
      serverLogLevel: environment.serverLogLevel,
      logLevel: environment.logLevel,
      serverLoggingUrl: environment.serverLoggingUrl,
      commonApiUrl: '',
      userGroupURL: '',
      feedbackEmail: environment.feedbackEmail,
      customerCareEmail: environment.customerCareEmail,
      productUrl: environment.productUrl
    }),
    NgSelectModule,
  ],
  providers: [
    AdminMenuService,
    AdminMenuUtilityService,
    ServiceCenterService,
    DaysNoticeRequirementsService,
    RecordReportUtilityService,
    MaintainReasonsService,
    MaintainReasonsUtilityService
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
})
export class AdminModule { }
