export interface PurgeReport {
    totalCount?: number;
    isDataPaginated?: boolean;
    pageNo?: number;
    pageSize?: number;
    paginationData?: PurgeRecords[];
    gridRowSelected?: PurgeRecords[];
}

export interface PurgeRecords {
    cnrUserDataV4ID?: number;
    insurerID?: number;
    insurerName?: string;
    insurerAddr1?: string;
    insurerAddr2?: string;
    insurerCity?: string;
    insurerStateProv?: string;
    insurerPostalCode?: string;
    logName?: string;
    logAddr1?: string;
    logAddr2?: string;
    logCity?: string;
    logStateProv?: string;
    logPostalCode?: string;
    policyNumber?: string;
    mailingDt?: string;
    mailType?: string;
    userNote?: string;
    apiGenerated?: string;
}

export interface PurgeReportDate {
    dateFrom?: string;
    dateTo?: string;
    pageNo?: number;
    pageSize?: number;
}
