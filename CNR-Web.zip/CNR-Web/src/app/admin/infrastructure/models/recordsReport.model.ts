export interface RecordsReport {
    dateFrom?: string;
    dateTo?: string;
}
export interface TransactionLimit {
    currentRecordCount?: number;
    archiveTransactionCount?: number;
    totalRecordCount?: number;
    mailTransactionLimit?: number;
    limitExceed?: boolean;
}

export interface RecordsReportView {
    totalCount?: number;
    isDataPaginated?: boolean;
    paginationData?: PaginationData[];
    pageNo?: number;
    pageSize?: number;
    gridRowSelected: PaginationData[];
}
export interface PaginationData {
    cnrUserDataV4ID?: number;
    acctNum?: number;
    acctName?: number;
    branch?: string;
    stateCode?: string;
    actionCode?: string;
    lobid?: string;
    whereConditionDesc?: string;
    mailType?: string;
    userNote?: string;
    entryDateTime?: string;
    transactionDt?: string;
    mailingDt?: string;
    policyNumber?: string;
    insurerName?: string;
    insurerAddr1?: string;
    insurerAddr2?: string;
    insurerCity?: string;
    insurerStateProv?: string;
    insurerPostalCode?: string;
    producerName?: string;
    producerAddr1?: string;
    producerAddr2?: string;
    producerCity?: string;
    producerStateProv?: string;
    pPostalCode?: string;
    logParty?: string;
    logName?: string;
    logAddr1?: string;
    logAddr2?: string;
    logCity?: string;
    logStateProv?: string;
    logPostalCode?: string;
    displayOrder?: number;
    rtfName?: string;
    apiGenerated?: number;
    isSelected?: boolean;
}
