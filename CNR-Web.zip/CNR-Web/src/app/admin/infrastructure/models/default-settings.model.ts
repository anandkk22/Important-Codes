export class DefaultSettings {
    mailLogEnabled?: boolean;
    fill3817Insured?: boolean;
    fill3817Producer?: boolean;
    fill3817Mortgagee?: boolean;
    fill3817Lienholder?: boolean;
    fill3817Certholder?: boolean;
    fill3817AddInt?: boolean;
    fill3817Tp?: boolean;
    selectProducerByCode?: boolean;
    insuredMailType?: number;
    producerMailType?: number;
    mortgageeMailType?: number;
    lienholderMailType?: number;
    certholderMailType?: number;
    addIntMailType?: number;
    supMailType?: number;
    tpmailType?: number;
    wccmailType?: number;
    arpamailType?: number;
    mailFromBranch?: boolean;
    printTypistInitials?: boolean;
    producerToMailLog?: boolean;
    printProducerCode?: boolean;
    requireProducer?: boolean;
    requireInsurerAddr?: boolean;
    carrierUsesBranchAddress?: boolean;
    generateAddrPages?: boolean;
    displayAllFormFields?: boolean;
}

export interface MailTypes {
    id?: number;
    name?: string;
}

export interface DefaultSettingOption {
    name?: string;
    controlName?: string;
    controlOptions?: number;
}
