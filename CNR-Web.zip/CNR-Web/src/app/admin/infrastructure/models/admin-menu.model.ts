export interface AdminMenuMasterData {
    headerName?: string;
    addsChar?: string;
    fieldsDetails?: AdminFieldsData;
    tableData?: {
        columnData?: GridHeaderData[],
        rowData?: GridRowData[],
        pageNo?: number,
        pageSize?: number,
        sortOnItem?: number,
        orderby?: number,
        isDataPaginated?: boolean,
        totalCount?: number,
        gridRowSelected?: GridRowData[],
    };
    isEdit?: boolean;
    showCodeField?: boolean;
    isValidPostCode?: boolean;
    isExpand?: boolean;
    deleteOrExport?: boolean;
    isFilterSearch?: boolean;
    filterSearchData?: {
        heading?: string;
        searchFields?: string[];
    };
    maxCharacters?: {
        nameMaxChar?: number;
        address1MaxChar?: number;
        address2MaxChar?: number;
        cityMaxChar?: number;
        jurisdictionMaxChar?: number;
        postalCodeMaxChar?: number;
        codeMaxChar?: number;
    };
    addEditByForm?: boolean;
}

export interface AdminFieldsData {
    code?: string;
    name: string;
    address1: string;
    address2: string;
    city: string;
    stateProvidence: string;
    postalCode: string;
}

export interface GridRowData {
    recordID: number;
    type: string;
    code: string;
    recordActive: boolean;
    name: string;
    address1: string;
    address2: string;
    city: string;
    stateProvidence: string;
    postalCode: string;
}

export interface GridHeaderData {
    field: string;
    header: string;
    width?: string;
    sortBy?: number;
}

export interface GridTableEmitData {
    mode?: string;
    rowIndex?: number;
    col?: GridHeaderData;
    row?: GridRowData;
    data?: AdminFieldsData;
}

export enum ActionMode {
    add = 'add',
    save = 'save',
    edit = 'edit',
    delete = 'delete',
    bulkDelete = 'bulkDelete',
    cancel = 'cancel',
    reset = 'reset',
    pageUpdate = 'pageUpdate',
    getAllData = 'getAllData',
    upload = 'upload'
}

export enum maintainPartyEnums {
    addInt = 0,
    certHolder = 1,
    lienHolder = 2,
    mortgagee = 3
}

export enum checkKey {
    threeOne = 31,
    fourEight = 48,
    fiveSeven = 57
}
