export interface FormEditionByJurisdiction {
    stateName?: string;
    baseForms?: BaseFroms[];
}

export interface BaseFroms {
    baseFormName?: string;
    userAccountFormDbDTO?: UserAccountFormDbDTO[];
}

export interface UserAccountFormDbDTO {
    formId?: number;
    title?: string;
    baseForm?: string;
    editionMonth?: number;
    editionYear?: string;
    rtfName?: string;
    rtFilePath?: string;
    helpFile?: string;
    helpFilePath?: null;
    codes?: string;
    dateNonDisplayed?: null;
    useThisEdition?: boolean;
    stateCode?: string;
    stateName?: string;
}

export interface UpdateEditionByJurisdiction {
    edition: boolean;
    stateCode: string;
    formId: number;
}
