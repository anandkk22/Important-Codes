import { environment } from '@env';
export class MaintainReasonsConstants {

    static webApis = {
        getJurisdictions: environment.apiUrl + 'State',
        getLobs: environment.apiUrl + 'LOB?adminMenuItem={adminMenuItem}',
        deleteDaysNotice: environment.apiUrl + 'DaysNotice',
        getActions: environment.apiUrl + 'Action',
        getCircumstances: environment.apiUrl + 'Circumstance',
        getAllReasons: environment.apiUrl + 'Reason/All',
        addReason: environment.apiUrl + 'Reason',
        deleteReason: environment.apiUrl + 'Reason',
        editReason: environment.apiUrl + 'Reason/{reasonId}',
        deleteAllReasons: environment.apiUrl + 'Reason/All'
    };

    static maintainReasons = {
        allJurisdictions: 'All Jurisdictions',
        allLobs: 'All Sublines of Business',
        allActions: 'All Actions',
        allCircumstance: 'All Circumstances',
    };

    static accountNumber = {
        oneTwoSixNine: 1269
    };

    static formsValue = {
        empty: ''
    };

    static adminMenuItem = {
        one: 1
    };

    static selectLimit = 5;

    static all = 'ALL';

    static maintainReasonMasterData = {
        pageNo: 1,
        pageSize: 5000,
        totalCount: 0,
        isDataPaginated: false,
        paginationData: [],
        gridRowSelected: []
    };

    static dropDownClassName = '#pagination-bar-dynamic .wk-field-select';

    static maxLengthOfAddReasonText = 255;
}
