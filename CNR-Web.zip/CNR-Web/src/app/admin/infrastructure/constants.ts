import { environment } from '@env';
export class Constants {
    static webApis = {
        adminMenuDeleteRecords: environment.apiUrl + 'MaintainParties',
        getTableMaintainParties: environment.apiUrl + 'MaintainParties?Type={type}',
        getSingleRowData: environment.apiUrl + 'MaintainParties/{recordID}',
        getInsurers: environment.apiUrl + 'AccountInsurer/ByAccountId?',
        deleteInsurers: environment.apiUrl + 'AccountInsurer',
        deleteInsurer: environment.apiUrl + 'AccountInsurer/ByAccountId/{insurerId}',
        maintainParties: environment.apiUrl + 'MaintainParties',
        addInsurer: environment.apiUrl + 'AccountInsurer',
        editInsurer: environment.apiUrl + 'AccountInsurer/ByInsurerId/{insurerId}',
        updateSingleRowData: environment.apiUrl + 'MaintainParties?recordId={recordID}',
        saveEdittedInsurer: environment.apiUrl + 'AccountInsurer/{insurerId}',
        addProducer: environment.apiUrl + 'Producer',
        getProducers: environment.apiUrl + 'Producer?',
        deleteProducers: environment.apiUrl + 'Producer',
        getAllParties: environment.apiUrl + 'MaintainParties',
        getAllServiceCenter: environment.apiUrl + 'ServiceCenter',
        addServiceCenter: environment.apiUrl + 'ServiceCenter',
        updateServiceCenter: environment.apiUrl + 'ServiceCenter/{recordId}',
        getSingleServiceCenterRowData: environment.apiUrl + 'ServiceCenter/{recordId}',
        deleteServiceCenter: environment.apiUrl + 'ServiceCenter',
        getReportToandFromDate: environment.apiUrl + 'MailLog/Report/Dates',
        getReportReport: environment.apiUrl + 'MailLog/Report?DateFrom=',
        getTransactionLimit: environment.apiUrl + 'MailLog/Report/TransactionLimit',
        getPurgeParameter: environment.apiUrl + 'PurgeConfig',
        signatures: environment.apiUrl + 'AccountSignature',
        uploadSignature: environment.apiUrl + 'AccountSignature/Upload',
        searchSignature: environment.apiUrl + 'AccountSignature/Search?searchTerm={searchTerm}',
        addDaysNotice: environment.apiUrl + 'DaysNotice',
        getJurisdictions: environment.apiUrl + 'State',
        getLobs: environment.apiUrl + 'LOB?adminMenuItem={adminMenuItem}',
        deleteDaysNotice: environment.apiUrl + 'DaysNotice',
        getActions: environment.apiUrl + 'Action',
        getCircumstances: environment.apiUrl + 'Circumstance',
        getAllDaysNotice: environment.apiUrl + 'DaysNotice/Get',
        updateDaysNotice: environment.apiUrl + 'DaysNotice',
        deletetSignature: environment.apiUrl + 'AccountSignature?graphicFileName={signatureFileName}&signatureId={signatureId}',
        getAccountDefault: environment.apiUrl + 'AccountCNRDefault',
        getCnrDefaultSettings: environment.apiUrl + 'AccountCNRDefault/AccountDefaults',
        getDefaultSettings: environment.apiUrl + 'AccountCNRDefault/DefaultSetting',
        getEditionByJurisdiction: environment.apiUrl + 'Form/EditionByJurisdiction',
        updateEditionByJurisdiction: environment.apiUrl + 'Form/Edition',
        downloadFile: environment.apiUrl + 'File/Download?file={fileName}',
        customLobs: environment.apiUrl + 'CustomizedLob',
        getAccountJurisdiction: environment.apiUrl + 'AccountState/ByAccountId',
        getServiceCenters:  environment.apiUrl + 'ServiceCenter?SortOnItem=0&Orderby=0&PageNo=0&PageSize=100',
        getAccountSignatures: environment.apiUrl + 'AccountSignature/SignatureFile',
        signatureMapped: environment.apiUrl + 'SignatureMapped',
        getSignatureList: environment.apiUrl + 'SignatureMapped/Get',
        getAccountInsurers:  environment.apiUrl + 'AccountInsurer/ByAccountId?SortOnItem=0&Orderby=0&PageNo=0&PageSize=100',
        getCustomFooters: environment.apiUrl + 'CustomFooter?stateCode={stateCode}',
        getAccountFormNumber: environment.apiUrl + 'StateForms?stateCode={stateCode}',
        doesFormStateMappingExists: environment.apiUrl + 'CustomFooter/DoesFormStateMappingExists?stateCode={stateCode}&formId={formId}',
        customFooters: environment.apiUrl + 'CustomFooter',
        getPurgeReportDates: environment.apiUrl + 'MailLog/PurgeReport/Dates',
        getPurgeReport: environment.apiUrl + 'MailLog/PurgeReport',
        purgeRecords: environment.portalUrl + 'Webservices/API/CNR/v1/notices?beginDate=',
        deleteCustomFooter: environment.apiUrl + 'CustomFooter?stateCode=',
        producerUpload: environment.apiUrl + 'Producer/ConfirmBulkUpload',
        producerUploadExcel: environment.apiUrl + 'Producer/TemporaryBulkUpload',
        getProducerTemporary: environment.apiUrl + 'Producer/Temporary?pageNo={pageNo}&pageSize={pageSize}',
        getCustomFooterJurisdiction : environment.apiUrl + 'CustomFooterJurisdiction',
        downloadFileNils: environment.commonApiUrl + 'Download?file={fileName}',
        openImageFile: environment.portalUrl + 'webservices/api/cnrclientprivate/File/Open?file={signatureFileName}&isBlankFields=false',
        getReportCount: environment.apiUrl + 'MailLog/Report/Count?DateFrom={dateFrom}&DateTo={dateTo}',
        getCountOfAllDaysNotice: environment.apiUrl + 'DaysNotice/Count'
    };

    static urlGeenrate = {
        recordId: 'recordId=',
        andSymbol: '&',
        equalTo: '=',
        dateTo: 'DateTo',
        questionMark: '?',
        dateFrom: 'DateFrom',
        endDate: '&endDate='
    };

    static serviceCenterUrl = {
        recordIdList: 'recordIdList=',
        andSymbol: '&'
    };

    static columnData = [
        {
            field: 'id',
            header: 'ID',
            width: '5%',
            sortBy: 6
        },
        {
            field: 'code',
            header: 'Code',
            width: '7%',
            sortBy: 7
        },
        {
            field: 'name',
            header: 'Name',
            width: '16%',
            sortBy: 0
        },
        {
            field: 'address1',
            header: 'Address 1',
            width: '20%',
            sortBy: 1
        },
        {
            field: 'address2',
            header: 'Address 2',
            width: '15%',
            sortBy: 2
        },
        {
            field: 'city',
            header: 'City',
            width: '8%',
            sortBy: 3
        },
        {
            field: 'state',
            header: 'Jurisdiction',
            width: '10%',
            sortBy: 4
        },
        {
            field: 'postalCode',
            header: 'Postal Code',
            width: '10%',
            sortBy: 5
        },
        {
            field: 'actions',
            header: 'Actions',
            width: '10%',
            sortBy: null
        }
    ];

    static urlFilter = {
        type: '?Type=',
        pageNo: '&PageNo=',
        pageSize: '&PageSize=',
        sortOnItem: '&SortOnItem=',
        orderby: '&Orderby='
    };

    static urlServiceCenterUrl = {
        pageNo: '?PageNo='
    };

    static signatureRequirements = ['The file should be saved as: AccountNumber_Firstname_Lastname.jpg/.jpeg',
    'The file extension should be .jpg/.jpeg',
    'The file size should not be more than 210 pixels wide x 50 pixels high (3 1/4" x 3/4")',
    'Please use black ballpoint pen on white paper'];

    static daysNotice = {
        allJurisdictions: 'All Jurisdictions',
        allLobs: 'All Sublines of Business',
        allActions: 'All Actions',
        allCircumstance: 'All Circumstances',
    };
    static daysNoticeFormType = {
        display: 'display',
        addDays: 'addDays',
    };
    static editDaysType = {
        minDays: 'minDays',
        maxDays: 'maxDays',
        single: 'single',
        multiple: 'multiple',
        addMinMax: 'add'
    };
    static editDaysReload = {
        noReload: 'noReload',
        reload: 'reload'
    };
    static editdaysProperties = {
        stateCode: 'stateCode',
        stateName: 'stateName',
        actionId: 'actionId',
        actionDesc: 'actionDesc',
        lobId: 'lobId',
        lob: 'lob',
        circumstanceId: 'circumstanceId',
        circumstanceDescription: 'circumstanceDescription',
        daysNotice: 'daysNotice',
        daysNoticeMax: 'daysNoticeMax',
        defaults: 'defaults'
    };

    static accountNumber = {
        oneTwoSixNine: 1269
    };

    static rowColor = {
        yellowOpa: 'yellow_opa',
        orangeOpa: 'orange_opa',
        blueOpa: 'blue_opa'
    };

    static viewText = {
        was: ' was',
        were: 's were'
    };

    static AccountSettingsFormObject = {
        fill3817Insured: [],
        fill3817Producer: [],
        fill3817Mortgagee: [],
        fill3817Lienholder: [],
        fill3817Certholder: [],
        fill3817AddInt: [],
        fill3817Tp: [],
        insuredMailType: [],
        producerMailType: [],
        mortgageeMailType: [],
        lienholderMailType: [],
        certholderMailType: [],
        addIntMailType: [],
        supMailType: [],
        tpmailType: [],
        wccmailType: [],
        arpamailType: [],
        selectProducerByCode: [],
        producerToMailLog: [],
        printProducerCode: [],
        requireProducer: [],
        mailLogEnabled: [],
        mailFromBranch: [],
        printTypistInitials: [],
        requireInsurerAddr: [],
        carrierUsesBranchAddress: [],
        generateAddrPages: [],
        displayAllFormFields: []
    };

    static mailTypes = [
        {
            id: 0,
            name: 'Standard'
        },
        {
            id: 2,
            name: 'Certified'
        },
        {
            id: 1,
            name: 'Registered'
        },
        {
            id: 3,
            name: 'None'
        }
    ];

    static reportUrl = {
        dateTo: '&DateTo=',
        pageNo: '&PageNo=',
        pageSize: '&PageSize='
    };

    static pageSizes = [500, 1000, 1500];
    static policyCodes = 'CNR4\\policycodes.doc';
    static policyFilename = 'policycodes.doc';

    static responseType = {
        blobType: 'blob'
    };

    static maintainSignature = {
        allJurisdictions: 'All Jurisdictions',
        allInsurers: 'All Insurers',
        allServiceCenters: 'All Service Centers'
    };

    static signatureFileLocation = 'CNR\\cnrfiles\\';

    static regex = {
      charSpaceUndescoreHyphen: '^(\s{0,1}[a-zA-Z0-9-_ ])*$'
    };


    static customLOBMaxLength = 65;

    static invalidWords = ['javascript:alert', 'alert\(', 'alert "', 'alert &quot', 'alert%22', 'alert%27',
      'alert%28', 'alter database', 'alter table', 'drop database', 'drop table',
      'passwd', 'probe', 'query', 'sql', 'src', 'xml', '%3D', '<script', '1=1', '1=2', '.ini'
    ];

    static  northCarolinaStateCode = 'NC';

    static scrolltoAddFooter = 'footerField' ;

    static defautlSettingOptions = ['fill3817Insured', 'fill3817Producer', 'fill3817Mortgagee', 'fill3817Lienholder', 'fill3817Certholder', 'fill3817AddInt',
    'fill3817Tp', 'insuredMailType', 'producerMailType', 'mortgageeMailType', 'lienholderMailType', 'certholderMailType', 'addIntMailType',
    'supMailType', 'tpmailType', 'wccmailType', 'arpamailType', 'selectProducerByCode', 'producerToMailLog', 'printProducerCode', 'requireProducer',
    'mailLogEnabled', 'mailFromBranch', 'printTypistInitials', 'requireInsurerAddr', 'carrierUsesBranchAddress',
    'generateAddrPages', 'displayAllFormFields'];

    static selectLimit = 5;

    static numberWithComma = /\B(?=(\d{3})+(?!\d))/g;

    static imgFileExtensions = {
        jpg: 'jpg',
        jpeg: 'jpeg',
    };

    static purgeReportMasterPageSize = 500;

    static signatureMappingPaginationDetails = {
        pageNo: 1,
        pageSize: 500,
        totalCount: 0
    };

    static dropDownClassName = '#pagination-bar-dynamic .wk-field-select';

    static all = 'ALL';

    static signatureParamNames = ['code', 'insurerId', 'id'];

}
