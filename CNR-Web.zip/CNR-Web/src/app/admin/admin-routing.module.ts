import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppConstants } from 'app/app.constants';
import { AdditionalInterestComponent } from './components/additional-interests/additional-interests.component';
import { AdminMenuComponent } from './components/admin-menu/admin-menu.component';
import { CertificateHolderComponent } from './components/certificate-holders/certificate-holders.component';
import { MaintainInsurersComponent } from './components/insurers/insurers.component';
import { MaintainLienholderComponent } from './components/lienholders/lienholders.component';
import { ServiceCenterComponent } from './components/service-centers/service-centers.component';
import { MaintainMortgageesComponent } from './components/mortgagees/mortgagees.component';
import { MaintainProducersComponent } from './components/producers/producers.component';
import { RecordsReportComponent } from './components/record-report/records-report.component';
import { ConfigurePurgeParametersComponent } from './components/configure-purge-parameters/configure-purge-parameters.component';
import { SignatureFilesComponent } from './components/signature-files/signature-files.component';
import { DaysNoticeRequirementsComponent } from './components/days-notice-requirements/days-notice-requirements.component';
import { DefaultAccountSettingsComponent } from './components/default-account-settings/default-account-settings.component';
import { FormEditionsByJurisdictionComponent } from './components/form-editions-by-jurisdiction/form-editions-by-jurisdiction.component';
import { SignatureMappingsComponent } from './components/signature-mappings/signature-mappings.component';
import { SignatureListsComponent } from './components/signature-mappings/signature-lists/signature-lists.component';
import { CustomizedLobComponent } from './components/customized-lob/customized-lob.component';
import { MaintainReasonsComponent } from './components/maintain-reasons/maintain-reasons.component';
import { AuthGuardService } from '@global/services/auth-guard.service';
import { CustomFootersComponent } from './components/custom-footers/custom-footers.component';
import { PurgeMailLogComponent } from './components/purge-mail-log/purge-mail-log.component';
import { UploadProducersComponent } from './components/upload-producers/upload-producers.component';
import { RecordReportGridComponent } from './components/record-report/record-report-grid/record-report-grid.component';
import { PurgeMailDownloadComponent } from './components/purge-mail-log/purge-mail-download/purge-mail-download.component';
const routes: Routes = [
  {
    path: AppConstants.uiRoutes.empty,
    component: AdminMenuComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.additionalInterests,
    component: AdditionalInterestComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.insurers,
    component: MaintainInsurersComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.lienHolders,
    component: MaintainLienholderComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.producers,
    component: MaintainProducersComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.certificateholders,
    component: CertificateHolderComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.serviceCenters,
    component: ServiceCenterComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.mortgagees,
    component: MaintainMortgageesComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.recordsReport,
    component: RecordsReportComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.purgeParameters,
    component: ConfigurePurgeParametersComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.signatureFiles,
    component: SignatureFilesComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.daysNoticeRequirements,
    component: DaysNoticeRequirementsComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.defaultSettings,
    component: DefaultAccountSettingsComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.editionsByJurisdiction,
    component: FormEditionsByJurisdictionComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.customizedLOB,
    component: CustomizedLobComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.signatureMappings,
    component: SignatureMappingsComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.signatureLists,
    component: SignatureListsComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.customFooters,
    component: CustomFootersComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.purgeMailLog,
    component: PurgeMailLogComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.downloadPurgeMailLog,
    component: PurgeMailDownloadComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.maintainReasons,
    component: MaintainReasonsComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.uploadProducers,
    component: UploadProducersComponent,
    canActivate: [AuthGuardService]
  },
  {
    path: AppConstants.uiRoutes.recordsReportGrid,
    component: RecordReportGridComponent,
    canActivate: [AuthGuardService]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminRoutingModule { }
