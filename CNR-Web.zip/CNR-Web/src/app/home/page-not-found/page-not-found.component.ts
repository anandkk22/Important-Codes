﻿import { Component } from '@angular/core';

@Component({
    selector: 'page-not-found',
    template: `<div class="empty-page">page not found</div>`
})
export class PageNotFoundComponent {

    constructor() {
    }

}
