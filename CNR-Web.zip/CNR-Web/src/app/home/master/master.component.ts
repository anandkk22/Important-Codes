import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { Event, NavigationEnd, NavigationStart, Router } from '@angular/router';
import { AuthService, LoggerService } from '@core';
import { SharedDataService } from '@global';
import { HeaderData } from '@global/infrastructure/authentication.model';
import { Constants } from '@global/infrastructure/constants';
import { AccessService } from '@global/services/access.service';
import { AppConstants } from 'app/app.constants';
import { Subscription } from 'rxjs';
import { environment } from '@env';

export let browserRefresh = false;

declare let pendo: any;
@Component({
  selector: 'app-master',
  templateUrl: './master.component.html',
  styleUrls: ['./master.component.css']
})
export class MasterComponent implements OnInit, OnDestroy {

  isUserLoggedIn = false;
  showHeader = false;
  showFooter = false;
  headerData: any;
  displaySubHeader: HeaderData;
  cnrHeaderDetails = Constants.headerOptions;
  ActiveSubscription: Subscription;
  mailSubject = '';
  targetValue = Constants.targetKey.insource;
  displayPopup = false;
  popupData: any = {};
  feedbackEmail: String;
  showMenu = true;

  constructor(
    private logger: LoggerService,
    private router: Router,
    private sharedDataService: SharedDataService,
    private authService: AuthService,
    private accessService: AccessService,
    private cd: ChangeDetectorRef) {


  }

  ngOnInit(): void {
    this.hideUnauthMenus();
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationStart) {
        if ( event.url.indexOf(AppConstants.uiRoutes.circumstancesDefinitions) > -1) {
          this.setHeaderFooter(true, false);
        }
      }

      if (event instanceof NavigationEnd) {
        const userInfo = this.sharedDataService.getUserInfo();
        if (this.sharedDataService.getUserInfo()) {
          this.initializePendo(userInfo);
        }
      }
    });

    this.authService.triggerMessage.subscribe((res) => {
      if (res !== '' && res === Constants.somethingWentWrongOldMsg) {
        const message = Constants.somethingWentWrongNewMsg.replace('${customerCare}', environment.customerCareEmail);
        this.showCommonErrorPopup(message);
      } else if (res !== '') {
        this.showCommonErrorPopup(res);
      }
    });

    this.ActiveSubscription = this.accessService.headerDisplay.subscribe((result) => {
      this.displaySubHeader = result;
    });
    this.headerData = this.sharedDataService.getUserInfo();
    this.isUserLoggedIn = this.authService.isUserLoggedIn();
    this.feedbackEmail = environment.feedbackEmail;
    this.enableDisableHeaderFooter();
    if (!this.headerData.is_cnr_administrator) {
      this.cnrHeaderDetails = this.cnrHeaderDetails.filter(function (obj) {
        return obj.key !== 'administratorMenu';
      });
    }
    this.logger.info('MasterComponent : ngOnInit() ');

  }

  ngOnDestroy() {
    this.ActiveSubscription.unsubscribe();
  }

  initializePendo(sharedData: any) {
    try {
      const initializationObj = {
        visitor: {
          id: sharedData.sub,
          email: sharedData.email,
          full_name: sharedData.username,
          NILSrole: Constants.pendoData.NilsPlatformRole,
          CNRrole: Constants.pendoData.CNRRole
        },
        account: {
          id: Constants.pendoData.AccountID,
          accountName: Constants.pendoData.AccountName,
          soldTo: Constants.pendoData.SoldToID === undefined ? '' : Constants.pendoData.SoldToID,
          soldToName: Constants.pendoData.SoldToName === undefined ? '' : Constants.pendoData.SoldToName,
          type: Constants.pendoData.AccountType
        }
      };

      // Added logs for testing on Dev
      pendo.initialize(initializationObj);
    } catch (error) {
      // In case Pendo initialization errors out, we need to know the the reason why it failed
    }
  }

  exitModal(data: Boolean) {
    if (data) {
      this.displayPopup = false;
      this.cd.detectChanges();
    }
  }

  feedbackClicked(subject) {
    this.mailSubject = subject;
  }

  enableDisableHeaderFooter() {
    if (window.location.href.indexOf(AppConstants.uiRoutes.circumstancesDefinitions) > -1) {
      this.setHeaderFooter(true, false);
    }
    else if (window.location.href.indexOf(AppConstants.uiRoutes.lookupDate) > -1 ||
      window.location.href.indexOf(AppConstants.uiRoutes.addEditForm) > -1 ||
      window.location.href.indexOf(AppConstants.uiRoutes.uploadProducers) > -1) {
      this.setHeaderFooter(true, true);
    }
    else if (window.location.href.indexOf(AppConstants.uiRoutes.fileViewer) > -1) {
      this.setHeaderFooter(true, true);
    }
    else if (window.location.href.indexOf(AppConstants.uiRoutes.recordsReportGrid) > -1) { // recordsReportGrid
      this.setHeaderFooter(true, false);
    }
    else {
      this.setHeaderFooter(false, false);
    }
  }

  hideUnauthMenus() {
    if (window.location.href.indexOf(AppConstants.uiRoutes.unauthorized) > -1) {
      this.showMenu = false;
    }
  }
  setHeaderFooter(showHeader: boolean, showFooter: boolean) {
    this.showHeader = showHeader;
    this.showFooter = showFooter;
  }

  showCommonErrorPopup(message: any) {
    this.displayPopup = true;
    this.popupData.message = message;
    this.cd.detectChanges();
  }
}
