import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { AppConstants } from 'app/app.constants';

@Component({
  selector: 'app-file-viewer',
  templateUrl: './file-viewer.component.html'
})
export class FileViewerComponent implements OnInit {

  constructor(private titleService: Title) {
    this.titleService.setTitle(AppConstants.downloadFile);
  }

  ngOnInit(): void { }

}
