import { Component, OnDestroy, OnInit } from '@angular/core';

declare let pendo: any;
@Component({
  selector: 'home',
  template: 'This is home component'
})
export class HomeComponent implements OnInit, OnDestroy {

    constructor() {}

    ngOnInit(): void {}

    ngOnDestroy() {}
}
