const wkEnvConfig = window['wkEnvConfig'];

export const environment = {
  environmentName: wkEnvConfig.environmentName,
  portalUrl: wkEnvConfig.portalUrl,
  appUrl: 'http://localhost:4200/',
  apiUrl: 'https://localhost:5001/',
  commonApiUrl: 'https://localhost:5002/',
  wkApiUrl:  wkEnvConfig.portalUrl + 'webservices/api/cnr/',
  logLevel: '5',
  serverLogLevel: '5',
  serverLoggingUrl: 'https://localhost:5002/logs',
  authUrl: wkEnvConfig.portalUrl + 'Webservices/API/ICSAuth/',
  customerCareEmail: '',
  feedbackEmail: '',
  phoneNumber: '',
  productUrl: 'cnr',
  gtagMeasurementId: wkEnvConfig.gtagMeasurementId,
  pendoId: wkEnvConfig.pendoId,
  fillingInfoLink: wkEnvConfig.portalUrl + 'cnr4/',
  cnrPreview: wkEnvConfig.cnrPreview,
  filingInfoPath: wkEnvConfig.portalUrl + 'webservices/api/nilscommon/Download?file=',
  daysNoticeThreshold: wkEnvConfig.daysNoticeThreshold
};
