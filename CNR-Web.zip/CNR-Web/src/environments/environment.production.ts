const wkEnvConfig = window['wkEnvConfig'];

export const environment = {
  environmentName: wkEnvConfig.environmentName,
  portalUrl: wkEnvConfig.portalUrl,
  appUrl: wkEnvConfig.cnrPreview ? wkEnvConfig.portalUrl + 'preview/cnr/' :
  wkEnvConfig.portalUrl + 'cnr/',
  apiUrl: wkEnvConfig.cnrPreview ? wkEnvConfig.portalUrl + 'webservices/api/cnrclientprivatepreview/' :
  wkEnvConfig.portalUrl + 'webservices/api/cnrclientprivate/',
  wkApiUrl: wkEnvConfig.portalUrl + 'webservices/api/cnr/',
  commonApiUrl: wkEnvConfig.portalUrl + 'webservices/api/nilscommon/',
  logLevel: '5',
  serverLogLevel: '5',
  serverLoggingUrl: wkEnvConfig.portalUrl + 'webservices/api/insource/logs',
  authUrl: wkEnvConfig.portalUrl + 'Webservices/API/ICSAuth/',
  customerCareEmail: '',
  feedbackEmail: '',
  phoneNumber: '',
  productUrl: 'cnr',
  gtagMeasurementId: wkEnvConfig.gtagMeasurementId,
  pendoId: wkEnvConfig.pendoId,
  fillingInfoLink: wkEnvConfig.portalUrl + 'cnr4/',
  cnrPreview: wkEnvConfig.cnrPreview,
  filingInfoPath: wkEnvConfig.portalUrl + 'webservices/api/nilscommon/Download?file=',
  daysNoticeThreshold: wkEnvConfig.daysNoticeThreshold
};
