
window['wkEnvConfig'] = {
  environmentName: 'Local',
  portalUrl: 'https://dev.onesumxnils.com/',
  gtagMeasurementId: 'UA-38744069-4',
  pendoId: '45714dba-e54e-4151-5080-3f3034a6026f',
  cnrPreview: false,
  daysNoticeThreshold: 10000
};
