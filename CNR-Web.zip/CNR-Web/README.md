## Machine setup

- vscode
- gitscm
- nodejs 12+

## Package installation

- `cd xp.mi.web`
- `npm i`
- `cd xp.mi.web\server`
- `npm i`

## Run dummy api

- you can fake the actual api in dummy server file `index.js`
- `cd xp.mi.web\server`
- make sure `xp.mi.web\src\environment.ts` to point to `http://localhost:9043` - note its `http`
- `npm start`
- you should have api running at `http://localhost:9043`. 
- visit this in browser, should return json data [GET /user/getUserData](http://localhost:9043/api/user/getuserdata?id=1)
- NOTE : in `/server/index.js` you can change the port number to match your actual backend. Make sure you update that in `environment.ts` as well

## Run fronetned

- `cd xp.mi.web`
- `ng serve`
- you should have app running at `http://localhost:4200`

## Using application

- login using any username and password
- you can make changes and save in code and application should get refreshed in browser

## Run AUT

- `ng test`
- By default `jasmine` framework is used for writing AUT. 
- If you prefer `mocha` you can add the support

## Creating builds

- `npm run build:staging`
- `npm run build:prod`
- To add more environments, add requierd sections in angular.json, package.json, and add environemnt.xyz.ts file with all keys

## Debugging

- in browser developer tool -> sources tab -> do ctl + p - search `GlobalErrorHandlerService`
- put breakpoint in `handleError` method, reload browser

## Integration with backend

- Following api's are required to integrate the kit with actual backend. NOTE - dummy api's have mock implementation
- POST `/api/user/login` - verify user and return OAuth token ( will differ if you are using other authentication)
- POST `/api/user/logout` - do any work on logout
- GET  `/api/user/getUserData` - return user name, any common data, master data that you want available as globally
- POST `/api/logs` - to accept client side user journey ( last 100 logger.info message) + exception. Log this to daily client log file.
- Reset password if you want to use will need 3 more apis as here `shared module -> constants.ts -> webApis`

## Adding libraries

- you can add libraries and import them in `App module`

## Styles

- base scss structure is provided using bootstrap, you can change base set to make use of your preferred styles

## UI Components

- some inbult UI components are provided modal, toastr, spinner. 
- You can use them as is or if required replace their implementation with preferred/required one

## To be removed

- demo module is provided as reference, when you know how to use components demoed in this module, delete it
- if you are not using reset password functionality, make sure you remove `user module` - `forgot and sent email` components.

## Authentication

- you can modify the kit to use any authentication, currently its set for OAuth
- `auth.service.ts` should be kept as central auth service to do work like login, logout, refreshToken etc

## Internationalization

- it pays off to start using the feature from day 1. When need arises in future, all thats left to be done is add a new language file
- in `src/assets/en.json`add key value pairs in your preferred way
- use this key in html files `{{ page.key | translate}}`
- if required in .component.ts files, keys can be red using `TranslateService`

- NOTE : Date, currency formatting are not handled here. You need to handle them explicitly

## Common issues

- for any issue : check browser console for errors, read the messages
- api not found : make sure your environment.ts -> apiUrl is pointing to either dummy api provided or your own api url
- invalid certificate for api url error on dev machine : you need to open your api url in new browser tab, accept risk and proceed. Reload you app.
- not able to login : make sure either dummy api or your own api is running, and is returning response. If you are using inbuilt dummy api, check if returns data 
  [GET /user/getUserData](http://localhost:9043/api/user/getuserdata?id=1)
- circular reference : within the module do not import from module level index.ts file, use relative paths. Module level index.ts file should
be used by other modules consuming this module
